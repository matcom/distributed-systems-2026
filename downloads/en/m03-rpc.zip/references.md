> **Reference view.** This page is optional context; return to the [Lesson](../lesson/) for the required path.

## Essential

- **● gRPC Core Concepts, Architecture and Lifecycle** — gRPC Authors. [documentation](https://grpc.io/docs/what-is-grpc/core-concepts/)
- **● Protocol Buffers Documentation** — Google. [documentation](https://protobuf.dev/)

## Recommended

- **●● gRPC Deadlines Guide** — gRPC Authors. [documentation](https://grpc.io/docs/guides/deadlines/)
- **●● gRPC Retry Guide** — gRPC Authors. [documentation](https://grpc.io/docs/guides/retry/)

## Advanced

- **●●● Implementing Remote Procedure Calls** — Andrew D. Birrell and Bruce Jay Nelson. [paper](https://www.cs.cmu.edu/~dga/15-712/F07/papers/birrell842.pdf)
- **●●● End-to-End Arguments in System Design** — Saltzer, Reed, Clark. [paper](https://web.mit.edu/Saltzer/www/publications/endtoend/endtoend.pdf)

## Tools & Practice

- **● gRPC Documentation** — gRPC Authors. [documentation](https://grpc.io/docs/)

## Explore

- **●●● 6.5840 Distributed Systems** — MIT PDOS. [course](https://pdos.csail.mit.edu/6.824/)
