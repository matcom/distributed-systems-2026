<div class="ds-lesson-banner">
  <div><span>Required laboratory</span><strong>Chapter 4</strong></div>
  <div><span>Evidence model</span><strong>predict → run → observe → explain</strong></div>
  <div><span>Verification</span><strong>6 transparent public tests + evidence</strong></div>
</div>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 4 of 12</span>
    <span>33% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 33%"></span></div>
</div>
<p class="ds-back-link"><a href="../quick-check/">← Return to knowledge check</a></p>

> **Before you start:** Complete the guided-practice and knowledge-check steps. You should already be able to state a prediction and name the evidence that would support or contradict it. If not, [return to the knowledge check](../quick-check/) and revisit the lesson where needed.

## Target

Build a small **Ray-free** RPC service, reproduce an ambiguous timeout, demonstrate how a naive retry can duplicate a non-idempotent effect, and then redesign the protocol using a stable request identifier plus duplicate suppression.

The lab is successful only when the evidence shows both the failure and the repair.

## Learning outcomes

By the end of the laboratory you should be able to:

- define a versioned request/response contract;
- implement one remote operation without Ray;
- configure and observe a client deadline;
- distinguish client observation from server execution;
- reproduce duplicate execution caused by retry;
- use one logical request ID across several transport attempts;
- implement and explain a basic duplicate-suppression mechanism;
- state precisely what your implementation does and does not guarantee.

## Implementation boundary

Ray is prohibited in this laboratory.

Recommended native stack:

- Go;
- gRPC;
- Protocol Buffers;
- local files or another simple local durable mechanism where persistence is required.

A small HTTP/JSON implementation may be used for an instructor-approved alternative, but it must preserve the same semantic experiments.

The objective is not framework syntax. The objective is the remote-operation failure model.

## Service problem

Implement a tiny counter service with two operations:

```text
GetCounter(name) -> value
Increment(request_id, name, delta) -> value
```

`Increment` is intentionally non-idempotent when executed repeatedly.

The service must expose structured evidence containing at least:

```text
node_id
request_id
attempt_id or attempt_number when known by the client
operation
counter_name
old_value
new_value
event
local_timestamp
```

The client must generate one stable `request_id` for a logical increment and may use different attempt numbers for retries.

## Suggested Protocol Buffers contract

The exact schema is part of your design, but it should be equivalent in meaning to:

```proto
service CounterService {
  rpc GetCounter(GetCounterRequest) returns (GetCounterReply);
  rpc Increment(IncrementRequest) returns (IncrementReply);
}

message IncrementRequest {
  string request_id = 1;
  string name = 2;
  int64 delta = 3;
}
```

The implementation should avoid unnecessary fields. Every field should have a reason.

## Required command surface

The exact binaries may differ, but the submission should provide equivalent commands for:

```text
start server
get counter
increment counter with explicit request ID
increment with a client deadline
configure deterministic server delay/failure point
restart server
inspect durable state/logs
```

The final repository should expose reproducible commands through its `Makefile` or documented equivalent.

## Experiment 0 — normal execution

Start with no artificial delay.

Prediction:

> One `Increment(R1, x, 1)` should change counter `x` exactly once and return the resulting value.

Collect:

- client send event;
- server receive event;
- server apply event;
- server response event;
- final counter value.

Draw the normal sequence.

Do not proceed until request IDs can be correlated between client and server evidence.

## Experiment 1 — deadline before execution

Configure the server to delay **before** applying the effect.

Example conceptual timeline:

```text
client sends R2
server receives R2
server waits 500 ms
client deadline expires at 200 ms
server has not yet applied
```

Record:

- client result;
- whether server eventually applies;
- final counter value.

Depending on implementation/cancellation handling, the server may stop or may continue. The report must describe the observed behavior rather than assuming one result.

## Experiment 2 — effect before delayed response

Now create the important ambiguity.

Configure the service so that:

```text
receive request
apply increment
record state
wait before reply
reply
```

Choose a client deadline shorter than the response delay but long enough for the effect to be applied.

Expected shape:

```text
client                   server
  |                         |
  |------ R3 -------------> |
  |                         | apply +1
  |                         | record state
  |                         | wait
  | deadline                |
  |<------- X --------------|
```

After the client reports failure, inspect the server state.

The required evidence must establish:

> The client did not receive a timely success response, but the application effect occurred.

This is the core experiment of Chapter 4.

## Experiment 3 — naive retry with a new logical request ID

Starting from a known counter value:

1. execute the delayed-response scenario;
2. let the client time out after the server has applied the effect;
3. retry the same intended user action using a **new** request ID;
4. inspect the final value.

For example:

```text
initial x = 10
R4 applies +1, response is not observed
R5 retries intended +1
final x = 12
```

The user intended one increment. The service produced two effects.

Explain why TCP reliability, gRPC, and the deadline mechanism do not prevent this application-level duplicate.

## Experiment 4 — stable request ID without deduplication

Repeat the experiment using the same request ID for both attempts.

If the server simply executes every received request, the duplicate effect still occurs.

This establishes an important distinction:

> A request ID is useful metadata, but it does not enforce idempotency by itself.

## Experiment 5 — duplicate suppression

Add server-side state that remembers completed logical request IDs and their results.

Conceptually:

```text
if request_id already completed:
    return recorded result
else:
    apply effect
    remember request_id -> result
    return result
```

Repeat the ambiguous timeout and retry using one stable request ID.

Required result:

- more than one transport attempt may occur;
- the logical increment changes the counter once;
- the second attempt returns or reconstructs the prior logical result.

Collect logs showing:

```text
req=R6 event=apply
req=R6 event=duplicate-detected
```

## Experiment 6 — restart and deduplication durability

Restart the server between the first uncertain attempt and the retry.

If duplicate-suppression state exists only in memory, a restart can erase the knowledge that R6 already completed.

Choose and implement one of these explicit contracts:

### Contract A — deduplication only within one server lifetime

Document the limitation clearly. Demonstrate the duplicate after restart.

### Contract B — durable duplicate suppression

Persist enough request/result state so the retry after restart remains suppressed.

For full-credit implementation work, Contract B is preferred because it makes the relationship between acknowledgement, state durability, and retries explicit.

You are **not** required yet to solve replication of this state across several servers. Chapter 9–Chapter 10 address that problem.

## Experiment 7 — concurrent increments

Run several clients concurrently against one counter.

For example:

```text
20 logical requests × delta 1
```

Each request must have a distinct logical request ID. Some attempts may be repeated intentionally.

Compare:

- expected logical total;
- number of transport attempts;
- number of unique request IDs;
- final counter value.

This experiment connects RPC semantics to local concurrency from Operating Systems and prepares Chapter 3.

## Experiment 8 — retry policy

Implement a bounded client retry policy.

The policy must specify:

- maximum attempts;
- overall deadline or time budget;
- backoff behavior;
- which error/status conditions are retryable;
- preservation of the logical request ID.

Do not simply retry every error.

The report should include at least one permanent error that is **not** retried.

## Required analysis — semantic boundary

Complete this table for your implementation:

| Claim | Supported? | Evidence / limitation |
|---|---|---|
| request bytes are framed by gRPC/HTTP | | |
| client waiting is bounded | | |
| transient failures may be retried | | |
| one logical request ID is preserved across retries | | |
| duplicate handler executions are possible | | |
| duplicate counter effects are suppressed | | |
| suppression survives server restart | | |
| suppression survives loss of the only server | | |
| exactly-once external side effects are guaranteed | | |

Do not mark the last two true unless your architecture actually supports them.

## Public-test target

Executable public tests now live under `tests/official/`, with a small semantic adapter in `starter/src/`. They verify deterministic request-identity and duplicate-suppression invariants; deadline, transport, restart, and multi-process behavior still require the evidence described above.

The public cases to be implemented are documented in `tests/official/README.md`. No hidden cases are planned.

You should add their own tests under `tests/student/`, particularly for:

- duplicate request IDs;
- malformed IDs;
- zero/negative deltas if permitted by the API;
- retry after timeout;
- restart behavior;
- concurrent requests.

## Evidence requirements

Your report must include machine-readable evidence where possible.

At minimum provide:

1. one normal execution trace;
2. one trace where the client times out **after** the server effect occurs;
3. one naive retry showing duplicate effect;
4. one repaired retry showing duplicate suppression;
5. final state before/after restart experiment;
6. explanation of your retry policy.

Screenshots may illustrate the experiment but are not substitutes for logs or state evidence.

## AI use

AI assistants and coding agents are permitted.

A useful AI-assisted workflow is:

1. ask the agent to predict possible timeout histories;
2. independently design an experiment that distinguishes those histories;
3. ask the agent to review the retry/idempotency code;
4. classify its findings as valid, invalid, or incomplete;
5. verify the final behavior with your own experiment.

Include the standard AI-use disclosure in assessed work.

## Report

Use `REPORT.md` as the structure for submission.

The most important sentence in the report should answer:

> **After a timeout, what evidence lets this client determine whether the logical operation has already taken effect?**

## Finish the chapter

Reproduce the important result from a clean start. Then return to your opening prediction: state what changed in your explanation, what evidence caused the change, and what uncertainty remains. A successful command or screenshot is not enough when the claim concerns retries, ordering, durability, consistency, recovery, security, or performance.

<div class="ds-next-action">
  <span>Chapter complete</span>
  <strong>Continue the course</strong>
  <a href="../../m12-dht-gossip/">Communication II — Messaging, Dissemination, and Overlays →</a>
</div>

<nav class="ds-sequence" aria-label="Course sequence">
<a class="ds-sequence-link" href="../../m05-processes-concurrency/">← Processes, Virtualization, and Distributed Execution</a>
<a class="ds-sequence-link next" href="../../m12-dht-gossip/">Communication II — Messaging, Dissemination, and Overlays →</a>
</nav>
