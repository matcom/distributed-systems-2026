<p class="ds-book-part">Part II — Communication and Coordination</p>
<p class="ds-module-kicker">Chapter 4</p>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 4 of 12</span>
    <span>33% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 33%"></span></div>
</div>
<p class="ds-guiding-question">When a remote operation does not return, what exactly do you know happened?</p>

Make communication explicit. Serialize a request, cross a process or network boundary, impose a deadline, lose a response, and decide whether retrying is safe. Treat a missing response as uncertainty, not as proof that the server did nothing.

## Key ideas

- messages and request/response
- serialization and framing
- HTTP/gRPC and Protocol Buffers
- deadlines and timeouts
- stable request identity
- retries and backoff
- idempotency
- at-most-once and at-least-once effects
- duplicate suppression

## Laboratory transition

Build a small networked service, simulate a response that never reaches the caller, observe a repeated effect, and then repair the protocol with explicit request identity.

## Start here

> **Before you read:** The server commits an operation and its reply is lost. Should the client retry? Write your answer before choosing an idempotency mechanism.

**Bring forward:** Process boundaries from Chapter 3 and basic transport/socket behavior from Computer Networks.

**This chapter builds toward:** An explicit request protocol whose timeout, retry, and duplicate semantics you can defend.

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>30 min–45 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>45 min–1 h</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>2 h–2 h 30 min · 6 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Read lesson →</a>
  <a class="ds-secondary-action" href="lab/">Open laboratory</a>
</div>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../downloads/en/m03-rpc.zip" download>Download chapter + laboratory for offline study (.zip)</a></p>

## What you will learn

- Design a versioned request/response protocol.
- Implement an RPC service without Ray.
- Explain why timeout is not equivalent to remote failure.
- Use request identifiers to reason about duplicate execution.
- Select retry and idempotency strategies appropriate to an operation.

## Learn by working the question

1. Write your answer to **Start here** before opening the full lesson.
2. Read until the next prediction or trace, then stop and work it out before revealing the explanation.
3. Treat guided practice as a **practice bank**, not a speed worksheet. Work the core traces until you can meet the chapter's Practice target; return to the remaining cases for retrieval practice or instructor-assigned work.
4. Use the knowledge check to find gaps, then enter the laboratory with a falsifiable prediction and name the evidence that could contradict it.
5. Finish by explaining what the experiment established, what it did not establish, and how the result changes the evolving service.

<nav class="ds-sequence" aria-label="Course sequence">
<a class="ds-sequence-link" href="../m05-processes-concurrency/">← Processes, Virtualization, and Distributed Execution</a>
<a class="ds-sequence-link next" href="../m12-dht-gossip/">Communication II — Messaging, Dissemination, and Overlays →</a>
</nav>
