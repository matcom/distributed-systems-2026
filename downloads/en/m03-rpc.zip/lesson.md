<p class="ds-book-part">Part II — Communication and Coordination</p>
<div class="ds-lesson-banner">
  <div><span>Course step</span><strong>Chapter 4</strong></div>
  <div><span>Core reading</span><strong>30 min–45 min</strong></div>
  <div><span>Required path</span><strong>Read → Practice target → Check → Lab</strong></div>
</div>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 4 of 12</span>
    <span>33% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 33%"></span></div>
</div>

> **Guiding question:** When a remote operation does not return, what exactly do you know happened?

## Before you read

> The server commits an operation and its reply is lost. Should the client retry? Write your answer before choosing an idempotency mechanism.

Write a short answer first. You are not expected to be correct yet; you need a prediction you can revise as the chapter gives you better models and evidence.

**Use what you already know:** Process boundaries from Chapter 3 and basic transport/socket behavior from Computer Networks.

## Workload map

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>30 min–45 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>45 min–1 h</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>2 h–2 h 30 min · 6 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../../downloads/en/m03-rpc.zip" download>Download lesson + practice + lab for offline study (.zip)</a></p>

## Why this chapter matters

In Chapter 2, Ray made remote execution look intentionally ordinary. A function could become a task, an actor could hold state, and a future-like reference could stand in for a result. That productivity is useful, but it hides the question this chapter must make unavoidable:

> **When a remote call fails, what exactly do we know happened?**

With a local function call, the caller and callee normally share one failure boundary. If the process continues and the function returns, the caller has strong evidence that the function completed. If the process crashes, both sides of the call disappear together.

A remote call is different. The caller, network, server process, storage subsystem, and response path may all fail independently. A timeout therefore does not answer a simple yes/no question about execution. It creates uncertainty.

Consider a client asking a service to increment an account balance:

```text
client                 server
  |                      |
  |---- increment(10) -->|
  |                      | apply +10
  |                      | persist
  |<------ X response ---|
  |                      |
  | timeout              |
```

What should the client do?

Retrying may be correct if the first request never arrived. It may be wrong if the first request completed and only the response was lost. This one diagram contains much of distributed-systems engineering: framing, serialization, deadlines, retries, duplicate suppression, durable state, observability, and application semantics.

> **Pause and predict.** A client receives `DEADLINE_EXCEEDED`. List at least four different executions that could have produced that observation.

This chapter moves from raw request/response communication to RPC, but its real subject is not gRPC syntax. It is the semantic gap between **a call attempt** and **an application effect**.

## 1. Communication begins with a protocol, not a library call

Two processes cannot share a normal call stack across a network. They exchange bytes according to a protocol.

A minimal request/response protocol must answer questions such as:

- how a message begins and ends;
- which operation is requested;
- how parameters are represented;
- how success and failure are represented;
- how versions evolve;
- how one request is distinguished from another;
- whether several requests may share a connection;
- whether responses can arrive out of order.

Even a tiny design therefore has structure:

```text
Request
+----------------------+-------------------------+
| header               | payload                 |
+----------------------+-------------------------+
| version              | operation-specific data |
| request_id           |                         |
| operation            |                         |
| payload_length       |                         |
+----------------------+-------------------------+
```

The exact representation can be JSON, Protocol Buffers, CBOR, a custom binary encoding, or something else. The systems question comes first: **what information must cross the failure boundary?**

### Framing is necessary on byte streams

TCP provides an ordered byte stream. It does not preserve application message boundaries.

If a sender performs:

```text
send("ABC")
send("DEF")
```

a receiver is not promised two reads returning exactly `ABC` and `DEF`. It may observe six bytes together or partial pieces depending on buffering and scheduling.

An application protocol therefore needs framing. Common choices include:

- a fixed-size message;
- a delimiter;
- a length prefix;
- self-describing structured encodings;
- a higher-level protocol such as HTTP/2 that already provides framing.

A robust parser must treat the network as a stream of bytes, not as a magical queue of application objects.

> **Worked example.** A protocol uses a 4-byte unsigned length prefix followed by a payload. The receiver first reads enough bytes to reconstruct the length `N`, then continues until exactly `N` payload bytes have been received. A single `read()` returning fewer than `N` bytes is not automatically an error; it can be normal stream behavior.

<aside class="ds-book-note ds-history">
  <span class="ds-book-note-label">History</span>
  <strong>RPC made distributed programs easier to write by hiding the network—and made failure semantics easier to forget</strong>
  <p>Remote procedure call turned messages into familiar-looking function calls, but timeouts, duplicate execution, retries, and partial failure ensured that a remote call could never truly behave like a local one.</p>
  <a class="ds-book-note-source" href="../../../history/rpc-transparency-and-failure/">Read the design history →</a>
</aside>

## 2. Serialization defines the wire representation

Objects in memory contain language- and process-specific details: pointers, padding, runtime metadata, object identities, and architecture-dependent representations. Sending those raw bytes directly is usually meaningless or unsafe.

Serialization creates a shared representation.

Suppose one process holds:

```text
Job {
    id: 41
    operation: "resize"
    width: 640
}
```

The receiver needs a representation whose fields and types both sides understand.

Serialization therefore raises compatibility questions:

- Can an old client talk to a new server?
- What happens to unknown fields?
- Can fields be added without breaking older peers?
- Are integers signed or unsigned?
- Is ordering significant?
- How large may a message be?
- Can hostile input allocate unbounded memory?

These are not cosmetic concerns. A distributed system often upgrades nodes gradually, so more than one software version may run simultaneously.

### Version the contract, not only the deployment

A protocol should make evolution deliberate.

A weak design says:

> “All nodes will always run exactly the same code.”

That assumption is often violated during rolling upgrades, partial deployments, failed restarts, cached clients, or long-running processes.

A stronger design states which changes are compatible and how unsupported behavior is reported.

## 3. RPC turns message exchange into an interface abstraction

Remote Procedure Call attempts to let a programmer invoke functionality on another process through a procedure-like interface.

Historically, RPC was a major step in distributed programming because it separated application code from many details of request marshalling, transport, dispatch, and response unmarshalling.

Conceptually:

```text
client application
       |
       v
   client stub
       |
   serialize request
       |
       v
     network
       |
       v
   server runtime
       |
     dispatch
       |
       v
server implementation
```

The abstraction is valuable because application programmers can reason in terms of operations such as:

```text
Get(key)
Put(key, value)
Submit(job)
GetStatus(job_id)
```

instead of manually defining every socket read and write.

But the abstraction is dangerous when it suggests that a remote call has the same semantics as a local call.

### Local and remote calls differ fundamentally

A local function invocation is generally:

- fast relative to network operations;
- inside one process failure boundary;
- based on in-memory arguments;
- directly controlled by one runtime;
- not subject to packet loss or partitions.

A remote invocation can be:

- delayed unpredictably;
- duplicated by retry logic;
- cancelled only locally while remote effects continue;
- rejected because of version mismatch;
- processed by a node that crashes immediately afterward;
- completed even though the caller reports failure.

This is why the course treats RPC as an abstraction worth using but never as “a local call somewhere else.”

## 4. HTTP and gRPC provide different kinds of application contracts

HTTP is a broadly deployed application protocol with methods, status codes, headers, request/response bodies, caching semantics, intermediaries, and a large tooling ecosystem.

It is often sufficient for distributed-service APIs. A JSON-over-HTTP service is easy to inspect with `curl`, proxies, logs, and browser tools.

gRPC provides a more explicitly RPC-oriented model. Services and methods are declared through an interface definition, commonly using Protocol Buffers. Generated client and server code then represents those methods in language-specific APIs.

A service definition might look conceptually like:

```proto
service Counter {
  rpc Add(AddRequest) returns (AddReply);
  rpc Get(GetRequest) returns (GetReply);
}
```

This makes the contract machine-readable and supports generated stubs, strongly typed messages, streaming RPC modes, metadata, deadlines, and status handling.

The point of using gRPC in this course is not that gRPC is universally superior. It gives us a convenient, realistic RPC environment in which **the network boundary remains visible enough to study**.

### Streaming changes the interaction shape

RPC is not limited to one request and one response. Modern RPC frameworks can support:

- unary request → unary response;
- one request → stream of responses;
- stream of requests → one response;
- bidirectional streams.

Streaming does not remove failure semantics. It introduces more questions:

- how much of the stream was processed before failure?
- can processing resume?
- where is progress recorded?
- what happens if a client reconnects?

The same principle returns: transport progress and application progress are not the same state.

## 5. Protocol Buffers separate interface structure from in-memory representation

Protocol Buffers are useful in the course because they force you to write down the wire contract.

For example:

```proto
message PutRequest {
  string request_id = 1;
  string key = 2;
  bytes value = 3;
}

message PutReply {
  bool applied = 1;
  string detail = 2;
}
```

Notice that `request_id` belongs in the application protocol. It is not merely tracing decoration. Later we can use it to distinguish a logical operation from repeated transport attempts.

### Field identity matters across versions

In a tagged binary format, numeric field identifiers become part of the durable protocol contract. Reusing a removed field number for a different meaning can create dangerous ambiguity when old and new software coexist.

The larger lesson is broader than Protocol Buffers:

> **Wire formats live longer than individual source-code versions.**

A student should be able to point to the interface definition and explain how a request is interpreted independently from the client implementation that produced it.

## 6. Deadlines bound waiting, not uncertainty

Without a deadline, a client may wait indefinitely for a response from a service that is slow, partitioned, overloaded, dead, or simply unreachable.

A deadline says roughly:

> “After this point, the caller is no longer willing to wait for this RPC attempt.”

This is primarily a resource and liveness decision.

It does **not** say:

> “After this point, I know the server did not execute the operation.”

Modern gRPC explicitly models deadlines/timeouts, and the server can often observe how much deadline remains. But each side still reaches conclusions based on local evidence.

### Four timeout histories

Suppose a client sends `Put(k, v)` and times out.

#### History A — request never reaches the server

```text
client ----X----> server
```

Retrying is necessary for progress.

#### History B — server begins but fails before effect

```text
client ----> server
             begin
             crash
```

Retry may be necessary.

#### History C — effect completes, response is lost

```text
client ----> server
             persist effect
client <----X response
```

Blind retry can duplicate a non-idempotent effect.

#### History D — operation is still running when client gives up

```text
client ----> server
             long computation ...
client timeout
             ... completes later
```

Client cancellation or timeout does not automatically undo application effects already performed.

A timeout therefore converts a call from “unknown result” into an **uncertain distributed operation** unless application semantics provide a way to resolve the uncertainty.

## 7. Cancellation is not rollback

A caller may cancel an RPC because:

- the user closed the request;
- a parent deadline expired;
- another replica returned first;
- the operation is no longer useful.

Cancellation can help the server stop unnecessary work. However, work already completed may remain completed.

Imagine:

```text
1. server writes row
2. server publishes event
3. client deadline expires
4. cancellation arrives
```

The system cannot simply pretend the write and publication never occurred.

This is why cancellation, transactions, compensation, and idempotency are distinct concepts.

## 8. Retries trade transient failure for duplicate risk and load

Retries are one of the most useful and most dangerous distributed-systems mechanisms.

They help when failure is temporary:

- a connection resets;
- a server process restarts;
- a load balancer selects an unhealthy backend;
- a packet is lost;
- a short overload period clears.

But every retry is additional work. Under widespread failure, many clients retrying simultaneously can increase load exactly when the system has the least spare capacity.

This produces a retry storm:

```text
service slows
    ↓
timeouts increase
    ↓
clients retry
    ↓
load increases
    ↓
service slows further
```

### Retry policy needs semantics

A useful retry policy asks:

1. **Which operations are safe to retry?**
2. **Which failures are plausibly transient?**
3. **How many attempts are allowed?**
4. **How long should the client wait between attempts?**
5. **Is there an overall deadline/budget?**
6. **How will retries be observed in metrics/traces?**

Exponential backoff and jitter help prevent synchronized clients from hammering a recovering service, but they do not solve duplicate effects.

### Transport-level retry and application-level retry are different

A framework may transparently retry when it knows an attempt was not processed by application code. That is much safer than retrying after the server may have executed a side effect.

You should distinguish:

```text
retry an attempt known not to execute
```

from:

```text
retry an operation whose outcome is uncertain
```

The latter requires application-level design.

## 9. Idempotency makes repeated execution converge to one effect

An operation is idempotent when applying it multiple times has the same intended effect as applying it once.

Examples often include:

```text
SetStatus(job, "cancelled")
Delete(object X)   [under some API definitions]
SetConfiguration(version, value)
```

Non-idempotent examples include:

```text
Increment(counter, 1)
Transfer($10 from A to B)
Append(new unique item without duplicate control)
SendEmail(message)
```

But idempotency depends on the **semantic operation**, not merely the HTTP method name or function signature.

### Idempotency keys convert attempts into one logical operation

Suppose the client assigns a stable operation ID:

```text
request_id = 8f31...
operation = Transfer(A, B, 10)
```

All retries use the same ID.

The server stores enough durable state to detect that ID:

```text
request 8f31 first time
    ↓
execute transfer
    ↓
record result for 8f31

request 8f31 again
    ↓
return recorded result
    ↓
do not execute transfer again
```

This sounds simple but raises an important atomicity requirement:

> Recording “request completed” separately from applying the side effect can itself fail in between.

Later modules on transactions and replicated state machines revisit this problem.

## 10. At-most-once and at-least-once describe effects only under assumptions

Informal systems discussions often use phrases such as:

- at-most-once;
- at-least-once;
- exactly-once.

These phrases are useful only when we define **what is being counted** and **where the guarantee ends**.

### At-most-once effect

An operation affects the application state zero or one times.

A simple implementation can avoid retries entirely. That may preserve at-most-once attempts but sacrifice liveness: transient message loss can cause a valid operation never to happen.

Deduplication with stable IDs can support stronger at-most-once effects while still permitting retries, provided the deduplication state is itself correct and durable.

### At-least-once effect

The client keeps retrying until it has sufficient evidence that the operation completed.

This supports progress under transient failure but may cause duplicate effects unless the operation is idempotent or deduplicated.

### “Exactly once” needs a boundary

There is no magic network mode that prevents every possible duplicate side effect across arbitrary external systems.

A service can provide exactly-once-like semantics inside a carefully defined transactional boundary using durable request IDs, atomic state changes, and deduplication. But if the operation also sends email, charges an external payment service, and updates another independent database, the guarantee depends on those systems too.

The correct question is:

> **Exactly once with respect to which state transition?**

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosity</span>
  <strong>A retry can make a reliable client less correct</strong>
  <p>If the first remote operation succeeded but its reply was lost, an automatic retry can duplicate a payment, append, email, or state transition. Reliability at the transport/request level and correctness at the application-effect level are different properties.</p>
  <p><strong>Try it:</strong> Take one non-idempotent API operation and redesign it around a stable request ID plus durable duplicate suppression.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">More chapter curiosities →</a>
</aside>

## 11. Request identifiers serve correctness and observability

Every significant request in this course should carry a stable logical identifier.

This supports two different tasks.

### Correctness

The server can recognize retries of one logical operation.

### Observability

Logs from several processes can be correlated:

```text
client  req=R7 attempt=1 send
proxy   req=R7 route=node2
node2   req=R7 apply
node2   req=R7 reply
client  req=R7 timeout
client  req=R7 attempt=2 send
node3   req=R7 duplicate lookup
node3   req=R7 return prior-result
```

Without the request ID, the second attempt may look like an unrelated operation.

A request ID is not a substitute for logical clocks, tracing, or transaction IDs. It answers a narrower but fundamental question: **which events belong to one intended operation?**

## 12. Errors should preserve useful distinctions

A distributed API should not collapse every problem into:

```text
ERROR
```

The client may need to distinguish:

- invalid input;
- authentication/authorization failure;
- resource not found;
- conflict/version mismatch;
- overloaded/unavailable service;
- deadline exceeded;
- operation rejected permanently;
- internal server failure.

However, error classification must not claim more certainty than the server has.

A transport failure such as connection loss may mean the client has no application-level response at all. The absence of a response is not equivalent to an application rejection.

## 13. Connection reuse changes performance, not application truth

Creating a fresh connection for every call can add handshake and resource overhead. Long-lived channels amortize setup cost and may maintain connections to several backends.

This is why modern RPC libraries represent a **channel** or client connection object rather than treating each call as an isolated socket creation.

But connection reuse introduces state:

- connection health;
- resolver results;
- backend selections;
- flow-control state;
- retry state.

The network library can optimize these mechanics without changing the application rule that remote effects may be uncertain after a failure.

## 14. Backpressure begins at the communication layer

Suppose a client can create 100,000 requests per second while the server completes 10,000.

If the system accepts all incoming work without bound, queues grow:

```text
arrival rate > service rate
        ↓
queue grows
        ↓
latency grows
        ↓
deadlines expire
        ↓
retries may add more work
```

Good communication design therefore includes bounded concurrency, admission control, flow control, or backpressure.

Chapter 12 studies these mechanisms deeply. Chapter 4 establishes the connection: retries and timeouts are not merely correctness features; they participate directly in load behavior.

## 15. Worked example — a safe `SubmitJob` API

Suppose we need an operation:

```text
SubmitJob(image-processing parameters)
```

A naive API returns only after the whole job completes. That creates a long RPC with uncertain state if the connection disappears after several minutes.

A more resilient contract separates submission from execution:

```text
SubmitJob(request_id, parameters) -> job_id
GetJob(job_id) -> state/result
```

The first call creates durable job metadata. If the response is lost, the client retries using the same `request_id`.

The service can answer with the same `job_id` rather than creating a second job.

Now job execution can continue independently from one client connection.

This design does not solve every problem, but it reduces the uncertainty boundary.

### State transition

```text
request_id R9 unseen
    ↓
create job J42
    ↓
record R9 -> J42
    ↓
reply J42
```

A correct implementation must define whether creation of `J42` and recording the deduplication mapping are atomic.

That question foreshadows Chapter 10 and Chapter 11.

## 16. Worked example — retrying a read

Reads are often easier to retry, but even they can have subtle semantics.

Suppose:

```text
GetBalance(A)
```

times out and is retried to another replica.

If replicas are not strongly consistent, the second attempt may return an older value than a previous successful read.

So “safe to retry” can mean:

- no duplicate side effect;

while still not guaranteeing:

- the same returned value;
- monotonic reads;
- linearizability.

Communication semantics and consistency semantics interact.

Chapter 9 develops that connection.

## 17. Worked example — the response arrived after the deadline

Imagine:

```text
0 ms   client sends request
40 ms  server receives
80 ms  server commits state
95 ms  server sends response
100 ms client deadline expires
120 ms response reaches client
```

The server can correctly report success locally.

The client can correctly report that its deadline was exceeded locally.

There is no contradiction. They are answering different questions from different observation points.

The client still needs an application mechanism to learn whether the operation took effect.

This is one reason production APIs often expose operation IDs, status lookups, or idempotency keys.

## 18. Historical path — from RPC transparency to explicit failure semantics

Early RPC work pursued a powerful goal: let programmers use procedure-call structure across machines without hand-writing all transport machinery.

That abstraction influenced distributed object systems, middleware platforms, enterprise RPC, Web services, and modern systems such as gRPC.

The history is useful because it teaches a recurring pattern:

```text
new abstraction hides mechanism
        ↓
programming becomes easier
        ↓
failures reveal semantic mismatch
        ↓
new APIs expose selected distributed concerns again
```

Modern RPC systems therefore include concepts such as deadlines, status codes, cancellation, metadata, streaming, service configuration, name resolution, retries, and observability hooks.

They are not evidence that RPC failed as an idea. They are evidence that useful abstractions must eventually expose the distributed properties applications need to control.

## 19. Common mistakes

### Mistake 1 — “Timeout means the server did nothing”

Wrong. Timeout means the caller stopped waiting without obtaining a timely successful response.

### Mistake 2 — retry every error

Some errors are permanent. Some operations are unsafe to duplicate. Unlimited retries can overload a failing service.

### Mistake 3 — use a new request ID for every retry

That prevents the server from recognizing repeated attempts of the same logical operation.

### Mistake 4 — declare an operation idempotent because it uses `PUT`

Protocol method names do not prove application semantics.

### Mistake 5 — rely on one `read()` per message

TCP is a byte stream. Application framing must handle partial reads and coalescing.

### Mistake 6 — confuse cancellation with rollback

A cancelled request may already have produced durable effects.

### Mistake 7 — treat generated RPC code as proof of compatibility

The IDL helps define the contract, but schema evolution and application meaning still require design.

### Mistake 8 — hide every communication error behind one generic exception

Useful client policy depends on distinguishing invalid requests, unavailability, deadlines, conflicts, and uncertain transport failures.

## 20. The Ray-removal connection

Return to Chapter 2.

A Ray call such as:

```text
worker.process.remote(job)
```

hid many decisions.

In the native system we now have to state them:

```text
Who is the worker?
How is it addressed?
What bytes represent the request?
What is the request ID?
What is the deadline?
What errors are retryable?
Can execution happen twice?
Where is deduplication state stored?
How is the response correlated?
What evidence proves the effect?
```

This is exactly the pedagogical purpose of removing Ray.

The native implementation is not “more real” merely because it contains more code. It is educationally useful because the semantic decisions are now visible and attributable to you.

## Laboratory transition

The Chapter 4 laboratory builds a small Ray-free RPC service. You define the interface, send concurrent requests, impose deadlines, introduce response loss or delay, and then repair duplicate side effects using stable request IDs and server-side deduplication.

The important deliverable is not only working code. The report must contain an execution in which the client cannot initially know whether the remote effect occurred, followed by evidence showing how the redesigned protocol resolves that uncertainty.

## Chapter summary

Communication in a distributed system is not merely moving bytes.

1. **A protocol defines message structure and semantics across independent processes.**
2. **TCP preserves bytes and order, not application message boundaries.**
3. **Serialization creates a durable wire contract that must evolve carefully.**
4. **RPC is useful precisely because it hides repetitive communication machinery.**
5. **Remote calls are not semantically equivalent to local calls.**
6. **A deadline bounds waiting but cannot prove that the remote effect did not happen.**
7. **Cancellation does not automatically undo completed effects.**
8. **Retries improve progress but can duplicate effects and amplify overload.**
9. **Stable request IDs and idempotency mechanisms turn repeated attempts into one logical operation.**
10. **Delivery guarantees are meaningful only when their application boundary is stated precisely.**
11. **Observability must correlate attempts with logical operations.**
12. **Removing Ray forces these previously hidden decisions into your architecture.**

The next chapter asks a different communication question. Even with a precise RPC contract, not every interaction should require a known receiver and a synchronous reply: queued work, publish/subscribe, gossip, and overlay dissemination change the coupling and delivery semantics.

<div class="ds-next-action">
  <span>Core reading complete</span>
  <strong>Next required step · Guided practice</strong>
  <a href="../guided-practice/">Start guided practice →</a>
</div>
