<p class="ds-book-part">Part I — Foundations and Architecture</p>
<div class="ds-lesson-banner">
  <div><span>Course step</span><strong>Chapter 1</strong></div>
  <div><span>Core reading</span><strong>30 min–40 min</strong></div>
  <div><span>Required path</span><strong>Read → Practice target → Check → Lab</strong></div>
</div>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 1 of 12</span>
    <span>8% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 8%"></span></div>
</div>

> **Guiding question:** What changes when one operation crosses an independent failure boundary?

## Before you read

> A client times out after sending an update. List three executions in which the server did nothing, and three in which the server changed state.

Write a short answer first. You are not expected to be correct yet; you need a prediction you can revise as the chapter gives you better models and evidence.

**Use what you already know:** Processes, sockets, latency, and ordinary local function calls from Operating Systems and Computer Networks.

## Workload map

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>30 min–40 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>35 min–50 min</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>1 h 15 min–1 h 45 min · 6 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../../downloads/en/m01-distributed-systems.zip" download>Download lesson + practice + lab for offline study (.zip)</a></p>

## Why this chapter matters

A program that works perfectly inside one process can become incorrect when its state and computation are split across several machines.

The syntax may barely change. A local call such as:

```text
result = service.update(x)
```

may become:

```text
result = remote_service.update(x)
```

But the semantic difference is enormous.

A local call either returns, raises, loops, or the process itself fails. A remote operation adds a network, another scheduler, another process, another clock, another failure domain, and uncertainty about what happened after a message left the caller.

This chapter establishes the mental model used throughout the rest of the course.

The short answer is not “it becomes slower.” The important changes are **independent state, uncertain communication, concurrency, partial failure, and incomplete knowledge**.

## 1. Start with the simplest possible distributed system

Consider two processes:

```text
Client                          Server
  │                               │
  │ -------- request -----------> │
  │                               │ compute
  │ <------- response ----------- │
  │                               │
```

Even this tiny system already contains several independent pieces of state:

### Client state

- the operation it wants;
- request identifier;
- timeout;
- retry policy;
- whether it believes the operation completed.

### Server state

- whether the request arrived;
- whether execution started;
- whether execution completed;
- whether durable state changed;
- whether a response was sent.

### Communication state

- whether request bytes were delivered;
- how long delivery took;
- whether a connection exists;
- whether response bytes were delivered.

No participant can inspect all of this state atomically.

That absence of one perfect global observation is one of the defining difficulties of distributed systems.

<aside class="ds-book-note ds-history">
  <span class="ds-book-note-label">History</span>
  <strong>RPC made distributed programs easier to write by hiding the network—and made failure semantics easier to forget</strong>
  <p>Remote procedure call turned messages into familiar-looking function calls, but timeouts, duplicate execution, retries, and partial failure ensured that a remote call could never truly behave like a local one.</p>
  <a class="ds-book-note-source" href="../../../history/rpc-transparency-and-failure/">Read the design history →</a>
</aside>

## 2. Distribution is not the same as parallelism

These concepts are related but distinct.

### Parallel system

Several computations execute at the same time to finish work faster.

```text
one program
   ├── CPU core 1
   ├── CPU core 2
   └── CPU core 3
```

The workers may share memory and a common operating-system failure domain.

### Distributed system

Several independently executing components cooperate through communication.

```text
process A       process B       process C
   │               │               │
   └──── network / messages ────────┘
```

A distributed system may use parallelism, but it does not have to. Two services exchanging requests sequentially are still distributed.

A parallel program can also exist entirely within one machine and one process address space.

> **Pause and predict.** If eight goroutines update a shared map under one mutex, is that automatically a distributed system? No. They are concurrent components inside one address space. If the process exits, they all disappear together, and the mutex can directly protect their shared memory.

## 3. Independent memory changes the coordination problem

Inside one process, two functions may coordinate through shared variables:

```text
counter = counter + 1
```

Across machines there is no ordinary shared variable that both CPUs can read and write atomically.

Instead:

```text
Node A                   Node B
 state_A                  state_B
   │                         │
   └────── messages ─────────┘
```

If A wants B to know something, information must cross a communication boundary or both nodes must depend on some third service.

This creates an important rule:

> **Distributed coordination is communication plus state transitions under failure.**

A local mutex can prevent two goroutines from entering a critical section in one process. It cannot directly stop another machine from making a conflicting decision.

Later chapters solve different versions of this problem using:

- leaders;
- leases;
- quorums;
- consensus;
- transactions;
- CRDT merge rules;
- application-specific coordination.

## 4. There is no single perfectly shared clock

Every node can read a local clock, but two local clocks may disagree.

Suppose logs contain:

```text
10:00:00.120  Node A sends request R
10:00:00.090  Node B receives request R
```

Did B receive the request before A sent it?

No. The timestamps came from different clocks.

The message itself establishes a causal relationship even when wall-clock values are misleading.

Chapter 6 develops this formally with happened-before, Lamport clocks, and vector clocks. For now, remember:

```text
local clock reading ≠ universal event order
```

This matters for:

- debugging;
- conflict resolution;
- leases;
- transaction ordering;
- performance measurement;
- audit trails.

## 5. Communication has delay, and the delay is not perfectly predictable

A local memory access has latency too, but distributed communication introduces far larger variation and more failure modes.

A request may experience:

```text
serialization
   +
local scheduling
   +
transport / network delay
   +
remote scheduling
   +
server execution
   +
response path
```

The caller usually sees only the total time until a response or timeout.

Even a reliable byte-stream transport does not give the application a fixed upper bound on how long a remote operation must take.

A system that normally answers in 2 ms may occasionally answer in 200 ms because of:

- queueing;
- CPU scheduling;
- garbage collection;
- storage delay;
- packet retransmission;
- overload;
- another dependency;
- failover.

This variability is not merely a performance issue. Timeouts convert it into a **correctness and availability decision**.

<figure class="ds-book-figure">
  <img src="../../../assets/book/m01-remote-ambiguity.svg" alt="Several different remote executions can produce the same client timeout." loading="lazy" decoding="async" />
  <figcaption><span>Figure</span>One timeout, several compatible remote histories. The caller observes waiting; it does not directly observe the server's history.</figcaption>
</figure>

## 6. Partial failure is the central difference

In a single-process program, a catastrophic process failure often removes both caller and callee together.

In a distributed system:

```text
Client   ✓ alive
Server   ✗ crashed
Network  ✓ partly working
DB       ✓ alive
Replica  ? unreachable
```

Some components may continue while others fail.

This is **partial failure**.

Partial failure creates uncertainty because the surviving nodes must decide what to do without direct access to the failed component's internal state.

### Example: the ambiguous timeout

Consider a withdrawal request:

```text
Client                Server
  │                      │
  │ -- withdraw 10 ----> │
  │                      │ subtract 10
  │                      │ persist result
  │ <---- response -- X  │
  │
 timeout
```

The client knows it did not receive the response.

It does **not** know whether the server:

1. never received the request;
2. received it but crashed before execution;
3. executed it but crashed before persistence;
4. persisted it but failed before replying;
5. replied but the response was lost or delayed.

Retrying blindly may subtract another 10.

This one diagram motivates several later topics:

- request identifiers;
- idempotency;
- retry semantics;
- transactions;
- durable state;
- replication;
- exactly-once effects as an application/system property.

## 7. Failure and slowness can be observationally indistinguishable

Suppose A sends a heartbeat to B and receives no response for 500 ms.

Possible explanations include:

```text
B crashed
B is paused
B is overloaded
request delayed
response delayed
path partitioned
A's own scheduler paused
```

At the moment the timeout fires, A cannot always know which explanation is true.

A **failure detector** therefore makes a local suspicion based on incomplete information.

This distinction is essential:

> **A timeout can justify a local action without proving a remote fact.**

Chapter 10 studies this directly.

## 8. Concurrency means several valid orders may exist

Suppose two clients update the same logical object:

```text
Client A: set x = 1
Client B: set x = 2
```

If requests reach different replicas in different orders, the system may temporarily observe:

```text
Replica R1: A then B  → x = 2
Replica R2: B then A  → x = 1
```

Nothing about the network guarantees that messages from independent senders arrive in one universal order.

The system must define the order it needs—or define how conflicting states merge.

Later approaches include:

- a single sequencer/leader;
- consensus on log order;
- causal order;
- timestamps/version vectors;
- CRDT merge rules;
- application-level conflict resolution.

## 9. A distributed system is a collection of local state machines

A productive way to reason about distributed software is to stop imagining one giant program.

Instead, model each node as:

```text
local state
    +
incoming event
    ↓
state transition
    +
outgoing messages
```

For example, a worker might have states:

```text
IDLE → RUNNING(job-7) → IDLE
                │
                └→ CRASHED
```

A coordinator may simultaneously believe:

```text
worker-2 = RUNNING(job-7)
```

If the worker crashes before informing the coordinator, those two views diverge.

Distributed algorithms are largely about how these local state machines communicate so that important global properties still emerge.

## 10. State ownership must be explicit

For any piece of data, ask:

> **Where does the authoritative state live?**

Possible answers include:

### One owner

```text
Leader owns current write state
Followers replicate it
```

### Multiple writable replicas

```text
Replica A <---- merge/coordination ----> Replica B
```

### Partitioned ownership

```text
keys A–M → shard 1
keys N–Z → shard 2
```

### No durable owner

Some state is transient and can be recomputed.

If nobody can explain where state lives, then crash recovery, consistency, and retry behavior cannot be explained either.

This question becomes part of every final-project architecture record.

## 11. Transparency is useful until it hides a semantic difference

Distributed systems often try to provide **transparency**: make remote resources appear convenient to use.

Examples include:

- remote files that resemble local files;
- RPC that resembles a function call;
- replicated services that resemble one logical service;
- Ray tasks that resemble ordinary Python functions;
- distributed databases that resemble one database endpoint.

Transparency reduces programming effort.

But too much transparency can encourage incorrect assumptions.

The classic danger is:

```text
local call syntax
      ≈
remote call syntax
```

therefore incorrectly concluding:

```text
local failure semantics
      =
remote failure semantics
```

Chapter 2 intentionally gives you a convenient abstraction and then asks you to identify what it hides.

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosity</span>
  <strong>A timeout tells you what you did not observe, not what happened remotely</strong>
  <p>The request may have been lost, delayed, executed, committed, or completed while only the reply disappeared. Distributed systems become difficult exactly because local absence of evidence does not identify the remote state.</p>
  <p><strong>Try it:</strong> Draw four executions that all end with the client seeing the same timeout but leave the server in four different states.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">More chapter curiosities →</a>
</aside>

## 12. Distribution creates several kinds of transparency

Textbooks often distinguish transparency goals such as:

- **access transparency** — similar operations despite different representation/location;
- **location transparency** — users need not know physical location;
- **migration/relocation transparency** — resources can move;
- **replication transparency** — many copies appear as one logical resource;
- **failure transparency** — some failures are masked;
- **concurrency transparency** — many users share resources safely.

These are design goals, not free properties.

For example, hiding replication requires the system to define which replica answers, how writes propagate, and what consistency the client observes.

## 13. Scalability is not only “more machines”

A design can fail to scale in several dimensions.

### Size scalability

What happens as nodes, users, objects, or requests increase?

### Geographic scalability

What changes when communication delay rises from microseconds or milliseconds to tens or hundreds of milliseconds?

### Administrative scalability

Can independently controlled organizations participate without one universal configuration or trust authority?

### Load scalability

Can throughput increase by adding resources, or is there one serialized bottleneck?

A common anti-pattern is a component that every request must contact:

```text
           Central Coordinator
          /    /   |   \    \
       all requests and all state
```

Centralization is not automatically bad. It may be the simplest correct solution for a small system.

The engineering question is:

> **What bottleneck or failure domain does this design create, and is that acceptable for the stated requirements?**

## 14. System models make assumptions explicit

Distributed algorithms are correct only under assumptions.

One major assumption concerns timing.

### Synchronous model

The system assumes known upper bounds on relevant processing and communication delays.

### Asynchronous model

No fixed upper bound is assumed for message delay or relative process speed.

### Partially synchronous model

The system may behave asynchronously for a time but eventually satisfies useful timing bounds, or bounds exist but are initially unknown.

Real systems are often engineered with partially synchronous reasoning: timeouts may be unreliable during bad periods but eventually become useful once communication stabilizes.

A protocol described without its timing assumptions is incomplete.

## 15. Failure models matter just as much

Different algorithms tolerate different failures.

### Crash-stop

A node stops and never returns.

### Crash-recovery

A node may stop and later restart, possibly with some durable state preserved.

### Omission

Messages or actions may be missed.

### Timing failure

An action happens outside an expected timing bound.

### Byzantine failure

A participant may behave arbitrarily or maliciously.

Most of the course initially assumes crash/recovery and unreliable communication rather than Byzantine behavior. Chapter 12 widens the model.

Do not say “fault tolerant” without saying **fault tolerant to what**.

## 16. Safety and liveness are different kinds of promises

A useful way to classify distributed-system properties is:

### Safety

Something bad never happens.

Examples:

- two different committed values never occupy the same consensus-log position;
- money is not created by a transfer;
- an unauthorized user never reads a private message.

### Liveness

Something good eventually happens under stated assumptions.

Examples:

- an accepted request eventually completes;
- a leader is eventually elected after communication stabilizes;
- replicas eventually converge.

A system can preserve safety while losing liveness.

During a partition, a strongly consistent service might intentionally reject writes rather than risk conflicting committed state.

That may be the correct behavior.

## 17. Availability is observable progress, not the same thing as liveness

Availability usually concerns whether a request receives a useful response now or within a service objective.

A system can be:

- safe but temporarily unavailable;
- available but return stale data;
- live in a theoretical sense but too slow for users;
- highly available for reads but not writes.

The final project requires you to state these distinctions explicitly rather than promising “the system always works.”

## 18. The network is not an adversary, but it is not a perfect bus either

From Computer Networks, you already know that packets share finite-capacity paths, queues form, losses occur, routes change, and transport protocols recover imperfectly from network conditions.

Distributed Systems asks a different question:

> **What do those network behaviors mean for application state and correctness?**

Examples:

```text
packet loss
  ↓
retransmission / delay
  ↓
application timeout
  ↓
retry
  ↓
possible duplicate side effect
```

or:

```text
network partition
  ↓
replicas cannot coordinate
  ↓
consistency / availability decision
```

This is the primary intersection with the Computer Networks course.

## 19. The “fallacies” are useful as questions, not slogans

Engineers sometimes summarize recurring mistakes using statements such as assuming that:

- the network is reliable;
- latency is negligible;
- bandwidth is infinite;
- topology does not change;
- there is one administrator;
- transport is secure;
- network cost is zero;
- the system is homogeneous.

Memorizing this list is less useful than turning each assumption into a test.

For example:

> “Our retry design assumes requests either arrive quickly or fail.”

Test it with a 2-second delay rather than a crash.

Or:

> “All nodes run the same binary.”

Test a rolling upgrade with two compatible versions.

The course repeatedly converts assumptions into experiments.

## 20. Worked example: one counter, three designs

Suppose clients need an incrementing counter.

### Design A — local counter

```text
one process
counter = 41
increment() → 42
```

Simple. A mutex can protect concurrent threads.

But if the process dies and the counter is only in memory, state disappears.

### Design B — one remote counter server

```text
Clients ───> Counter Server
```

Now all clients can share one logical value.

But the server becomes:

- a network dependency;
- a throughput bottleneck;
- a failure domain;
- a persistence problem.

A client timeout also creates ambiguity about whether an increment executed.

### Design C — three writable counter replicas

```text
         ┌─ Replica A
Clients ─┼─ Replica B
         └─ Replica C
```

Availability might improve, but now concurrent increments can reach different replicas.

The design must answer:

- Are increments coordinated?
- Can replicas diverge?
- Can values merge?
- What does a read promise?

Later chapters show that a counter is particularly interesting because some counter semantics can be expressed as a CRDT, while a globally ordered integer sequence may require stronger coordination.

The important lesson is that **distribution does not merely move the original program onto several machines. It changes the state model.**

## 21. Worked example: the server crashes at five different moments

Consider:

```text
PUT(key="x", value="7", request_id="r9")
```

The server might crash:

1. before receiving bytes;
2. after receiving but before validation;
3. after changing memory but before durable storage;
4. after durable storage but before sending a response;
5. after sending a response but before the client receives it.

The client may observe a timeout in several of these cases.

A complete design must therefore define:

- durability point;
- acknowledgement point;
- retry policy;
- duplicate detection;
- recovery state.

This analysis technique—enumerating failure points around state transitions—is used throughout the course and final project.

## 25. Common mistakes

### “It uses multiple threads, therefore it is distributed”

Concurrency inside one address space does not introduce independent node memory or network failure.

### “TCP is reliable, therefore my remote operation is reliable”

Reliable byte delivery under a live connection does not define application retry, idempotency, persistence, or what happens when the endpoint crashes.

### “A timeout means the server is down”

A timeout is a local suspicion after waiting for a selected interval.

### “Replication means the data is safe”

Only if the acknowledgement, placement, recovery, and consistency rules actually protect the required failure cases.

### “The system is eventually consistent” as an excuse for any stale result

Eventual consistency needs a convergence model and assumptions about delivery and future updates. Undefined divergence is not a consistency model.

### “We use consensus, so everything is consistent”

Consensus can order particular decisions among participants. The application must still correctly connect those decisions to state, persistence, reads, retries, and side effects.

### “The middleware handles it”

That may be true—but then you should identify **which property the middleware handles and under which configuration/assumptions**.

## 26. How to read every later chapter

For each system or algorithm, create the same table:

| Question | What to identify |
|---|---|
| Participants | clients, servers, replicas, peers, coordinators |
| Local state | variables, logs, files, caches, terms, versions |
| Messages | request, heartbeat, vote, append, gossip, acknowledgement |
| Safety | what must never happen |
| Liveness | what should eventually happen |
| Failure model | crashes, recovery, loss, partitions, Byzantine behavior |
| Timing model | what assumptions exist about delay/timeouts |
| Durability | what survives restart |
| Retry semantics | which operations can repeat safely |
| Evidence | tests, logs, traces, metrics, stored state |

This is also the template you should use when analyzing final-project architecture.

## Chapter summary

A distributed system differs fundamentally from one local program because:

1. **participants have independent state and failure lifecycles;**
2. **communication has uncertain delay and can fail independently from computation;**
3. **there is no perfectly shared clock or instantaneous global observation;**
4. **several operations can occur concurrently and be observed in different orders;**
5. **partial failure leaves surviving components with incomplete knowledge;**
6. **timeouts produce suspicions and policy decisions, not remote truth;**
7. **state ownership, durability, and acknowledgement boundaries must be explicit;**
8. **transparency helps programmers but can hide important semantic differences;**
9. **safety, liveness, availability, scalability, timing, and failure assumptions are distinct;**
10. **distributed correctness is always correctness under a stated model.**

Before continuing, you should be able to take an ordinary application requirement—“increment a counter,” “store a file,” “run a job,” “schedule a meeting”—and identify what new questions appear once the state or computation crosses a process/network boundary.

<div class="ds-next-action">
  <span>Core reading complete</span>
  <strong>Next required step · Guided practice</strong>
  <a href="../guided-practice/">Start guided practice →</a>
</div>
