<p class="ds-book-part">Part I — Foundations and Architecture</p>
<p class="ds-module-kicker">Chapter 1</p>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 1 of 12</span>
    <span>8% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 8%"></span></div>
</div>
<p class="ds-guiding-question">What changes when one operation crosses an independent failure boundary?</p>

Start with the smallest useful comparison: one local call and the same operation performed by another process. Then add delay, concurrency, a lost response, and an independently failing server. The syntax may look similar; the knowledge available to the caller is not.

## Key ideas

- autonomous components
- latency and uncertain delay
- independent state
- concurrency
- partial failure
- transparency and openness
- scalability
- system and failure assumptions

## Laboratory transition

Run the same operation locally and remotely. Inject delay and failure, then state exactly what the caller can and cannot know after a timeout.

## Start here

> **Before you read:** A client times out after sending an update. List three executions in which the server did nothing, and three in which the server changed state.

**Bring forward:** Processes, sockets, latency, and ordinary local function calls from Operating Systems and Computer Networks.

**This chapter builds toward:** The mental model used by every later chapter: independent state, uncertain communication, concurrency, and partial failure.

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>30 min–40 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>35 min–50 min</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>1 h 15 min–1 h 45 min · 6 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Read lesson →</a>
  <a class="ds-secondary-action" href="lab/">Open laboratory</a>
</div>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../downloads/en/m01-distributed-systems.zip" download>Download chapter + laboratory for offline study (.zip)</a></p>

## What you will learn

- Explain why a remote operation cannot be treated like a local function call.
- Distinguish concurrency from distribution and parallelism.
- Describe partial failure and why it complicates correctness.
- Identify assumptions in synchronous, asynchronous, and partially synchronous models.
- Translate an application description into nodes, channels, state, and failure assumptions.

## Learn by working the question

1. Write your answer to **Start here** before opening the full lesson.
2. Read until the next prediction or trace, then stop and work it out before revealing the explanation.
3. Treat guided practice as a **practice bank**, not a speed worksheet. Work the core traces until you can meet the chapter's Practice target; return to the remaining cases for retrieval practice or instructor-assigned work.
4. Use the knowledge check to find gaps, then enter the laboratory with a falsifiable prediction and name the evidence that could contradict it.
5. Finish by explaining what the experiment established, what it did not establish, and how the result changes the evolving service.

<nav class="ds-sequence" aria-label="Course sequence">
<a class="ds-sequence-link" href="../m00-tooling/">← Laboratory Bootcamp</a>
<a class="ds-sequence-link next" href="../m02-ray-middleware/">Architectures and Middleware →</a>
</nav>
