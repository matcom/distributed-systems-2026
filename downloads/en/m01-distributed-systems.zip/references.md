> **Reference view.** This page is optional context; return to the [Lesson](../lesson/) for the required path.

## Essential

- **● Distributed Systems, 4th ed.** — Maarten van Steen and Andrew S. Tanenbaum. [book](https://www.distributed-systems.net/index.php/books/ds4/)
- **● Distributed Systems lecture/book resources** — Maarten van Steen. [book resources](https://www.distributed-systems.net/)

## Recommended

- **●● Designing Data-Intensive Applications** — Martin Kleppmann. [book](https://dataintensive.net/)

## Advanced

- **●● Time, Clocks, and the Ordering of Events in a Distributed System** — Leslie Lamport. [paper](https://lamport.azurewebsites.net/pubs/time-clocks.pdf)

## Tools & Practice

- **● The Go Documentation** — The Go Project. [tool documentation](https://go.dev/doc/)

## Explore

- **●●● 6.5840 Distributed Systems** — MIT PDOS. [course](https://pdos.csail.mit.edu/6.824/)
