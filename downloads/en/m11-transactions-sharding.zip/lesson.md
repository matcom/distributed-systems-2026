<p class="ds-book-part">Part IV — Fault Tolerance</p>
<div class="ds-lesson-banner">
  <div><span>Course step</span><strong>Chapter 11</strong></div>
  <div><span>Core reading</span><strong>35 min–50 min</strong></div>
  <div><span>Required path</span><strong>Read → Practice target → Check → Lab</strong></div>
</div>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 11 of 12</span>
    <span>92% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 92%"></span></div>
</div>

> **Guiding question:** What happens when one logical operation changes state owned by several independently failing machines?

## Before you read

> A transfer debits one shard and must credit another. The coordinator crashes after the debit prepares. Which facts must be durable before any participant can decide?

Write a short answer first. You are not expected to be correct yet; you need a prediction you can revise as the chapter gives you better models and evidence.

**Use what you already know:** Replication, agreement, and crash-recovery reasoning.

## Workload map

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>35 min–50 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>50 min–1 h 15 min</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>2 h 30 min–3 h 30 min · 10 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<p class="ds-workload-note"><strong>Core scope:</strong> The core lab path is Steps 1–14 plus the Step 16 fault campaign. Step 15 is a performance extension, and the AI audit is required only when AI contributed. Steps 12–14 are focused comparison/recovery checkpoints, not separate production systems.</p>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../../downloads/en/m11-transactions-sharding.zip" download>Download lesson + practice + lab for offline study (.zip)</a></p>

## Why this chapter matters

Earlier coordination and replication work gave us the idea of one strongly ordered replicated state machine. That architecture is powerful, but real systems often grow beyond one state-machine group.

Data may be split because:

- one node cannot hold all data;
- one leader cannot sustain all writes;
- users should be served near their data;
- workloads are naturally separable;
- independent teams/services own different state.

Once state is partitioned, an operation that touches **one partition** can remain relatively simple. An operation that touches **several independently owned partitions** becomes a coordination problem.

The guiding question is:

> **What happens when one logical operation must change state owned by several machines?**

This chapter develops that problem through five connected ideas:

```text
partition data
      ↓
route operations
      ↓
observe local-vs-cross-shard cost
      ↓
coordinate atomic multi-shard changes
      ↓
recover or compensate when participants fail
```

---

## 1. Partitioning changes one system into several authorities

Suppose one key/value service stores:

```text
A, B, C, D, E, F
```

A single replicated group could own all six keys.

Sharding might instead create:

```text
Shard 1: A, B
Shard 2: C, D
Shard 3: E, F
```

Each shard may itself be replicated using the coordination and recovery techniques you studied earlier.

Now there are two levels of distribution:

```text
logical dataset
   ↓ partitioned into shards
multiple shard authorities
   ↓ each may be replicated
multiple replicas per shard
```

Replication and partitioning solve different scaling problems.

**Replication** creates additional copies of the same logical state.

**Partitioning/sharding** divides different logical state among owners.

A production design often uses both.

---

<aside class="ds-book-note ds-history">
  <span class="ds-book-note-label">History</span>
  <strong>Distributed transactions turned one local commit point into a protocol among machines</strong>
  <p>Once one logical operation touched state owned by several machines, atomicity required durable votes, coordinators, recovery rules, and an acceptance of blocking or stronger coordination machinery.</p>
  <a class="ds-book-note-source" href="../../../history/transactions-atomic-commit/">Read the design history →</a>
</aside>

## 2. The partition key is an architectural decision

A partitioning strategy answers:

> Given an object or operation, which shard owns it?

Simple approaches include:

### Range partitioning

```text
A–F → shard 1
G–M → shard 2
N–Z → shard 3
```

Advantages:

- natural range scans;
- easy human interpretation.

Risks:

- uneven ranges;
- hot ranges;
- rebalancing complexity.

### Hash partitioning

```text
shard = hash(key) mod N
```

Advantages:

- often distributes random-looking keys more evenly.

Risks:

- range queries scatter;
- changing `N` remaps many keys with naive modulo hashing.

### Application-aware partitioning

Examples:

```text
user_id
account_id
organization_id
region
project_id
```

This can keep frequently interacting data together.

The “best” partition key depends on access patterns, not abstract elegance.

---

## 3. Good partitioning tries to make common operations local

Consider a messaging system partitioned by `conversation_id`.

Most operations on one conversation may stay within one shard.

Now consider partitioning the same system by message ID. Fetching a complete conversation might scatter across many shards.

The partition key therefore determines how often the system pays the cost of cross-shard coordination.

A useful design objective is:

> Place data so the common correctness boundary aligns with one ownership boundary.

This does not eliminate cross-shard operations, but it can make them exceptional rather than routine.

---

## 4. Local-shard operations and cross-shard operations have different costs

A local operation may involve:

```text
client
  ↓
router
  ↓
shard leader
  ↓
replicated commit
```

A cross-shard operation may involve:

```text
client/coordinator
      ↓
   shard A
      +
   shard B
      +
possibly shard C
```

Each shard has:

- its own leader/replicas;
- its own network latency;
- its own failure state;
- its own locks/validation;
- its own commit decision.

The slowest required participant can dominate latency.

This is why the lab measures local and cross-shard paths separately.

---

## 5. Example: transferring money across shards

Suppose account A is on shard 1 and account B is on shard 2.

We want:

```text
TRANSFER 10 from A to B
```

The desired invariant is:

```text
A decreases by 10
AND
B increases by 10
```

not:

```text
A decreases, B unchanged
```

or:

```text
A unchanged, B increases
```

If both accounts lived in one strongly ordered state machine, the transfer could be one deterministic command.

Across two shards, there are two authorities.

We need a protocol for one atomic decision spanning them.

---

## 6. Atomic commit asks all-or-nothing across participants

An atomic commit protocol should ensure:

```text
all participating shards commit
```

or:

```text
all participating shards abort
```

for the same logical transaction.

This is different from consensus.

Consensus asks several nodes to agree on one value/sequence despite failures.

Atomic commit asks several participants, each with its own local state, to coordinate whether one distributed transaction may commit.

A real system may use consensus **inside each participant** and 2PC **across participants**.

That layered design is common and important conceptually.

---

## 7. Two-phase commit — basic structure

Two-phase commit (2PC) has two broad phases.

### Phase 1 — prepare/vote

Coordinator asks participants:

```text
Can you commit transaction T?
```

Each participant validates local conditions and responds:

```text
YES / prepared
```

or:

```text
NO / abort
```

### Phase 2 — global decision

If all required participants vote YES, coordinator decides:

```text
COMMIT
```

Otherwise:

```text
ABORT
```

Then the decision is communicated to participants.

Conceptually:

```text
             coordinator
             /         \
        PREPARE       PREPARE
          ↓              ↓
       shard A         shard B
          │ YES          │ YES
          └──────┬───────┘
                 ↓
             COMMIT
              /   \
             ↓     ↓
          shard A shard B
```

---

## 8. Prepared is a real durable state

A participant that answers YES cannot casually forget the promise.

By voting YES, it effectively says:

> I have validated the transaction and retained enough state/resources so that if the coordinator later says COMMIT, I can honor that decision.

Therefore prepared state may need to include:

- transaction ID;
- intended updates;
- locks/reservations;
- durable vote;
- enough recovery information to finish commit or abort later.

A participant must not vote YES and then forget everything after a crash.

Otherwise the global atomicity argument collapses.

---

## 9. Why 2PC can block

Suppose both participants vote YES.

Then the coordinator crashes before they learn the final decision.

Participant A knows:

```text
I voted YES
```

but may not know whether:

```text
coordinator decided COMMIT
```

or:

```text
coordinator had not decided yet
```

If A independently aborts while B later learns COMMIT, atomicity breaks.

Therefore a prepared participant may need to wait for the authoritative global decision.

This is the classic blocking problem of 2PC.

The lesson is not “2PC is bad.”

The lesson is:

> Atomicity across independent authorities creates a dependency on recovering the global decision.

---

## 10. Coordinator failure has several distinct crash windows

You should trace at least these:

### Window A — before any PREPARE

No participant has promised anything. Abort is simple.

### Window B — after some PREPARE messages

Some participants may be prepared; others may not know the transaction.

### Window C — after all YES votes but before durable global decision

Participants may block waiting for recovery.

### Window D — after durable COMMIT but before every participant receives it

Recovery must rediscover/retransmit the same COMMIT decision.

### Window E — after some participants commit and before others receive the decision

The transaction is globally committed; lagging participants must eventually learn and apply that same decision.

The report should identify which durable state makes each recovery path possible.

---

## 11. Transaction IDs play the same role request IDs played earlier

Chapter 4 and Chapter 10 used stable logical request identity.

Distributed transactions need the same discipline.

Every participant should recognize transaction `T42` as the same logical transaction across:

- retries;
- coordinator restart;
- duplicated PREPARE;
- duplicated COMMIT;
- duplicated ABORT.

Protocol messages should therefore be idempotent with respect to stable transaction identity whenever practical.

For example:

```text
PREPARE T42
PREPARE T42 again
```

should not create two independent reservations.

---

## 12. 2PC and consensus solve different failures

This distinction deserves repetition.

Suppose each shard is a replicated state machine:

```text
Shard A = Raft group A1,A2,A3
Shard B = Raft group B1,B2,B3
```

2PC coordinator asks **the shard authorities** to prepare/commit.

Raft inside shard A ensures shard A's local transactional state survives one replica crash.

Raft inside shard B does the same.

2PC coordinates the cross-shard all-or-nothing decision.

So:

```text
Raft/Paxos
→ agreement within a replicated authority
```

while:

```text
2PC
→ atomic decision across transaction participants
```

Neither is simply a substitute for the other.

---

## 13. Locks and isolation are separate from atomic commit

2PC answers whether all participants commit or abort.

It does not by itself define the complete concurrency/isolation policy.

Suppose two transfers concurrently modify the same account.

Participants still need mechanisms such as:

- locking;
- optimistic validation;
- version checks;
- serializable transaction scheduling;
- another concurrency-control policy.

A course implementation may use a simple lock-per-key or lock-per-transaction model, but should state what concurrent anomalies it prevents.

Do not equate:

```text
atomic commit
```

with:

```text
serializable execution
```

They are different properties.

---

## 14. Two-phase locking and two-phase commit are not the same “2P”

You may confuse:

- 2PL: two-phase locking, a concurrency-control discipline;
- 2PC: two-phase commit, a distributed atomic-commit protocol.

They can be used together, but they solve different problems.

A simple cross-shard transaction system might:

```text
acquire/hold participant locks
        ↓
2PC prepare
        ↓
global decision
        ↓
commit/abort
        ↓
release locks
```

Holding locks while waiting for coordinator recovery explains why blocked prepared transactions can hurt availability.

---

## 15. Timeout does not mean abort is safe

Chapter 4's central lesson returns again.

A participant sends YES and waits for the global decision.

The wait times out.

Can it simply abort?

Not necessarily.

The coordinator may already have durably decided COMMIT.

Timeout means:

```text
I do not currently know the decision
```

not:

```text
there is no committed decision
```

This is the same epistemic boundary seen throughout the course.

---

## 16. Recovery needs an authoritative transaction record

A recoverable coordinator should persist enough information to reconstruct the transaction state.

For example:

```text
T42:
  participants = [A,B]
  phase = decided
  decision = COMMIT
```

After restart it can retransmit COMMIT until participants acknowledge.

Likewise a participant can persist:

```text
T42:
  state = PREPARED
  intended_change = ...
```

and avoid forgetting a promise after restart.

The storage mechanism may be simple in the course, but recovery semantics must be explicit.

---

## 17. Heuristic decisions are dangerous

A system under operational pressure may be tempted to let a blocked participant decide locally after a timeout.

For example:

```text
if prepared for > 30s:
    abort locally
```

This may restore local availability but can violate global atomicity if COMMIT had already been decided elsewhere.

Such “heuristic” recovery decisions change the correctness contract.

If a project chooses them, the trade-off must be explicit and tested.

---

## 18. Sagas solve a different business problem

Not every multi-service workflow requires one atomic transaction.

Consider:

```text
book flight
book hotel
register conference
```

Holding all three services in prepared state until one atomic commit may be unrealistic or unsupported.

A saga instead decomposes the workflow into committed local steps plus compensating actions.

Example:

```text
book flight       ✓
book hotel        ✓
register event    ✗
      ↓
compensate hotel cancellation
compensate flight cancellation
```

The system may pass through intermediate externally visible states.

The guarantee is not “the whole world changed atomically.”

The goal is a controlled business-level recovery path.

---

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosity</span>
  <strong>The cheapest distributed transaction is often the one the data model avoids</strong>
  <p>Operations within one shard can use one local authority, while cross-shard invariants require communication, durable transaction state, and failure recovery. Good partitioning can remove coordination from the common path rather than merely optimize it later.</p>
  <p><strong>Try it:</strong> Take five application operations and choose a partition key that maximizes the fraction that remain single-shard.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">More chapter curiosities →</a>
</aside>

## 19. Compensation is not rollback

A database rollback may make an uncommitted local transaction disappear as if it never happened.

A compensating action is another real action.

For example:

```text
charge card $50
```

followed by:

```text
refund card $50
```

is not historically identical to never charging the card.

There may be:

- fees;
- notifications;
- audit entries;
- external observations;
- timing effects.

Therefore saga semantics must be described at the application level.

---

## 20. Orchestration and choreography are two saga styles

### Orchestration

A coordinator tells each step what to do next.

```text
workflow coordinator
   ↓ book flight
   ↓ book hotel
   ↓ register
   ↓ compensate if needed
```

Advantages:

- explicit workflow state;
- easier centralized reasoning.

Risks:

- coordinator becomes an important dependency;
- workflow logic can centralize heavily.

### Choreography

Services react to events.

```text
flight_booked event
       ↓
hotel service reacts
       ↓
hotel_booked event
       ↓
registration reacts
```

Advantages:

- looser coupling;
- event-driven composition.

Risks:

- global workflow harder to observe/reason about;
- compensation paths may become implicit.

You may choose either style for final projects when appropriate.

---

## 21. Consistent hashing reduces remapping when membership changes

Naive hash partitioning:

```text
hash(key) mod N
```

can remap a large fraction of keys when `N` changes.

Consistent hashing places both keys and nodes in a logical identifier space, often visualized as a ring.

A key maps to the next node position according to the chosen rule.

When one node joins/leaves, only a portion of the key space needs to move.

This concept connects directly to Chapter 5 DHTs, but here the focus is **data placement and rebalancing**, not decentralized routing.

---

## 22. Virtual nodes improve load distribution

One physical node can own multiple positions/partitions in the logical hash space.

This allows finer-grained movement:

```text
physical A owns vnodes A1,A2,A3,...
physical B owns vnodes B1,B2,B3,...
```

When capacity changes, some virtual partitions can move without reshaping the entire dataset.

The same broad idea appears in many distributed storage systems under different names such as tokens, partitions, ranges, or tablets.

---

## 23. Rebalancing is a correctness problem, not only a copying problem

Suppose shard range R moves from node A to node B while clients continue writing.

A naive sequence:

```text
copy old data A → B
change routing
```

can miss writes that occurred during the copy.

A correct migration needs a transition protocol.

Possible approaches include:

- pause writes briefly;
- record a cutover log position;
- stream old snapshot plus incremental changes;
- temporarily dual-write under one authority;
- route through a migration coordinator.

You should state when ownership changes and how writes around the boundary are handled.

---

## 24. Routing metadata itself becomes distributed state

If data is partitioned, clients/routers need to know:

```text
which shard owns key K?
```

That mapping can become stale.

This reconnects to Chapter 8 discovery.

A client may route to the old shard after rebalancing.

The old shard can:

- redirect;
- return a newer mapping version;
- forward temporarily;
- reject and force refresh.

Routing metadata should have a version/incarnation/epoch so stale ownership can be detected rather than silently accepted.

---

## 25. Hot shards defeat nominal horizontal scaling

Even perfectly balanced key counts do not imply balanced load.

Suppose one celebrity account receives 30% of all traffic.

Hashing by user ID may place all that load on one shard.

This is a **hot-key/hot-shard** problem.

Potential mitigations include:

- caching;
- read replicas;
- splitting hot logical objects;
- application-specific aggregation;
- finer-grained partitioning;
- load-aware routing.

The correct solution depends on whether strong ordering for that key must be preserved.

---

## 26. Scatter/gather queries trade simplicity for fan-out

If a query does not include the partition key, the system may need to ask many shards.

Example:

```text
SELECT all users WHERE age > 40
```

when partitioned by `user_id`.

Execution:

```text
query router
  ├→ shard 1
  ├→ shard 2
  └→ shard 3
      ↓
merge results
```

Latency now depends on multiple shards, and one slow shard can create a tail-latency problem.

This connects to Chapter 12.

---

## 27. Cross-shard work amplifies failure probability

If one local operation depends on one shard being available, its success condition is narrow.

A cross-shard operation involving five participants needs all required participants/coordinators to reach the relevant protocol state.

More dependencies create more opportunities for:

- delay;
- timeout;
- retries;
- partial progress;
- lock holding;
- coordinator failure.

This is another reason to design data placement around common transaction boundaries.

---

## 28. Worked example — successful 2PC transfer

Initial state:

```text
Shard A: account A = 100
Shard B: account B = 40
```

Transaction:

```text
T7: transfer 30 A → B
```

Prepare:

```text
Coordinator → A: PREPARE T7 debit 30
A verifies balance, reserves/locks, persists PREPARED, votes YES

Coordinator → B: PREPARE T7 credit 30
B validates, persists PREPARED, votes YES
```

Decision:

```text
Coordinator durably records COMMIT T7
```

Completion:

```text
Coordinator → A: COMMIT T7
A applies debit, releases state

Coordinator → B: COMMIT T7
B applies credit, releases state
```

Final:

```text
A = 70
B = 70
```

Duplicate COMMIT messages should be harmless under stable transaction identity.

---

## 29. Worked example — coordinator crashes after COMMIT decision

Same transaction T7.

Execution:

```text
A prepared YES
B prepared YES
coordinator durably records COMMIT
coordinator sends COMMIT only to A
A commits
coordinator crashes before B receives COMMIT
```

B remains PREPARED.

After coordinator recovery:

```text
load durable decision COMMIT T7
retransmit COMMIT to B
B commits
```

Atomicity is eventually restored because the authoritative decision survived.

The temporary period where A has applied and B has not may be externally hidden/controlled depending on isolation and participant semantics.

---

## 30. Worked example — coordinator crashes before global decision

Execution:

```text
A votes YES
B votes YES
coordinator crashes before durably deciding
```

A and B know they promised to commit if instructed but cannot safely infer the global outcome from silence.

They may block until coordinator/decision recovery.

This is the key liveness weakness of classical 2PC.

---

## 31. Worked example — saga compensation

Workflow:

```text
reserve hotel   ✓
charge card     ✓
issue ticket    ✗
```

Compensation:

```text
refund card
cancel hotel reservation
```

Questions:

- What if the refund call times out?
- Can cancellation itself fail?
- Are compensations idempotent?
- How is workflow progress persisted?
- What if the process crashes after compensation succeeds but before recording success?

Notice that saga execution immediately reuses Chapter 4 retry semantics and Chapter 10 durable workflow state.

---

## 32. Transactions and partitions create explicit availability choices

During a network partition, a cross-shard transaction may be unable to contact one required participant.

If atomicity is mandatory, the coordinator cannot simply commit the reachable half.

So availability may decrease.

A different application may choose a saga/eventual workflow that accepts temporary intermediate state and continues more work independently.

Again, the right architecture depends on the business invariant.

---

## 33. The final project should not add 2PC just to look distributed

A poor design artificially creates several services then uses 2PC everywhere.

A better design asks:

> Which invariant genuinely spans independent ownership boundaries?

Examples where cross-shard coordination may matter:

- transfer between accounts;
- reserve capacity in two independent resources;
- atomically move an object between namespaces;
- commit one tournament result and ranking update across independent shards.

Examples where a saga/eventual process may be better:

- sending notifications after a durable state change;
- processing media transcoding stages;
- long-running external workflows;
- crawling and indexing pipelines.

---

## 34. Connection to the 20-project catalog

### P07 — Distributed Calendar

Creating one meeting across several users may be modeled as coordinated multi-owner state. You can compare atomic commit with invitation/acceptance workflow semantics.

### P09 — Tag-Based Distributed File Store

A file's content and tag metadata may be partitioned separately. Moving/deleting state across ownership boundaries exposes transactional questions.

### P13 — Replicated Event Log

Topics/partitions are natural shards. Consumer state and multi-partition writes expose coordination trade-offs.

### P16 — Distributed Object Storage

Placement, rebalancing, metadata ownership, and object moves make partitioning central.

### P19 — Distributed Vector Search

Vector collections can be sharded, while queries may scatter/gather over several shards.

---

## 35. AI-assisted engineering: transaction code is deceptively easy to generate

A coding agent can produce a textbook-looking 2PC coordinator quickly.

The hard questions are in crash windows and durable promises.

Require you to answer:

- What exact record exists before a participant says YES?
- Can PREPARE be retried safely?
- Can COMMIT be retried safely?
- What if the coordinator crashes after deciding but before notifying everyone?
- What if a participant crashes while prepared?
- What locks/resources remain held?
- How is the transaction identified after restart?
- What does timeout permit a participant to conclude?

A useful audit exercise is to ask an agent for a “timeout recovery” strategy and then check whether it accidentally violates atomicity by allowing a prepared participant to abort unilaterally.

---

## 36. Common mistakes

### Mistake 1 — confuse replication with partitioning

Copies of the same data and division of different data solve different problems.

### Mistake 2 — choose a partition key without studying access patterns

This can turn every common operation into a scatter/gather or distributed transaction.

### Mistake 3 — say “2PC guarantees consistency”

2PC is an atomic-commit protocol; it does not define every isolation/consistency property.

### Mistake 4 — forget to persist prepared state

A YES vote is a promise that must survive the declared crash model.

### Mistake 5 — abort after timeout despite having voted YES

Silence does not prove the coordinator did not already commit.

### Mistake 6 — treat compensation as rollback

Compensating actions are real externally visible operations.

### Mistake 7 — ignore duplicated protocol messages

Stable transaction identity should make retried PREPARE/COMMIT/ABORT safe.

### Mistake 8 — rebalance by copying once and flipping a routing pointer

Concurrent writes around migration can be lost or misrouted.

### Mistake 9 — assume balanced key counts mean balanced load

Hot keys can dominate one shard.

### Mistake 10 — use one global transaction when local ownership could avoid it

Architecture can eliminate coordination more effectively than optimizing coordination.

---

## Laboratory transition

The lab builds a small sharded key/value/account service with:

1. at least two shards;
2. a deterministic routing function;
3. measurable local and cross-shard operations;
4. stable transaction IDs;
5. a simplified 2PC coordinator;
6. durable prepared/decision state within the declared failure model;
7. duplicated message handling;
8. coordinator crash/recovery tests;
9. participant crash/recovery tests;
10. one saga-style workflow comparison;
11. one rebalancing/migration exercise;
12. latency/fan-out measurements.

The target is not to build a production database.

The target is to be able to say:

> “This operation is local to one authority; this operation spans these participants; this protocol provides this atomicity guarantee; and these crash windows explain when progress may block or compensation is required.”

---

## Chapter summary

Sharding improves scale by dividing ownership, but ownership boundaries become coordination boundaries.

The central chain is:

```text
partition data
    ↓
route by ownership
    ↓
keep common work local when possible
    ↓
coordinate cross-shard invariants when necessary
```

For atomic multi-participant updates, 2PC can establish one global commit/abort decision, but prepared participants may block when that decision is unavailable.

For long-running or externally visible workflows, sagas provide a different model based on local commits plus compensating actions.

The deepest design lesson is architectural:

> **The cheapest distributed transaction is often the one good partitioning lets you avoid.**

Chapter 5 now removes another centralized assumption: what if membership and lookup themselves should be decentralized?

<div class="ds-next-action">
  <span>Core reading complete</span>
  <strong>Next required step · Guided practice</strong>
  <a href="../guided-practice/">Start guided practice →</a>
</div>
