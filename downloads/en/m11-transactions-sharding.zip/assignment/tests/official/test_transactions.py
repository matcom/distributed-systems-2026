import unittest

from transactions import Coordinator, Participant, RangeRouter, StaleEpoch


class ShardingTests(unittest.TestCase):
    def setUp(self):
        self.router = RangeRouter([(0, 49, "A"), (50, 99, "B")], epoch=3)

    def test_deterministic_routing(self):
        self.assertEqual(self.router.route(0), "A")
        self.assertEqual(self.router.route(49), "A")
        self.assertEqual(self.router.route(50), "B")
        self.assertEqual(self.router.route(99), "B")

    def test_missing_key_range_is_explicit(self):
        with self.assertRaises(LookupError):
            self.router.route(100)

    def test_stale_ownership_epoch_is_rejected(self):
        with self.assertRaises(StaleEpoch):
            self.router.route(60, request_epoch=2)
        self.assertEqual(self.router.route(60, request_epoch=3), "B")


class TwoPhaseCommitTests(unittest.TestCase):
    def test_successful_two_participant_commit(self):
        a, b = Participant(), Participant()
        votes = [a.prepare("tx1", True), b.prepare("tx1", True)]
        coordinator = Coordinator()
        self.assertEqual(coordinator.decide("tx1", votes), "COMMIT")
        self.assertEqual(a.commit("tx1"), "COMMIT")
        self.assertEqual(b.commit("tx1"), "COMMIT")

    def test_no_vote_forces_abort(self):
        a, b = Participant(), Participant()
        votes = [a.prepare("tx1", True), b.prepare("tx1", False)]
        coordinator = Coordinator()
        self.assertEqual(coordinator.decide("tx1", votes), "ABORT")
        self.assertEqual(a.abort("tx1"), "ABORT")
        self.assertEqual(b.abort("tx1"), "ABORT")

    def test_duplicate_prepare_is_idempotent(self):
        p = Participant()
        self.assertEqual(p.prepare("tx1", True), "YES")
        self.assertEqual(p.prepare("tx1", False), "YES")
        self.assertEqual(p.records["tx1"].state, "PREPARED")

    def test_duplicate_commit_applies_one_logical_effect(self):
        p = Participant()
        p.prepare("tx1", True)
        self.assertEqual(p.commit("tx1"), "COMMIT")
        self.assertEqual(p.commit("tx1"), "COMMIT")
        self.assertEqual(p.effects.get("tx1"), 1)

    def test_prepared_state_does_not_timeout_into_abort(self):
        p = Participant()
        p.prepare("tx1", True)
        self.assertEqual(p.records["tx1"].state, "PREPARED")
        self.assertEqual(p.records["tx1"].vote, "YES")

    def test_coordinator_decision_is_stable_across_repeat_decide(self):
        coordinator = Coordinator()
        self.assertEqual(coordinator.decide("tx1", ["YES", "YES"]), "COMMIT")
        self.assertEqual(coordinator.decide("tx1", ["NO", "NO"]), "COMMIT")
        self.assertEqual(coordinator.recover_decision("tx1"), "COMMIT")

    def test_commit_without_yes_prepare_is_rejected(self):
        p = Participant()
        with self.assertRaises(ValueError):
            p.commit("tx1")


if __name__ == "__main__":
    unittest.main()
