# Planned Public Tests — M11 Distributed Transactions, Partitioning, and Sharding

These cases define the intended transparent test surface. No hidden cases are planned.

Executable public tests are provided in this directory together with the starter sharding/2PC adapter under `starter/src/`. They cover deterministic routing, ownership epochs, stable transaction decisions, and idempotent protocol messages; multi-process crash/recovery experiments remain evidence-based.

## T1 — deterministic routing

Given a fixed ownership configuration, known keys map to the expected shards.

## T2 — local operation touches one owner

A local-shard operation must not unnecessarily contact unrelated shard authorities.

## T3 — successful 2PC

For a two-participant transaction where both vote YES:

- one global COMMIT is recorded;
- both participants commit the same transaction ID;
- the application invariant holds.

## T4 — participant NO causes abort

If any required participant votes NO, verify the global outcome is ABORT and no participant exposes a committed partial update.

## T5 — duplicate PREPARE is idempotent

Send PREPARE twice for the same transaction ID.

Verify no duplicate reservation/mutation is created.

## T6 — duplicate COMMIT is idempotent

Deliver COMMIT repeatedly.

Verify the logical effect occurs once.

## T7 — coordinator recovery preserves decision

Persist/record COMMIT, deliver it to only a subset of participants, restart coordinator state, and verify it retransmits the same COMMIT rather than choosing again.

## T8 — participant recovery preserves PREPARED

Restart a participant after YES/PREPARED and before final decision.

Verify it reconstructs enough state to honor the recovered global decision.

## T9 — prepared timeout does not invent abort

Delay the global decision past a local waiting threshold.

Verify a participant that already voted YES does not silently decide ABORT solely from timeout.

## T10 — conflicting transactions obey declared concurrency control

Run two transactions sharing at least one key.

Verify the result matches the declared lock/version/validation policy.

## T11 — stable transaction identity across retries

Retry coordinator and participant messages using the same transaction ID and verify one logical outcome.

## T12 — ownership epoch rejects stale authority

After a range/key ownership move, send a request using the previous ownership epoch.

Verify it is rejected, redirected, or otherwise handled according to the declared migration protocol rather than silently accepted by two authorities.

## T13 — rebalancing preserves acknowledged writes

Execute writes around cutover and verify all acknowledged writes are present at the authoritative post-migration owner/state.

## T14 — saga compensation retry

Where the saga comparison is implemented, duplicate one compensation request and verify the workflow does not accidentally compensate twice within the declared request-identity boundary.

## Student extensions

Useful student tests include:

- coordinator restart multiple times;
- participant receives COMMIT before duplicated PREPARE retry;
- malformed transaction participant list;
- stale router after several ownership epochs;
- three-shard transaction;
- one hot-shard workload assertion;
- scatter/gather partial-result policy.

Every test should name the invariant it is intended to falsify.