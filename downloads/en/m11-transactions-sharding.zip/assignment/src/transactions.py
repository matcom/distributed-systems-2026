"""Deterministic sharding and two-phase-commit model for M11."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Tuple


class StaleEpoch(ValueError):
    pass


class RangeRouter:
    """Route integer keys through inclusive [low, high] ranges."""

    def __init__(self, ranges: Iterable[Tuple[int, int, str]], epoch: int):
        self.ranges = list(ranges)
        self.epoch = epoch

    def route(self, key: int, request_epoch: int | None = None) -> str:
        """Return owner, rejecting a supplied stale ownership epoch."""
        raise NotImplementedError("TODO: implement deterministic routing and epoch check")


@dataclass
class TxRecord:
    state: str
    vote: str | None = None


class Participant:
    def __init__(self):
        self.records: Dict[str, TxRecord] = {}
        self.effects: Dict[str, int] = {}

    def prepare(self, tx_id: str, can_commit: bool) -> str:
        """Return YES/NO and make duplicate PREPARE idempotent."""
        raise NotImplementedError("TODO: implement PREPARE/PREPARED state")

    def commit(self, tx_id: str) -> str:
        """Commit a prepared transaction once; duplicate COMMIT is idempotent."""
        raise NotImplementedError("TODO: implement durable-style commit transition")

    def abort(self, tx_id: str) -> str:
        """Abort unless already committed; duplicate ABORT is idempotent."""
        raise NotImplementedError("TODO: implement abort transition")


class Coordinator:
    def __init__(self):
        self.decisions: Dict[str, str] = {}

    def decide(self, tx_id: str, votes: List[str]) -> str:
        """Choose COMMIT iff every required vote is YES, and remember the decision."""
        raise NotImplementedError("TODO: implement one stable global decision")

    def recover_decision(self, tx_id: str) -> str | None:
        return self.decisions.get(tx_id)
