# Laboratory — Distributed Transactions, Partitioning, and Sharding

## Target

Build a small sharded service, measure the difference between local and cross-shard operations, implement a simplified two-phase commit protocol, then exercise coordinator/participant crash windows and one saga/rebalancing comparison.

This lab is Ray-free.

## Main question

> When one logical operation spans several independently owned shards, what state must each participant preserve so the system can still reach one coherent outcome after failures?

## Core completion path

Complete Steps 1–14 and the fault campaign in Step 16. Step 15 (hot-shard or scatter/gather performance) is an **extension** unless your instructor assigns it. Step 17 is required only when an AI agent contributed to the implementation.

Treat Steps 12–14 as focused comparison/recovery checkpoints, not invitations to build three additional production systems. The core artifact remains one small sharded service whose transaction, recovery, and ownership behavior you can explain from evidence.

## Recommended service model

Use a small account or key/value service with at least two shards.

A convenient API is:

```text
GET(key)
PUT(key,value)
TRANSFER(from_key,to_key,amount)
```

or an equivalent application-specific model with one clearly local operation and one clearly cross-shard invariant.

The lab should expose:

```text
transaction_id
shard_id
ownership_epoch
phase
participant_vote
global_decision
```

in structured logs.

## Required invariants

Write these before implementation:

1. Each key/range has one declared owner for a given ownership epoch.
2. A local operation affects only its owning shard.
3. A committed cross-shard transaction reaches one global COMMIT/ABORT decision.
4. A prepared participant does not forget its YES promise across the declared restart model.
5. Duplicate transaction protocol messages do not duplicate logical effects.
6. Rebalancing does not silently lose writes around ownership cutover.

---

## Step 1 — Partition the data

Implement at least two shards and one deterministic routing policy.

Possible choices:

- range partitioning;
- hash partitioning;
- application-aware partitioning.

For each key, the router must be able to explain:

```text
key → shard
```

### Required evidence

Provide:

- routing configuration;
- at least six example keys;
- their selected shard;
- one argument explaining why your partition key matches the workload.

---

## Step 2 — Establish a local-shard baseline

Execute operations that touch only one shard.

Measure at least:

```text
request latency
remote messages/RPCs
number of participating authorities
```

Run enough repetitions to observe a distribution rather than one timestamp where practical.

Record median and p95 latency if the harness supports it.

---

## Step 3 — Build stable transaction identity

Every cross-shard operation must have a stable transaction ID.

For example:

```text
T42
```

Every participant should treat repeated protocol messages for T42 as belonging to the same logical transaction.

Log transitions such as:

```text
T42 NEW
T42 PREPARED
T42 COMMITTED
T42 ABORTED
```

Do not generate a new transaction ID merely because an RPC was retried.

---

## Step 4 — Implement simplified PREPARE

Coordinator identifies the participants and sends:

```text
PREPARE T42 ...
```

Each participant should:

1. validate its local preconditions;
2. reserve/lock/version-check the affected state according to your model;
3. persist/record PREPARED before promising YES under the declared crash model;
4. return YES or NO.

### Required experiment

Force one participant to vote NO.

Verify the global outcome is ABORT and no participant exposes a committed partial result.

---

## Step 5 — Implement the global decision

If all required participants vote YES, the coordinator records a durable/logically recoverable COMMIT decision before treating the transaction as globally committed.

Otherwise it records ABORT.

Then it sends the decision to participants.

### Required normal-path experiment

Run one cross-shard transfer successfully.

Show:

```text
PREPARE A
PREPARE B
YES A
YES B
GLOBAL COMMIT
COMMIT A
COMMIT B
```

or the equivalent trace for your implementation.

Verify the application invariant.

---

## Step 6 — Compare local versus cross-shard cost

Execute equivalent workloads where possible:

```text
local operation
cross-shard operation
```

Compare:

- number of protocol rounds;
- number of required participants;
- median latency;
- p95 latency;
- failure exposure.

Explain the difference structurally rather than only reporting numbers.

---

## Step 7 — Duplicate protocol messages

Deliberately duplicate:

```text
PREPARE T42
COMMIT T42
ABORT T43
```

as applicable.

### Required result

Repeated messages for the same transaction ID must not create:

- duplicate reservations;
- duplicate debits/credits;
- contradictory final states.

Use structured logs to show the duplicate was recognized.

---

## Step 8 — Coordinator crash before global decision

This is the first required failure checkpoint.

Execute:

```text
1. participants vote YES
2. coordinator crashes before recording COMMIT/ABORT
```

Prepared participants should not invent a decision from silence.

### Required evidence

Show:

- their persisted/recoverable PREPARED state;
- resources/locks still held if your isolation model uses them;
- inability to safely infer COMMIT or ABORT;
- recovery procedure.

### Required conclusion

Explain why this is **blocking**, not a safety violation.

---

## Step 9 — Coordinator crash after durable COMMIT

This is the second required failure checkpoint.

Execute:

```text
1. all participants vote YES
2. coordinator records COMMIT
3. coordinator sends COMMIT to only one participant
4. coordinator crashes
```

After coordinator restart/recovery:

```text
load T decision
retransmit same COMMIT
remaining participants finish
```

### Required evidence

Show that the coordinator does not choose a new decision after restart.

---

## Step 10 — Participant crash while prepared

Crash one participant after it votes YES and before it learns the final decision.

Restart it.

### Required behavior

The participant reconstructs:

```text
transaction ID
PREPARED status
required local reservation/change
```

and can still honor the recovered global decision.

If your reduced implementation cannot make participant state durable, state that limitation explicitly and test it with a deterministic restart simulation.

---

## Step 11 — Timeout is not a decision

Delay coordinator-to-participant decision messages until the participant's local waiting timeout expires.

Verify the participant does not silently convert:

```text
unknown decision
```

into:

```text
ABORT
```

if it has already voted YES.

Document how the implementation reports/handles an unresolved prepared transaction.

---

## Step 12 — Isolation/concurrency experiment

Run two cross-shard transactions that touch at least one common key.

Use your chosen concurrency-control policy:

- lock per key;
- lock per transaction;
- optimistic version validation;
- another justified approach.

### Required evidence

Show whether:

- one waits;
- one aborts/retries;
- both can proceed safely.

State the isolation guarantee actually implemented. Do not call 2PC itself an isolation mechanism.

---

## Step 13 — Saga comparison

Implement or simulate one three-step workflow whose final step can fail.

Example:

```text
reserve resource A
reserve resource B
create final record
```

On final failure, execute compensating actions.

### Required analysis

Compare with 2PC:

| Property | 2PC-style atomic commit | Saga-style workflow |
|---|---|---|
| intermediate states externally visible | | |
| participant blocking | | |
| compensation required | | |
| suitability for external/long-running actions | | |

Inject one compensation timeout and explain how stable request identity prevents duplicate compensation effects where possible.

---

## Step 14 — Rebalancing experiment

Move one partition/range from shard A to shard B.

Introduce an explicit ownership epoch/version.

Example:

```text
epoch 7: range R owned by A
epoch 8: range R owned by B
```

### Required experiment

Execute writes during migration.

Demonstrate your cutover rule, for example:

```text
snapshot/copy at boundary K
capture incremental updates
activate epoch 8
reject/redirect stale epoch 7 writes
```

or another coherent design.

### Required evidence

Show that a stale router does not silently create a second authoritative owner after cutover.

---

## Step 15 — Hot-shard or scatter/gather experiment

Choose one:

### Hot-shard option

Generate a workload where one key/range receives a disproportionate share of requests. Measure queue/latency imbalance.

### Scatter/gather option

Issue a query requiring all shards. Delay one shard and measure how it affects end-to-end latency.

Explain how partitioning affects the performance result.

---

## Step 16 — Fault campaign

At minimum include:

```text
F1  participant votes NO
F2  duplicated PREPARE/COMMIT
F3  coordinator crash before decision
F4  coordinator crash after durable COMMIT
F5  participant crash while PREPARED
F6  delayed decision / participant timeout
F7  concurrent conflicting transactions
F8  stale routing during rebalancing
```

For each provide:

```text
prediction
fault point
recoverable state
observed result
atomicity/isolation judgment
recovery behavior
```

---

## Step 17 — AI audit

If an AI agent contributed, explicitly ask it to analyze the crash windows in the 2PC coordinator and participant state machines.

Check for these common generated-code errors:

- YES response before prepared state is durable;
- global COMMIT returned to client before decision state is recoverable;
- unilateral abort by a prepared participant after timeout;
- new transaction ID on retry;
- duplicate COMMIT applies the mutation again;
- participant loses its prepared transaction on restart.

Document at least one issue you verified, corrected, or rejected.

---

## Transparent-test target

The intended public tests are documented under:

```text
tests/official/README.md
```

Executable public tests now live under `tests/official/`, with deterministic routing and 2PC state-machine helpers in `starter/src/`. They verify ownership epochs, stable transaction decisions, and idempotent protocol messages; real coordinator/participant crash windows and rebalancing remain evidence-based.

No hidden cases are planned.

You may add cases under `tests/student/`.

---

## Submission

Submit:

- source code;
- routing/ownership configuration;
- reproducible run instructions;
- `REPORT.md`;
- machine-readable transaction traces;
- public/student tests;
- AI-use disclosure.

## Success criterion

A successful submission can clearly state:

> This data is owned by these shards; these operations remain local; this operation spans these participants; this durable state supports one global 2PC decision under the tested crash model; and this alternative workflow uses compensation instead of pretending to be atomic.