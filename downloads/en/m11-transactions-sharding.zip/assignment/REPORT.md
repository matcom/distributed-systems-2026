# Laboratory Report — Distributed Transactions, Partitioning, and Sharding

## 1. Environment

Document:

- OS/platform;
- language/runtime version;
- shard count;
- replica count per shard if applicable;
- persistence paths;
- transaction coordinator configuration;
- exact startup/teardown commands.

## 2. Data ownership model

Describe:

- partition key;
- routing function;
- ownership metadata;
- ownership epoch/version;
- why this partitioning matches the workload.

Include at least six key→shard examples.

## 3. Local-shard baseline

Record:

- operation;
- shard touched;
- message/RPC count;
- median latency;
- p95 latency where available.

Explain why the operation remains local.

## 4. Cross-shard invariant

State the application invariant spanning several owners.

For example:

```text
A decreases by amount
AND
B increases by amount
```

List invalid partial outcomes.

## 5. Transaction state machine

Document coordinator and participant states.

Example participant states:

```text
NEW
PREPARED
COMMITTED
ABORTED
```

Explain which transitions must survive restart.

## 6. Successful 2PC trace

Provide one full normal execution with stable transaction ID.

Mark:

- PREPARE messages;
- participant YES/NO votes;
- durable global decision;
- participant COMMIT/ABORT application;
- client response.

## 7. Local versus cross-shard cost

Compare both paths using a table:

| Metric | Local | Cross-shard |
|---|---:|---:|
| participants | | |
| protocol rounds | | |
| messages/RPCs | | |
| median latency | | |
| p95 latency | | |

Explain the difference structurally.

## 8. Duplicate protocol messages

Document duplicated PREPARE/COMMIT/ABORT experiments.

Show that stable transaction identity prevents duplicate logical effects or contradictory decisions.

## 9. Coordinator crash before decision

Record:

- participant votes;
- coordinator state at crash;
- participant recoverable PREPARED state;
- locks/reservations held;
- observed blocking behavior;
- recovery procedure.

Explain why timeout does not determine the global outcome.

## 10. Coordinator crash after durable COMMIT

Show:

```text
durable COMMIT exists
one participant receives it
coordinator crashes
coordinator recovers
same COMMIT is retransmitted
all participants finish
```

Identify the record that prevents the coordinator from choosing a different result after restart.

## 11. Participant crash while PREPARED

Document what participant state survives and how the participant completes after recovery.

If durability is simulated rather than physically persisted, state that limitation.

## 12. Concurrency/isolation

Describe the chosen concurrency-control mechanism.

Run two transactions sharing at least one key.

Report:

- observed wait/abort/retry behavior;
- whether atomicity held;
- the isolation claim you can honestly make.

Explicitly distinguish this from 2PC atomic commit.

## 13. Saga comparison

Describe the workflow and compensations.

Include:

- successful local steps;
- failing step;
- compensation sequence;
- one compensation timeout/retry;
- stable compensation request identity if used.

Explain why the history is not equivalent to rollback.

## 14. Rebalancing

Document:

- old owner/epoch;
- transfer procedure;
- write handling during movement;
- new owner/epoch;
- stale-router behavior.

Show one write around the cutover boundary and where it ends up.

## 15. Hot-shard or scatter/gather experiment

Record workload and latency/queue evidence.

Explain how partitioning—not only CPU speed—caused the observed behavior.

## 16. Fault campaign matrix

| Scenario | Prediction | Observed result | Atomicity | Availability/liveness | Recovery evidence |
|---|---|---|---|---|---|
| participant votes NO | | | | | |
| duplicate PREPARE/COMMIT | | | | | |
| coordinator crash before decision | | | | | |
| coordinator crash after COMMIT | | | | | |
| participant crash PREPARED | | | | | |
| delayed decision timeout | | | | | |
| conflicting transactions | | | | | |
| stale router during migration | | | | | |

## 17. Architectural alternative

Answer:

> Could a different partition key eliminate the distributed transaction in the common case?

If yes, describe the redesign. If no, explain why the invariant naturally spans ownership boundaries.

## 18. AI-use disclosure

Record:

- tools used;
- tasks delegated;
- transaction/rebalancing code affected;
- tests/experiments used for verification;
- at least one AI suggestion corrected, rejected, or experimentally audited.

## 19. Limits

State what the experiment does not prove, such as:

- full serializability;
- arbitrary multi-datacenter durability;
- Byzantine coordinator behavior;
- production-scale rebalancing;
- atomicity of unrelated external systems.

## 20. Final technical claim

Write one concise paragraph answering:

> Which operations are local, which require cross-shard coordination, what atomicity/isolation guarantees does the implementation provide, and under which crash windows can progress block?