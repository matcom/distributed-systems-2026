<p class="ds-book-part">Part IV — Fault Tolerance</p>
<p class="ds-module-kicker">Chapter 11</p>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 11 of 12</span>
    <span>92% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 92%"></span></div>
</div>
<p class="ds-guiding-question">What happens when one logical operation changes state owned by several independently failing machines?</p>

Partitioning state creates several authorities. A formerly local transition may now require atomic commit, durable recovery records, replay, compensation, state transfer, or ownership movement. Trace the crash points before choosing the mechanism.

## Key ideas

- partitioning and sharding
- consistent hashing and ownership
- durable decision records
- two-phase commit
- prepared state and blocking
- coordinator/participant recovery
- replay and duplicate protocol messages
- sagas and compensation
- snapshots/state transfer as recovery tools
- rebalancing and cross-shard operations

## Laboratory transition

Shard the service, add one cross-owner operation, crash the coordinator at several protocol points, restart it, and use durable evidence to justify the final outcome.

## Start here

> **Before you read:** A transfer debits one shard and must credit another. The coordinator crashes after the debit prepares. Which facts must be durable before any participant can decide?

**Bring forward:** Replication, agreement, and crash-recovery reasoning.

**This chapter builds toward:** A recovery model for operations that cross independently owned state.

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>35 min–50 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>50 min–1 h 15 min</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>2 h 30 min–3 h 30 min · 10 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<p class="ds-workload-note"><strong>Core scope:</strong> The core lab path is Steps 1–14 plus the Step 16 fault campaign. Step 15 is a performance extension, and the AI audit is required only when AI contributed. Steps 12–14 are focused comparison/recovery checkpoints, not separate production systems.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Read lesson →</a>
  <a class="ds-secondary-action" href="lab/">Open laboratory</a>
</div>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../downloads/en/m11-transactions-sharding.zip" download>Download chapter + laboratory for offline study (.zip)</a></p>

## What you will learn

- Explain how partitioning turns one logical system into several state authorities.
- Compare local and cross-owner operations and identify when atomic coordination is required.
- Trace two-phase commit through coordinator/participant failure and durable recovery.
- Compare blocking atomic commit with saga/compensation-style workflows.
- Reason about snapshots/state transfer, duplicate protocol messages, rebalancing, and ownership movement.

## Learn by working the question

1. Write your answer to **Start here** before opening the full lesson.
2. Read until the next prediction or trace, then stop and work it out before revealing the explanation.
3. Treat guided practice as a **practice bank**, not a speed worksheet. Work the core traces until you can meet the chapter's Practice target; return to the remaining cases for retrieval practice or instructor-assigned work.
4. Use the knowledge check to find gaps, then enter the laboratory with a falsifiable prediction and name the evidence that could contradict it.
5. Finish by explaining what the experiment established, what it did not establish, and how the result changes the evolving service.

<nav class="ds-sequence" aria-label="Course sequence">
<a class="ds-sequence-link" href="../m07-failures/">← Fault Tolerance I — Failure Models, Resilience, and Recovery</a>
<a class="ds-sequence-link next" href="../m15-security-byzantine/">Security, Trust, and Operating Distributed Systems →</a>
</nav>
