> **Reference view.** This page is optional context; return to the [Lesson](../lesson/) for the required path.

## Essential

- **●●● Notes on Data Base Operating Systems** — Jim Gray. [classic reference](https://jimgray.azurewebsites.net/papers/DBOS.pdf)

## Recommended

- **●●● Consistent Hashing and Random Trees** — David Karger et al.. [paper](https://www.cs.princeton.edu/courses/archive/fall09/cos518/papers/chash.pdf)
- **●● Designing Data-Intensive Applications** — Martin Kleppmann. [book](https://dataintensive.net/)

## Advanced

- **●●● Spanner: Google's Globally-Distributed Database** — Corbett et al.. [paper](https://research.google/pubs/spanner-googles-globally-distributed-database/)
- **●●● Dynamo: Amazon's Highly Available Key-value Store** — DeCandia et al.. [paper](https://www.allthingsdistributed.com/files/amazon-dynamo-sosp2007.pdf)

## Tools & Practice

- **● The Go Documentation** — The Go Project. [tool documentation](https://go.dev/doc/)

## Explore

- **●●● 6.5840 Distributed Systems** — MIT PDOS. [course](https://pdos.csail.mit.edu/6.824/)
