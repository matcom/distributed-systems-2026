<p class="ds-book-part">Part II — Communication and Coordination</p>
<p class="ds-module-kicker">Chapter 7</p>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 7 of 12</span>
    <span>58% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 58%"></span></div>
</div>
<p class="ds-guiding-question">When do ordering, exclusive access, leader election, and consensus require different mechanisms?</p>

Start with coordination problems that look similar but demand different guarantees. Compare centralized, permission-based, and token-style mutual exclusion; trace a classical leader election; then ask why choosing a leader is still not enough to make replicated state safe.

## Key ideas

- distributed mutual exclusion
- permission and token approaches
- classical leader election intuition
- Bully/ring-style comparison
- agreement, validity, and termination
- quorum intersection
- Raft terms, votes, and leader election
- replicated logs and commit rules
- Paxos/Multi-Paxos as comparison
- partition behavior

## Laboratory transition

Trace election and mutual-exclusion cases by hand, then run the Raft election/log checkpoints. For each execution, state whether you established a coordinator, exclusive access, or replicated agreement.

## Start here

> **Before you read:** One algorithm chooses who coordinates; another prevents two nodes entering a critical section; another makes replicas agree on a log. Why are these not the same problem?

**Bring forward:** Causality from Chapter 6 and the difference between silence and failure from earlier timeout examples.

**This chapter builds toward:** A progression from mutual exclusion and elections to quorum-based replicated agreement.

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>45 min–1 h</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>1 h–1 h 30 min</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>3 h–4 h · 14 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<p class="ds-workload-note"><strong>Core scope:</strong> This is intentionally the heaviest coordination chapter. The core lab path is the required warm-up, Checkpoints A–B, Steps C–F, bounded schedule exploration in Step I, transparent tests, and the report; Steps G–H remain extensions.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Read lesson →</a>
  <a class="ds-secondary-action" href="lab/">Open laboratory</a>
</div>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../downloads/en/m09-consensus.zip" download>Download chapter + laboratory for offline study (.zip)</a></p>

## What you will learn

- Distinguish distributed mutual exclusion, leader election, and consensus as different coordination problems.
- Compare centralized, permission/token, and classical election mechanisms by their assumptions and failure behavior.
- Explain agreement, validity, termination, quorum intersection, and the safety/liveness split.
- Implement and reason about Raft-style election, terms, replicated logs, and commit rules.
- Use explicit invariants and bounded schedule exploration to expose unsafe coordination histories and explain why leader election alone does not make replicated state safe.

## Learn by working the question

1. Write your answer to **Start here** before opening the full lesson.
2. Read until the next prediction or trace, then stop and work it out before revealing the explanation.
3. Treat guided practice as a **practice bank**, not a speed worksheet. Work the core traces until you can meet the chapter's Practice target; return to the remaining cases for retrieval practice or instructor-assigned work.
4. Use the knowledge check to find gaps, then enter the laboratory with a falsifiable prediction and name the evidence that could contradict it.
5. Finish by explaining what the experiment established, what it did not establish, and how the result changes the evolving service.

<nav class="ds-sequence" aria-label="Course sequence">
<a class="ds-sequence-link" href="../m06-time-causality/">← Coordination I — Time, Events, and Causality</a>
<a class="ds-sequence-link next" href="../m04-architecture-discovery/">Naming, Discovery, and Decentralized Lookup →</a>
</nav>
