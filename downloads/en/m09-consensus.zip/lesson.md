<p class="ds-book-part">Part II — Communication and Coordination</p>
<div class="ds-lesson-banner">
  <div><span>Course step</span><strong>Chapter 7</strong></div>
  <div><span>Core reading</span><strong>45 min–1 h</strong></div>
  <div><span>Required path</span><strong>Read → Practice target → Check → Lab</strong></div>
</div>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 7 of 12</span>
    <span>58% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 58%"></span></div>
</div>

> **Guiding question:** When do ordering, exclusive access, leader election, and consensus require different mechanisms?

## Before you read

> One algorithm chooses who coordinates; another prevents two nodes entering a critical section; another makes replicas agree on a log. Why are these not the same problem?

Write a short answer first. You are not expected to be correct yet; you need a prediction you can revise as the chapter gives you better models and evidence.

**Use what you already know:** Causality from Chapter 6 and the difference between silence and failure from earlier timeout examples.

## Workload map

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>45 min–1 h</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>1 h–1 h 30 min</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>3 h–4 h · 14 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<p class="ds-workload-note"><strong>Core scope:</strong> This is intentionally the heaviest coordination chapter. The core lab path is the required warm-up, Checkpoints A–B, Steps C–F, bounded schedule exploration in Step I, transparent tests, and the report; Steps G–H remain extensions.</p>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../../downloads/en/m09-consensus.zip" download>Download lesson + practice + lab for offline study (.zip)</a></p>

## Why this chapter matters

Several coordination problems are easy to confuse:

- **mutual exclusion** asks who may enter a critical section now;
- **leader election** asks which participant should coordinate a role;
- **consensus** asks correct participants to agree on a decision or evolving history despite failures.

A centralized lock can provide exclusion without replicated agreement. A Bully- or ring-style election can select a coordinator without proving that replicated logs are safe. A token can serialize access while becoming its own recovery problem.

Trace those distinctions first. Then use Raft to see what agreement adds beyond simply choosing a leader.

## Coordination ladder: exclusion, election, then agreement

### Mutual exclusion coordinates access to one logical critical section

Suppose three processes must update a resource that cannot safely accept concurrent writers.

A **central coordinator** can grant permission:

```text
P1 → coordinator: request
coordinator → P1: grant
P1 → coordinator: release
```

This is easy to understand, but the coordinator is now a liveness dependency. If it crashes after granting permission, recovery must determine whether the old grant is still valid.

A **permission-based** design asks peers for permission before entering. This removes one permanent coordinator but increases messages and makes membership assumptions important.

A **token-based** design gives one unique token the authority to enter:

```text
P1 → P2 → P3 → P1
        token
```

The token makes exclusion intuitive while creating a new recovery problem: what happens if the holder crashes or the token appears lost? Re-creating a token carelessly can create two valid-looking tokens and violate safety.

The important lesson is not to memorize three algorithms. It is to separate:

```text
safety: at most one process in the critical section
liveness: a correct requester eventually enters
```

### Leader election chooses a coordinator, not a committed history

A **Bully-style** election uses ordered process identifiers. When a participant believes the coordinator is unavailable, it contacts higher-ID participants. If none respond, it declares itself coordinator; otherwise a higher participant continues the election.

A **ring-style** election circulates candidate identifiers through a logical ring until a winner is known.

These algorithms illustrate useful ideas:

- election depends on a membership view;
- silence is interpreted through timeout assumptions;
- different participants can temporarily have different views;
- choosing a coordinator does not by itself reconcile application state.

> **Pause and predict.** A ring election chooses node C as coordinator while an isolated old coordinator A is still running. Has the system already solved the problem of which of A's or C's writes are authoritative? No: election selected a role; agreement still needs a rule for state/history.

### Consensus couples authority to preserved decisions

Consensus adds a stronger requirement: a new coordinator cannot simply start a fresh history. It must preserve decisions that were already made safely.

That is the bridge to Raft:

```text
mutual exclusion → who may act now?
leader election  → who coordinates now?
consensus        → which decisions remain authoritative across leader changes?
```

Replication will soon give us a difficult problem: keeping several copies of state is useful only if their decisions can be reconciled safely.

We can keep several copies of state, but a replicated service often needs one authoritative order for updates.

Suppose five replicas receive two concurrent commands:

```text
set x = 7
set x = 9
```

If different replicas permanently apply those commands in different orders, they may end in different states.

A primary can serialize requests—but only while everyone agrees which process is the primary.

Now introduce failure:

```text
leader L becomes unreachable
```

Some nodes believe L crashed. Others can still communicate with L. The network may be partitioned. A replacement leader may be elected. Old messages may still arrive.

The challenge is no longer merely to detect failure.

It is:

> **How can independent nodes agree on one evolving sequence of decisions despite crashes and partitions?**

This is the consensus problem.

Consensus underlies many strongly consistent replicated services, coordination systems, metadata services, and fault-tolerant control planes.

This chapter uses **Raft** for the principal implementation model because it decomposes consensus into understandable pieces: leader election, log replication, and safety restrictions. Paxos and Multi-Paxos are included so you understand that Raft is one member of a broader family of consensus approaches rather than the definition of consensus itself.

---

<aside class="ds-book-note ds-history">
  <span class="ds-book-note-label">History</span>
  <strong>Consensus research separated safety from progress and clarified what agreement can mean under uncertainty</strong>
  <p>Paxos, FLP, and related work established the modern language for reasoning about agreement, failure assumptions, quorum intersection, and the difference between what must never happen and what may temporarily stop happening.</p>
  <a class="ds-book-note-source" href="../../../history/paxos-consensus/">Read the design history →</a>
</aside>

## 1. Consensus is agreement on a decision under failure

A single consensus instance asks several nodes to agree on one value.

A useful introductory set of properties is:

### Agreement

Correct participants do not decide different values for the same consensus instance.

### Validity

The decided value must satisfy the protocol's validity rule—typically relating the decision to proposed values rather than inventing an arbitrary value.

### Termination

Under the timing/failure assumptions required for liveness, correct participants eventually decide.

The exact formal definitions vary by consensus model, but the engineering distinction is crucial:

```text
safety: do not decide conflicting values
liveness: eventually decide something
```

During severe failures, a consensus protocol may preserve safety while temporarily losing liveness.

---

## 2. Replicated services need repeated consensus, not only one decision

A key/value service does not decide only one value for its entire lifetime.

It needs an ordered sequence:

```text
index 1: PUT x=1
index 2: PUT y=8
index 3: DELETE x
index 4: PUT z=4
...
```

This leads to a **replicated log** abstraction.

If replicas agree on the same committed command at each log index and later execute commands deterministically, they can build a replicated state machine. Fault-tolerance chapters will revisit persistence, replay, snapshots, and recovery.

So a practical consensus service often solves:

> agreement on an evolving log prefix.

---

<figure class="ds-book-figure">
  <img src="../../../assets/book/m09-quorum-partition.svg" alt="A five-node cluster partitioned into a minority of two and a majority of three." loading="lazy" decoding="async" />
  <figcaption><span>Figure</span>A leader can remain alive in a minority and still be unable to commit. Majority intersection is about authoritative evidence, not about who still believes they are leader.</figcaption>
</figure>

## 3. Leader election alone is not consensus

Many systems elect a leader.

But merely selecting one process at one instant does not solve all consensus requirements.

Questions remain:

- Can two leaders exist temporarily?
- Which leader's writes are authoritative?
- What if the old leader returns?
- How do logs from different terms reconcile?
- Which entries are committed?

A leader-election algorithm can be useful without providing a replicated log.

Raft integrates election with log safety so leadership is meaningful for a replicated state machine.

---

## 4. Application-level voting is not distributed consensus

Suppose three AI agents vote on an answer:

```text
agent A -> answer X
agent B -> answer X
agent C -> answer Y
majority -> X
```

This is an application decision rule.

It does not automatically provide:

- agreement among distributed replicas under message loss;
- durable decided state;
- recovery after crashes;
- leader epochs;
- log-prefix safety;
- protection from stale participants.

Similarly, three users voting in a web application are not implementing Raft.

Consensus is a protocol with explicit failure assumptions and safety/liveness properties.

---

## 5. Why majorities matter

For N replicas, a strict majority contains more than half the nodes.

Examples:

```text
N=3 -> majority=2
N=5 -> majority=3
N=7 -> majority=4
```

Any two strict majorities intersect.

For N=5:

```text
majority A = {1,2,3}
majority B = {3,4,5}
intersection = {3}
```

This intersection is powerful because information accepted by one majority cannot be completely invisible to every later majority.

Majority intersection is only one ingredient. The protocol must specify **what information an intersecting node must preserve and how future leaders use it**.

---

## 6. A 5-node cluster tolerates two unavailable nodes for majority progress

With five nodes, a leader needs communication with at least two followers to form a majority of three.

Therefore:

```text
5 nodes
2 unavailable
3 remain -> majority possible
```

If only two can communicate:

```text
2/5 -> no majority
```

The cluster should preserve safety but cannot normally commit new consensus decisions requiring a majority.

This is an example of sacrificing liveness/availability under partition to protect agreement.

---

## 7. Partitions make “who is leader?” observer-relative

Suppose a five-node cluster splits:

```text
A B C   X   D E
```

Before the split, D may have been leader.

D can still believe it is leader temporarily.

But D and E contain only two of five nodes. They cannot form a majority.

A/B/C can eventually elect a new leader because they contain three nodes.

For a period, therefore:

```text
D may locally think "leader"
new node in ABC may think "leader"
```

How can safety survive this apparent two-leader situation?

Because **leadership belief alone does not authorize commitment**. Terms, majority acknowledgement, and log rules determine which operations can become committed.

This is an essential mental model.

---

## 8. Raft organizes time into terms

Raft associates activity with monotonically increasing **terms**.

Conceptually:

```text
term 1
term 2
term 3
...
```

A term usually begins with an election. At most one leader should be elected for a term under the voting rules, though some terms may end with no leader because of split votes or failures.

Every message carries a term.

Terms provide an epoch mechanism.

A node seeing a larger term learns that its current leadership/election information is stale.

---

## 9. Raft nodes have three main roles

At a high level:

```text
Follower
Candidate
Leader
```

### Follower

Responds to leaders/candidates and waits for valid leader communication.

### Candidate

Starts an election after an election timeout, increments its term, votes for itself, and requests votes.

### Leader

Accepts/coordinates log replication and sends AppendEntries messages, including heartbeat-like empty AppendEntries.

Roles can change repeatedly over process lifetime.

---

## 10. Election timeouts turn silence into a liveness trigger

Chapter 10 taught that silence cannot prove leader death.

Raft does not require perfect proof.

A follower that stops receiving valid leader communication for long enough may start a new election.

This is a liveness decision based on suspicion.

If the old leader was merely slow, the term mechanism allows higher-term information to force stale leadership to step down.

This is a key pattern:

> **Failure detection may be imperfect while protocol safety is protected by epochs/terms and quorum rules.**

---

## 11. Randomized election timeouts reduce repeated split votes

If every follower timed out at exactly the same instant, many could become candidates together.

In a 5-node cluster:

```text
candidate A gets {A,B}
candidate C gets {C,D}
E undecided
```

No candidate reaches three votes.

Raft uses randomized election timeouts so one candidate is likely to start earlier, contact followers, win a majority, and begin sending heartbeats before others time out.

Randomization helps liveness; it is not the primary safety mechanism.

---

## 12. A node votes at most once per term

One important persistent rule is:

> A server grants at most one vote in a given term.

Suppose a 5-node cluster elected two leaders in the same term.

Each would need a majority of at least three votes.

The two majorities must intersect.

The intersecting node would have had to vote for both candidates in the same term, violating the one-vote-per-term rule.

Thus majority intersection plus stable vote state protects election uniqueness for a term.

---

## 13. `currentTerm` and `votedFor` are safety-relevant persistent state

If a node crashes and forgets that it already voted in term 8, it could restart and grant another vote in term 8.

That would violate the intended election safety argument.

Therefore Raft implementations persist critical metadata such as:

```text
currentTerm
votedFor
log
```

before relying on those updates as stable protocol state.

The fault-tolerance chapters will expand the storage and recovery implications.

---

## 14. Higher terms invalidate stale authority

Suppose leader L is in term 5.

A partition isolates L while a majority elects a new leader in term 6.

Later L receives a message carrying term 6.

L must recognize that its term-5 authority is stale and step down.

This prevents a returned old leader from indefinitely acting as if its previous authority still applies.

Terms are therefore closely related to the incarnation/epoch ideas introduced earlier.

---

## 15. Elections must consider log freshness

Electing an arbitrary majority candidate is not enough for replicated-log safety.

Suppose candidate A has an old log while candidate B contains entries that were previously committed.

If A could become leader and overwrite the committed history, agreement would fail.

Raft therefore restricts voting using a candidate's last-log term/index so voters reject candidates whose logs are not sufficiently up to date according to the protocol's rule.

This is the bridge from **leader election** to **leader completeness**.

The leader is not selected solely because it is alive or fast.

It must also be safe with respect to replicated history.

---

## 16. Log entries carry an index and term

A simplified Raft log entry contains:

```text
index
term
command
```

Example:

```text
1 term1 PUT x=1
2 term1 PUT y=4
3 term2 DELETE x
4 term3 PUT z=8
```

The index identifies position in the ordered log.

The term identifies the leadership epoch that created the entry.

Both matter for detecting conflicting histories.

---

## 17. AppendEntries replicates the log and checks prefix continuity

The leader sends followers AppendEntries containing information about the log position preceding new entries.

Conceptually:

```text
prevLogIndex
prevLogTerm
entries[]
leaderCommit
```

A follower accepts new entries only when the preceding log position matches the expected term/index condition.

This consistency check prevents the leader from blindly appending onto an incompatible prefix.

If the follower's log conflicts, the leader backs up and repairs the suffix until the logs match at the boundary.

---

## 18. Heartbeats are not a separate magical message type

In Raft, a heartbeat can be understood as AppendEntries with no new log entries.

It still carries important metadata such as term and commit information.

This is worth emphasizing because it is easy to implement a disconnected “heartbeat subsystem” whose semantics drift away from the actual log protocol.

Leader liveness signaling and log replication belong to one authority mechanism.

---

## 19. Log matching gives a shared-prefix property

A central Raft property is roughly:

> If two logs contain an entry with the same index and term, then their preceding entries are the same.

The AppendEntries consistency check and leader repair rules support this property.

This lets a leader reason about follower prefixes rather than compare whole logs on every message.

---

## 20. Followers may contain uncommitted entries that later disappear

Consider an old leader that replicated entry X to only one follower before losing leadership.

```text
old leader: ... X
follower:   ... X
other nodes: ...
```

If X never became committed, a later legitimate leader may carry a different entry at that position and overwrite the conflicting uncommitted suffix.

You may treat “written to a log file” as equivalent to “committed.”

It is not.

```text
present locally != committed by consensus
```

Later recovery work will distinguish durable local log state from committed application state.

---

## 21. Commitment requires quorum evidence

A leader tracks replication progress, commonly using follower match indexes.

A log entry becomes eligible for commitment when the protocol's commit rule is satisfied by a majority and the relevant term restrictions hold.

For a five-node cluster, an entry replicated on:

```text
leader + two followers
```

has reached three nodes—a majority.

But Raft's commitment rule is more subtle than “any entry stored on a majority is immediately committed.”

The term of the entry matters for how a leader advances `commitIndex` safely.

---

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosity</span>
  <strong>Two processes can both believe they are leader without two conflicting values becoming committed</strong>
  <p>During a partition an old leader may continue acting on stale authority while a majority elects a newer-term leader. Consensus safety depends on terms, quorum intersection, and commit rules—not on a mystical guarantee that only one process ever thinks it leads.</p>
  <p><strong>Try it:</strong> Partition a five-node cluster into 2+3 and explain which side can create a new committed entry and why the minority's old leader cannot.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">More chapter curiosities →</a>
</aside>

## 22. Why the current-term commit rule matters

A Raft leader advances commit based directly on majority replication of an entry from its **current term**.

Once a current-term entry is committed, earlier entries in the leader's log become committed through the log-prefix safety argument.

This rule avoids unsafe reasoning about older-term entries that happen to be present on a majority under complicated leader-change histories.

For the course implementation, you should follow the Raft paper's commit rule rather than simplify it to:

```text
if any log index exists on majority -> committed
```

That shortcut can break safety.

---

## 23. `commitIndex` and `lastApplied` are different

A node may know that entries through index K are committed but not yet have applied every one to its application state machine.

Two useful variables are:

```text
commitIndex
lastApplied
```

The node applies committed log entries in order:

```text
while lastApplied < commitIndex:
    lastApplied++
    apply(log[lastApplied])
```

This distinction becomes central when you add durable recovery.

Consensus determines **which commands are committed and in what order**.

The state machine executes those commands.

---

## 24. Leader state tracks follower replication progress

A typical leader keeps per-follower state such as:

```text
nextIndex[follower]
matchIndex[follower]
```

### `nextIndex`

The next log index the leader expects to send to that follower.

### `matchIndex`

The highest log index known replicated on that follower.

When AppendEntries fails because a follower's prefix does not match, the leader adjusts `nextIndex` backward until it finds a matching point, then repairs the follower's suffix.

Optimizations can accelerate this, but the conceptual behavior is enough for the undergraduate implementation.

---

## 25. Worked example — split vote

Five nodes A–E start in term 4.

A and C time out nearly together and each start term 5.

Votes:

```text
A: A,B
C: C,D
E: no vote yet
```

Neither has majority 3.

Eventually another election timeout occurs.

Suppose C times out first, increments to term 6, and requests votes.

Nodes seeing term 6 update their term and may vote according to the normal rules.

C obtains C,D,E and becomes leader term 6.

Safety was never violated because no two candidates both obtained majorities in the same term.

---

## 26. Worked example — old leader in minority partition

Initial leader A, term 8:

```text
A B C D E
```

Partition:

```text
A B   X   C D E
```

A remains leader locally in term 8 but cannot replicate new entries to a majority.

C/D/E elect D in term 9.

D can commit new entries using three-node majority.

When partition heals, A receives term-9 information and steps down.

Any uncommitted term-8 suffix conflicting with D's log is repaired.

The important result is:

> Temporary leadership belief on the minority side does not imply ability to commit new authoritative state.

---

## 27. Worked example — stale candidate denied a vote

Suppose three nodes have:

```text
A log: [1:t1, 2:t2, 3:t4]
B log: [1:t1, 2:t2, 3:t4]
C log: [1:t1, 2:t2]
```

C times out and requests votes for a new term.

Although C may have a higher current election term after incrementing, its log is less up to date than A/B according to the Raft log freshness rule.

A and B should reject C's vote request.

This prevents a candidate missing the newer log entry from becoming leader merely by timing out first.

---

## 28. Worked example — conflicting follower suffix

Leader L has:

```text
1:t1 2:t1 3:t2 4:t4 5:t4
```

Follower F has:

```text
1:t1 2:t1 3:t2 4:t3 5:t3 6:t3
```

The logs agree through index 3 and diverge afterward.

L cannot simply append index 6.

It must find the matching prefix boundary, delete/replace the conflicting suffix at F, and replicate its own authoritative suffix:

```text
1:t1 2:t1 3:t2 4:t4 5:t4
```

assuming L is the legitimate leader under the full protocol.

---

## 29. Election safety and state-machine safety are different properties

It is useful to separate Raft safety properties conceptually.

### Election safety

At most one leader can be elected in a given term.

### Leader append-only

A leader does not overwrite/delete entries in its own log; it appends new ones.

### Log matching

Matching term/index entries imply matching prefixes.

### Leader completeness

Committed entries appear in the logs of future leaders.

### State-machine safety

Different servers do not apply different commands for the same log index.

The exact formal statements belong in the Raft paper. The educational point is that “Raft is safe” decomposes into several invariants that can be tested and reasoned about separately.

---

## 30. Safety should not depend on favorable timing

Election timeouts influence when elections happen.

They should not determine whether conflicting values can become committed.

This is a core consensus design principle:

> **Timing assumptions may be required for liveness, but safety should survive arbitrary delay/reordering within the protocol's failure model.**

A very slow network may prevent progress.

It should not cause two different commands to become committed at one index.

---

## 31. FLP gives important context about liveness

The Fischer-Lynch-Paterson impossibility result shows that deterministic consensus cannot guarantee termination in a fully asynchronous system with even one crash failure under the standard model.

For this course, the key takeaway is not the proof.

It is:

> **There is a fundamental difference between preserving agreement and guaranteeing progress under completely unbounded uncertainty.**

Practical protocols use additional assumptions/mechanisms such as partial synchrony, timeouts, leaders, randomized timing, or failure detectors to obtain useful liveness.

Raft's election timeouts should therefore be understood as part of a practical liveness strategy, not as perfect failure knowledge.

---

## 32. Paxos solves the same fundamental agreement problem differently

Paxos is historically foundational.

A single-decree/basic Paxos explanation typically introduces roles such as proposers, acceptors, and learners, and uses numbered proposals/ballots plus quorum intersection to preserve agreement.

The protocol is often presented through two conceptual phases:

```text
prepare/promise
accept/accepted
```

with rules ensuring later proposals preserve already chosen values.

The details differ from Raft, but the shared ideas include:

- quorum intersection;
- monotonically increasing ballot/epoch information;
- preserving prior accepted/committed information;
- safety despite message loss/reordering/crash failures.

---

## 33. Multi-Paxos optimizes repeated decisions around stable leadership

Running a full independent Paxos instance for every log slot can be expensive.

Multi-Paxos uses a stable leader/coordinator pattern so repeated log decisions can proceed efficiently after leadership is established.

This makes the practical architecture resemble leader-based replicated logs more closely.

The course does not require implementing Paxos unless a student explicitly chooses it for an advanced/final project.

You should still be able to compare the conceptual mechanisms with Raft.

---

## 34. Raft and Paxos should not be taught as “easy versus hard” slogans

Raft was explicitly designed for understandability and decomposes the problem differently.

Paxos has an enormous literature and many practical variants.

A useful comparison asks:

```text
How is an epoch/ballot represented?
How does quorum intersection preserve prior decisions?
How is a leader/coordinator established?
How are repeated log positions handled?
How is recovery performed?
```

The goal is not to declare one universally superior.

---

## 35. Leader leases are an optimization with time assumptions

Some systems use leases to let a leader answer certain requests without contacting a quorum every time.

A lease depends on assumptions about elapsed time and clock behavior.

Chapter 6 taught that logical clocks cannot measure seconds; Chapter 10 taught that delays create uncertainty.

Therefore lease-based optimizations must state their timing model carefully.

The base Chapter 7 Raft implementation should not require lease optimizations.

Correctness first, optimization later.

---

## 36. Consensus does not solve every distributed problem

Consensus can establish one ordered sequence of decisions, but it does not automatically provide:

- efficient sharding;
- application-level transactions across independent groups;
- conflict-free offline editing;
- DHT routing;
- secure Byzantine tolerance;
- high-throughput analytics;
- application idempotency.

Consensus is a powerful mechanism with coordination cost.

Use it where the application needs the guarantees it provides.

---

## 37. Consensus does not remove RPC ambiguity for clients

Suppose a client submits command R7 to the leader.

The leader replicates and commits R7.

Before the response reaches the client, the connection fails.

The client still sees:

```text
timeout
```

Consensus may know R7 was committed, but the client does not.

If the client retries, the state machine must recognize the duplicate logical operation.

Thus Chapter 4's request-ID/idempotency problem survives consensus.

Later fault-tolerance work carries this solution into replicated state-machine recovery.

---

## 38. Persist-before-reply boundaries matter

Suppose a follower grants a vote but replies before durably recording `votedFor`.

It crashes, restarts, forgets the vote, and grants another vote in the same term.

A seemingly small storage-order optimization can break election safety.

Likewise, appending a log entry to volatile memory and acknowledging replication before durable persistence may violate the intended crash-recovery model.

Consensus implementation is therefore also a storage-ordering problem.

---

## 39. Testing consensus requires adversarial schedules

A protocol that works with:

```text
leader starts first
network has no delay
one request at a time
no crashes
```

has demonstrated very little.

Useful tests include:

- simultaneous election timeouts;
- message delay/reordering;
- candidate restart;
- leader partition;
- minority old leader;
- conflicting uncommitted suffixes;
- follower lag;
- crash after vote persistence boundary;
- repeated client requests;
- partition healing.

The lab asks you to predict expected terms/logs before injecting faults.

---

## 40. Invariants are more useful than line-by-line debugging

When Raft fails, ask which invariant was violated.

Examples:

```text
voted twice in same term
accepted stale leader term
committed without majority
future leader missing committed entry
applied different command at same index
```

Then trace backward to the implementation transition that allowed it.

This is more scalable than staring at thousands of heartbeat log lines.

---

## 41. Observability should expose protocol state transitions

Useful structured events include:

```text
node
term
role
leader_id
voted_for
last_log_index
last_log_term
commit_index
message type
peer
request_id
```

Do not log entire state on every heartbeat by default; that creates noise.

Log meaningful transitions:

- term increase;
- role change;
- vote granted/rejected;
- AppendEntries conflict;
- commit index advance;
- leadership lost.

Chapter 12 later formalizes observability design.

---

## 44. Common mistakes

### Mistake 1 — majority vote means consensus

Consensus requires a protocol preserving decisions across failures and future rounds/terms.

### Mistake 2 — timeout proves leader death

Election timeout is a liveness trigger based on suspicion.

### Mistake 3 — heartbeat is separate from AppendEntries

In Raft, heartbeat behavior is normally empty AppendEntries carrying term/commit information.

### Mistake 4 — candidate with highest term should always win

Log freshness restrictions also matter.

### Mistake 5 — locally persisted entry means committed

Commit is a consensus property, not local disk presence.

### Mistake 6 — any majority-replicated old-term entry can be directly committed

Raft's current-term commit rule matters.

### Mistake 7 — minority old leader must immediately know it lost leadership

It may remain locally stale until higher-term evidence arrives; quorum inability prevents new commitment.

### Mistake 8 — randomized timeout is the safety mechanism

Randomization mainly improves election liveness by reducing collisions.

### Mistake 9 — consensus makes client retries exactly once

The client can still lose the response after commitment; deduplication remains necessary.

### Mistake 10 — passing normal-path tests demonstrates consensus correctness

Fault schedules and log-conflict histories are essential.

---

## Laboratory transition

The Chapter 7 laboratory begins with election only, then adds log replication.

You will repeatedly partition a five-node cluster and answer before running:

```text
Which nodes can form a majority?
Which term should win?
Can the old leader commit?
Which log entries may be overwritten?
Which entries must survive into future leaders?
```

Required evidence includes:

- one clean election;
- one split vote/re-election;
- one minority old-leader partition;
- one stale candidate rejected by log freshness;
- one conflicting follower log repaired;
- one entry committed on a majority;
- one client operation that becomes ambiguous because the response is lost after commitment.

---

## Chapter summary

1. **Consensus is a protocol-level agreement problem with safety and liveness properties.**
2. **Replicated services need agreement on a sequence/log, not just one value.**
3. **Leader election alone does not make replicated state safe.**
4. **Majority intersection ensures later quorums share at least one participant with earlier majorities, but protocol rules determine what information is preserved.**
5. **Raft terms provide epochs that invalidate stale authority.**
6. **Election timeouts trigger liveness actions without proving leader failure.**
7. **One vote per term plus majority intersection protects election safety.**
8. **Log freshness restrictions prevent stale candidates from replacing committed history.**
9. **AppendEntries enforces prefix compatibility and repairs conflicting uncommitted suffixes.**
10. **Locally stored entries are not necessarily committed.**
11. **Raft's current-term majority commit rule is safety-relevant.**
12. **Committed entries are applied later to a deterministic state machine.**
13. **Consensus safety should survive adverse timing; liveness requires additional timing/failure assumptions.**
14. **Paxos and Raft solve the same fundamental agreement class with different structures.**
15. **Consensus does not solve client exactly-once semantics, transactions, sharding, or Byzantine faults automatically.**

Keep the next question in mind for fault tolerance: **How does an agreed log become a useful service whose state survives crashes and retries?**

<div class="ds-next-action">
  <span>Core reading complete</span>
  <strong>Next required step · Guided practice</strong>
  <a href="../guided-practice/">Start guided practice →</a>
</div>
