> **Reference view.** This page is optional context; return to the [Lesson](../lesson/) for the required path.

## Essential

- **●● In Search of an Understandable Consensus Algorithm** — Diego Ongaro and John Ousterhout. [paper](https://raft.github.io/raft.pdf)

## Recommended

- **●●● Paxos Made Simple** — Leslie Lamport. [paper](https://lamport.azurewebsites.net/pubs/paxos-simple.pdf)

## Advanced

- **●●● Impossibility of Distributed Consensus with One Faulty Process** — Michael J. Fischer, Nancy A. Lynch, Michael S. Paterson. [paper](https://groups.csail.mit.edu/tds/papers/Lynch/jacm85.pdf)
- **●●● Viewstamped Replication Revisited** — Barbara Liskov and James Cowling. [paper](https://pmg.csail.mit.edu/papers/vr-revisited.pdf)

## Tools & Practice

- **●● The Raft Consensus Algorithm** — Raft community. [reference](https://raft.github.io/)

## Explore

- **●●● 6.5840 Distributed Systems** — MIT PDOS. [course](https://pdos.csail.mit.edu/6.824/)
