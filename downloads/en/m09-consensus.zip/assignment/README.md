# Laboratory — Consensus and Leader Election

## Target

Implement a small Raft-style consensus core in two checkpoints: first leader election, then replicated-log agreement. Run a five-node cluster under split votes, crashes, minority/majority partitions, stale candidates, and conflicting log suffixes.

The goal is not production Raft performance. The goal is to preserve explicit safety invariants while the message schedule becomes hostile.

## Core completion path

The required path is the coordination warm-up, Checkpoints A–B, Steps C–F, the bounded schedule exploration in Step I, transparent tests, and the report.

Steps G–H are **extensions**. Use them for comparison, discussion, or additional practice; they are not required to demonstrate the chapter's core outcomes.

## Required warm-up — prove which coordination problem you are solving

Before implementing Raft, work three short traces with the same five logical nodes.

### Trace 1 — mutual exclusion

Choose either a central grant or a token-style design. Show one normal critical-section entry and one coordinator/token-holder crash.

Record:

- what establishes exclusive authority;
- which event threatens liveness;
- which recovery action would accidentally create two authorities.

### Trace 2 — classical election

Use ordered node IDs and trace a Bully- or ring-style election after the current coordinator becomes unreachable.

Then keep the old coordinator alive in a minority partition.

State explicitly:

```text
new coordinator selected != old application history reconciled
```

### Trace 3 — agreement requirement

Give the old and new coordinators conflicting proposed commands at the same logical position.

Write the invariant you need before any command may become authoritative.

Only then begin the Raft checkpoints. The point of the warm-up is to make Raft answer a problem you can already state, rather than appear as a collection of terms and RPCs.

## Scope

Required:

- five-node configurable cluster;
- follower/candidate/leader roles;
- monotonically increasing terms;
- persistent `currentTerm` and `votedFor` according to the crash-recovery model;
- randomized election timeout;
- RequestVote request/response;
- higher-term step-down behavior;
- log entries carrying index, term, and command payload;
- AppendEntries request/response;
- prefix consistency checks;
- per-follower replication progress;
- conflicting uncommitted suffix repair;
- majority-based commitment following the Raft current-term rule;
- `commitIndex` output/handoff for Chapter 10.

Not required in Chapter 7:

- snapshots;
- membership reconfiguration;
- optimized conflict backtracking;
- lease reads;
- production-grade persistence engine;
- Byzantine tolerance;
- complete client KV state machine.

## Required observable state

Every node must make the following state visible through structured logs, a debug endpoint, or both:

```text
node_id
incarnation_id
role
current_term
voted_for
leader_id if known
last_log_index
last_log_term
commit_index
```

Leaders should additionally expose enough information to inspect:

```text
next_index[peer]
match_index[peer]
```

Do not print every heartbeat at full verbosity by default. Prefer meaningful transitions.

## Checkpoint A — Leader election

### Step A1 — follower baseline

Start five followers with empty/equivalent logs.

Verify that all begin with the same configured initial term/state and no elected leader.

Record startup persistence state.

### Step A2 — one clean election

Allow one follower's election timeout to expire first.

Record:

```text
term increment
candidate transition
self vote
RequestVote messages
votes granted/rejected
majority reached
leader transition
```

Before execution, predict the minimum number of votes required.

### Step A3 — one vote per term

Drive two candidates in the same term.

Verify each voter grants at most one vote.

Restart one voter after it has granted a vote and show that crash recovery does not permit a second vote in the same term if persistent state is configured correctly.

State the persistence boundary actually implemented.

### Step A4 — split vote

Manipulate election timing so two candidates divide votes and no majority forms.

Example target:

```text
A <- A,B
C <- C,D
E undecided or split by timing
```

Confirm no leader is elected from a non-majority.

Then allow a later term to begin and eventually elect a leader.

Measure election recovery time from the unresolved term to stable leadership.

### Step A5 — higher-term evidence

Take a leader in term T and deliver a valid message carrying term `T+1` or greater.

Verify that the stale leader/candidate updates its term and becomes follower as required.

### Step A6 — stale candidate log

Prepare:

```text
A/B: newer log
C: older log
```

Allow C to start an election with a higher current term.

Verify A/B reject the vote because C's log is not sufficiently up to date.

This test establishes that election is coupled to replicated-log safety.

## Checkpoint B — Log replication

### Step B1 — append one command

With one stable leader, submit a dummy command such as:

```text
SET x 1
```

The Chapter 7 command payload does not need to mutate application state yet.

Observe:

```text
leader append
AppendEntries to followers
follower prefix validation
successful replication
matchIndex updates
commitIndex advance
```

### Step B2 — majority commitment

For N=5, delay or isolate two followers while allowing the leader and two followers to communicate.

Submit one current-term command.

Verify it can become committed after replication to a majority of three.

Then isolate one additional follower so only two nodes remain connected and show that a new command does not become committed.

### Step B3 — follower lag

Keep one follower disconnected while several entries commit on the majority.

Reconnect it.

Observe the leader bringing it to the current prefix.

Measure catch-up time and number of AppendEntries attempts.

### Step B4 — conflicting suffix

Create or inject a controlled follower log with a stale uncommitted suffix, for example:

```text
leader:   1:t1 2:t1 3:t2 4:t4 5:t4
follower: 1:t1 2:t1 3:t2 4:t3 5:t3 6:t3
```

Verify that the follower rejects an incompatible prefix and that the leader eventually finds the matching point and replaces only the conflicting uncommitted suffix.

The final follower log should match the leader through the replicated range.

### Step B5 — old leader in minority partition

Start with leader A.

Partition:

```text
A B   X   C D E
```

Keep every process alive.

Submit command X to old leader A and command Y to the majority side after it elects a newer-term leader.

Before running, predict:

- whether A can append X locally;
- whether A can commit X;
- whether C/D/E can elect a new leader;
- whether Y can commit;
- what should happen to uncommitted X after healing.

Capture the complete trace.

### Step B6 — heal and repair

Restore communication.

Verify:

- old leader learns the newer term and steps down;
- committed majority history survives;
- stale/conflicting uncommitted suffixes are repaired;
- all nodes eventually agree on the committed prefix.

Define recovery as more than simple network reconnection.

## Step C — Commit-rule audit

Construct a log/term state in which an older-term entry appears on a majority but the current leader has not yet committed a current-term entry covering that prefix.

Explain why the implementation must follow the Raft commit rule rather than directly marking arbitrary old-term majority presence as committed.

The executable harness may provide this as a deterministic state fixture once available.

## Step D — `commitIndex` versus application state

Expose the committed entries but do not yet implement the full KV application.

Create an explicit handoff stream or method:

```text
CommittedEntry{index, term, command}
```

that Chapter 10 could consume.

This reinforces:

```text
consensus module decides order
state machine module executes commands
```

## Step E — Client response ambiguity

Submit logical request R7 to the leader.

Arrange for R7 to become committed, then lose/withhold the client response.

The client should observe a timeout or unknown outcome even though the consensus layer knows R7 is committed.

Do **not** solve duplicate application in Chapter 7. Record the problem for Chapter 10.

## Step F — Safety invariant table

For each fault experiment, complete:

| Scenario | Election safety | Committed-prefix safety | Liveness/progress | Evidence |
|---|---|---|---|---|
| split vote | | | | |
| one crash | | | | |
| minority old leader | | | | |
| stale candidate | | | | |
| conflicting suffix | | | | |
| severe delay | | | | |

A correct cluster may temporarily fail to make progress while still preserving safety.

## Extension G — Raft/Paxos conceptual comparison

No Paxos implementation is required.

Use the readings to compare:

```text
epoch / term / ballot
quorum intersection
preservation of prior decisions
stable-leader optimization
repeated log decisions
```

Do not describe Paxos simply as “harder Raft.”

## Extension H — AI-audited consensus trace

Give an AI assistant one trace containing:

- two terms;
- a leader change;
- one uncommitted old-leader entry;
- one later committed entry.

Ask which entries are committed and why.

Audit every answer against:

- majority size;
- term;
- log freshness;
- commit rule;
- role transitions.

Your invariant-based audit is assessed.

## Step I — Bounded schedule exploration

A live cluster samples only one ordering of events. Use the provided small schedule explorer to make one invariant failure reproducible without depending on real timing.

Run:

```bash
python3 starter/src/vote_schedule_demo.py
```

The first model treats a granted vote as volatile across restart. The explorer permutes the finite events and should find an ordering in which one node grants votes to two candidates in the same term.

Compare the durable-vote model, where the same bounded event set should not produce that counterexample.

Record:

```text
invariant
event set
states explored
counterexample trace, if any
model assumption that caused or fixed the violation
```

Then create one small explorer case of your own. Keep the state abstract. Good targets include two processes both believing they hold exclusive authority, a stale leader acting after higher-term evidence, or an entry applied before the model says it is committed.

This is a bounded teaching model, not proof of the complete implementation. State what event/state space you explored and what remains outside the model.

## Transparent-test target

Executable public tests live under `tests/official/`, with a deterministic Raft reasoning model and bounded schedule explorer in `starter/src/`. They verify election, log-prefix, suffix-repair, commit-rule, and small schedule/invariant behavior; the full five-node timing/partition protocol remains evidence-based.

The complete visible target cases are documented in `tests/official/README.md`. `make test` runs only those public official tests plus student cases under `tests/student/`.

No hidden tests are planned.

## AI use

AI assistants and coding agents are permitted.

Consensus is particularly vulnerable to plausible-looking but unsafe generated code. You remain responsible for every term/vote/log/commit transition and must be able to explain and modify the implementation during review.

## Report

Complete `REPORT.md` with:

- state/persistence model;
- clean election trace;
- split vote;
- crash/restart vote test;
- stale candidate election;
- majority/minority partition;
- conflicting suffix repair;
- commit-rule reasoning;
- safety/liveness table;
- client-response ambiguity;
- AI trace audit.