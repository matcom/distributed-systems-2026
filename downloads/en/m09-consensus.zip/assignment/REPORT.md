# M09 Laboratory Report — Consensus and Leader Election

## 1. Environment and cluster

Record the five node IDs, persistence locations, election-timeout range, heartbeat/AppendEntries interval, and startup commands.

## 2. Persistent state model

State which values survive crash/restart:

```text
currentTerm
votedFor
log
```

and identify any simplifications in the laboratory persistence layer.

## 3. Clean election

Provide a term/role/vote trace from followers to one elected leader.

State majority size and election latency.

## 4. Split vote

Show the vote distribution that prevented a leader from being elected in one term, followed by the later successful term.

Explain why safety was preserved during the leaderless period.

## 5. Crash/restart vote persistence

Demonstrate that a restarted voter does not grant a second vote in the same term.

## 6. Higher-term step down

Record one leader/candidate receiving a higher term and transitioning to follower.

## 7. Stale candidate

Provide the candidate/voter last-log term/index state and explain the vote rejection.

## 8. Majority commitment

For one command, list:

| Node | Entry present? | Match index / evidence | Partition side |
|---|---|---|---|
| | | | |

State when the leader advanced `commitIndex` and why.

## 9. No-majority case

Show that a command may be appended locally or sent to one peer without becoming committed when only two of five nodes communicate.

## 10. Conflicting suffix repair

Provide before/after leader and follower logs. Identify the matching prefix and the uncommitted suffix replaced.

## 11. Old leader in minority partition

Record:

- old leader term/role;
- new majority leader term;
- command submitted to each side;
- which command could commit;
- behavior after healing.

## 12. Commit-rule audit

Explain one scenario where “entry appears on a majority” is insufficient as a naive direct commit rule for an older-term entry. State the Raft rule used instead.

## 13. `commitIndex` and handoff

Show committed entries becoming available to the state-machine layer without yet treating every local log entry as applied state.

## 14. Safety/liveness table

| Scenario | Election safety | Committed-prefix safety | Liveness | Evidence |
|---|---|---|---|---|
| split vote | | | | |
| crash | | | | |
| minority partition | | | | |
| stale candidate | | | | |
| suffix conflict | | | | |

## 15. Client response ambiguity

Document one command that committed while the client failed to receive a success response. Explain why consensus does not solve duplicate retry behavior by itself.

## 16. Raft/Paxos comparison

Compare epochs/ballots, quorums, preservation of prior decisions, and repeated-log leadership at a conceptual level.

## 17. AI audit

- tool, if any:
- trace supplied:
- model's commitment/leadership conclusions:
- invariant-based corrections:

## 18. Conclusion

Answer the guiding question: **How can independent nodes agree on one evolving sequence of decisions despite crashes and partitions?**
