# Planned Public Tests — M09

Executable public tests are provided in this directory together with the starter Raft reasoning model under `starter/src/`. They cover deterministic election, log-prefix, suffix-repair, and commit-rule invariants; the full five-node protocol execution remains evidence-based. No hidden tests are planned.

## Election cases

1. A follower whose election timeout expires increments its term and becomes candidate.
2. A candidate votes for itself once in the new term.
3. A node grants at most one vote per term.
4. `currentTerm` and `votedFor` survive the configured crash/restart persistence boundary.
5. A candidate becomes leader only after obtaining a strict majority.
6. Split votes without a majority do not elect a leader.
7. A later election term can resolve a split vote.
8. Receipt of a higher term makes a leader/candidate update its term and step down to follower.
9. A RequestVote from a candidate whose log is less up to date is rejected according to the Raft freshness rule.

## Log replication cases

10. New leader commands append with the leader's current term and next log index.
11. AppendEntries rejects a request whose `prevLogIndex/prevLogTerm` does not match the follower prefix.
12. A successful AppendEntries extends the matching prefix with the leader's entries.
13. A conflicting **uncommitted** follower suffix is replaced once the leader finds the matching prefix.
14. A lagging follower can catch up after reconnecting.
15. Leader `nextIndex`/`matchIndex` state progresses consistently with successful/failed replication attempts.

## Commitment cases

16. In N=5, a current-term entry replicated to leader plus two followers may advance commit according to the Raft rule.
17. An entry replicated to only two of five nodes is not committed.
18. The implementation does not directly commit an arbitrary older-term entry solely because it happens to appear on a majority; it follows the current-term commit rule.
19. `commitIndex` never decreases.
20. `lastApplied`/application handoff never advances beyond `commitIndex`.

## Partition cases

21. An old leader isolated with one follower cannot commit new entries requiring a 3-of-5 majority.
22. The 3-node side of a 2+3 partition can eventually elect a newer-term leader when timing allows.
23. When the partition heals, the old lower-term leader steps down after receiving higher-term evidence.
24. Committed entries are not replaced by the healed cluster's log repair.
25. Conflicting uncommitted minority entries may be removed/replaced.

## Client-boundary case

26. A test may arrange for a command to commit while withholding the client response; the consensus layer reports committed state even though the client result remains ambiguous.

## Bounded schedule-exploration cases

27. The provided explorer finds a one-vote-per-term counterexample when granted-vote state is incorrectly forgotten across restart.
28. The same finite event set produces no counterexample when the vote survives restart.
29. A depth bound can deliberately restrict the explored schedule prefix.

Add at least one case under `tests/student/` for an election/log schedule or small invariant model not represented above.
