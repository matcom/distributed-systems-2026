import unittest

from schedule_explorer import explore_schedules
from vote_schedule_demo import (
    EVENTS,
    VoteState,
    durable_vote_step,
    one_vote_per_term,
    volatile_vote_step,
)


class ScheduleExplorerTests(unittest.TestCase):
    def test_finds_counterexample_when_vote_is_not_durable(self):
        result = explore_schedules(
            VoteState(), EVENTS, volatile_vote_step, one_vote_per_term
        )
        self.assertFalse(result.passed)
        self.assertIsNotNone(result.violation_trace)
        self.assertGreater(result.explored_states, 0)

    def test_no_counterexample_when_vote_survives_restart(self):
        result = explore_schedules(
            VoteState(), EVENTS, durable_vote_step, one_vote_per_term
        )
        self.assertTrue(result.passed)
        self.assertIsNone(result.violation_trace)

    def test_depth_bound_can_stop_before_violation(self):
        result = explore_schedules(
            VoteState(),
            EVENTS,
            volatile_vote_step,
            one_vote_per_term,
            max_depth=1,
        )
        self.assertTrue(result.passed)


if __name__ == "__main__":
    unittest.main()
