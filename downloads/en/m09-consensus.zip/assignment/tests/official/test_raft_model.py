import unittest

from raft_model import (
    Entry,
    RaftNode,
    candidate_log_is_up_to_date,
    majority,
    may_commit,
    prefix_matches,
    repair_uncommitted_suffix,
)


class RaftElectionTests(unittest.TestCase):
    def test_majority(self):
        self.assertEqual(majority(3), 2)
        self.assertEqual(majority(5), 3)
        self.assertEqual(majority(6), 4)

    def test_start_election_increments_term_and_self_votes(self):
        node = RaftNode("n2", current_term=4)
        term, vote = node.start_election()
        self.assertEqual((term, vote), (5, "n2"))
        self.assertEqual(node.role, "candidate")
        self.assertEqual(node.voted_for, "n2")

    def test_one_vote_per_term(self):
        node = RaftNode("n1", current_term=3)
        self.assertTrue(node.grant_vote(3, "a", candidate_last_term=2, candidate_last_index=4,
                                        voter_last_term=2, voter_last_index=4))
        self.assertFalse(node.grant_vote(3, "b", candidate_last_term=2, candidate_last_index=4,
                                         voter_last_term=2, voter_last_index=4))

    def test_higher_term_forces_step_down(self):
        node = RaftNode("n1", current_term=2)
        node.role = "leader"
        node.observe_term(5)
        self.assertEqual(node.current_term, 5)
        self.assertEqual(node.role, "follower")
        self.assertIsNone(node.voted_for)

    def test_log_freshness_prefers_higher_last_term(self):
        self.assertTrue(candidate_log_is_up_to_date(4, 1, 3, 100))
        self.assertFalse(candidate_log_is_up_to_date(2, 100, 3, 1))

    def test_log_freshness_uses_index_when_terms_equal(self):
        self.assertTrue(candidate_log_is_up_to_date(3, 8, 3, 7))
        self.assertFalse(candidate_log_is_up_to_date(3, 6, 3, 7))


class RaftLogTests(unittest.TestCase):
    def setUp(self):
        self.log = [Entry(1, "a"), Entry(2, "b"), Entry(2, "c")]

    def test_virtual_empty_prefix_matches(self):
        self.assertTrue(prefix_matches(self.log, 0, 0))

    def test_matching_prefix(self):
        self.assertTrue(prefix_matches(self.log, 2, 2))
        self.assertFalse(prefix_matches(self.log, 2, 1))
        self.assertFalse(prefix_matches(self.log, 4, 2))

    def test_conflicting_uncommitted_suffix_is_replaced(self):
        repaired = repair_uncommitted_suffix(self.log, 1, [Entry(3, "x"), Entry(3, "y")])
        self.assertEqual(repaired, [Entry(1, "a"), Entry(3, "x"), Entry(3, "y")])

    def test_majority_current_term_entry_may_commit(self):
        self.assertTrue(may_commit(3, 5, entry_term=7, current_term=7))
        self.assertFalse(may_commit(2, 5, entry_term=7, current_term=7))

    def test_older_term_entry_is_not_directly_committed_by_this_rule(self):
        self.assertFalse(may_commit(5, 5, entry_term=6, current_term=7))


if __name__ == "__main__":
    unittest.main()
