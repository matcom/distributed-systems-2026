"""Explore a small vote-persistence schedule."""

from __future__ import annotations

from dataclasses import dataclass

from schedule_explorer import explore_schedules


@dataclass(frozen=True)
class VoteState:
    voted_for: str | None = None
    granted_history: tuple[str, ...] = ()


EVENTS = ("grant:A", "restart", "grant:C")


def one_vote_per_term(state: VoteState) -> bool:
    return len(set(state.granted_history)) <= 1


def volatile_vote_step(state: VoteState, event: str) -> VoteState:
    if event == "restart":
        return VoteState(None, state.granted_history)
    if event.startswith("grant:") and state.voted_for is None:
        candidate = event.split(":", 1)[1]
        return VoteState(candidate, state.granted_history + (candidate,))
    return state


def durable_vote_step(state: VoteState, event: str) -> VoteState:
    if event == "restart":
        return state
    if event.startswith("grant:") and state.voted_for is None:
        candidate = event.split(":", 1)[1]
        return VoteState(candidate, state.granted_history + (candidate,))
    return state


def show(label: str, step) -> None:
    result = explore_schedules(VoteState(), EVENTS, step, one_vote_per_term)
    print(label)
    print("states explored:", result.explored_states)
    print("invariant: one_vote_per_term")
    if result.passed:
        print("result: PASS")
    else:
        print("result: FAIL")
        print("counterexample:", " -> ".join(result.violation_trace or ()))


if __name__ == "__main__":
    show("volatile vote", volatile_vote_step)
    print()
    show("durable vote", durable_vote_step)
