"""Tiny bounded event-schedule explorer for distributed-systems exercises.

This is deliberately not a production model checker. It explores every ordering
of a finite set of named events up to a chosen depth and stops at the first state
that violates an invariant. The state model and transition function remain part
of the exercise.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Callable, Hashable, Optional, Sequence, Tuple, TypeVar

State = TypeVar("State")


@dataclass(frozen=True)
class ExplorationResult:
    explored_states: int
    violation_trace: Optional[Tuple[str, ...]]
    violation_state: object | None

    @property
    def passed(self) -> bool:
        return self.violation_trace is None


def explore_schedules(
    initial_state: State,
    events: Sequence[str],
    step: Callable[[State, str], State],
    invariant: Callable[[State], bool],
    *,
    state_key: Callable[[State], Hashable] = lambda state: state,  # type: ignore[return-value]
    max_depth: int | None = None,
) -> ExplorationResult:
    """Explore event orderings and return the first invariant violation.

    Each event occurrence is consumed at most once. Duplicate event labels are
    allowed because pending events are tracked by position, not by set identity.
    """

    if max_depth is None:
        max_depth = len(events)
    if max_depth < 0:
        raise ValueError("max_depth must be non-negative")

    initial_pending = tuple(events)
    queue = deque([(initial_state, initial_pending, tuple())])
    seen: set[tuple[Hashable, tuple[str, ...], int]] = set()
    explored = 0

    while queue:
        state, pending, trace = queue.popleft()
        marker = (state_key(state), pending, len(trace))
        if marker in seen:
            continue
        seen.add(marker)
        explored += 1

        if not invariant(state):
            return ExplorationResult(explored, trace, state)

        if len(trace) >= max_depth:
            continue

        for index, event in enumerate(pending):
            next_pending = pending[:index] + pending[index + 1 :]
            next_state = step(state, event)
            queue.append((next_state, next_pending, trace + (event,)))

    return ExplorationResult(explored, None, None)
