"""Deterministic Raft reasoning model for M09 public tests.

This is not a complete networked Raft implementation. It exposes the core election,
log-prefix, and commitment invariants that every implementation must preserve.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, List, Optional


@dataclass(frozen=True)
class Entry:
    term: int
    command: object


def majority(cluster_size: int) -> int:
    raise NotImplementedError("TODO: return the strict-majority size")


def candidate_log_is_up_to_date(candidate_last_term: int, candidate_last_index: int,
                                voter_last_term: int, voter_last_index: int) -> bool:
    """Implement Raft's lexicographic last-term/last-index freshness rule."""
    raise NotImplementedError("TODO: implement RequestVote log freshness")


class RaftNode:
    def __init__(self, node_id: str, current_term: int = 0):
        self.node_id = node_id
        self.current_term = current_term
        self.voted_for: Optional[str] = None
        self.role = "follower"

    def start_election(self) -> tuple[int, str]:
        """Increment term, become candidate, vote for self, and return (term,vote)."""
        raise NotImplementedError("TODO: implement election transition")

    def grant_vote(self, term: int, candidate_id: str, *, candidate_last_term: int,
                   candidate_last_index: int, voter_last_term: int, voter_last_index: int) -> bool:
        """Apply term, one-vote-per-term, and log-freshness rules."""
        raise NotImplementedError("TODO: implement vote granting")

    def observe_term(self, term: int) -> None:
        """Higher-term evidence updates term and forces follower state."""
        raise NotImplementedError("TODO: implement higher-term step-down")


def prefix_matches(log: List[Entry], prev_log_index: int, prev_log_term: int) -> bool:
    """Index 0 denotes the virtual empty-log prefix; real entries are 1-based."""
    raise NotImplementedError("TODO: implement AppendEntries prefix check")


def repair_uncommitted_suffix(log: List[Entry], prev_log_index: int, entries: Iterable[Entry]) -> List[Entry]:
    """Return a log whose suffix after the matching prefix is replaced by entries."""
    raise NotImplementedError("TODO: implement conflicting suffix repair")


def may_commit(replication_count: int, cluster_size: int, entry_term: int, current_term: int) -> bool:
    """Model the Raft leader rule used in the lab for advancing commitIndex."""
    raise NotImplementedError("TODO: require majority and current-term entry")
