<p class="ds-book-part">Part IV — Fault Tolerance</p>
<p class="ds-module-kicker">Chapter 10</p>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 10 of 12</span>
    <span>83% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 83%"></span></div>
</div>
<p class="ds-guiding-question">How do you keep making safe decisions when failure and slowness can look the same?</p>

Treat failure as part of normal execution. Distinguish crashes, omissions, timing faults, partitions, overload, and correlated failure. A timeout gives you local evidence; it does not reveal the remote truth. Recovery must restore the system's invariants, not merely restart a process.

## Key ideas

- crash, omission, timing, and partition failures
- synchronous, asynchronous, and partial-synchrony assumptions
- failure detection as suspicion
- heartbeats and adaptive timeouts
- message loss, duplication, and reordering
- retry amplification and backoff
- correlated failure domains
- safety and liveness
- recovery and reincarnation
- reproducible fault injection

## Laboratory transition

Build a heartbeat detector, then create crash, delay, loss, partition, and recovery scenarios. For each one, separate what the detector suspects from what your evidence actually proves.

## Start here

> **Before you read:** A node is silent for five seconds. What may you safely conclude? Now suppose it restarts: what state must survive before it can safely rejoin?

**Bring forward:** Timeout ambiguity, replication, consensus, and observable histories from the preceding chapters.

**This chapter builds toward:** Failure handling that includes detection, bounded retries, durable recovery, replay, and safe reintegration.

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>40 min–55 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>50 min–1 h 15 min</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>2 h 30 min–3 h · 8 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<p class="ds-workload-note"><strong>Core scope:</strong> The core lab is Steps 1–6, Step 8, durable recovery checkpoint 8b, and Steps 10–13. The one-way-fault and extra detector-policy comparisons remain extensions.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Read lesson →</a>
  <a class="ds-secondary-action" href="lab/">Open laboratory</a>
</div>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../downloads/en/m07-failures.zip" download>Download chapter + laboratory for offline study (.zip)</a></p>

## What you will learn

- State an explicit failure model covering crash, omission, timing, partition, and correlated failures.
- Explain why silence produces suspicion rather than perfect knowledge of remote failure.
- Build and tune a heartbeat/failure detector and identify false-suspicion trade-offs.
- Design repeatable crash, delay, loss, partition, retry, and recovery experiments.
- Explain how recovery, reincarnation, backoff, and failure domains affect safety and liveness.

## Learn by working the question

1. Write your answer to **Start here** before opening the full lesson.
2. Read until the next prediction or trace, then stop and work it out before revealing the explanation.
3. Treat guided practice as a **practice bank**, not a speed worksheet. Work the core traces until you can meet the chapter's Practice target; return to the remaining cases for retrieval practice or instructor-assigned work.
4. Use the knowledge check to find gaps, then enter the laboratory with a falsifiable prediction and name the evidence that could contradict it.
5. Finish by explaining what the experiment established, what it did not establish, and how the result changes the evolving service.

<nav class="ds-sequence" aria-label="Course sequence">
<a class="ds-sequence-link" href="../m08-replication-consistency/">← Replication and Consistency</a>
<a class="ds-sequence-link next" href="../m11-transactions-sharding/">Fault Tolerance II — Transactions, Recovery, and Distributed State →</a>
</nav>
