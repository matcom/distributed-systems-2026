"""Deterministic failure-detector and retry-policy model for M07."""

from dataclasses import dataclass
from typing import Callable


@dataclass
class PeerState:
    node_id: str
    incarnation: int
    last_sequence: int
    last_heard: float
    status: str = "ALIVE"


class FailureDetector:
    def __init__(self, now: Callable[[], float], suspicion_after: float):
        if suspicion_after <= 0:
            raise ValueError("suspicion_after must be positive")
        self._now = now
        self.suspicion_after = suspicion_after
        self._peers = {}

    def heartbeat(self, node_id: str, incarnation: int, sequence: int) -> str:
        """Observe a heartbeat and return the resulting peer status.

        Newer incarnations replace older process state. Older incarnations and
        backward sequence numbers within one incarnation must not refresh the
        current process record.
        """
        raise NotImplementedError("TODO: implement heartbeat freshness rules")

    def status(self, node_id: str) -> str:
        """Return ALIVE, SUSPECT, or UNKNOWN using local elapsed time."""
        raise NotImplementedError("TODO: implement suspicion transition")


class RetryPolicy:
    def __init__(self, max_attempts: int, base_delay: float):
        if max_attempts <= 0 or base_delay < 0:
            raise ValueError("invalid retry policy")
        self.max_attempts = max_attempts
        self.base_delay = base_delay

    def should_retry(self, attempt_number: int) -> bool:
        """attempt_number is 1 for the first completed/failed attempt."""
        raise NotImplementedError("TODO: enforce bounded attempts")

    def delay_before(self, next_attempt_number: int) -> float:
        """Return deterministic exponential backoff delay before the next attempt."""
        raise NotImplementedError("TODO: implement deterministic backoff")
