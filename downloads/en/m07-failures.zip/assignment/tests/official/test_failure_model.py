import unittest

from failure_model import FailureDetector, RetryPolicy


class FakeClock:
    def __init__(self):
        self.t = 0.0

    def now(self):
        return self.t

    def advance(self, seconds):
        self.t += seconds


class FailureDetectorTests(unittest.TestCase):
    def setUp(self):
        self.clock = FakeClock()
        self.detector = FailureDetector(self.clock.now, suspicion_after=5.0)

    def test_recent_heartbeat_is_alive(self):
        self.assertEqual(self.detector.heartbeat("n1", 1, 1), "ALIVE")
        self.clock.advance(4.9)
        self.assertEqual(self.detector.status("n1"), "ALIVE")

    def test_missing_heartbeat_becomes_suspect(self):
        self.detector.heartbeat("n1", 1, 1)
        self.clock.advance(5.1)
        self.assertEqual(self.detector.status("n1"), "SUSPECT")

    def test_fresh_heartbeat_recovers_suspect_peer(self):
        self.detector.heartbeat("n1", 1, 1)
        self.clock.advance(6)
        self.assertEqual(self.detector.status("n1"), "SUSPECT")
        self.assertEqual(self.detector.heartbeat("n1", 1, 2), "ALIVE")

    def test_stale_incarnation_does_not_revive_newer_process(self):
        self.detector.heartbeat("n1", 2, 1)
        self.clock.advance(6)
        self.detector.heartbeat("n1", 1, 99)
        self.assertEqual(self.detector.status("n1"), "SUSPECT")

    def test_backward_sequence_does_not_refresh_current_incarnation(self):
        self.detector.heartbeat("n1", 1, 5)
        self.clock.advance(4)
        self.detector.heartbeat("n1", 1, 4)
        self.clock.advance(2)
        self.assertEqual(self.detector.status("n1"), "SUSPECT")

    def test_unknown_peer_is_explicit(self):
        self.assertEqual(self.detector.status("missing"), "UNKNOWN")


class RetryPolicyTests(unittest.TestCase):
    def test_attempts_are_bounded(self):
        policy = RetryPolicy(max_attempts=3, base_delay=0.1)
        self.assertTrue(policy.should_retry(1))
        self.assertTrue(policy.should_retry(2))
        self.assertFalse(policy.should_retry(3))

    def test_backoff_grows_exponentially(self):
        policy = RetryPolicy(max_attempts=5, base_delay=0.25)
        self.assertEqual(policy.delay_before(2), 0.25)
        self.assertEqual(policy.delay_before(3), 0.5)
        self.assertEqual(policy.delay_before(4), 1.0)


if __name__ == "__main__":
    unittest.main()
