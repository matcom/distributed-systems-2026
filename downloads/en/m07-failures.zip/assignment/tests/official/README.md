# Planned Public Tests — M07

Executable public tests are provided in this directory together with the starter failure-detector/retry adapter under `starter/src/`. They cover deterministic suspicion, incarnation, sequence, and retry-policy invariants; real process/network failures remain evidence-based. No hidden cases are planned.

## Detector cases

1. A healthy peer sending heartbeats within the configured interval remains `ALIVE`.
2. Missing heartbeats longer than the suspicion threshold transitions the peer to `SUSPECT`.
3. A fresh heartbeat after suspicion returns the peer to `ALIVE` according to the documented recovery rule.
4. Heartbeat freshness is evaluated with local elapsed-time semantics, not by subtracting a remote wall timestamp.
5. Stable node ID plus incarnation ID prevents an old-incarnation heartbeat from reviving the current process incorrectly.
6. Heartbeat sequence numbers that move backward within one incarnation are rejected or identified as stale according to the protocol.

## Failure-model cases

7. A killed worker eventually becomes suspected.
8. An alive-but-delayed worker can produce the same local suspicion result, demonstrating that suspicion is not proof of crash.
9. A partitioned worker remains alive according to independent process evidence while the isolated observer marks it suspect.
10. Two observers may hold different reachability views of the same healthy process during a partition.

## Retry cases

11. Retry attempts are bounded by the declared maximum-attempt or deadline policy.
12. Backoff delay grows or follows the declared policy rather than retrying in an unbounded tight loop.
13. Stable request IDs are preserved across retry attempts for the same logical operation.
14. A state-changing test workload does not apply a deduplicated request more than once where M03-style duplicate suppression is enabled.

## Recovery cases

15. Healing the communication fault eventually allows a fresh heartbeat to restore the peer state.
16. Detector recovery is not treated as proof that replicated application state is already synchronized.

Students should add at least one case under `tests/student/` that explores a false-suspicion or retry-policy edge case not present above.
