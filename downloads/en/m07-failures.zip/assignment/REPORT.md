# M07 Laboratory Report — Failure Models and Unreliable Networks

## 1. Environment and topology

Record process/node IDs, incarnation IDs, host/container placement, heartbeat path, and exact startup commands.

## 2. Detector configuration

| Parameter | Value | Reason |
|---|---:|---|
| heartbeat interval | | |
| suspicion timeout | | |
| recovery rule | | |

## 3. Healthy baseline

Report heartbeat inter-arrival observations and establish the normal environment before injecting faults.

## 4. Real crash

- crash time:
- last heartbeat at A:
- last heartbeat at C:
- suspicion time at A:
- suspicion time at C:
- detection latency:
- explanation:

## 5. Restart and incarnation

Show how the restarted process is distinguished from its previous incarnation. Explain the stale-message risk being prevented.

## 6. False suspicion by delay

- injected delay:
- true process state:
- local observation:
- detector transition:
- evidence B remained alive:
- explanation:

## 7. Packet-loss experiment

Compare at least two detector configurations.

| Configuration | Loss rate | Missed heartbeats | False suspicions | Crash-detection latency |
|---|---:|---:|---:|---:|
| | | | | |

Explain the trade-off.

## 8. Partition experiment

Describe the partition and include evidence from at least two observers if possible.

Distinguish:

- actual process state;
- A's reachability view;
- C's reachability view;
- any authoritative membership action.

## 9. Recovery

Record:

- fault-heal time;
- first fresh heartbeat;
- ALIVE transition;
- any additional application recovery milestone.

Define the recovery metric used.

## 10. Retry amplification

| Strategy | Logical requests | Actual attempts | Amplification | Timeouts | Throughput | Recovery time |
|---|---:|---:|---:|---:|---:|---:|
| immediate retry | | | | | | |
| bounded backoff/jitter | | | | | | |

Explain whether retries prolonged overload.

## 11. Duplicate-effect analysis

If the workload changes state, show whether stable request IDs prevented duplicate effects.

## 12. Fault campaign

| Fault | True world | Local observation | Detector decision | Application effect | Recovery criterion |
|---|---|---|---|---|---|
| crash | | | | | |
| delay | | | | | |
| loss | | | | | |
| partition | | | | | |

## 13. Failure-domain inventory

State one tolerance claim supported by the experiment and one claim that cannot be supported because of shared infrastructure.

## 14. AI-audited diagnosis

- tool, if any:
- trace supplied:
- model hypothesis:
- classification:
- experiment/evidence used to verify:

## 15. Conclusion

Answer the guiding question: **How can a process distinguish a failed peer from a slow or partitioned peer?**

A complete answer should acknowledge where perfect distinction is impossible and explain how the detector turns uncertainty into policy.
