<p class="ds-book-part">Part IV — Fault Tolerance</p>
<div class="ds-lesson-banner">
  <div><span>Course step</span><strong>Chapter 10</strong></div>
  <div><span>Core reading</span><strong>40 min–55 min</strong></div>
  <div><span>Required path</span><strong>Read → Practice target → Check → Lab</strong></div>
</div>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 10 of 12</span>
    <span>83% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 83%"></span></div>
</div>

> **Guiding question:** How do you keep making safe decisions when failure and slowness can look the same?

## Before you read

> A node is silent for five seconds. What may you safely conclude? Now suppose it restarts: what state must survive before it can safely rejoin?

Write a short answer first. You are not expected to be correct yet; you need a prediction you can revise as the chapter gives you better models and evidence.

**Use what you already know:** Timeout ambiguity, replication, consensus, and observable histories from the preceding chapters.

## Workload map

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>40 min–55 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>50 min–1 h 15 min</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>2 h 30 min–3 h · 8 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<p class="ds-workload-note"><strong>Core scope:</strong> The core lab is Steps 1–6, Step 8, durable recovery checkpoint 8b, and Steps 10–13. The one-way-fault and extra detector-policy comparisons remain extensions.</p>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../../downloads/en/m07-failures.zip" download>Download lesson + practice + lab for offline study (.zip)</a></p>

## Why this chapter matters

Distributed systems become interesting when the environment stops behaving politely.

A process can disappear. A machine can remain alive while one service hangs. A packet can be delayed, duplicated, reordered, or dropped. Two groups of healthy machines can become unable to communicate. A dependency can respond so slowly that a caller gives up even though the dependency later completes the work.

The difficult part is that these observations are often ambiguous.

Suppose node A has received a heartbeat from node B every 500 ms. Suddenly three heartbeats are missing.

What does A know?

Not much.

Possibilities include:

```text
B crashed
B is paused
B is overloaded
A is overloaded
packets from B are lost
packets to B are lost
routing changed
a partition separates A and B
B's heartbeat thread is stuck
A's clock/timer assumptions are wrong
```

Yet a real system still has to make decisions.

This chapter therefore introduces one of the central engineering disciplines of distributed systems:

> **Turn uncertainty into an explicit failure model, then design the system around what can and cannot be known.**

The guiding question is:

> **How can a process distinguish a failed peer from a slow or partitioned peer?**

In a fully asynchronous system, it generally cannot do so perfectly from silence alone.

That fact drives failure detectors, timeouts, quorum systems, leader leases, consensus, retry strategies, and much of the architecture studied later in the course.

---

## 1. Failure is not one thing

The word *failure* is too broad to support precise reasoning.

Consider a service request that does not complete. Several different failures may have occurred:

- the client failed before sending;
- the request was lost;
- the server crashed before processing;
- the server processed the request but crashed before replying;
- the response was lost;
- the response arrived after the client's deadline;
- the service was healthy but unreachable because of a partition.

These histories can produce the same client-side observation:

```text
timeout
```

A useful failure model gives names to different classes of behavior and states which ones the design assumes.

---

<aside class="ds-book-note ds-history">
  <span class="ds-book-note-label">History</span>
  <strong>Consensus research separated safety from progress and clarified what agreement can mean under uncertainty</strong>
  <p>Paxos, FLP, and related work established the modern language for reasoning about agreement, failure assumptions, quorum intersection, and the difference between what must never happen and what may temporarily stop happening.</p>
  <a class="ds-book-note-source" href="../../../history/paxos-consensus/">Read the design history →</a>
</aside>

## 2. Crash-stop is a useful abstraction, not a description of all reality

A common introductory model is **crash-stop**:

> A process behaves correctly until it crashes, and once crashed it never returns.

This model simplifies reasoning.

If process P stops forever, we do not need to model arbitrary corrupted messages from P after the crash.

But real services often restart.

That gives a **crash-recovery** model:

```text
running
  ↓
crashed
  ↓
restarted
  ↓
running again
```

Crash-recovery immediately raises new questions:

- Which state survived?
- Is the restarted process the same logical node or a new incarnation?
- Can old delayed messages from the previous incarnation still arrive?
- Can the process repeat work it had completed before crashing?

This is why Chapter 8 introduced incarnation identifiers and why Chapter 10 later treats persistent state explicitly.

> **Pause and predict.** A worker named `worker-3` crashes and restarts with empty memory but the same network address. Should another node assume it remembers tasks assigned before the crash?

No. The stable name or address does not prove continuity of volatile state.

---

## 3. Omission failures mean expected actions do not occur

An **omission failure** occurs when a message or action that should occur does not occur from the observer's perspective.

Examples:

```text
send omitted
receive omitted
response omitted
heartbeat omitted
```

The important point is that omission does not identify the failing component.

If A does not receive B's heartbeat, the failure could be at B, A, or anywhere along the communication path.

This is a recurring systems principle:

> **Absence of evidence from one observation point rarely identifies root cause.**

The Warm-up established this as an evidence discipline; Chapter 10 turns it into a protocol-design constraint.

---

## 4. Timing failures depend on assumptions about acceptable delay

A **timing failure** occurs when an action happens outside the timing bounds required by the system model.

For example, suppose a real-time control service requires a response within 20 ms.

A response after 2 seconds is functionally a failure for that application even if the server eventually returns the correct value.

This distinction matters because distributed algorithms often assume different timing models.

### Synchronous model

There are known bounds on relevant quantities such as:

- message delay;
- process execution time;
- clock drift.

### Asynchronous model

No useful fixed upper bound is assumed for message or processing delay.

A correct process may appear silent for arbitrarily long.

### Partially synchronous model

Timing may be unbounded for some period, but eventually the system behaves within useful bounds, or bounds exist but are initially unknown.

Many practical systems live conceptually closer to partial synchrony than to an ideal fully synchronous network.

This is important for consensus later: liveness often depends on timing eventually becoming favorable even when safety does not.

---

## 5. A timeout is a local decision, not a remote fact

Suppose A sends a request to B and waits 500 ms.

At 500 ms, A's timer expires.

What happened remotely?

The timeout establishes only something like:

> A did not observe the expected completion before its local deadline.

It does **not** prove:

```text
B is dead
request was lost
request did not execute
response will never arrive
network is broken
```

This connects directly to Chapter 4.

A deadline is valuable because a caller cannot wait forever, but every timeout turns uncertainty into a policy decision.

The policy may be:

- retry;
- fail the user request;
- choose another replica;
- mark the peer suspected;
- trigger leader election;
- degrade service;
- queue the work for later.

The engineering question is not simply:

> What timeout value should we use?

It is:

> **What action becomes safe or useful when this timeout expires, given that the remote state remains uncertain?**

---

## 6. Failure detection is fundamentally suspicion

A practical failure detector usually converts missing evidence into a state transition.

For example:

```text
ALIVE
  |
  | no heartbeat for T
  v
SUSPECT
  |
  | additional evidence / expiry
  v
DEAD or REMOVED
```

Calling the first transition **suspect** rather than **dead** is conceptually useful.

A detector is an information service whose output may be wrong temporarily.

This leads to two classic properties.

### Completeness

Does the detector eventually suspect processes that really failed?

### Accuracy

Does the detector avoid suspecting correct processes?

In an asynchronous setting with unbounded delay, a perfect detector cannot simultaneously know that silence means permanent failure rather than extreme delay.

That is not an implementation defect. It follows from the observation available to the process.

---

## 7. Why perfect detection fails under asynchrony

Compare two executions from A's point of view.

### Execution 1 — B crashes

```text
A               B
| heartbeat <---|
|               X crash
| ...silence... |
```

### Execution 2 — B is merely delayed

```text
A               B
| heartbeat <---|
|               |
| ...silence... |  scheduler/network delay
|               |
| heartbeat <---|
```

Until the next heartbeat eventually arrives in Execution 2, A's observations can be identical in both executions.

If A declares B dead after finite silence, it risks a false suspicion in Execution 2.

If A waits forever to avoid false suspicion, it never detects B in Execution 1.

This is one of the deepest recurring patterns in distributed systems:

> **When two different worlds generate the same local observations, no algorithm using only those observations can always distinguish the worlds immediately.**

---

## 8. Heartbeats create evidence of recent reachability

A simple detector uses periodic heartbeats.

Suppose B sends one heartbeat every second.

A records the most recent heartbeat time using a local monotonic clock.

```text
last_seen[B] = monotonic_now()
```

A may suspect B when:

```text
monotonic_now() - last_seen[B] > timeout
```

This design is intentionally local.

Do not compare A's wall clock to a timestamp generated from B's wall clock unless the protocol has a well-defined synchronization/error model.

For basic liveness detection, the receiver often only needs:

> How long has it been according to **my local elapsed timer** since I last heard from B?

Chapter 6 prepared this distinction.

---

## 9. Heartbeat interval and suspicion timeout are different parameters

If heartbeats are sent every 1 second, the detector does not necessarily need to suspect after exactly 1 second.

A simple design might use:

```text
heartbeat interval = 1 s
suspicion timeout = 4 s
```

This tolerates several missed messages before changing membership state.

The trade-off is direct.

Short timeout:

```text
faster failure detection
more false suspicions
more churn
```

Long timeout:

```text
slower failover
fewer false suspicions
```

There is no universally correct value.

The workload, network, scheduler, latency distribution, and cost of false suspicion all matter.

---

## 10. Adaptive detectors respond to observed conditions

A fixed timeout is simple but may perform badly when latency changes.

A more adaptive detector can track recent heartbeat delays and adjust its suspicion threshold.

Conceptually:

```text
observed delay distribution
        ↓
confidence/suspicion estimate
        ↓
decision threshold
```

The course does not require implementing a sophisticated probabilistic failure detector in Chapter 10, but you should understand the motivation.

A detector should be evaluated experimentally, not by choosing a number that “looks reasonable.”

Useful measurements include:

- detection latency after a real crash;
- false-suspicion rate under delay;
- recovery time after communication heals;
- sensitivity to load;
- message overhead.

---

## 11. Failure detector output is not the same as membership authority

Suppose node A suspects B.

Can A delete B permanently from the cluster?

That depends on architecture.

A local detector may only produce:

```text
A believes B is currently unreachable
```

Turning that belief into globally authoritative membership may require:

- a central registry;
- a replicated membership service;
- quorum agreement;
- gossip convergence;
- consensus.

Chapter 8 introduced registry leases. Chapter 10 clarifies that the expiry mechanism and the authority mechanism are separate concerns.

---

## 12. Network partitions create disagreement among healthy nodes

A **network partition** occurs when communication is disrupted such that the system is divided into groups that cannot exchange required messages.

For example:

```text
A <-> B     X     C <-> D
```

All four processes may be healthy.

From A's viewpoint, C and D may appear failed.

From C's viewpoint, A and B may appear failed.

This symmetry is dangerous.

If both sides independently conclude:

> “The other side is dead, therefore I am authoritative,”

the system can create conflicting state.

This motivates quorum intersection and consensus in later modules.

---

## 13. Partitions are not only Internet cable cuts

A partition can arise from many causes:

- routing failure;
- firewall rule;
- virtual-network misconfiguration;
- switch failure;
- service-mesh policy;
- overloaded queue behaving like effective loss;
- one-way connectivity;
- DNS or discovery state pointing to unreachable nodes.

A process-level test that kills a peer is therefore not enough to claim partition tolerance.

The laboratory should exercise **communication failure while processes remain alive**.

---

## 14. One-way partitions are especially revealing

Suppose A can send to B, but B's responses cannot reach A.

```text
A ----request----> B
A <---X response-- B
```

B may continue changing state while A experiences timeouts.

This recreates the ambiguous RPC problem from Chapter 4.

Likewise, heartbeat direction matters.

If B sends heartbeats to A but A cannot send requests to B, A's detector may report B healthy even though the application path is unusable.

This yields an important practical rule:

> **Health is path- and function-specific.**

A successful heartbeat proves less than many systems assume.

---

## 15. Message loss and duplication interact with application semantics

Transport and middleware may retransmit. Clients may retry. Proxies may retry. Queues may redeliver.

Therefore an application may receive duplicate logical requests even when no component is “broken.”

Consider:

```text
client sends R7
server applies R7
response lost
client retries R7
server sees R7 again
```

The network failure model and the operation's idempotency model are coupled.

Chapter 4 introduced request identifiers and deduplication. Chapter 10 places them inside a broader failure campaign.

A system that tolerates packet loss by retrying but cannot tolerate duplicate effects is not actually robust.

---

## 16. Reordering means arrival order is not a semantic guarantee

Messages can arrive in an order different from the order in which the application conceptually expects them.

For example:

```text
M1: set mode = ACTIVE
M2: set mode = STOPPED
```

If M2 is observed before a delayed M1, naive last-arrival processing may end in the wrong state.

Possible solutions depend on semantics:

- sequence numbers;
- versions;
- causal metadata;
- consensus log order;
- idempotent monotonic updates;
- explicit state-machine rules.

The lesson is not “the network always reorders.”

It is:

> **If correctness depends on order, the protocol must define how order is established.**

---

## 17. Recovery is part of fault tolerance

A system is not resilient merely because it survives the moment of failure.

It must also define what happens afterward.

Suppose replica C is disconnected for ten minutes while A and B process writes.

When C returns:

```text
C's state is stale
```

Possible recovery strategies include:

- replay missing log entries;
- copy a snapshot;
- compare versions;
- anti-entropy exchange;
- rebuild from another replica;
- discard C and provision a fresh node.

Later replication, coordination, and recovery work will implement different versions of these ideas.

Chapter 10 establishes the general requirement:

> **Every failure scenario needs a recovery story.**

### Recovery of a replicated state machine needs more than restarting the process

Earlier coordination work gave you an agreed command sequence. Turning that sequence into a recoverable service adds another boundary:

```text
client request
      ↓
committed command
      ↓
durable log / recovery record
      ↓
deterministic application
      ↓
service state
```

A restarted process must answer several questions before it serves traffic:

- Which commands were committed?
- Which committed commands were already applied?
- Can applying one of them again duplicate a side effect?
- Is the current in-memory state reconstructable from durable information?
- Is a snapshot recent enough, and which log suffix must be replayed after it?
- If this node is far behind, is replay cheaper than state transfer from another replica?

This is why systems often distinguish:

```text
commit index
last applied
snapshot index
durable request/deduplication state
```

Those values do not all advance at the same instant.

### Stable request identity must survive recovery too

Suppose request 81 was committed and applied before a crash, but the response never reached the client.

After restart, the client retries request 81.

If duplicate-suppression state existed only in memory, the recovered service may apply the effect twice. Therefore retry safety and crash recovery meet at the same durable-state boundary.

A simple educational design can persist:

```text
last snapshot
committed log suffix
request_id → result/effect record
```

and reconstruct deterministic state after restart.

### Snapshots shorten recovery but create a new correctness boundary

Replaying ten commands is simple. Replaying ten million may be impractical.

A snapshot captures application state at a known log position:

```text
snapshot through index 5000
log suffix 5001..current
```

Recovery loads the snapshot, then replays the suffix.

The snapshot is only useful if you can state:

- exactly which committed commands it includes;
- how it is written atomically enough for the crash model;
- which deduplication/session state must be included;
- how the node verifies or replaces a corrupted/incomplete snapshot.

> **Pause and predict.** A node restarts successfully but has restored a snapshot from index 5000 while the cluster has committed through 5400. Is the node “recovered”? It is alive, but it is not yet safe for every service role.

---

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosity</span>
  <strong>A perfect crash detector would need to know whether a silent node is dead or merely slow</strong>
  <p>In an asynchronous setting, a sufficiently delayed healthy process can look exactly like a crashed process from another node's local perspective. Practical detectors therefore produce suspicions under timing assumptions rather than omniscient truth.</p>
  <p><strong>Try it:</strong> Run the same heartbeat timeout once with a killed process and once with injected delay. Compare the detector's local evidence.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">More chapter curiosities →</a>
</aside>

## 18. Rejoining safely may require incarnation information

Imagine a process restarts with the same node ID.

An old delayed heartbeat from before the crash arrives after the restart.

Without incarnation/version information, another component may confuse stale evidence with current liveness.

Useful metadata may include:

```text
node_id = worker-3
incarnation = 91384
sequence = 22
```

After restart:

```text
node_id = worker-3
incarnation = 77102
sequence = 1
```

Now old messages from incarnation `91384` can be recognized as stale.

This is a small example of a general principle:

> **Identity often needs both a stable logical name and a changing epoch/incarnation.**

---

## 19. Retry storms can turn partial failure into total failure

Suppose 10,000 clients call a service.

The service slows down.

Clients hit timeouts and retry immediately.

Traffic increases.

The service becomes slower.

More clients retry.

```text
slow service
   ↓
timeouts
   ↓
retries
   ↓
more load
   ↓
slower service
```

This positive feedback loop can cause a **retry storm**.

The retry mechanism intended to improve availability becomes a failure amplifier.

---

## 20. Exponential backoff reduces synchronized retry pressure

A common strategy increases the delay between retries.

Conceptually:

```text
attempt 1 -> wait ~100 ms
attempt 2 -> wait ~200 ms
attempt 3 -> wait ~400 ms
attempt 4 -> wait ~800 ms
```

This reduces repeated load on a dependency that may still be recovering.

But if every client uses the exact same schedule, they may synchronize:

```text
all retry at 100 ms
all retry at 200 ms
all retry at 400 ms
```

Therefore systems commonly introduce **jitter**—random variation in retry timing.

The purpose is not randomness for its own sake.

It is to avoid correlated behavior across many clients.

---

## 21. Retry budgets bound how much extra work failure can create

A robust system should define how much retry traffic one logical operation may generate.

Possible limits include:

- maximum attempts;
- absolute deadline;
- total retry time;
- per-client budget;
- global circuit-breaking/load-shedding policy.

Without a bound, failure handling itself can become unbounded work.

This connects to Chapter 3's backpressure discussion.

---

## 22. Circuit breakers are policy, not proof of failure

A circuit breaker may stop sending traffic to a dependency after repeated failures.

Conceptually:

```text
CLOSED -> OPEN -> HALF-OPEN -> CLOSED
```

This can protect an overloaded dependency and reduce wasted work.

But an open circuit does not prove the dependency is dead.

It means:

> The caller's local policy currently considers sending more requests undesirable.

Again, local operational state must not be confused with global truth.

---

## 23. Correlated failures defeat naive replication assumptions

Suppose we run three replicas.

```text
R1 R2 R3
```

Are we tolerant of one hardware failure?

Maybe not if all three are containers on the same physical laptop.

Are we tolerant of one power failure?

Not if all three machines share the same power circuit.

Are we tolerant of one software bug?

Not if every replica runs identical buggy code.

Failure domains can include:

- process;
- container;
- VM;
- host;
- rack;
- switch;
- power domain;
- availability zone;
- region;
- software version;
- credentials/configuration.

Replication only improves resilience when copies do not fail together under the failures being claimed.

---

## 24. Fail-stop, crash, omission, timing, and Byzantine behavior are different claims

It is useful to distinguish several abstractions.

### Crash

Process stops executing.

### Fail-stop

Other processes can reliably detect the stop according to the model.

### Omission

Expected messages/actions are missing.

### Timing

Actions occur too early/late relative to required bounds.

### Byzantine

A component may behave arbitrarily, including sending inconsistent or malicious messages.

Chapter 12 treats Byzantine failures later.

Most of this course assumes crash/omission/timing/network faults unless a module explicitly says otherwise.

You must not claim tolerance to arbitrary malicious behavior merely because the system survives a process kill.

---

## 25. Safety and liveness react differently to failure

Recall:

### Safety

Something bad never happens.

Examples:

- two conflicting values are not both committed as the same log position;
- one request ID does not apply a payment twice;
- a reader does not observe an impossible state according to the claimed model.

### Liveness

Something good eventually happens.

Examples:

- a valid request eventually completes;
- a new leader is eventually elected;
- a recovered replica eventually catches up.

Failure often forces a system to preserve safety by sacrificing liveness temporarily.

For example, during a partition a minority group may refuse writes rather than risk conflicting committed state.

This distinction becomes central in Chapter 9 and Chapter 7.

---

## 26. Availability is contextual

A service can be:

- process-alive but not accepting requests;
- accepting reads but not writes;
- available to one partition but not another;
- reachable but too slow to satisfy the user's deadline;
- returning stale results under a degraded mode.

Therefore reports should avoid vague claims such as:

> “The system remains available.”

Prefer:

> “During loss of one worker, read operations continue from the remaining replicas; writes block until a quorum is restored.”

That statement can be tested.

---

## 27. A fault injector changes the environment; an oracle evaluates the result

Tools such as `tc netem`, process signals, firewall/network namespace rules, or container controls can inject faults.

They do not decide whether the system behaved correctly.

For example:

```bash
tc qdisc add ... netem delay 300ms loss 10%
```

can create delay/loss.

But you still needs an **oracle**:

- expected invariant;
- allowed availability degradation;
- expected recovery behavior;
- data-integrity check;
- trace interpretation.

This is why every lab begins with prediction.

---

## 28. Fault injection must be reproducible and scoped

A good experiment records:

```text
fault type
fault target
start time
end time
parameters
workload
expected behavior
observed behavior
recovery criterion
```

A statement like:

> “I disconnected something and it still worked.”

is not useful evidence.

Prefer:

> “At t=12.0 s, node B's outbound traffic to node A was blocked for 8 s while 20 requests/s continued. A suspected B after 3.1 s. No request was acknowledged twice. B was considered healthy again 1.0 s after connectivity returned.”

Now another person can reason about the experiment.

---

## 29. Worked example — heartbeat false suspicion

Assume:

```text
heartbeat every = 1 s
suspicion timeout = 3 s
```

Normal arrivals at A:

```text
t=0
t=1
t=2
t=3
```

Now the network delays B's heartbeat traffic by 4 seconds.

A observes no new heartbeat between t=3 and t=6.

At approximately t=6:

```text
A marks B SUSPECT
```

Yet B never crashed.

When delayed traffic or fresh heartbeats arrive, A may return B to ALIVE.

This demonstrates:

```text
false suspicion != detector bug necessarily
```

The detector is operating under a timing assumption that the environment temporarily violated.

The design question becomes:

- What incorrect actions are allowed while B is falsely suspected?

If the answer is “A may delete durable data owned by B,” the architecture is dangerous.

If the answer is “A temporarily routes new work elsewhere but preserves safety,” the consequence may be acceptable.

---

## 30. Worked example — crash versus partition

Three nodes:

```text
A B C
```

A monitors B.

### Scenario 1

B process is killed.

A stops receiving heartbeat messages.

### Scenario 2

B stays running, but traffic between A and B is blocked.

A again stops receiving heartbeat messages.

From A's detector alone, the observations may be the same.

However, evidence from another node C may differ:

```text
Scenario 1: C also cannot talk to B
Scenario 2: C may still communicate with B
```

This shows why multi-observer/quorum information can improve decisions—but it still must be interpreted under a network model.

---

## 31. Worked example — unsafe retry amplification

A service can handle 100 requests/s.

It receives 90 requests/s normally.

A temporary pause causes latency to cross client deadlines.

Suppose every timed-out request is retried three times immediately.

Effective offered load can jump toward:

```text
90 original + up to 270 retries
```

The service is now far beyond capacity even after the original pause ends.

Adding retry logic without backoff, jitter, and budgets can therefore reduce availability.

This is why failure handling must be evaluated under load, not only with one client.

---

## 32. Worked example — recovery criterion

A node returns after a 20-second partition.

When is the system “recovered”?

Possible answers:

- TCP connectivity restored;
- heartbeat observed;
- node appears in registry;
- missing state copied;
- node begins serving reads;
- node becomes eligible for writes;
- all replicas converge.

These are different milestones.

A strong experiment defines the one relevant to the claim being measured.

For replication later, a useful metric may be:

```text
repair time = time from healed connectivity to replica fully synchronized
```

For service discovery, it may be:

```text
reroute recovery = time from heal to successful client request
```

---

## 33. Historical perspective — failure detectors made uncertainty explicit

Distributed computing theory did not solve unreliable communication by pretending timeouts were accurate.

Instead, failure-detector research formalized the idea that algorithms can receive **hints or suspicions** about process failures with specified completeness and accuracy properties.

This is a powerful conceptual move.

Rather than ask:

> “How do I detect crashes perfectly?”

we ask:

> “What quality of suspicion does this algorithm require to make progress while preserving safety?”

That framing will matter when consensus appears in Chapter 7.

---

## 36. Common mistakes

### Mistake 1 — timeout means server crashed

Timeout means the caller's deadline expired without the expected observation.

### Mistake 2 — heartbeat means the whole service is healthy

Heartbeat success proves only the tested path/function at one time.

### Mistake 3 — one process kill proves partition tolerance

A crash and a communication partition produce different global conditions.

### Mistake 4 — immediate retries always improve reliability

Retries can duplicate side effects and amplify overload.

### Mistake 5 — replication automatically tolerates failures

Replicas in one shared failure domain may fail together.

### Mistake 6 — recovery starts and ends when the process restarts

State repair and reintegration may still be required.

### Mistake 7 — wall-clock timestamps should compare heartbeat freshness across machines

Use local elapsed-time measurement unless a synchronization model justifies remote timestamp comparison.

### Mistake 8 — suspected equals removed

Suspicion and authoritative membership change are separate mechanisms.

### Mistake 9 — packet loss is the only network fault worth testing

Delay, asymmetry, partitions, duplication, and recovery can reveal different bugs.

### Mistake 10 — failure testing is destructive chaos

A good fault campaign is scoped, repeatable, measurable, and tied to explicit invariants.

---

## Laboratory transition

The Chapter 10 laboratory turns these ideas into measurements.

You will build a heartbeat-based detector, then separately inject:

- process crash;
- delay;
- loss;
- partition;
- healed connectivity;
- repeated client retries.

The important output is not simply whether the system “worked.”

You must measure:

```text
true-failure detection latency
false-suspicion behavior
recovery time
duplicate/retry behavior
load amplification
```

and connect each result to the detector and failure assumptions.

---

## Chapter summary

1. **Failure is a model, not a single event type.** Crash, omission, timing, partition, recovery, and Byzantine behavior carry different assumptions.
2. **A timeout is a local observation.** It does not reveal exactly what happened remotely.
3. **Perfect failure detection is impossible from silence alone in a fully asynchronous setting.** Slow and failed executions can be locally indistinguishable.
4. **Practical failure detectors produce suspicion.** Their quality can be discussed in terms of completeness, accuracy, detection delay, and false positives.
5. **Heartbeats provide evidence of recent communication, not universal health.**
6. **Partitions separate healthy nodes and can produce contradictory local views.**
7. **Retries are part of the failure model.** They may duplicate effects and amplify overload.
8. **Backoff, jitter, and retry budgets limit correlated retry pressure.**
9. **Failure domains determine whether replication actually adds resilience.**
10. **Recovery is part of correctness.** A restarted or reconnected node may require state repair before it is safe to serve traffic.
11. **Safety, liveness, and availability should be stated separately.** Failure may require temporarily sacrificing progress to preserve correctness.
12. **Fault injection only becomes evidence when paired with an oracle, workload, measurements, and explicit expected behavior.**

The next chapter crosses another boundary: one logical operation may need to change state owned by several independent authorities. Recovery now has to preserve a decision across participants, not only reconstruct one replica.

<div class="ds-next-action">
  <span>Core reading complete</span>
  <strong>Next required step · Guided practice</strong>
  <a href="../guided-practice/">Start guided practice →</a>
</div>
