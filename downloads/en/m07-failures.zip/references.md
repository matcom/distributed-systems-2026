> **Reference view.** This page is optional context; return to the [Lesson](../lesson/) for the required path.

## Essential

- **●●● Unreliable Failure Detectors for Reliable Distributed Systems** — Chandra and Toueg. [paper](https://dl.acm.org/doi/10.1145/226643.226647)

## Recommended

- **●●● End-to-End Arguments in System Design** — Saltzer, Reed, Clark. [paper](https://web.mit.edu/Saltzer/www/publications/endtoend/endtoend.pdf)

## Advanced

No additional item assigned yet.

## Tools & Practice

- **●● tc-netem manual** — Linux man-pages project. [tool documentation](https://man7.org/linux/man-pages/man8/tc-netem.8.html)

## Explore

- **●●● Jepsen** — Kyle Kingsbury et al.. [testing resource](https://jepsen.io/)
