<div class="ds-lesson-banner">
  <div><span>Required laboratory</span><strong>Chapter 10</strong></div>
  <div><span>Evidence model</span><strong>predict → run → observe → explain</strong></div>
  <div><span>Verification</span><strong>8 transparent public tests + evidence</strong></div>
</div>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 10 of 12</span>
    <span>83% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 83%"></span></div>
</div>
<p class="ds-back-link"><a href="../quick-check/">← Return to knowledge check</a></p>

> **Before you start:** Complete the guided-practice and knowledge-check steps. You should already be able to state a prediction and name the evidence that would support or contradict it. If not, [return to the knowledge check](../quick-check/) and revisit the lesson where needed.

## Target

Build a heartbeat-based failure detector, then make the same local detector state arise from several different realities: a real process crash, network delay, packet loss, and partition. Measure detection, false suspicion, and recovery rather than merely stating that the system “failed.”

The lab also adds a retry-amplification experiment so you can observe that failure-handling logic can become part of the outage.

## Core completion path

Complete Steps 1–6, Step 8, the durable recovery checkpoint in Step 8b, and Steps 10–13.

Step 7 (one-way fault) and Step 9 (comparing additional detector policies) are **extensions**. They are useful when your environment supports them, but the core chapter does not require every fault shape or detector variant.

## Required topology

Use at least three processes:

```text
observer A
observer C
worker B
```

A and C independently receive heartbeat evidence from B.

Each process should expose or log:

```text
node_id
incarnation_id
heartbeat sequence
local monotonic receive time
peer status: ALIVE/SUSPECT
status transition reason
```

The detector must use local elapsed time for heartbeat freshness.

## Configurable parameters

At minimum:

```text
heartbeat interval
suspicion timeout
recovery threshold or rule
```

Do not hard-code them into protocol logic.

## Step 1 — Healthy baseline

Run the three processes without injected faults for at least ten heartbeat intervals.

Measure:

- configured heartbeat interval;
- observed inter-arrival times at A and C;
- number of missed heartbeats;
- status transitions.

The baseline should establish the normal variability of the environment before choosing conclusions about failure.

## Step 2 — Predict crash detection

Before killing B, calculate an expected range for suspicion latency from the detector's rules.

Then abruptly kill B.

Record:

```text
actual crash time
last heartbeat observed by A
last heartbeat observed by C
A suspicion time
C suspicion time
```

Compute detection latency separately for A and C.

Explain why they need not transition at exactly the same instant.

## Step 3 — Restart and incarnation

Restart B with the same stable node ID but a different incarnation ID.

Verify that observers can distinguish the restarted process from the old incarnation.

If the implementation uses heartbeat sequence numbers, explain why sequence alone may be insufficient across restart unless paired with incarnation/epoch information.

## Step 4 — False suspicion by delay

Keep B alive.

Introduce communication delay larger than the configured suspicion timeout on the relevant heartbeat path.

Where supported, use a scoped network-emulation mechanism such as `tc/netem`, a container/network-namespace rule, or an instructor-provided fault wrapper.

Before applying the fault, predict:

- whether A should suspect B;
- whether C should also suspect B;
- how long suspicion should take.

Collect independent evidence that B remains alive while A changes B's status to `SUSPECT`.

This is the central experiment of the lab.

## Step 5 — Packet loss

Restore normal delay and inject a repeatable loss rate, for example 10–30%.

Run long enough to observe several heartbeat intervals.

Compare at least two suspicion-timeout choices.

For each configuration report:

- true process state;
- number of received/missed heartbeats;
- false-suspicion count;
- approximate detection sensitivity.

Do not claim one timeout is universally best. Explain the trade-off.

## Step 6 — Partition while processes remain alive

Create a communication partition between A and B while keeping both processes running.

Where possible, leave C able to communicate with B:

```text
A  X  B <-> C
```

Collect evidence showing:

```text
A believes B is unreachable/suspect
C still receives B heartbeats
B process remains alive
```

Explain why A's local detector cannot infer the global network topology from silence.

## Extension 7 — One-way fault

If the environment supports directional rules, block or delay only one communication direction.

For example:

```text
A ----request----> B
A <---X response-- B
```

or block heartbeat delivery in only one direction.

Document why “health” depends on the path and operation being tested.

If directional fault injection is not available locally, analyze a provided trace or create a deterministic application-level simulation.

## Step 8 — Heal the partition

Restore normal communication.

Measure at least two milestones:

```text
first fresh heartbeat observed
peer marked ALIVE again
```

If application state also needs repair, identify that as a separate recovery milestone.

Compute:

```text
recovery latency = ALIVE transition time - fault-heal time
```

## Step 8b — Durable state recovery checkpoint

Reuse the smallest stateful service you already have from the communication, consensus, or replication work. You do not need to build a second production-quality service.

Persist enough information to reconstruct one key/value state after a crash:

- a small snapshot or initial durable state;
- an ordered command/update log after that point;
- stable request IDs for side-effecting operations.

Run this sequence:

1. start from a known snapshot/state;
2. apply several updates;
3. ensure at least one acknowledged update is represented durably;
4. stop the process abruptly;
5. restart with empty memory;
6. restore the snapshot/state and replay the required suffix;
7. retry one previously completed request ID.

Before restart, predict the recovered value and whether the retried request should create another effect.

Record:

```text
snapshot/recovery point
durable commands
replay order
recovered state
deduplication decision
time until safe to serve the claimed operation
```

If you already have a replicated log from Chapter 7, use its committed entries as the ordered input. If not, a single-node durable command log is enough to demonstrate the recovery boundary.

The required conclusion is narrower than “the system is fault tolerant.” State exactly which crash/restart history you recovered and which state survived.

## Extension 9 — Compare detector policies

Evaluate two configurations, for example:

```text
Policy A: heartbeat 500 ms, suspect after 1.5 s
Policy B: heartbeat 500 ms, suspect after 4 s
```

Run both under:

- real crash;
- artificial delay/loss.

Compare:

| Policy | Crash detection | False suspicions | Recovery delay | Message rate |
|---|---:|---:|---:|---:|
| A | | | | |
| B | | | | |

Explain the operational trade-off.

## Step 10 — Retry-amplification service

Use a small service whose processing capacity can be limited or artificially delayed.

Generate a steady workload below capacity.

Then introduce latency so client deadlines expire.

Compare:

### Strategy 1 — immediate retries

Retry timed-out operations immediately up to a fixed number of attempts.

### Strategy 2 — bounded backoff

Use:

- maximum attempts or total deadline;
- exponential or increasing backoff;
- jitter where feasible.

Measure:

- logical requests submitted;
- actual attempts sent;
- timeout count;
- throughput;
- tail latency or queue growth;
- time to return to normal after the fault ends.

The key ratio is:

```text
amplification = actual attempts / logical requests
```

## Step 11 — Duplicate-effect audit

If the retry workload contains a state-changing operation, use stable request IDs and determine whether duplicate effects occur.

Connect the result to Chapter 4:

```text
failure handling
    +
retry semantics
    +
idempotency/deduplication
```

must be designed together.

## Step 12 — Failure-domain inventory

Draw the actual physical/logical deployment used in the lab.

For each process, identify shared:

- host OS/kernel;
- CPU/memory pressure;
- storage;
- network interface;
- container runtime;
- power domain.

Then write one fault-tolerance claim the lab **can** support and one it cannot support.

For example:

> The experiment supports tolerance to one process crash, but not to one physical-host failure because all nodes ran on the same laptop.

## Step 13 — Fault campaign table

Summarize all experiments:

| Fault | True world | Local observation | Detector decision | Application effect | Recovery criterion |
|---|---|---|---|---|---|
| crash | | | | | |
| delay | | | | | |
| loss | | | | | |
| partition | | | | | |

The distinction between **true world** and **local observation** is mandatory.

## Transparent-test target

Executable public tests now live under `tests/official/`, with deterministic failure-detector and retry-policy helpers in `starter/src/`. They verify suspicion, incarnation/sequence freshness, and bounded retry behavior; actual crash, delay, partition, false-suspicion, and recovery experiments still require process/network evidence.

The public cases are documented under `tests/official/README.md`. `make test` executes only visible official tests and student additions under `tests/student/`.

No hidden tests are planned.

## AI use

AI assistants and coding agents are permitted.

Include one AI-audited failure diagnosis:

1. provide an assistant with a timeout or heartbeat trace;
2. ask for the cause;
3. identify which claims are observations, plausible hypotheses, or unsupported certainty;
4. verify at least one hypothesis experimentally.

The assessed skill is evidence-based diagnosis, not whether the model guessed correctly.

## Report

Complete `REPORT.md` with predictions, configuration, fault definitions, detector measurements, retry amplification, recovery criteria, and the final failure-domain inventory.

Prefer structured logs/tables over screenshots where possible.

## Finish the chapter

Reproduce the important result from a clean start. Then return to your opening prediction: state what changed in your explanation, what evidence caused the change, and what uncertainty remains. A successful command or screenshot is not enough when the claim concerns retries, ordering, durability, consistency, recovery, security, or performance.

<div class="ds-next-action">
  <span>Chapter complete</span>
  <strong>Continue the course</strong>
  <a href="../../m11-transactions-sharding/">Fault Tolerance II — Transactions, Recovery, and Distributed State →</a>
</div>

<nav class="ds-sequence" aria-label="Course sequence">
<a class="ds-sequence-link" href="../../m08-replication-consistency/">← Replication and Consistency</a>
<a class="ds-sequence-link next" href="../../m11-transactions-sharding/">Fault Tolerance II — Transactions, Recovery, and Distributed State →</a>
</nav>
