<p class="ds-book-part">Part V — Security and Operations</p>
<div class="ds-lesson-banner">
  <div><span>Course step</span><strong>Chapter 12</strong></div>
  <div><span>Core reading</span><strong>40 min–55 min</strong></div>
  <div><span>Required path</span><strong>Read → Practice target → Check → Lab</strong></div>
</div>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 12 of 12</span>
    <span>100% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 100%"></span></div>
</div>

> **Guiding question:** What changes when a participant may be unauthorized, compromised, malicious, overloaded, or simply hard to diagnose?

## Before you read

> A request is slow and eventually succeeds, but the caller was unauthorized. Which evidence belongs to performance diagnosis, which to security, and which to both?

Write a short answer first. You are not expected to be correct yet; you need a prediction you can revise as the chapter gives you better models and evidence.

**Use what you already know:** The complete service built across the course: communication, naming, coordination, replication, recovery, and evidence.

## Workload map

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>40 min–55 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>45 min–1 h 10 min</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>2 h–3 h · 8 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../../downloads/en/m15-security-byzantine.zip" download>Download lesson + practice + lab for offline study (.zip)</a></p>

## Why this chapter matters

Most of the course has assumed **non-malicious failure**. A process may crash, become slow, lose messages, restart with stale state, or become separated by a network partition, but it does not intentionally forge another node's identity or send contradictory messages to different peers.

That assumption is extremely useful. It is also a boundary.

Real distributed systems cross administrative domains, expose APIs to untrusted clients, execute third-party workloads, store secrets, and increasingly allow autonomous software agents to invoke tools and services. Once a node or client may behave adversarially, many earlier mechanisms need stronger assumptions and stronger evidence.

The guiding question is:

> **What changes when a participant may be unauthorized, compromised, malicious, overloaded, or simply hard to diagnose?**

The short answer is that trust and operation become part of correctness. Identity, authority, replay protection, resource limits, latency evidence, backpressure, auditability, and protocol design must all be explicit.

Before the security mechanisms, keep one operational rule:

```text
request ID / trace ID
        ↓
structured events
        ↓
latency + queue + error measurements
        ↓
claim about what happened
```

Averages can hide tail latency. Retries can amplify overload. A healthy process can still be an unhealthy service. Logs and traces must therefore help you answer *which request, which node, which state transition, and which delay* without leaking secrets.

Use the local toolbox for load generation, latency distributions, queue/backpressure experiments, correlation identifiers, and trace reasoning. No hosted observability backend is required.

## Operating the system: evidence before explanation

A distributed system can be correct in its normal trace and still fail its users under load.

### Averages hide tails

Suppose 99 requests finish in 10 ms and one finishes in 5 seconds.

The mean may still look modest compared with the user's experience of the slow request. Record distributions or percentiles rather than one average:

```text
p50
p95
p99
max / timeout rate
```

Tail latency matters because one user operation may depend on several downstream calls. A slow dependency can dominate the whole path.

### Queues reveal pressure before failure becomes obvious

If arrivals exceed service capacity, work accumulates:

```text
arrival rate > service rate
        ↓
queue grows
        ↓
latency grows
        ↓
timeouts/retries
        ↓
more offered load
```

Backpressure, bounded queues, admission control, and load shedding are ways to keep overload from becoming unbounded hidden work.

### Correlation turns logs into a distributed explanation

A useful event record contains enough stable identity to join observations:

```text
request_id
trace_id
node_id / incarnation
operation
start/end or duration
outcome
relevant state/version
```

Without correlation, ten individually correct log lines may still fail to reconstruct one request.

### Diagnose with competing hypotheses

When latency rises, do not begin with “the network is slow.”

Write competing explanations:

- queueing at the service;
- slow storage;
- retries amplifying load;
- one lagging replica;
- expensive serialization;
- network delay;
- authorization or validation work;
- an overloaded downstream dependency.

Then ask which metric, trace span, log event, packet observation, or state snapshot could distinguish them.

> **Pause and predict.** Throughput is flat, CPU is 40%, p99 latency triples, and the request queue grows steadily. Which observation argues against “CPU saturation” as the primary cause? What evidence would you collect next?

Operational evidence is not separate from security. The same traces that help diagnose a request can leak credentials or sensitive payloads, and the same rate/queue controls that stabilize overload can limit resource-exhaustion attacks.

<aside class="ds-book-note ds-history">
  <span class="ds-book-note-label">History</span>
  <strong>Cloud control planes turned reconciliation, leases, service discovery, and consensus into ordinary operational machinery</strong>
  <p>Modern orchestration and coordination platforms made distributed control loops visible to application engineers: desired state, observed state, leader election, watch streams, health, and automatic repair became standard infrastructure concepts.</p>
  <a class="ds-book-note-source" href="../../../history/cloud-control-planes/">Read the design history →</a>
</aside>

## 1. Security begins with a threat model

A useful threat model states:

- what assets matter;
- who the principals are;
- which components are trusted;
- which components may be compromised;
- which communication paths are exposed;
- what an attacker can read, modify, replay, forge, delay, or suppress;
- which failures are outside scope.

Without this, statements such as “the system is secure” are not testable.

For a three-node replicated store, possible assets include:

- client data;
- credentials;
- replica state;
- authorization policy;
- service private keys;
- audit logs.

Possible adversaries include:

- unauthenticated Internet clients;
- authenticated but unauthorized users;
- a compromised worker node;
- a malicious administrator;
- a network attacker able to observe or modify traffic.

Different threat models produce different architectures.

## 2. Trust boundaries should be visible in the architecture

A trust boundary is a point where assumptions change.

For example:

```text
Untrusted client
      |
      v
+------------------+
| Public API       |
+------------------+
      |
      | authenticated identity
      v
+------------------+
| Internal service |
+------------------+
      |
      | service identity
      v
+------------------+
| Storage          |
+------------------+
```

Do not draw all boxes as equally trusted.

Questions to ask at every boundary:

1. How is the caller identified?
2. What is the caller allowed to do?
3. Is traffic confidential?
4. Is message integrity protected?
5. Can old valid messages be replayed?
6. What evidence is recorded for later audit?

## 3. Authentication and authorization solve different problems

**Authentication** answers:

> Who is this principal?

**Authorization** answers:

> Is this principal permitted to perform this action on this resource?

A client can be perfectly authenticated and still be unauthorized.

Example:

```text
identity = student-17
operation = DELETE project/p02
```

Authentication may prove the request originated from `student-17`.

Authorization must still decide whether `student-17` owns or administers that resource.

Do not merge these two checks conceptually.

<figure class="ds-book-figure">
  <img src="../../../assets/book/m15-trust-boundaries.svg" alt="Client, gateway, service, and storage separated by explicit identity and authorization boundaries." loading="lazy" decoding="async" />
  <figcaption><span>Figure</span>Network reachability is not identity, and identity is not authority. Each boundary needs an explicit trust decision and observable enforcement.</figcaption>
</figure>

## 4. Identity is more than an address

Chapter 8 separated names, IDs, addresses, and process incarnations. Security strengthens that distinction.

An IP address is normally a weak identity claim. Addresses can change, be reused, exist behind proxies, or be spoofed in some contexts.

Service identity should usually be tied to a cryptographic credential or authenticated channel rather than merely:

```text
10.0.0.8 means replica-2
```

The authenticated statement should be closer to:

> the peer presenting this credential is authorized to act as replica-2.

## 5. TLS protects a channel, not the entire application

TLS can provide important channel properties such as:

- confidentiality;
- integrity;
- peer authentication when configured appropriately.

But a TLS connection does not establish that every application request is authorized or semantically valid.

A malicious authenticated client can still send dangerous requests.

A compromised authenticated server can still return incorrect data.

So:

```text
TLS
 !=
authorization
 !=
application validation
 !=
distributed consensus
```

These are different layers.

## 6. Server authentication versus mutual authentication

In a common client/server deployment, the client authenticates the server using a certificate chain.

For internal distributed systems, **mutual TLS (mTLS)** may be useful because both sides authenticate one another.

Conceptually:

```text
Client verifies Server
Server verifies Client
```

The server then maps the authenticated client/service identity to an authorization policy.

mTLS can be useful for service-to-service communication, but it adds certificate issuance, rotation, revocation, and operational complexity.

## 7. Certificate validation is part of the protocol

A secure channel is only as meaningful as its verification policy.

Common mistakes include:

- disabling certificate verification during development and leaving it disabled;
- accepting any certificate signed by a broad authority without checking expected service identity;
- ignoring certificate expiration;
- failing to rotate credentials;
- putting private keys in source repositories.

The course does not require production PKI engineering, but you should understand that certificates are assertions bound to trust policy, not magical encryption files.

## 8. Encryption in transit does not imply encryption at rest

A message can be encrypted while crossing the network and later stored unencrypted on disk.

Similarly, a database may encrypt disks while application logs expose sensitive fields in plaintext.

Threat analysis should separate:

- data in transit;
- data at rest;
- data in process memory;
- secrets in configuration;
- data copied into logs/traces.

Observability itself creates security obligations.

## 9. Integrity and authenticity do not prevent replay automatically

Suppose a valid authenticated request says:

```text
transfer 100 from A to B
```

An attacker who cannot modify the message might still replay the exact valid message if the protocol permits it.

This connects directly to Chapter 4's request identifiers and deduplication.

Useful replay defenses can include:

- unique request IDs;
- sequence numbers;
- nonces;
- expiration windows;
- application-level deduplication.

The correct mechanism depends on the protocol.

## 10. Security and idempotency intersect

A duplicate may arise accidentally through a retry or intentionally through replay.

The service should not need to guess which happened.

If the operation semantics require one logical effect, the same duplicate-suppression mechanisms can protect both reliability and security properties.

This is an example of one mechanism supporting multiple concerns.

## 11. Authorization should follow least privilege

A service should receive only the capabilities required for its role.

For example, a worker that performs image resizing may need:

```text
read input object
write result object
update own job status
```

It may not need:

```text
delete arbitrary users
change cluster membership
read every secret
```

Reducing authority limits the damage of compromise.

This becomes especially important in agentic systems where software can autonomously invoke tools.

## 12. Capability-based thinking is useful for autonomous tools

An agent that can call a tool is effectively being granted authority.

The meaningful question is not:

> Is this agent intelligent?

It is:

> What operations can this principal perform, on which resources, under which constraints?

A tool interface that allows:

```text
read_calendar
```

has a different risk profile from:

```text
send_email
```

or:

```text
execute_shell_command
```

Agentic infrastructure should therefore be analyzed with ordinary security concepts:

- identity;
- delegation;
- least privilege;
- explicit scopes;
- audit trails;
- idempotency;
- confirmation boundaries;
- revocation.

## 13. A compromised node changes the failure model

In crash-fault systems, a faulty node generally stops contributing useful responses.

A Byzantine node may behave **arbitrarily**.

It might:

- lie about its state;
- send one value to node A and another to node B;
- forge data if credentials permit;
- omit selected messages;
- replay old messages;
- claim to have persisted data it did not persist;
- collude with other faulty nodes.

This is fundamentally harder than a simple crash.

## 14. Equivocation is a characteristic Byzantine behavior

Consider node X telling two peers:

```text
To A: value = red
To B: value = blue
```

A crash-only protocol may never have been designed to handle this contradiction.

In Byzantine settings, protocols often need authenticated messages, quorum structures, and evidence that allows honest replicas to detect or tolerate inconsistent statements.

## 15. Crash-fault consensus and Byzantine consensus are not interchangeable

Raft assumes a crash-fault model. A node may fail or become unreachable, but the algorithm is not designed for a replica intentionally fabricating protocol messages while still participating.

This does **not** make Raft insecure or useless.

It means its correctness theorem has a defined assumption boundary.

Always state:

```text
protocol guarantee
under
failure model
```

rather than claiming a protocol “handles failures” generically.

## 16. Byzantine quorums require stronger redundancy

For many classic Byzantine fault-tolerant designs, tolerating `f` Byzantine replicas requires at least:

```text
n >= 3f + 1
```

and decisions often require evidence from at least:

```text
2f + 1
```

replicas.

Why?

Because quorums must overlap in enough replicas that contradictory decisions cannot both be supported solely through faulty participants.

For `f = 1`:

```text
n >= 4
```

This is already more expensive than the three-node crash-fault cluster used in many earlier exercises.

## 17. PBFT is a useful historical reference

Practical Byzantine Fault Tolerance (PBFT) demonstrated that Byzantine fault tolerance could be engineered for practical replicated services under appropriate deployment assumptions.

You do not need to implement full PBFT in this course.

Instead, use it to compare:

- failure model;
- replica count;
- quorum intersection;
- message complexity;
- authentication assumptions;
- view/leader changes;
- performance trade-offs.

The central lesson is architectural: stronger adversary models cost more.

## 18. Byzantine agreement is still about distributed-system properties

Do not reduce BFT to cryptography.

Cryptographic signatures or MACs can provide authenticity/integrity evidence, but they do not by themselves cause replicas to agree.

Agreement still requires a protocol that reasons about:

- messages;
- quorums;
- rounds/views;
- failures;
- progress assumptions.

Similarly:

```text
signatures != consensus
```

## 19. Sybil attacks reveal another identity assumption

In an open system, one physical attacker might create many apparent identities.

If the protocol says:

> majority of identities decides

but identities are cheap to create, a majority may be cheap to fabricate.

Permissioned systems can rely on controlled membership.

Open membership systems need a different mechanism for deciding who has voting weight or participation rights.

This is one reason blockchain and distributed-ledger systems often introduce economic or resource-based admission mechanisms.

## 20. Distributed ledgers are a case study, not the definition of distributed systems

The historical course used proof-of-work and proof-of-stake near coordination topics. In this redesign they appear late, after you already understand:

- failure models;
- replication;
- quorum intersection;
- consensus;
- state-machine replication;
- security boundaries.

This ordering makes it possible to ask better questions.

A ledger may need:

```text
ordered transactions
replicated state
membership/admission rules
Byzantine tolerance
economic incentives
cryptographic integrity
```

These are related but distinct mechanisms.

## 21. Proof of work and proof of stake solve membership/weight problems differently

In open networks, there may be no fixed list of trusted replicas.

Proof-of-work associates influence with computational expenditure.

Proof-of-stake associates participation/influence with stake under a protocol's economic rules.

Neither concept should be presented as a universal replacement for Raft/Paxos/PBFT.

They are responses to different deployment and adversary assumptions.

## 22. Permissioned versus permissionless changes the system problem

A university cluster where all replicas are provisioned by one administrator has a different membership problem from a global open network where anonymous parties can join.

Before choosing an algorithm, ask:

- Who may join?
- Who issues identity?
- Is membership fixed or dynamic?
- Can an attacker cheaply create many participants?
- What fraction of participants may be malicious?

The answers determine which consensus/security model makes sense.

## 23. Security failures can look like ordinary distributed failures

A malicious node can intentionally create:

- timeouts;
- stale responses;
- partial replies;
- inconsistent metadata;
- fabricated health reports.

Therefore observability alone does not automatically distinguish accident from attack.

Security investigation often needs stronger audit evidence and authenticated identities.

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosity</span>
  <strong>Four replicas may be needed to tolerate one Byzantine fault where three were enough for one crash fault</strong>
  <p>Stronger adversary models require stronger redundancy and quorum reasoning. A malicious node can equivocate rather than merely disappear, so a crash-fault majority protocol cannot simply be relabeled Byzantine tolerant.</p>
  <p><strong>Try it:</strong> Use `n >= 3f + 1` for `f = 1` and compare the resulting four-replica requirement with a three-node Raft cluster.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">More chapter curiosities →</a>
</aside>

## 24. Logging and tracing become security-sensitive

Rich telemetry helps you diagnose the system, but it also creates a warning:

**do not leak secrets into the evidence system.**

Avoid logging:

- passwords;
- bearer tokens;
- private keys;
- raw session secrets;
- unnecessarily sensitive user data.

A distributed trace can propagate baggage/context through many services. Sensitive metadata can therefore become widely replicated if telemetry is designed carelessly.

## 25. Audit logs need stronger properties than debug logs

Debug logs are primarily operational evidence.

Audit logs may need to answer:

- who performed an operation;
- what resource was affected;
- when authorization was checked;
- which policy was applied;
- whether the event record has been tampered with.

Not every project needs a tamper-evident audit system, but you should understand that security auditing has different requirements from ordinary diagnostics.

## 26. Secrets are distributed state too

Certificates, tokens, API keys, and credentials have life cycles:

```text
issue
  ↓
distribute
  ↓
use
  ↓
rotate
  ↓
revoke
  ↓
expire
```

Embedding a secret permanently in source code ignores that life cycle.

For course projects, secrets should be externalized from source and test credentials should be clearly non-production.

## 27. Compromised workers are especially relevant in job systems

Projects such as:

- distributed build execution;
- tournament execution;
- ML training;
- cluster orchestration

run code on workers.

Ask two independent questions:

1. Can the submitted workload harm the worker?
2. Can a compromised worker lie about the result?

Container isolation can help with the first.

It does not automatically solve the second.

## 28. Sandboxing and Byzantine correctness are different

Suppose a tournament worker executes untrusted player code inside a container.

The container may limit filesystem/process access.

But the worker host can still potentially fabricate a match result.

Isolation protects one boundary.

Result trust is a separate distributed/security problem.

This is another recurring pattern of the chapter: one mechanism rarely solves all layers.

## 29. Modern cloud architectures combine many trust domains

A simplified cloud service may contain:

```text
Internet client
    ↓
Gateway
    ↓
Service mesh / service identity
    ↓
Application services
    ↓
Databases / queues / object stores
    ↓
Cloud control plane
```

Each layer may be operated by different software, identities, permissions, and infrastructure.

A strong architecture review asks:

- what is trusted at each boundary;
- what credentials cross it;
- what happens when one internal service is compromised;
- which actions require stronger authorization;
- where durable authority actually resides.

## 30. Zero-trust language is less important than explicit verification

The phrase “zero trust” can become vague.

For this course, prefer specific statements such as:

- internal service calls are mutually authenticated;
- authorization policy is checked per operation;
- service credentials have bounded scope;
- network location alone is not accepted as authority;
- sensitive operations are audited.

Specific mechanisms are easier to reason about and test.

## 31. Agentic systems make delegation visible

Modern agent platforms often connect:

```text
User
  ↓
Agent
  ↓
Tool / service
```

The agent may make decisions autonomously, but the tool ultimately performs an action.

Questions include:

- Which user identity is propagated?
- Does the agent act as itself or on behalf of the user?
- Which scopes were delegated?
- Can the tool distinguish read-only from destructive authority?
- How is approval represented?
- How is a duplicated tool action prevented?
- What happens when the tool succeeds but the agent times out?

Notice how Chapter 4 reliability semantics return immediately.

## 32. Agent-to-agent communication does not remove ordinary distributed-system problems

Whether the communicating components are called services, workers, actors, or agents, the platform still faces:

- discovery;
- authentication;
- authorization;
- deadlines;
- retries;
- message validation;
- task persistence;
- observability;
- partial failure.

Agentic software adds semantic uncertainty, but the infrastructure remains distributed infrastructure.

## 33. Tool descriptions are not security policy

An agent may see a tool described as:

> “send a calendar invitation”

That human-language description does not enforce which calendars, recipients, or fields the caller is authorized to modify.

The tool implementation must still validate identity and authorization.

Never rely on a model instruction as the sole access-control boundary.

## 34. Prompt injection is an application-layer trust problem

If an agent reads untrusted content and that content can influence later tool calls, untrusted data has crossed into a control path.

From a systems viewpoint, ask:

```text
What input is untrusted?
Which component interprets it?
Which authority can that component exercise?
Where is policy enforced independently?
```

The course does not need to become an AI-security course to teach this correctly. It is an instance of untrusted input influencing privileged action.

## 35. Validation belongs at every external boundary

A parser accepting a well-formed Protobuf or JSON message has only established syntax.

Application validation still needs to enforce constraints such as:

- ranges;
- identities;
- ownership;
- state transitions;
- resource limits;
- authorization.

Distributed systems often fail when a message is considered “trusted” merely because it came from another internal service.

## 36. Resource exhaustion is both availability and security

An attacker may not need to break cryptography.

They may instead:

- create too many connections;
- submit huge payloads;
- trigger expensive fan-out;
- cause retry amplification;
- exhaust queues;
- force unbounded state creation.

Admission control and bounded-resource reasoning therefore contribute to security as well as performance.

## 37. Byzantine tolerance has performance costs

Compared with crash-fault replication, BFT commonly increases:

- replica count;
- message exchange;
- verification work;
- protocol complexity;
- state-management complexity.

That cost may be justified when the threat model requires it.

It is wasteful when the environment does not.

Choose the failure model from the deployment assumptions, not from algorithm prestige.

## 38. Not every compromised component should trigger Byzantine consensus

Suppose a public API client may be malicious, but all storage replicas run under one trusted administrative domain.

The correct response may be:

```text
authenticate client
authorize operation
validate input
rate limit
use ordinary crash-fault replication internally
```

rather than replacing the storage consensus algorithm with PBFT.

Security architecture is layered.

## 39. Final-project trust model

Every final project should contain a compact trust table.

Example:

| Component | Trusted? | Identity mechanism | Main authority | Failure/adversary assumption |
|---|---|---|---|---|
| Client | No | user credential | own resources | may send invalid requests |
| Gateway | Yes | service credential | route/authenticate | crash-fault |
| Worker | Partially | service identity | execute assigned work | may crash; optional compromise analysis |
| Storage replicas | Yes | service identity | durable state | crash-fault |

The table forces hidden assumptions into the open.

## 40. Threat-model one historical project

Consider the decentralized messaging project.

Assets:

- message content;
- contact identity;
- delivery metadata.

Threats:

- impersonation;
- eavesdropping;
- replay;
- message tampering;
- malicious relay;
- offline recipient.

Notice that availability and confidentiality interact: relaying/storing messages for offline recipients increases the number of places sensitive data may exist.

## 41. Threat-model one modern project

Consider the distributed build executor.

Assets:

- repository contents;
- build secrets;
- produced artifacts;
- worker hosts.

Threats:

- malicious submitted code;
- compromised worker;
- artifact substitution;
- secret leakage;
- forged completion result.

Possible controls map cleanly to course concepts:

- workload isolation;
- authenticated workers;
- content hashes;
- scoped credentials;
- durable job state;
- audit logs.

## 42. Worked example — authenticated request but unauthorized action

Suppose:

```text
Alice authenticates successfully.
Alice requests DELETE /objects/bob/report.pdf.
```

The channel is encrypted and Alice's identity is valid.

The operation must still fail if Alice lacks authority over Bob's object.

This simple example prevents a common conceptual collapse:

```text
secure channel
   !=
allowed operation
```

## 43. Worked example — replayed transfer

Request:

```text
request_id = R77
operation = transfer(A,B,100)
```

The request is authenticated and integrity-protected.

The server commits the transfer but the response is lost.

The client retries R77.

If the service uses durable request deduplication, it returns the prior result without a second transfer.

If an attacker later replays the same authenticated message, the same mechanism also prevents another effect, subject to the request-ID retention policy.

Reliability and security meet at the semantic boundary.

## 44. Worked example — malicious replica equivocation

Four replicas tolerate one Byzantine fault under a simplified BFT discussion.

Faulty replica R4 sends:

```text
value X to R1
value Y to R2
value Y to R3
```

A protocol must not let R4's contradictory statements create two independently committed outcomes.

The exact PBFT phases are beyond the implementation requirement, but quorum reasoning should explain why one faulty participant cannot alone create two honest decision quorums.

## 45. Worked example — agent tool timeout

An agent calls:

```text
send_payment(request_id=R9)
```

The payment service commits successfully, but the response is delayed beyond the agent deadline.

The agent retries.

Nothing about “agentic AI” changes the distributed-systems question.

The system still needs:

- stable request identity;
- authenticated authority;
- authorization;
- retry-safe semantics;
- auditability.

This is exactly why the course treats agentic systems as consumers of distributed-systems engineering rather than substitutes for it.

## 46. Historical perspective — stronger failure models followed deployment needs

Early distributed-system work often distinguished benign failures from arbitrary failures because the algorithms and required redundancy differ drastically.

Byzantine-failure research asked what could be guaranteed when participants could send contradictory or arbitrary information.

PBFT later demonstrated a practical state-machine replication design for Byzantine settings under realistic cryptographic/network assumptions of its era.

Modern blockchains, permissioned ledgers, cross-organization systems, and agent/tool ecosystems continue revisiting the same fundamental questions:

> Who is trusted, who participates, what can fail maliciously, and what evidence makes a decision authoritative?

The technology changes. The questions persist.

## 47. Common mistakes

### Mistake 1 — “TLS means the service is secure”

TLS protects a channel. Authorization, validation, storage security, and compromised endpoints remain separate concerns.

### Mistake 2 — use IP address as identity

Addresses locate endpoints. They are not generally sufficient authentication claims.

### Mistake 3 — authenticate but never authorize

Knowing who the caller is does not determine what the caller may do.

### Mistake 4 — log secrets for debugging

Observability data often has broad access and long retention. Sensitive values should not be copied casually into it.

### Mistake 5 — treat Raft as Byzantine tolerant

Raft is designed around benign/crash-style replica failure assumptions, not arbitrary malicious replicas.

### Mistake 6 — add signatures and claim consensus

Authentication evidence does not create agreement by itself.

### Mistake 7 — use blockchain because multiple nodes exist

Deployment and adversary assumptions should select the mechanism.

### Mistake 8 — trust an internal service automatically

Compromise often crosses “internal” boundaries. Authenticate and authorize according to actual risk.

### Mistake 9 — grant an AI agent broad tool authority because its prompt says not to misuse it

Policy must be enforced outside the model at the tool/service boundary.

### Mistake 10 — conflate convergence with integrity

Replicas can converge to the same maliciously injected value. Consistency does not imply authorization or correctness of input.

## 50. Laboratory transition

The lab takes a system built earlier in the course and performs three transformations:

```text
implicit trust
    ↓
explicit threat model
    ↓
authenticated service/client boundary
    ↓
malicious-node thought experiment
```

You must not merely “turn on TLS.” They must identify exactly which threat TLS addresses, add an authorization or message-validation boundary, test at least one unauthorized/replayed request, and explain which earlier correctness guarantee breaks if one trusted replica becomes Byzantine.

## Chapter summary

Security changes distributed-systems reasoning by changing assumptions about **who may participate and how they may behave**.

Remember the layer boundaries:

```text
address
 !=
identity

identity
 !=
authority

TLS
 !=
authorization

signatures
 !=
consensus

crash tolerance
 !=
Byzantine tolerance

agent instruction
 !=
security policy
```

A strong design states its threat model, protects trust boundaries with appropriate mechanisms, minimizes authority, validates external messages, and uses a distributed protocol whose failure model matches the deployment.

The final-project question is therefore not merely:

> Does the system survive node failure?

It is also:

> **Which nodes are trusted, what may an untrusted participant do, and which guarantees remain valid if those assumptions are violated?**

<div class="ds-next-action">
  <span>Core reading complete</span>
  <strong>Next required step · Guided practice</strong>
  <a href="../guided-practice/">Start guided practice →</a>
</div>
