<p class="ds-book-part">Part V — Security and Operations</p>
<p class="ds-module-kicker">Chapter 12</p>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 12 of 12</span>
    <span>100% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 100%"></span></div>
</div>
<p class="ds-guiding-question">What changes when a participant may be unauthorized, compromised, malicious, overloaded, or simply hard to diagnose?</p>

Finish by widening the assumptions you made throughout the book. Identify who you trust, authenticate service identity, authorize actions, test replay, and ask which crash-fault arguments fail when a node lies. At the same time, use logs, metrics, traces, latency distributions, and backpressure signals to determine what the running system is actually doing.

## Key ideas

- threat models and trust boundaries
- authentication and authorization
- TLS and service identity
- replay and message validation
- least privilege
- Byzantine behavior and equivocation
- crash-fault versus Byzantine agreement
- structured logs and correlation identifiers
- metrics, traces, latency distributions, and backpressure
- audit evidence and secret handling

## Laboratory transition

Threat-model a service from an earlier chapter, add one authenticated/authorized boundary, reproduce an unauthorized or replayed request, then diagnose the execution from compact operational evidence.

## Start here

> **Before you read:** A request is slow and eventually succeeds, but the caller was unauthorized. Which evidence belongs to performance diagnosis, which to security, and which to both?

**Bring forward:** The complete service built across the course: communication, naming, coordination, replication, recovery, and evidence.

**This chapter builds toward:** A system you can operate and defend: observable under load, explicit about trust, and honest about its failure model.

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>40 min–55 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>45 min–1 h 10 min</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>2 h–3 h · 8 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Read lesson →</a>
  <a class="ds-secondary-action" href="lab/">Open laboratory</a>
</div>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../downloads/en/m15-security-byzantine.zip" download>Download chapter + laboratory for offline study (.zip)</a></p>

## What you will learn

- Draw explicit trust boundaries and distinguish authentication, authorization, and transport protection.
- Test replay, unauthorized action, and message-validation behavior at a service boundary.
- Distinguish crash-fault consensus from Byzantine behavior such as equivocation.
- Use structured logs, metrics, traces, latency distributions, and backpressure evidence to diagnose a distributed execution.
- State which security and operational claims your evidence supports and which assumptions remain outside the design.

## Learn by working the question

1. Write your answer to **Start here** before opening the full lesson.
2. Read until the next prediction or trace, then stop and work it out before revealing the explanation.
3. Treat guided practice as a **practice bank**, not a speed worksheet. Work the core traces until you can meet the chapter's Practice target; return to the remaining cases for retrieval practice or instructor-assigned work.
4. Use the knowledge check to find gaps, then enter the laboratory with a falsifiable prediction and name the evidence that could contradict it.
5. Finish by explaining what the experiment established, what it did not establish, and how the result changes the evolving service.

<nav class="ds-sequence" aria-label="Course sequence">
<a class="ds-sequence-link" href="../m11-transactions-sharding/">← Fault Tolerance II — Transactions, Recovery, and Distributed State</a>
</nav>
