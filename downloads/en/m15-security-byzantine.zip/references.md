> **Reference view.** This page is optional context; return to the [Lesson](../lesson/) for the required path.

## Essential

- **●●● Practical Byzantine Fault Tolerance** — Miguel Castro and Barbara Liskov. [paper](https://pmg.csail.mit.edu/papers/osdi99.pdf)

## Recommended

- **●●● RFC 8446 — The Transport Layer Security (TLS) Protocol Version 1.3** — IETF. [standard](https://www.rfc-editor.org/rfc/rfc8446)

## Advanced

No additional item assigned yet.

## Tools & Practice

- **●● OpenSSL Documentation** — OpenSSL Project. [tool documentation](https://docs.openssl.org/)

## Explore

- **●●● A2A Protocol Specification** — A2A Project. [protocol reference](https://a2a-protocol.org/)
