import json
import threading
import unittest
import urllib.error
import urllib.request

from client import request_work
from node import make_server
from protocol import make_event, normalize_request_id, parse_work_value, validate_delay_ms, validate_timeout_ms


class WorkbenchProtocolTests(unittest.TestCase):
    def test_request_id_is_required_and_normalized(self):
        self.assertEqual(normalize_request_id("  req-7  "), "req-7")
        with self.assertRaises(ValueError):
            normalize_request_id(" ")

    def test_work_value_parsing(self):
        self.assertEqual(parse_work_value("/work?value=-7"), -7)
        with self.assertRaises(ValueError):
            parse_work_value("/work")
        with self.assertRaises(ValueError):
            parse_work_value("/work?value=nope")

    def test_configuration_validation(self):
        self.assertEqual(validate_delay_ms(0), 0)
        self.assertEqual(validate_timeout_ms(25), 25)
        with self.assertRaises(ValueError):
            validate_delay_ms(-1)
        with self.assertRaises(ValueError):
            validate_timeout_ms(0)

    def test_structured_event_fields(self):
        event = make_event(
            node_id="b",
            request_id="req-1",
            event="request_finished",
            value=21,
            result=42,
        )
        self.assertEqual(
            event,
            {
                "node_id": "b",
                "request_id": "req-1",
                "event": "request_finished",
                "value": 21,
                "result": 42,
            },
        )


class WorkbenchHTTPTests(unittest.TestCase):
    def setUp(self):
        self.events = []
        self.server = make_server(
            node_id="test-node",
            port=0,
            event_sink=self.events.append,
        )
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.port = self.server.server_address[1]

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)

    def test_health_shape(self):
        with urllib.request.urlopen(
            f"http://127.0.0.1:{self.port}/health", timeout=1
        ) as response:
            body = json.loads(response.read().decode("utf-8"))
        self.assertEqual(body, {"ok": True, "node_id": "test-node"})

    def test_work_result_and_request_id_propagation(self):
        body = request_work(
            port=self.port,
            value=21,
            request_id="m00-test",
            timeout_ms=1000,
        )
        self.assertEqual(body["result"], 42)
        self.assertEqual(body["request_id"], "m00-test")
        self.assertEqual(body["node_id"], "test-node")
        self.assertEqual(
            [event["event"] for event in self.events],
            ["request_started", "request_finished"],
        )
        self.assertTrue(all(event["request_id"] == "m00-test" for event in self.events))

    def test_malformed_request_returns_400(self):
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}/work?value=nope",
            headers={"X-Request-ID": "bad-1"},
        )
        with self.assertRaises(urllib.error.HTTPError) as caught:
            urllib.request.urlopen(req, timeout=1)
        self.assertEqual(caught.exception.code, 400)


if __name__ == "__main__":
    unittest.main()
