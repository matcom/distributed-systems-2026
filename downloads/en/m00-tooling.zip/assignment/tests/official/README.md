# Transparent official cases

These tests are executable and intentionally visible.

They verify only deterministic behavior you can inspect from the starter implementation:

- `/health` response shape;
- integer parsing for `/work?value=`;
- deterministic `value * 2` behavior;
- request-ID validation and propagation;
- structured event fields;
- non-negative delay and positive timeout validation;
- clean HTTP 400 behavior for malformed work requests.

The suite does **not** pretend that a unit test proves the process-kill, timeout-ambiguity, socket, or packet-observation claims from the laboratory. Those remain explicit experiments supported by your evidence.

Add your own visible cases under `tests/student/`.

No hidden tests are used.
