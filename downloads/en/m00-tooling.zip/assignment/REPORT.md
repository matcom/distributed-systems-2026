# M00 Laboratory Report

## Environment

- OS:
- Python version:
- Git revision / dirty state:
- Optional tools available (`ss`, `curl`, `tcpdump`, Wireshark, Docker/Podman, `tc`):

## Logical topology and physical failure domain

Describe the three nodes, endpoints, and what all nodes still share physically.

## Baseline

### Prediction

### Commands / configuration

### Evidence

### Explanation

## Correlated request

- Request ID:
- Client evidence:
- Server/node evidence:
- Socket/network evidence:
- What this proves:

## Node-kill experiment

### Prediction

### Evidence

### Explanation

## Slow-node and timeout experiment

### Prediction

### Client observation

### Server observation

### What the timeout proves

### What the timeout does not prove

## Optional packet or network-level evidence

State capture/impairment point and cleanup procedure.

## Student-authored transparent test

Describe the case and why it matters.

## AI-use disclosure

```yaml
ai_use:
  used: false
  tools: []
  activities: []
  verification: []
```

## Final reflection

Before saying “the distributed system is broken,” which evidence will you now collect first, and why?