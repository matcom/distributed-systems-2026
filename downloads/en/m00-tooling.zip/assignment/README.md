# Laboratory — Warm-up: Observe and Break a Local Cluster

## Purpose

Before building a distributed algorithm, prove that you can create, observe, perturb, and restore a small distributed execution on your own machine.

You will run three independent service processes, identify their process and socket state, issue requests carrying request IDs, kill one node, introduce controlled delay, and produce an evidence-based report.

This laboratory is intentionally simple at the application level. The assessed skill is **experimental control and observation**.

## Learning target

By the end, you should be able to answer:

> Which node handled request `R`, which process/endpoint represented that node, what changed when one node was killed or slowed, and which evidence proves each statement?

## Environment

Required:

- Python 3
- Git

Strongly recommended:

- `ss`
- `curl`

Optional for deeper observation:

- `tcpdump` or Wireshark
- Docker/Podman
- `tc netem`

The mandatory path does not require root privileges.

## Minimal service contract

Implement a deliberately small HTTP node and client as the first Warm-up exercise. Keep the implementation simple enough that the systems evidence—not application logic—remains the focus.

Use this suggested layout:

```text
src/node.py
src/client.py
src/protocol.py
```

Each node should expose:

```text
GET /health
GET /work?value=<integer>
```

`/work` returns twice the supplied integer after an optional configurable delay. The node must accept a stable `X-Request-ID` header and include the same request ID in structured server events.

The required command-line shape used by the remainder of this lab is:

```text
node.py --node-id <id> --port <port> [--delay-ms <ms>]
client.py --port <port> --value <integer> --request-id <id> [--timeout-ms <ms>]
```

A student may implement this contract with the Python standard library or another small local implementation approved by the instructor. This is not meant to be an interesting distributed application; it gives us a stable target for observation.

## Step 1 — Establish repository state

Record:

```bash
git status --short
git rev-parse --short HEAD
```

If the exported lab is not itself committed yet, state that clearly in the report rather than inventing a revision identifier.

## Step 2 — Start three nodes

Use three terminals:

```bash
python3 src/node.py --node-id a --port 8101
python3 src/node.py --node-id b --port 8102
python3 src/node.py --node-id c --port 8103
```

Predict before inspecting: how many Python server processes and listening TCP sockets should exist?

Now collect evidence:

```bash
pgrep -af 'src/node.py'
ss -lntp | grep -E '8101|8102|8103'
```

If your platform does not expose process ownership through `ss`, record the socket evidence you can obtain and use process evidence separately.

## Step 3 — Issue a correlated request

Send a request through the provided client:

```bash
python3 src/client.py --port 8102 --value 21 --request-id m00-r1
```

The result should be `42`.

Find the corresponding server event using `request_id=m00-r1` in the structured output.

Your report must connect:

```text
client request
    ↓
network endpoint
    ↓
server process/node ID
    ↓
server request event
    ↓
response
```

## Step 4 — Confirm with an independent client

Use `curl`:

```bash
curl -s 'http://127.0.0.1:8102/work?value=7' -H 'X-Request-ID: m00-curl-1'
```

Explain what this establishes that the provided client alone does not.

## Step 5 — Observe traffic

If packet capture is available and permitted, capture loopback traffic in a separate terminal:

```bash
sudo tcpdump -i lo -nn tcp port 8102
```

Generate one request and stop the capture.

Record:

- capture interface;
- client/server addresses and ports;
- whether you can identify connection/request traffic;
- one limitation of what this capture proves.

If packet capture is unavailable, use the provided process/socket/log evidence path instead. Lack of root privilege does not prevent completion of the lab.

## Step 6 — Kill one node

Before killing node B, predict the outcome of:

```bash
python3 src/client.py --port 8102 --value 5 --request-id m00-dead
```

Terminate the node B process.

Then collect:

```bash
pgrep -af 'src/node.py'
ss -lntp | grep -E '8101|8102|8103'
```

Run the client request.

Explain why failure of B does not imply failure of A or C.

Also state the shared physical failure domain of this experiment.

## Step 7 — Restart with artificial delay

Restart B with a 700 ms application delay:

```bash
python3 src/node.py --node-id b --port 8102 --delay-ms 700
```

Run:

```bash
python3 src/client.py --port 8102 --value 8 --request-id m00-slow --timeout-ms 1500
```

Then deliberately use a smaller timeout:

```bash
python3 src/client.py --port 8102 --value 8 --request-id m00-timeout --timeout-ms 200
```

The second command should fail locally even though the server may still finish the operation.

Explain precisely what the timeout proves and what it does **not** prove.

## Step 8 — Optional network-level delay

If you have a disposable interface or namespace and understand how to restore it, repeat the delay experiment using `tc netem` rather than the application `--delay-ms` option.

Do **not** apply impairment to a remote-management or production interface.

Document the exact interface and cleanup command.

## Step 9 — Transparent tests

The starter service and client live under:

```text
starter/src/
```

The executable public cases live under:

```text
tests/official/
```

Run them with the course's transparent test runner. The public suite checks only behavior you can inspect locally: request parsing, configuration validation, structured event fields, health response, deterministic work, request-ID propagation, and malformed-request handling.

Add at least one case under:

```text
tests/student/
```

Good additions include:

- another negative integer case;
- missing request ID;
- an unknown path;
- a second structured-event assertion.

Process termination, delay, socket inspection, and packet evidence remain report-based because those experiments are about interpretation of a running system rather than hidden unit-test tricks.

No hidden cases are planned.

## Step 10 — Teardown

Stop all remaining node processes.

Confirm that the lab ports are no longer listening.

A reproducible experiment includes cleanup.

## Required report

Complete `REPORT.md` with:

1. environment and tool availability;
2. logical topology and physical failure domain;
3. baseline prediction and evidence;
4. one correlated request trace;
5. node-kill prediction/evidence/explanation;
6. slow-node/timeout prediction/evidence/explanation;
7. optional packet/network evidence;
8. one student-authored test;
9. AI-use disclosure;
10. a short statement of what you can now prove before saying “the distributed system is broken.”

## Assessment emphasis

A successful submission does **not** need elaborate application code.

It does need to show that you can distinguish:

- process state;
- socket state;
- application behavior;
- timing behavior;
- network evidence;
- local suspicion from remote fact.

## AI use

AI assistants and coding agents are permitted.

If an assistant proposes the reason for a failure, include the local evidence you used to confirm or reject that hypothesis. An AI explanation is not a substitute for an observation from the experiment.