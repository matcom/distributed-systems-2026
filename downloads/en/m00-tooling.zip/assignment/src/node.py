"""Minimal observable HTTP node for the Warm-up lab."""

from __future__ import annotations

import argparse
import json
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Callable, Dict

from protocol import make_event, normalize_request_id, parse_work_value, validate_delay_ms, work_result

EventSink = Callable[[Dict[str, object]], None]


def stdout_event_sink(event: dict[str, object]) -> None:
    print(json.dumps(event, sort_keys=True), flush=True)


class WorkbenchServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(
        self,
        address: tuple[str, int],
        *,
        node_id: str,
        delay_ms: int = 0,
        event_sink: EventSink = stdout_event_sink,
    ) -> None:
        if not node_id.strip():
            raise ValueError("node_id must not be empty")
        super().__init__(address, WorkbenchHandler)
        self.node_id = node_id.strip()
        self.delay_ms = validate_delay_ms(delay_ms)
        self.event_sink = event_sink


class WorkbenchHandler(BaseHTTPRequestHandler):
    server: WorkbenchServer

    def log_message(self, format: str, *args) -> None:
        return

    def _json(self, status: int, payload: dict[str, object]) -> None:
        body = json.dumps(payload, sort_keys=True).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        if self.path == "/health":
            self._json(200, {"ok": True, "node_id": self.server.node_id})
            return

        try:
            request_id = normalize_request_id(self.headers.get("X-Request-ID"))
            value = parse_work_value(self.path)
        except ValueError as exc:
            self._json(400, {"error": str(exc)})
            return

        self.server.event_sink(
            make_event(
                node_id=self.server.node_id,
                request_id=request_id,
                event="request_started",
                value=value,
            )
        )
        if self.server.delay_ms:
            time.sleep(self.server.delay_ms / 1000.0)

        result = work_result(value)
        self.server.event_sink(
            make_event(
                node_id=self.server.node_id,
                request_id=request_id,
                event="request_finished",
                value=value,
                result=result,
            )
        )
        self._json(
            200,
            {
                "node_id": self.server.node_id,
                "request_id": request_id,
                "value": value,
                "result": result,
            },
        )


def make_server(
    *,
    node_id: str,
    port: int,
    delay_ms: int = 0,
    host: str = "127.0.0.1",
    event_sink: EventSink = stdout_event_sink,
) -> WorkbenchServer:
    if not 0 <= port <= 65535:
        raise ValueError("port must be between 0 and 65535")
    return WorkbenchServer(
        (host, port),
        node_id=node_id,
        delay_ms=delay_ms,
        event_sink=event_sink,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--node-id", required=True)
    parser.add_argument("--port", required=True, type=int)
    parser.add_argument("--delay-ms", type=int, default=0)
    args = parser.parse_args()

    server = make_server(
        node_id=args.node_id,
        port=args.port,
        delay_ms=args.delay_ms,
    )
    print(
        json.dumps(
            {
                "event": "listening",
                "node_id": server.node_id,
                "port": server.server_address[1],
                "delay_ms": server.delay_ms,
            },
            sort_keys=True,
        ),
        flush=True,
    )
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
