"""Small protocol helpers for the Warm-up service."""

from __future__ import annotations

from urllib.parse import parse_qs, urlparse


def normalize_request_id(value: str | None) -> str:
    if value is None or not value.strip():
        raise ValueError("X-Request-ID is required")
    return value.strip()


def parse_work_value(target: str) -> int:
    parsed = urlparse(target)
    if parsed.path != "/work":
        raise ValueError("unknown path")
    values = parse_qs(parsed.query).get("value")
    if not values or len(values) != 1:
        raise ValueError("exactly one value query parameter is required")
    try:
        return int(values[0])
    except ValueError as exc:
        raise ValueError("value must be an integer") from exc


def validate_delay_ms(value: int) -> int:
    if value < 0:
        raise ValueError("delay must be non-negative")
    return value


def validate_timeout_ms(value: int) -> int:
    if value <= 0:
        raise ValueError("timeout must be positive")
    return value


def work_result(value: int) -> int:
    return value * 2


def make_event(
    *,
    node_id: str,
    request_id: str,
    event: str,
    value: int | None = None,
    result: int | None = None,
) -> dict[str, object]:
    record: dict[str, object] = {
        "node_id": node_id,
        "request_id": request_id,
        "event": event,
    }
    if value is not None:
        record["value"] = value
    if result is not None:
        record["result"] = result
    return record
