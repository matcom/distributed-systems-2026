"""Command-line client for the Warm-up service."""

from __future__ import annotations

import argparse
import json
import urllib.error
import urllib.request

from protocol import normalize_request_id, validate_timeout_ms


def request_work(
    *,
    port: int,
    value: int,
    request_id: str,
    timeout_ms: int = 1000,
    host: str = "127.0.0.1",
) -> dict[str, object]:
    rid = normalize_request_id(request_id)
    timeout = validate_timeout_ms(timeout_ms) / 1000.0
    req = urllib.request.Request(
        f"http://{host}:{port}/work?value={value}",
        headers={"X-Request-ID": rid},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError) as exc:
        raise RuntimeError(f"request failed: {exc}") from exc


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", required=True, type=int)
    parser.add_argument("--value", required=True, type=int)
    parser.add_argument("--request-id", required=True)
    parser.add_argument("--timeout-ms", type=int, default=1000)
    args = parser.parse_args()

    try:
        result = request_work(
            port=args.port,
            value=args.value,
            request_id=args.request_id,
            timeout_ms=args.timeout_ms,
        )
    except (ValueError, RuntimeError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, sort_keys=True))
        return 2

    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
