The course content is local-first, but a chapter ZIP cannot contain an entire operating-system toolchain. Use this page as the **environment contract**: install the tools you expect to use before a long offline period, then download the relevant chapter bundle.

You do **not** need every tool for every chapter. The required path prefers the smallest tool that makes the mechanism and its evidence visible.

## Baseline environment

Have these available from the beginning of the course.

| Tool | What it is used for | Offline preparation |
|---|---|---|
| **Linux-capable environment** | processes, files, signals, sockets, local networking, namespaces, fault experiments | Have a working Linux installation, VM, or equivalent Linux-capable environment before disconnecting. |
| **Shell + standard process tools** | starting/stopping services, inspecting files/processes, scripting repeatable experiments | Verify normal shell commands and process control work locally. |
| **Git** | reproducible source history and experiment provenance | Clone/download the repositories you need before disconnecting. |
| **Python 3** | course tooling, introductory labs, support/analysis scripts | Install Python with `venv` and `pip`; keep the course repository available locally. |
| **Go toolchain** | native services, concurrency, networking, tests, race detection, profiling | Install Go and verify `go version` before the chapters that build native services. |
| **make** | consistent local lab/test commands where an assignment exports a Makefile | Install it or use the documented underlying command when unavailable. |
| **curl** | independent HTTP/application probe | Install locally; no Internet access is required when probing local services. |
| **iproute2 tools** (`ss`, `ip`, `tc`) | socket inspection, namespaces, local network configuration, `tc netem` fault injection | Install the operating-system package that provides these commands. Some `tc`/namespace experiments require local administrative privileges. |

The Warm-up deliberately checks this environment before later chapters depend on it.

## Chapter-specific development tools

Install these before the chapter or project phase that uses them.

| Tool | Main use | Course status |
|---|---|---|
| **Ray Core 2.58.0** | Chapter 2 middleware experiment and project Phase 1 | Required only for the Ray phase. It is removed from the native runtime afterward. |
| **gRPC libraries** | explicit RPC implementation | Recommended native path in the RPC chapter. |
| **Protocol Buffers + `protoc`** | typed/versioned RPC messages and generated bindings | Used with the gRPC path. |
| **grpcurl** | independent inspection of a local gRPC service | Recommended diagnostic tool for the RPC chapter. |
| **netcat / `nc`** | simple local endpoint and byte-stream experiments | Useful inspection tool; not a substitute for application evidence. |
| **OpenSSL** | certificate/key inspection and small local TLS experiments | Used in the security/trust chapter; a public CA account is not required. |

For Ray, the chapter pins its dependency in `modules/M02-ray-middleware/lab/starter/requirements.txt`. If you expect to be offline when completing that chapter, download the Python packages while connected:

```bash
python3 -m pip download -r modules/M02-ray-middleware/lab/starter/requirements.txt -d offline-wheels
```

Later, from the directory containing those wheels:

```bash
python3 -m pip install --no-index --find-links offline-wheels -r modules/M02-ray-middleware/lab/starter/requirements.txt
```

Do the equivalent pre-download for any additional Python dependency your instructor explicitly assigns.

## Inspection and packet evidence

These tools help answer specific questions. Do not collect output merely because the tool is available.

| Tool | Use |
|---|---|
| **`ss`** | listening/connected sockets and endpoint state |
| **`tcpdump`** | packet evidence on a chosen interface/namespace |
| **Wireshark** | interactive packet inspection when a GUI is useful |
| **`curl` / `grpcurl` / `nc`** | independent probes at different protocol layers |

Packet capture is normally optional. Application logs and explicit state are often better evidence for application-level effects.

## Isolation and fault injection

| Tool/mechanism | Use | Requirement |
|---|---|---|
| process kill/restart | crash and crash-recovery experiments | Core technique |
| application-configured delay/failure point | deterministic, reversible fault injection | Preferred when it answers the question |
| **`tc netem`** | network delay, loss, duplication, reordering | Use only on a disposable interface/namespace you can restore |
| Linux network/process namespaces | local isolation and partition experiments | Use when a stronger boundary than ordinary processes is needed |
| **Docker or Podman** | reproducible process/container boundaries | Optional; local-process fallbacks are preferred where practical |

Do not make Docker/Podman a hidden prerequisite for a lab whose learning objective can be demonstrated with ordinary local processes.

## Correctness, concurrency, and performance

| Tool | Use |
|---|---|
| **`go test`** | deterministic Go checks |
| **`go test -race`** | evidence of unsafe shared-memory access in exercised executions |
| **Go `pprof` / runtime profiles** | CPU, memory, goroutine, and blocking evidence |
| structured logs | request/node IDs, state transitions, retries, recovery histories |
| small local load generator | repeatable latency/throughput/backpressure experiments |

A clean test or race-detector run establishes only what it exercised. Distributed guarantees still need explicit invariants, histories, fault scenarios, and recovery evidence.

## Observability tools

The course teaches observability concepts without requiring a hosted platform.

- **OpenTelemetry** may be used for trace/metric instrumentation and context propagation.
- **Prometheus-style metrics** or a lightweight local metrics endpoint may be used for rates, queues, errors, and resource behavior.
- A dedicated tracing backend is optional; compact local traces/logs are sufficient for the required learning path.

No paid monitoring service is required.

## Tools that are not course prerequisites

The required path does not depend on:

- paid cloud infrastructure;
- paid SaaS products;
- paid AI APIs;
- Kubernetes;
- a public certificate-authority account;
- a hosted observability backend;
- permanent Internet access during laboratories.

Projects may justify additional libraries or infrastructure, but they must not hide the distributed mechanism being assessed.

## Before you disconnect

For the chapters you plan to study offline:

1. download the chapter ZIP;
2. clone or update your working repository;
3. install the baseline toolchain;
4. install or pre-download the chapter-specific dependencies above;
5. run the chapter's setup/version checks once;
6. verify the transparent tests can start locally;
7. keep any required language/module/package caches on the machine.

After that, the required reading, starter code, public tests, logs, histories, and normal local experiments should not require Internet access.

The **offline contract is therefore two-part**:

- the course supplies the learning material, starter code, reports, and public tests in the offline bundle;
- you prepare third-party compilers, runtimes, packages, and system tools on the machine before disconnecting.
