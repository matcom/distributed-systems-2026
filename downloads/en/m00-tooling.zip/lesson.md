<p class="ds-book-part">Warm-up</p>
<div class="ds-lesson-banner">
  <div><span>Course step</span><strong>Warm-up</strong></div>
  <div><span>Core reading</span><strong>25 min–35 min</strong></div>
  <div><span>Required path</span><strong>Read → Practice target → Check → Lab</strong></div>
</div>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Warm-up</span>
    <span>0% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 0%"></span></div>
</div>

> **Guiding question:** How do you observe, control, and break a distributed system safely on one machine?

## Before you read

> Three service processes run on one laptop. If one process crashes, what failed independently? If the laptop loses power, what failed together?

Write a short answer first. You are not expected to be correct yet; you need a prediction you can revise as the chapter gives you better models and evidence.

**Use what you already know:** Basic Linux command-line use, processes, files, and Git.

## Workload map

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>25 min–35 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>25 min–40 min</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>1 h–1 h 30 min · 7 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../../downloads/en/m00-tooling.zip" download>Download lesson + practice + lab for offline study (.zip)</a></p>

## Why this chapter matters

Distributed-systems experiments fail for many reasons that are not the distributed algorithm itself. A process may never have started. Two services may be listening on the same assumed port. A container may be on a different network. A timeout may be too small. A client may be talking to yesterday's process. A packet capture may be observing the wrong interface. A test may depend on state left behind by a previous run.

Before we study RPC, logical clocks, replication, Raft, DHTs, CRDTs, or transactions, we need a repeatable way to answer a more basic question:

> **What is running, where is it running, how is it communicating, and what evidence supports that claim?**

The Warm-up establishes the experimental discipline used throughout the course. The objective is not to memorize shell commands. It is to learn which observation answers which question, how to create a small cluster on one machine, and how to change one condition at a time without losing the ability to explain the result.

> **Pause and predict.** A client prints `timeout`. Does that prove the server crashed? No. The server may be slow, the request may be delayed, the response may be delayed, the address may be wrong, the process may be alive but overloaded, or the server may have completed the operation before the response disappeared. A timeout is evidence about the client's waiting interval—not a complete diagnosis.

## 1. One laptop is enough to study many distributed-system failures

A production distributed system uses many physical machines, racks, zones, and networks. A teaching environment does not need all of that to expose the fundamental mechanisms.

On one Linux machine we can create several independent processes:

```text
terminal/process A          terminal/process B          terminal/process C
      :8101                       :8102                       :8103
        │                           │                           │
        └──────────── localhost / virtual network ─────────────┘
```

Each process has its own:

- program counter and call stack,
- heap and local variables,
- file descriptors and sockets,
- logs,
- failure lifecycle,
- view of time,
- durable files if it writes any.

The processes still share a kernel and physical machine, so this is not equivalent to a datacenter. But it preserves several properties that matter immediately:

- one process can crash while another continues;
- messages cross a socket boundary;
- serialization is explicit;
- timeouts become meaningful;
- requests can be delayed or duplicated;
- state cannot be shared accidentally through ordinary local variables;
- each node can produce independent evidence.

Later labs use containers or namespaces when we need stronger network isolation. We move to more complicated environments only when the mechanism being studied requires them.

### The local-first rule

The authoritative laboratory must run locally before CI, cloud infrastructure, or a remote service is involved.

This gives every student the same debugging hierarchy:

```text
source code
   ↓
local process
   ↓
local multi-process cluster
   ↓
container/namespace isolation when needed
   ↓
optional CI or remote deployment
```

If the simplest version does not work, adding infrastructure usually adds uncertainty rather than insight.

## 2. A node is a role in the experiment, not necessarily a physical computer

Throughout this course, the word **node** means an independently executing participant in the distributed protocol.

Depending on the lab, a node may be:

- one operating-system process;
- one container;
- one VM;
- one physical host;
- one Ray worker or actor during Chapter 2;
- one storage replica;
- one peer in a DHT;
- one consensus server.

Do not confuse the logical role with the hardware running it.

For example, three Raft servers on one laptop are still three logical Raft nodes for the purpose of protocol state and messages, even though a laptop power failure would kill all three simultaneously. That shared physical failure domain is a limitation of the experiment, not a reason to pretend the processes are one node.

> **Systems habit:** always state both the **logical topology** and the **physical failure domain** of an experiment.

## 3. Processes give us independent execution and failure

Useful process views include:

```bash
ps -ef
ps -o pid,ppid,state,etime,cmd -p <PID>
pgrep -af python
pgrep -af go
```

The important questions are:

1. Does the process exist?
2. Which executable and arguments started it?
3. How long has it been running?
4. Which process is its parent?
5. Does its PID match the process whose logs you are reading?

A PID is only a local operating-system identifier. It is not a stable distributed identity. PIDs can be reused after a process exits.

Later, when services need stable identities such as `node-1` or `replica-a`, we will explicitly separate:

```text
logical node ID ≠ operating-system PID ≠ network address
```

That distinction becomes essential during restarts.

## 4. Addresses and ports locate endpoints, not services forever

A service listening on:

```text
127.0.0.1:8101
```

has a current network endpoint consisting of an address and transport port.

Inspect listening sockets with:

```bash
ss -lntp
```

and established TCP connections with:

```bash
ss -tnp
```

A listening socket proves that, at this observation point, a process has successfully bound an endpoint.

It does **not** prove that:

- the application protocol is correct;
- the handler is responsive;
- a remote namespace can reach it;
- the service contains the data a client expects;
- the process will still be there one second later.

This course repeatedly distinguishes **identity** from **location**. An address tells us where to try now. A service-discovery system in Chapter 8 will help clients map more stable service identities to changing locations.

## 5. Start with a known-good request before injecting failure

Every laboratory should establish a baseline.

For an HTTP-like toy service:

```bash
curl -v http://127.0.0.1:8101/health
```

A baseline should record at least:

- command or workload;
- client start/end time;
- target endpoint;
- response or error;
- relevant server log entry;
- process/socket state if relevant.

Only after the baseline works should we introduce a fault.

The basic experiment shape is:

```text
prediction
   ↓
baseline
   ↓
one controlled change
   ↓
observation
   ↓
explanation
   ↓
recovery / teardown
```

Changing five things at once produces a demonstration, not an experiment.

## 6. Structured logs turn stories into reconstructable evidence

Unstructured output such as:

```text
handling request
finished
error
```

is hard to combine across several processes.

Prefer events that include stable fields:

```json
{
  "event": "request_start",
  "node": "worker-a",
  "request_id": "req-1042",
  "operation": "double",
  "value": 21
}
```

and later:

```json
{
  "event": "request_finish",
  "node": "worker-a",
  "request_id": "req-1042",
  "result": 42
}
```

A **request identifier** lets us correlate events from different components without assuming their clocks are perfectly synchronized.

Useful fields commonly include:

- `event`;
- `node`;
- `request_id` or `job_id`;
- local timestamp;
- peer or target;
- operation;
- term/version/sequence where the protocol has one;
- result or failure category.

Do not log secrets merely because structured logging makes it convenient. Security and observability must share a clear boundary.

## 7. Wall-clock timestamps are useful evidence, but not a proof of causality

Logs often contain timestamps because humans need them.

However, two nodes may have clocks that differ. Even on one laptop, process scheduling can make closely timed events appear in surprising orders.

In Chapter 6 we will learn logical clocks and causal ordering. For the Warm-up, adopt a simple rule:

> **Use wall-clock time to locate events, and use message/request relationships to explain order.**

For performance measurements inside one process, prefer a monotonic duration source when the language provides one.

## 8. `curl` and small clients are application-level probes

`curl` is useful because it lets us create a request independently from our application client.

If a custom client fails but `curl` succeeds against the same endpoint, that narrows the investigation toward client protocol logic.

If both fail, inspect the lower layers next:

```text
application request
      ↓
listening socket?
      ↓
correct address / route / namespace?
      ↓
traffic visible?
      ↓
server handler / state?
```

A single command should not be treated as proof of the entire system. Every observation has an **authority boundary**.

## 9. Packet capture answers a different question from application logs

Packet-oriented tools include:

- `tcpdump`;
- TShark;
- Wireshark.

A simple localhost capture might use:

```bash
sudo tcpdump -i lo -nn tcp port 8101
```

The capture can show whether traffic crossed that interface and which addresses/ports were involved.

A capture cannot directly tell you that an application-level transaction is correct. Encrypted payloads may also hide application data.

Always record the capture point:

```text
client namespace?
server namespace?
loopback?
container bridge?
physical interface?
```

A packet that does not appear at one observation point may still exist elsewhere in the path.

## 10. Containers add isolation, not automatic correctness

Containers are useful because several nodes can have independent process trees, filesystems, and network namespaces while remaining easy to create and destroy.

But a containerized program is not automatically distributed or fault tolerant.

Compare:

```text
three functions in one process       not distributed
three processes in one container     distributed processes, shared container failure domain
three containers on one host         stronger isolation, shared host failure domain
three physical hosts                 independent host failures, still possibly shared rack/network
```

The correct environment depends on what we are trying to test.

For most early labs, processes on loopback are sufficient. For partition experiments, namespaces or containers are convenient because we can alter connectivity between selected participants rather than affecting your whole machine.

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosity</span>
  <strong>Three processes on one laptop are still a distributed experiment—but not three hardware failure domains</strong>
  <p>Separate processes can communicate only through explicit interfaces and can fail independently at the process level, which is enough to study many distributed semantics. They still share one kernel, disk, power source, and often one network stack.</p>
  <p><strong>Try it:</strong> Run three service processes, kill only one, then list which failures would still take down all three simultaneously.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">More chapter curiosities →</a>
</aside>

## 11. Reproducibility starts with explicit configuration

Distributed systems become difficult to reproduce when addresses, ports, timeouts, or data paths are buried in source code.

Prefer configuration such as:

```bash
python3 src/node.py --node-id a --listen 127.0.0.1:8101 --delay-ms 0
```

rather than editing a constant for each run.

Important parameters often include:

- node identity;
- listen address;
- peer addresses;
- timeout;
- retry count;
- data directory;
- random seed;
- replication factor;
- workload size.

The final project applies the same principle at larger scale.

## 12. Git is part of the experiment record

A reproducible result needs to identify the code that produced it.

Useful evidence includes:

```bash
git status --short
git rev-parse --short HEAD
```

A report should not claim that an experiment used commit `abc1234` if uncommitted modifications materially changed the code. Record dirty state when it matters.

The course does not require GitHub to run laboratories. Git is a local version-control system; a hosted repository is optional infrastructure around it.

## 13. Go and Python have different roles in this course

The native distributed-system implementations are primarily written in **Go** because it provides:

- explicit networking;
- lightweight concurrency through goroutines;
- channels and synchronization primitives;
- a strong standard library;
- built-in testing;
- the race detector;
- straightforward static binaries.

Python is used for:

- Ray in Chapter 2 and Phase 1 of the final project;
- compact laboratory helpers;
- deterministic workload generation;
- analysis scripts when appropriate.

You should not infer a conceptual difference from the language choice. A process, message, retry, timeout, or replicated state remains a distributed-systems concern regardless of language.

## 14. Fault injection should change the environment, not secretly change the specification

We want to ask questions such as:

- What if this process disappears?
- What if messages take 300 ms longer?
- What if 10% of packets are lost?
- What if one side of the cluster cannot reach another?
- What if a client repeats a request?

The simplest failure is process termination:

```bash
kill <PID>
```

A graceful stop and a forced crash are different experiments. A graceful process may flush state and notify peers. A sudden crash may not.

For network impairment, Linux `tc netem` can introduce controlled conditions such as delay, loss, duplication, and reordering on an interface. It normally requires elevated privileges, so it must be applied carefully and removed after the experiment.

A typical pattern is:

```bash
sudo tc qdisc add dev <lab-interface> root netem delay 300ms
# experiment
sudo tc qdisc del dev <lab-interface> root
```

Do not apply destructive rules blindly to a machine's production or remote-management interface.

### Application-level delay is still useful

Early labs often expose a `--delay-ms` option. That does not simulate every network property, but it safely demonstrates that **slow** and **failed** are observationally different only after a chosen timeout expires.

Use the simplest fault mechanism that tests the property you care about.

## 15. A network partition is selective communication failure

A partition does not mean “the whole network is down.” It means the communication graph has split such that some participants cannot exchange required messages.

For example:

```text
A <──> B      X      C <──> D
```

A and B may still communicate with each other. C and D may still communicate with each other. Clients might reach both groups.

Later, replication and consensus depend heavily on exactly which links remain available.

Therefore every partition experiment should document the intended connectivity matrix rather than saying only “we disconnected the network.”

## 16. Transparent tests are executable parts of the specification

Every course lab that has deterministic behavior exposes its official tests.

You may:

- read them;
- run them repeatedly;
- add tests under `tests/student/`;
- use AI tools to help generate additional cases;
- modify their own copy while investigating behavior.

There are no hidden correctness cases.

This does not make the course easier. It shifts the assessment from guessing what the grader might test to understanding **why the required behavior is correct**.

Some distributed properties are not well captured by one unit test. For those, the laboratory also requires an experiment and explanation.

## 17. Evidence has a hierarchy

Suppose a student says:

> “The server definitely never received the request.”

What evidence supports that statement?

Possible evidence has different authority:

1. the client printed a timeout;
2. the server log has no matching request ID;
3. `tcpdump` on the server-side interface saw no packet;
4. socket statistics show no connection;
5. the server process was not running.

None is universally sufficient by itself. The best investigation combines independent evidence until alternative explanations become unlikely.

A useful troubleshooting table is:

| Question | Useful evidence |
|---|---|
| Is the process alive? | `ps`, `pgrep`, container state |
| Is it listening? | `ss -lntp` |
| Can I reach the application endpoint? | `curl`, purpose-built client |
| Did traffic cross this interface? | `tcpdump`, Wireshark |
| Which request did this log entry belong to? | request/job ID |
| Did a failure change latency or throughput? | duration/metrics/workload results |
| Did state survive restart? | persistent files/state query |

## 18. The report format is part of the engineering method

Every significant lab should be explainable using four elements:

### Prediction

State what you expect **before** running the fault.

### Procedure

Record the commands, configuration, workload, and topology needed to reproduce it.

### Evidence

Include machine-readable excerpts where possible: logs, traces, test output, metrics, persistent state, or packet summaries.

### Explanation

Connect the observation to the system model. Name the mechanism and the changed assumption.

A weak report says:

> “It stopped working after I killed the server.”

A stronger report says:

> “The client timed out after 500 ms because the only process bound to `127.0.0.1:8102` was terminated. `ss` showed no listener and the client produced no application response. Restarting the process restored the endpoint because no durable state was required by this toy service.”

## 19. AI assistants may accelerate investigation, but the evidence still belongs to you

The course permits AI assistants and coding agents.

Useful Warm-up tasks include asking an assistant to:

- explain a command;
- propose hypotheses for a timeout;
- generate an additional test;
- review a shell script;
- suggest which logs would discriminate two explanations.

But an AI-generated statement is not an observation from your machine.

The correct workflow is:

```text
AI suggestion
    ↓
technical hypothesis
    ↓
local experiment
    ↓
evidence
    ↓
student conclusion
```

This pattern continues throughout the semester.

## 22. Common mistakes

### Starting with packet capture before confirming the process exists

Collect evidence from the simplest dependency first. A dead process cannot answer regardless of packet details.

### Hard-coding ports and then forgetting old processes

A stale process may still own yesterday's port. Inspect the listener instead of assuming which binary owns it.

### Treating a timeout as a crash detector

Timeouts convert uncertainty into a local decision. They do not reveal the remote truth.

### Using `sudo` for the entire laboratory

Use elevated privileges only for operations that require them, such as selected packet captures or network impairment.

### Applying `tc` to the wrong interface

A fault-injection command can affect unrelated traffic. Prefer dedicated namespaces/containers or an application-level delay in early work.

### Reporting screenshots without reproducible commands

A screenshot can support a narrative, but commands, configuration, logs, and tests are easier to reproduce and inspect.

### Treating successful unit tests as proof of a fault-tolerance property

A deterministic function test and a process-crash experiment establish different facts. Use both when the specification requires both.

## Chapter summary

The Warm-up establishes the working method for the rest of the course:

1. **A local machine can host several useful logical nodes.**
2. **Logical nodes, PIDs, and network addresses are different identities.**
3. **Establish a known-good baseline before injecting failure.**
4. **Structured logs and request identifiers make distributed evidence easier to correlate.**
5. **Every observation has an authority boundary.**
6. **Containers and namespaces add isolation but do not create correctness automatically.**
7. **Configuration, Git state, and explicit commands make experiments reproducible.**
8. **Fault injection should be controlled, selective, and reversible.**
9. **Transparent tests are part of the public specification.**
10. **AI-generated hypotheses still require local evidence.**

Before continuing, be able to start three local nodes, identify their PIDs and listening endpoints, issue a request with a request ID, stop one process, and explain the resulting client behavior using at least two independent pieces of evidence.

<div class="ds-next-action">
  <span>Core reading complete</span>
  <strong>Next required step · Guided practice</strong>
  <a href="../guided-practice/">Start guided practice →</a>
</div>
