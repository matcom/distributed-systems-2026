<p class="ds-book-part">Warm-up</p>
<p class="ds-module-kicker">Warm-up</p>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Warm-up</span>
    <span>0% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 0%"></span></div>
</div>
<p class="ds-guiding-question">How do you observe, control, and break a distributed system safely on one machine?</p>

Before you study algorithms, build a warm-up environment where you can start several independent processes, observe them, delay messages, disconnect paths, kill/restart nodes, and collect evidence you can reproduce later.

## Key ideas

- Linux processes and ports
- Git and reproducible repositories
- Go and Python environments
- containers and network namespaces when useful
- curl, ss, tcpdump and Wireshark
- controlled fault injection
- structured logs and stable request identifiers
- compact evidence that works offline

## Laboratory transition

Run a three-process toy service, capture one request, kill one process, add latency to another, and explain what your evidence proves.

## Start here

> **Before you read:** Three service processes run on one laptop. If one process crashes, what failed independently? If the laptop loses power, what failed together?

**Bring forward:** Basic Linux command-line use, processes, files, and Git.

**This chapter builds toward:** A warm-up environment where every later claim can be tested with reproducible local evidence.

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>25 min–35 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>25 min–40 min</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>1 h–1 h 30 min · 7 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Read lesson →</a>
  <a class="ds-secondary-action" href="lab/">Open laboratory</a>
</div>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../downloads/en/m00-tooling.zip" download>Download chapter + laboratory for offline study (.zip)</a></p>

## What you will learn

- Prepare a reproducible local environment for every later lab.
- Run multiple independent service processes and identify their network endpoints.
- Capture and interpret a simple request/response exchange.
- Inject latency or process failure without modifying application code.
- Package observations so another student can reproduce them.

## Learn by working the question

1. Write your answer to **Start here** before opening the full lesson.
2. Read until the next prediction or trace, then stop and work it out before revealing the explanation.
3. Treat guided practice as a **practice bank**, not a speed worksheet. Work the core traces until you can meet the chapter's Practice target; return to the remaining cases for retrieval practice or instructor-assigned work.
4. Use the knowledge check to find gaps, then enter the laboratory with a falsifiable prediction and name the evidence that could contradict it.
5. Finish by explaining what the experiment established, what it did not establish, and how the result changes the evolving service.

<nav class="ds-sequence" aria-label="Course sequence">
<a class="ds-sequence-link next" href="../m01-distributed-systems/">Thinking in Distributed Systems →</a>
</nav>
