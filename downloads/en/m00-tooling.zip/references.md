> **Reference view.** This page is optional context; return to the [Lesson](../lesson/) for the required path.

## Essential

- **● The Go Documentation** — The Go Project. [tool documentation](https://go.dev/doc/)
- **● Docker Documentation** — Docker. [tool documentation](https://docs.docker.com/)

## Recommended

- **● Wireshark User's Guide** — Wireshark Foundation. [tool documentation](https://www.wireshark.org/docs/wsug_html_chunked/)

## Advanced

No additional item assigned yet.

## Tools & Practice

- **●● tc-netem manual** — Linux man-pages project. [tool documentation](https://man7.org/linux/man-pages/man8/tc-netem.8.html)

## Explore

- **●●● 6.5840 Distributed Systems** — MIT PDOS. [course](https://pdos.csail.mit.edu/6.824/)
