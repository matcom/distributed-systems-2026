<div class="ds-lesson-banner">
  <div><span>Required laboratory</span><strong>Chapter 8</strong></div>
  <div><span>Evidence model</span><strong>predict → run → observe → explain</strong></div>
  <div><span>Verification</span><strong>7 transparent public tests + evidence</strong></div>
</div>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 8 of 12</span>
    <span>67% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 67%"></span></div>
</div>
<p class="ds-back-link"><a href="../quick-check/">← Return to knowledge check</a></p>

> **Before you start:** Complete the guided-practice and knowledge-check steps. You should already be able to state a prediction and name the evidence that would support or contradict it. If not, [return to the knowledge check](../quick-check/) and revisit the lesson where needed.

## Target

Build a small **Ray-free** worker registry and client-side discovery system. Demonstrate that worker failure, registry state, client cache state, and actual reachability can temporarily disagree. Then compare endpoint-selection strategies and define the behavior when the discovery service itself is unavailable.

The central experimental timeline is:

```text
worker fails
    ↓
registry eventually expires/removes worker
    ↓
client eventually refreshes membership
    ↓
client successfully reroutes
```

Those are four different events.

## Learning outcomes

By the end of the lab you should be able to:

- separate service name, node identity, process incarnation, and address;
- implement worker registration and discovery without Ray;
- implement a TTL/lease-based membership record;
- demonstrate stale registry and stale client views;
- compare at least two endpoint-selection policies;
- combine discovery with Chapter 4 deadlines and retry/reselection;
- explain the registry's own failure model;
- identify which state would later need replication or consensus for stronger guarantees.

## Implementation boundary

Ray is prohibited.

Recommended implementation:

- Go services;
- HTTP or gRPC for registry operations;
- gRPC or HTTP for worker operations;
- structured JSON logs;
- local processes or containers.

Kubernetes, Consul, etcd, ZooKeeper, cloud load balancers, and production service meshes may be studied as references but may not replace the mechanism being implemented in this lab.

## Logical architecture

Start with:

```text
                    registry
                   /   |   \
                  /    |    \
                W1    W2    W3
                  \     |    /
                   \    |   /
                      client
```

The client should address a logical service name, for example:

```text
image-worker
```

not one hard-coded worker address.

## Required registry model

Each registration must include at least:

```text
service_name
node_id
incarnation
endpoint
lease_duration or expires_at
```

Useful optional metadata includes:

```text
capacity
zone
version
labels
```

Do not include metadata merely because production registries have it. Each field should support a design decision or experiment.

## Required worker behavior

A worker should expose one deterministic operation such as:

```text
Work(request_id, value) -> result
```

and one basic health/readiness signal.

The operation should identify the worker that handled it so load distribution can be observed.

Example response meaning:

```text
request_id=R7
node_id=W2
incarnation=3
result=84
```

## Required client behavior

The client must:

1. resolve the logical service through the registry;
2. cache the returned endpoint set for a configurable period;
3. select one endpoint according to a configurable policy;
4. execute an RPC with a deadline;
5. react to a failed endpoint according to a documented refresh/reselection policy.

At minimum implement:

- `pick-first` or fixed first usable endpoint;
- `round-robin`.

A weighted or least-outstanding policy is an optional extension.

## Experiment 0 — normal registration and resolution

Start the registry and three workers.

Example conceptual deployment:

```text
registry :7100
W1       :7201
W2       :7202
W3       :7203
```

Each worker registers itself and begins refreshing its lease.

Collect registry state showing:

```text
service=image-worker
members=[W1,W2,W3]
```

Then issue a client request.

Required evidence:

- registry registration event;
- client resolution event;
- selected endpoint;
- worker receive/reply event;
- logical service name separated from physical endpoint.

## Experiment 1 — compare selection policies

Send at least 30 deterministic requests while all workers are healthy.

### Policy A — pick first

Record the distribution by worker.

### Policy B — round robin

Record the distribution by worker.

Present a table:

| Worker | Pick-first requests | Round-robin requests |
|---|---:|---:|
| W1 | | |
| W2 | | |
| W3 | | |

Explain why equal request counts do not necessarily mean equal load if request costs or worker capacities differ.

## Experiment 2 — abrupt worker death

Kill W2 **without** clean deregistration.

Immediately record four clocks/events:

```text
t_fail       process actually stops
t_registry   registry expires/removes W2
t_refresh    client obtains membership without W2
t_recover    client successfully completes through another worker
```

Do not assume these timestamps are equal.

If a client selects W2 while the lease is still valid, Chapter 4 behavior should apply: the request may time out/fail, after which policy may trigger reselection or refresh.

## Experiment 3 — lease tuning

Run the worker-failure experiment with at least two lease settings, for example:

```text
lease A = short
lease B = longer
```

Compare:

- stale-entry duration;
- false-removal risk under temporary delay;
- heartbeat/control traffic;
- recovery time.

The point is not to find one universally correct number. Explain the trade-off.

## Experiment 4 — worker alive, registry path broken

Create a condition in which W3 remains reachable by the client but cannot refresh its lease with the registry.

This may be approximated locally through process/network controls available in the environment.

Observe:

```text
worker is alive
client may still reach worker
registry eventually removes worker
```

Answer:

- Is W3 failed?
- Is the registry wrong?
- Should new clients select W3?
- What assumption does your lease policy make?

This experiment distinguishes **membership** from **reachability**.

## Experiment 5 — stale client cache

Configure a client cache TTL longer than the registry's removal interval.

1. Client resolves `[W1,W2,W3]`.
2. Kill W2.
3. Registry removes W2.
4. Client deliberately continues using the cached set.

Show an interval during which:

```text
registry state = [W1,W3]
client state   = [W1,W2,W3]
```

This is a required result, not a bug to hide.

Then demonstrate the client recovery policy.

Possible policies include:

- refresh discovery immediately after connection failure;
- mark one endpoint locally unhealthy for a bounded time;
- select another cached endpoint before refreshing;
- combine both.

Justify the choice.

## Experiment 6 — replacement process and incarnation

Restart logical worker `W2` at a different endpoint and increment its incarnation.

Example:

```text
old: node_id=W2 incarnation=7 endpoint=:7202
new: node_id=W2 incarnation=8 endpoint=:7292
```

Demonstrate that the registry can distinguish the new process from stale metadata associated with the old incarnation.

If your implementation does not transmit delayed old heartbeats, explain with a trace/table how an incarnation field would be used to reject them.

## Experiment 7 — registry unavailable

Stop the registry while all workers remain healthy.

Test two clients:

### Client A — already has cached endpoints

Can it continue making requests for some bounded interval?

### Client B — starts with no discovery state

Can it find the service?

The answer depends on your architecture and must be documented.

This experiment identifies how strongly the data path depends on the control/discovery path.

## Experiment 8 — registry restart

Restart the registry.

Observe how membership is reconstructed.

Possible designs:

- workers re-register on heartbeat failure/recovery;
- registry persists registrations but still requires lease refresh;
- clients trigger no registration behavior at all.

Explain which state survives restart and which state is rebuilt.

Do not claim the registry is fault tolerant merely because it restarts. Fault tolerance depends on what service guarantees remain available and whether important state is lost.

## Experiment 9 — scale out

Start a new worker W4 after one client has already cached membership.

Measure:

```text
t_start_W4
t_registry_sees_W4
t_existing_client_sees_W4
t_first_request_to_W4
```

This reveals that adding capacity and **using** capacity are different events.

Discuss how cache TTL or push/watch mechanisms would change the delay.

## Experiment 10 — health semantics

Introduce one worker that is alive and listening but deliberately returns an application-level “not ready” result.

Decide whether the registry should:

- keep it registered but mark it not ready;
- remove it;
- let clients decide;
- use a separate readiness field.

Your implementation need not reproduce a production health-check system, but the report must distinguish process liveness from service readiness.

## Required architecture analysis

Complete this table:

| Question | Your design |
|---|---|
| What is the stable logical service name? | |
| What is the stable node ID? | |
| What changes on process restart? | |
| Where is current endpoint state stored? | |
| Who creates/refreshes registration? | |
| How does a stale entry expire? | |
| How long may the client cache membership? | |
| What triggers client refresh? | |
| Which balancing policy is used? | |
| What happens when registry is unavailable? | |
| What state survives registry restart? | |
| Is registry state replicated? | |

If the registry is intentionally a single point of failure in Chapter 8, state that clearly. Later modules provide stronger mechanisms.

## Public-test target

Executable public tests now live under `tests/official/`, with the deterministic registry/lease/selection adapter in `starter/src/`. They verify the portable discovery invariants; process death, registry restart, and client-cache timing still require experimental evidence.

The intended visible cases are documented in `tests/official/README.md`. No hidden tests are planned.

You should add cases for:

- duplicate registration;
- lease renewal;
- expired member removal;
- re-registration with higher incarnation;
- selection over an empty set;
- round-robin membership changes;
- malformed endpoints;
- registry restart behavior.

## Evidence requirements

The report must include:

1. normal registration/resolution trace;
2. endpoint-selection distribution for two policies;
3. worker-failure timeline with four distinct events;
4. registry-versus-client stale-state evidence;
5. lease-setting comparison;
6. registry-unavailable behavior;
7. replacement-incarnation evidence;
8. architecture table and limitations.

## AI use

AI assistants and coding agents are permitted.

A useful audit exercise is to ask an AI assistant whether a design using one startup registration and an infinite client cache is “fault tolerant.” Classify the assistant's claims, then use your fault experiments to demonstrate where its reasoning is correct or incomplete.

Include the standard AI-use disclosure in assessed work.

## Report

Use `REPORT.md` as the submission structure.

The most important conceptual result should answer:

> **At each moment after a worker failure, who knows what—and how does that knowledge eventually change?**

## Finish the chapter

Reproduce the important result from a clean start. Then return to your opening prediction: state what changed in your explanation, what evidence caused the change, and what uncertainty remains. A successful command or screenshot is not enough when the claim concerns retries, ordering, durability, consistency, recovery, security, or performance.

<div class="ds-next-action">
  <span>Chapter complete</span>
  <strong>Continue the course</strong>
  <a href="../../m08-replication-consistency/">Replication and Consistency →</a>
</div>

<nav class="ds-sequence" aria-label="Course sequence">
<a class="ds-sequence-link" href="../../m09-consensus/">← Coordination II — Mutual Exclusion, Elections, and Agreement</a>
<a class="ds-sequence-link next" href="../../m08-replication-consistency/">Replication and Consistency →</a>
</nav>
