> **Reference view.** This page is optional context; return to the [Lesson](../lesson/) for the required path.

## Essential

- **●● RFC 1034 — Domain Names: Concepts and Facilities** — Paul Mockapetris. [standard](https://www.rfc-editor.org/rfc/rfc1034.html)
- **● Distributed Systems, 4th ed.** — Maarten van Steen and Andrew S. Tanenbaum. [book](https://www.distributed-systems.net/index.php/books/ds4/)

## Recommended

- **●● gRPC Custom Name Resolution** — gRPC Authors. [documentation](https://grpc.io/docs/guides/custom-name-resolution/)
- **●● gRPC Service Config** — gRPC Authors. [documentation](https://grpc.io/docs/guides/service-config/)
- **●● Designing Data-Intensive Applications** — Martin Kleppmann. [book](https://dataintensive.net/)

## Advanced

- **●● DNS for Services and Pods** — Kubernetes Authors. [system documentation](https://kubernetes.io/docs/concepts/services-networking/dns-pod-service/)

## Tools & Practice

- **● The Go Documentation** — The Go Project. [tool documentation](https://go.dev/doc/)

## Explore

- **●●● 6.5840 Distributed Systems** — MIT PDOS. [course](https://pdos.csail.mit.edu/6.824/)
