<p class="ds-book-part">Part III — Naming and Replicated State</p>
<div class="ds-lesson-banner">
  <div><span>Course step</span><strong>Chapter 8</strong></div>
  <div><span>Core reading</span><strong>35 min–50 min</strong></div>
  <div><span>Required path</span><strong>Read → Practice target → Check → Lab</strong></div>
</div>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 8 of 12</span>
    <span>67% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 67%"></span></div>
</div>

> **Guiding question:** How do you find the right logical service when names stay stable but locations and membership change?

## Before you read

> A service called payments restarts at a new address. Which identifier should stay stable, which value should change, and who is allowed to cache the old mapping?

Write a short answer first. You are not expected to be correct yet; you need a prediction you can revise as the chapter gives you better models and evidence.

**Use what you already know:** Architecture, communication, and failure boundaries from Chapters 2–7.

## Workload map

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>35 min–50 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>45 min–1 h 10 min</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>2 h–2 h 30 min · 7 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../../downloads/en/m04-architecture-discovery.zip" download>Download lesson + practice + lab for offline study (.zip)</a></p>

## Why this chapter matters

You already used architecture and communication earlier. Now focus on a narrower question: how does one component refer to another when logical identity should survive changing processes, addresses, replicas, and placement?

The first architecture sections below are a short recap because naming only makes sense when you know **who must discover whom**. The main progression is names → identifiers → addresses → structured naming → DNS/caching → dynamic discovery → decentralized lookup.


Chapter 4 made one remote operation explicit. We now know that a client needs a protocol, a request identifier, a deadline, retry semantics, and evidence about what happened.

But one assumption was still conveniently hidden:

> **How does the client know where the service is?**

Hard-coding `10.0.0.7:50051` appears to answer the question until that process restarts somewhere else, a second replica is added, the node becomes unhealthy, or a deployment replaces the machine.

Distributed applications therefore need to separate at least three ideas:

```text
logical identity      address/location      current instance
"payments"            10.0.0.7:50051       process P42
```

These can change at different rates.

A good service name should usually survive the replacement of one process. An address identifies where something can currently be contacted. A concrete process instance may be short lived.

This chapter studies architecture and naming together because architecture determines **who must discover whom**, **which state must remain stable**, and **what happens when discovery information becomes stale**.

> **Pause and predict.** A registry says that service `worker` has three endpoints. One endpoint crashed five seconds ago but remains in the registry. Is the registry “wrong”? How would your answer change if registrations expire after 30 seconds? What behavior must the client have during that interval?

## 1. Architecture is the placement of responsibility

A distributed architecture is not simply a diagram of boxes. It assigns responsibility and state.

For every component, ask:

- What does it know?
- What state does it own?
- Whom does it trust?
- Whom does it contact?
- Can another component replace it?
- What happens if it disappears?
- What must remain consistent with it?

A useful architecture diagram includes **channels and state**, not only service names.

Weak diagram:

```text
frontend → backend → database
```

Stronger diagram:

```text
client
  |
  | RPC
  v
API replicas ----> registry
  |                    |
  |                    | membership + leases
  v                    |
state service <--------+
  |
  v
replicated durable state
```

Now there are questions to study.

<aside class="ds-book-note ds-history">
  <span class="ds-book-note-label">History</span>
  <strong>Peer-to-peer systems asked what happens when participants contribute the infrastructure instead of merely using it</strong>
  <p>Structured overlays such as Chord and Kademlia, together with swarming systems, explored scalable lookup, churn, decentralized membership, and direct use of participant storage and bandwidth.</p>
  <a class="ds-book-note-source" href="../../../history/peer-to-peer-dhts/">Read the design history →</a>
</aside>

## 2. Client/server centralizes a role, not necessarily one machine

The client/server model distinguishes request initiators from service providers.

A simple version is:

```text
client → server
```

You may equate this with “one server process.” That is not necessary.

A logical service can contain many server replicas:

```text
             ┌→ server A
client → LB ─┼→ server B
             └→ server C
```

The architecture remains client/server because clients use a service role rather than behaving as equal peers.

This distinction matters because a logical name such as:

```text
api.course.local
```

may represent a changing set of physical endpoints.

## 3. Multi-tier systems separate different state and scaling concerns

Applications often separate roles such as:

```text
client
  ↓
API / presentation
  ↓
application service
  ↓
storage
```

Why introduce more components?

Different tiers may have different:

- scaling patterns;
- security boundaries;
- persistence needs;
- deployment cadence;
- failure consequences;
- hardware requirements.

For example, stateless API replicas are easy to replace because durable user state lives elsewhere. A storage node cannot be treated identically if it owns the only copy of acknowledged data.

The architectural lesson is:

> **Replaceability depends on state placement.**

A process becomes easier to scale and recover when its identity is not the only place where important durable state lives.

## 4. Microservices trade local simplicity for distributed coordination

A monolithic application can make an ordinary in-process call:

```text
orders.create()
```

Splitting that component into a service changes the operation:

```text
order-api → network → inventory-service
```

Now we inherit:

- serialization;
- service naming;
- discovery;
- authentication;
- deadlines;
- retries;
- partial failure;
- versioning;
- distributed tracing.

Microservices can provide useful organizational and scaling boundaries, but they also **manufacture distributed-systems problems** where local calls previously existed.

This course therefore avoids treating “microservices” as automatically modern or superior. A service boundary should justify its operational cost.

> **Pause and predict.** If two functions always scale together, deploy together, share the same owner, share the same durability boundary, and require synchronous low-latency calls, what distributed-systems benefit is gained by putting a network between them?

## 5. Peer-to-peer systems distribute both service and discovery responsibilities

In peer-to-peer architectures, participants may both consume and provide resources.

A centralized directory can still exist:

```text
      directory
      /   |   \
     /    |    \
   P1 ↔ P2 ↔ P3
```

or discovery itself can be decentralized:

```text
P1 ↔ P2
|     |
P4 ↔ P3
```

This changes the failure and scaling model.

A central registry offers simple coordination but creates a service whose availability and consistency must be protected.

A decentralized overlay avoids that particular center but introduces:

- routing state;
- churn;
- partial membership views;
- probabilistic dissemination;
- repair of overlay structure.

Chapter 5 studies DHTs and gossip in depth. Here, peer-to-peer is introduced as an architectural decision about **who is allowed to know and serve what**.

## 6. Names, identifiers, and addresses answer different questions

This distinction is foundational.

### Name

A human- or application-meaningful label for a resource or service.

Examples:

```text
orders.service
student-42
object/photos/logo
```

### Identifier

A token intended to distinguish an entity, often independently of current location.

Examples:

```text
job_id = J731
node_id = 9b2f...
content_hash = sha256:...
```

### Address

Information used to contact or route toward a current location.

Examples:

```text
192.0.2.8:50051
[2001:db8::7]:443
unix:///run/service.sock
```

A common architectural mistake is to make a supposedly stable identity equal to an unstable address.

If `worker-7` means only `10.0.0.7:9000`, what happens when the process moves?

A better model is:

```text
logical ID worker-7
       ↓ resolution
current endpoint 10.0.0.31:9000
```

Resolution is itself a distributed operation.

## 7. Naming systems map stable questions onto changing information

A naming system lets clients ask for information associated with a name.

The mapping does not need to be one-to-one.

A service name may resolve to:

- one address;
- several replicas;
- an alias;
- metadata;
- a delegation to another naming authority.

A useful abstraction is:

```text
name + record type/context
          ↓
       resolver
          ↓
current information
```

The resolver may consult caches, local configuration, recursive services, registries, or several authoritative sources.

The key point is that **resolution has state and freshness semantics**.

## 8. DNS is a distributed system, not merely a phone book

DNS is an excellent historical case study because it replaced a model that did not scale well: globally distributing one hosts file as the Internet grew.

Its design separates a hierarchical namespace, authoritative information, resolvers, delegation, and caching.

The hierarchy allows responsibility to be distributed:

```text
.
└── example
    └── course
        └── api
```

A resolver does not need one global database stored locally forever. It can follow delegated authority and cache answers.

### Caching creates a controlled staleness trade-off

Suppose an address record has TTL 60 seconds.

A client resolver may continue using that answer until the cached record expires, even if the authoritative mapping changes after ten seconds.

That is not necessarily a bug. It is the result of an explicit freshness/performance trade-off.

Caching reduces:

- latency;
- load on authoritative servers;
- repeated network traffic.

But it creates a period in which different clients may legitimately hold different views.

This is a recurring distributed-systems pattern:

```text
cache more aggressively
       ↓
lower lookup cost
       ↓
potentially older information
```

### DNS availability depends on more than one server

The DNS architecture uses replication, delegation, caching, and multiple servers to avoid one global central point.

However, individual applications can still misuse DNS—for example by assuming that an address remains valid forever after one startup lookup.

Naming-system resilience does not automatically make the client's discovery policy resilient.

## 9. Service discovery adds dynamic membership to naming

Traditional host naming often changes relatively slowly. Service instances in clusters may change much faster.

A deployment might look like:

```text
09:00  service A = [node1, node2]
09:10  node2 fails
09:11  node3 starts
09:12  service A = [node1, node3]
```

Clients need some mechanism to learn the current set.

A service registry typically stores records such as:

```text
service: image-worker
instance: worker-17
endpoint: 10.0.0.31:7000
metadata:
  zone: lab-a
  capacity: 4
expires_at: ...
```

The registry is not merely a dictionary. It must define:

- who may register;
- how registrations expire;
- how health is represented;
- whether clients watch for changes or poll;
- how updates are replicated;
- what stale clients should do.

## 10. Registration can be push, pull, static, or derived

There is no universal discovery mechanism.

### Static configuration

Clients receive a fixed endpoint list.

Advantages:

- simplest possible mechanism;
- easy to reason about;
- no registry dependency.

Disadvantages:

- membership changes require configuration updates;
- stale state can persist indefinitely;
- operational work grows with deployment dynamism.

Static configuration is not “wrong.” For a three-node educational cluster with rare changes, it may be entirely appropriate.

### Self-registration

A service instance starts and registers itself.

```text
worker → registry: register(worker-17, endpoint)
```

This is flexible but requires the worker to refresh or remove its record correctly.

### Third-party registration

An orchestrator or control plane observes the process and publishes membership.

This avoids trusting every application to maintain registry state itself.

### Derived discovery

The discovery system can derive endpoints from another source of truth, such as an orchestrator's desired/observed state.

The architecture should identify which component is authoritative.

## 11. Leases turn silence into eventual removal

Suppose a worker registers once and then crashes.

If the registry retains the entry forever, clients may repeatedly select a dead endpoint.

A lease or TTL-based registration says:

> “This entry is valid only if refreshed before expiration.”

Example:

```text
lease duration = 15 s
heartbeat every = 5 s
```

If heartbeats stop, the registry eventually removes or marks the instance unhealthy.

But a lease introduces timing assumptions.

Questions include:

- How long should expiration be?
- What if the network is slow but the worker is healthy?
- What if the worker can reach clients but not the registry?
- What if the registry clock and worker clock differ?

Failure detection is never free. Chapter 10 will study this in depth.

## 12. Health has several meanings

A process can be:

- alive;
- accepting TCP connections;
- answering a health endpoint;
- able to access its database;
- able to complete useful application requests;
- caught up enough to serve consistent reads.

These are not the same property.

A simplistic health check can create misleading discovery information.

For example:

```text
GET /health -> 200
```

may prove only that the HTTP process is alive. It may not prove that the service can perform its primary operation.

On the other hand, a health check that synchronously verifies every dependency can create cascading failure: one database slowdown makes every API replica declare itself unhealthy, removing all capacity at once.

Health checks therefore encode architecture.

## 13. Discovery information can be stale even when the registry is correct

Suppose:

1. registry returns `[A, B, C]`;
2. client caches the result;
3. `B` crashes;
4. registry removes `B`;
5. client has not refreshed yet.

The registry is correct at step 4. The client still has stale state.

This is normal in distributed systems.

A resilient client combines discovery with runtime failure handling:

```text
resolve service
    ↓
choose endpoint
    ↓
attempt RPC
    ↓
observe success/failure
    ↓
refresh/reselect when policy requires
```

Discovery does not replace deadlines, retries, or health observation from Chapter 4.

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosity</span>
  <strong>A healthy service can be unreachable because discovery is stale—and an unhealthy service can remain discoverable</strong>
  <p>Naming and discovery systems publish beliefs about where services live. Leases, caches, and health checks make those beliefs time-dependent, so registry state and real process state are rarely updated at the same instant.</p>
  <p><strong>Try it:</strong> Write a timeline from worker crash to lease expiry to client refresh and mark every interval where registry truth and physical truth differ.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">More chapter curiosities →</a>
</aside>

## 14. Load balancing consumes discovery information

Once a logical service resolves to several endpoints, someone must select one.

Common policies include:

- pick first;
- round robin;
- random;
- least outstanding requests;
- weighted selection;
- locality-aware selection;
- consistent hashing by key.

Each policy requires different state.

### Round robin

Simple and deterministic over a healthy set, but it ignores request cost and backend capacity.

### Least loaded

Potentially better when requests vary, but “load” must be measured and communicated. Measurements can be stale.

### Consistent hashing

Useful when requests for the same key should tend to reach the same backend/cache, but membership changes must be handled carefully.

### Client-side vs proxy-side balancing

Client-side:

```text
registry → client → selected server
```

Proxy-side:

```text
client → load balancer/proxy → server
```

Client-side balancing distributes selection logic across clients and can avoid an extra application proxy hop, but requires clients to implement discovery/balancing behavior.

Proxy-side balancing centralizes policy and simplifies clients, but the proxy layer becomes infrastructure that must itself scale and survive failures.

There is no free architecture.

## 15. gRPC makes naming and load balancing explicit enough to study

A gRPC client commonly creates a channel for a **target** rather than manually opening one socket for each call.

The target is resolved into one or more addresses. A load-balancing policy then chooses among usable backend connections.

This is a useful modern example of the distinction:

```text
logical target
    ↓
name resolver
    ↓
address set
    ↓
load-balancing policy
    ↓
subchannel/backend
```

DNS is a default resolver in common gRPC usage, but gRPC also supports pluggable/custom resolution mechanisms in supported languages. Service configuration can influence load balancing and call behavior.

The important lesson is not the exact API. It is that a mature RPC system recognizes **name resolution and endpoint selection as separate distributed responsibilities**.

## 16. Kubernetes-style service names illustrate indirection

Container orchestration provides another modern comparison.

Short-lived workload instances may receive changing addresses. Applications should not normally hard-code those pod/instance addresses.

A logical Service can receive a stable DNS name, while the system maintains the current set of backing endpoints.

Conceptually:

```text
client asks for logical service
         ↓
DNS/service discovery
         ↓
service abstraction
         ↓
current backing instances
```

This illustrates a recurring design principle:

> **Put volatile placement behind a more stable name or identity.**

You do not need Kubernetes to implement this principle locally.

## 17. Registries create their own distributed-systems problem

A central registry appears simple:

```text
clients + workers → registry
```

But now ask:

- What if the registry crashes?
- What if it loses registration state?
- What if two replicas disagree?
- What if a partition divides registry replicas?
- Which replica may accept writes?
- How are watches delivered?

We have moved the distributed problem rather than eliminated it.

This is not an argument against registries. It is an argument for accounting honestly for their guarantees.

A small final project may reasonably accept a single registry as a documented single point of failure if the problem specification does not require registry fault tolerance.

A stronger project may replicate the registry using mechanisms introduced later in the course.

Architecture is about choosing which complexity is justified.

## 18. Membership is not the same as failure detection

Membership answers:

> Which nodes are currently considered part of the system?

Failure detection answers:

> Which nodes do I currently suspect are unavailable?

Those sets may differ temporarily.

A node can be a valid member but currently unreachable.

A node can be reachable but no longer authorized as a member.

A process can restart at the same address with a new incarnation.

Therefore a robust membership record often needs identity/version information beyond host and port.

For example:

```text
node_id = worker-7
incarnation = 43
endpoint = 10.0.0.7:9000
```

If an old delayed heartbeat from incarnation 42 arrives, the registry should not necessarily resurrect obsolete state.

This pattern becomes important in gossip membership protocols later.

## 19. Stale membership can create correctness problems, not only failed requests

Selecting a dead backend usually causes a timeout and retry.

But stale discovery can be more dangerous when endpoints carry authority.

Suppose a client caches that node A is the current leader. A leadership change occurs, but the client continues sending writes to A.

A correct consensus protocol requires A to reject or redirect requests once it learns it is no longer leader. The client cache cannot be the source of truth for authority.

This leads to a useful rule:

> **Discovery may locate a candidate endpoint; the protocol must still validate authority where correctness requires it.**

Naming and consensus solve different problems.

## 20. Worked example — a worker registry

Consider three workers:

```text
W1 capacity=2
W2 capacity=4
W3 capacity=1
```

Each registers:

```text
POST /register
{
  "node_id": "W2",
  "incarnation": 5,
  "endpoint": "127.0.0.1:7202",
  "capacity": 4,
  "lease_seconds": 15
}
```

The registry records a lease deadline.

A client requests:

```text
GET /services/worker
```

and receives the current candidates.

Now inject a failure:

```text
kill W2
```

Immediately afterward, some clients may still select W2.

Expected behavior is not instant omniscience. The design should define:

1. how quickly W2 is suspected;
2. how quickly its registration expires;
3. what an RPC to W2 does in the meantime;
4. whether the client refreshes discovery after failure;
5. when replacement W4 becomes eligible.

The lab should measure these intervals rather than hand-wave them.

## 21. Worked example — stale cache after scale-out

Initial state:

```text
service = [A]
```

Client C resolves the service and caches A for 60 seconds.

Ten seconds later:

```text
service = [A, B, C]
```

The new replicas exist, but client C still uses only A until refresh.

This means adding capacity does not guarantee that every existing client immediately uses it.

Discovery freshness affects elasticity.

A system that scales quickly may require:

- shorter TTLs;
- push/watch updates;
- connection/channel refresh;
- proxy-side balancing;
- another dynamic control mechanism.

Again, the right choice depends on workload and operational goals.

## 22. Worked example — registry partition

Suppose a registry is replicated:

```text
R1 ----- R2 ----- R3
```

A partition isolates R1.

Workers near R1 continue refreshing registrations there. Clients near R2/R3 see a different membership view.

What should happen?

There is no universal answer. Possibilities include:

- only a quorum side accepts membership changes;
- both sides accept changes and reconcile later;
- registry state is treated as eventually consistent and clients tolerate stale candidates;
- authoritative membership changes require consensus while health observations remain local.

The project design must distinguish **safety-critical membership state** from **advisory discovery information**.

Later modules provide the mechanisms needed to implement stronger choices.

## 23. Architecture patterns should be chosen by failure consequences

Consider three designs for a job service.

### Design A — single coordinator

```text
clients → coordinator → workers
```

Advantages:

- simple state model;
- easy scheduling decisions;
- easy debugging.

Risk:

- coordinator failure can stop progress.

### Design B — replicated coordinator

```text
clients → coordinator group → workers
```

Advantages:

- stronger control-plane availability.

Cost:

- replicated-state coordination;
- leader election/consensus;
- more complex recovery.

### Design C — decentralized workers

```text
workers ↔ workers
```

Advantages:

- no single scheduler role.

Cost:

- distributed membership;
- work ownership;
- duplicate assignment prevention;
- convergence.

A student should not receive extra credit merely for choosing the most complicated diagram. The best design is the smallest one that satisfies the stated guarantees and can be defended experimentally.

## 24. Historical path — from global host files to dynamic service discovery

Naming history illustrates why distributed systems often evolve from static configuration toward delegated and dynamic mechanisms.

Early host-name mappings could be distributed as a shared file while the network was small. Growth made centralized maintenance and repeated global distribution expensive and brittle.

DNS introduced a distributed hierarchical database with delegated authority and caching.

Data-center and cloud systems later introduced much more dynamic membership: processes and containers can be replaced frequently, replicas scale up and down, and services span zones or regions. Registries, orchestrator-managed Services, sidecars/proxies, and client-side resolvers emerged to bridge stable application identity and volatile placement.

Despite the changing software, the question remains the same:

> **Which name stays stable while the thing that serves it moves?**

## 25. Common mistakes

### Mistake 1 — hard-code addresses and call that discovery

Static addresses can be valid bootstrap configuration, but the architecture must admit their update/failure consequences.

### Mistake 2 — equate DNS with always-current state

DNS intentionally uses caching. Different resolvers may temporarily hold different answers.

### Mistake 3 — assume health is binary and objective

Alive, reachable, ready, caught up, and semantically healthy are different properties.

### Mistake 4 — remove endpoints instantly after one timeout

One timeout may represent network delay, overload, client-side trouble, or transient loss rather than a dead server.

### Mistake 5 — let stale discovery grant authority

A cached leader address does not make that node the current leader.

### Mistake 6 — build a registry without explaining registry failure

The registry is part of the distributed system and needs its own failure model.

### Mistake 7 — choose microservices because distribution sounds modern

Every remote boundary introduces failure, versioning, observability, and operational cost.

### Mistake 8 — confuse logical identity with process incarnation

A restarted process may represent the same logical role but should still be distinguishable from delayed messages sent by its predecessor.

## 26. The Ray-removal connection

Ray previously handled much of this indirectly.

When a student wrote:

```text
@ray.remote
class Worker:
    ...
```

and obtained handles to workers, the runtime provided mechanisms for locating and scheduling work on distributed processes.

After Ray removal, the architecture must answer explicitly:

```text
How does a worker join?
What is its stable identity?
Where is its current endpoint stored?
How does a client learn the endpoint?
How long may that information be cached?
How is failure suspected?
How is a dead entry removed?
Who selects among replicas?
What happens when registry information is stale?
What happens if the registry itself fails?
```

These questions extend the **middleware dependency map** you began in Chapter 2.

## Laboratory transition

The Chapter 8 laboratory builds a small Ray-free registry and worker pool. Workers register logical identity, endpoint, metadata, and lease information. Clients resolve a logical service name, select a backend, observe stale membership after a crash, and compare at least two balancing strategies.

The final experiment deliberately partitions or disconnects part of the discovery path so you must distinguish:

```text
service exists
registry knows it
client knows it
client can reach it
service can actually complete the operation
```

Those are separate facts.

## Chapter summary

Architecture determines where distributed state and responsibility live.

1. **A logical service is not the same as one process or address.**
2. **Client/server, multi-tier, microservice, and peer-to-peer structures create different failure and discovery responsibilities.**
3. **Names, identifiers, addresses, and concrete instances should be separated deliberately.**
4. **DNS demonstrates delegated naming plus caching and controlled staleness.**
5. **Dynamic service discovery adds rapidly changing membership and health information.**
6. **Leases allow stale registrations to expire but depend on timing and failure-detection assumptions.**
7. **Clients can remain stale even when the registry is already correct.**
8. **Load balancing consumes endpoint information and therefore inherits its freshness limitations.**
9. **A registry is itself a distributed-system component whose failure must be accounted for.**
10. **Discovery locates candidate endpoints; it does not by itself establish authority or correctness.**
11. **Static architecture can be correct when its assumptions match the problem; complexity is not a learning objective by itself.**
12. **Removing Ray exposes membership, placement, naming, and endpoint-selection decisions that middleware previously made for the application.**

The next chapter asks what happens after you have found the right participants but several of them hold copies of the same logical state: which histories may clients observe, and what does it mean for those copies to agree?

<div class="ds-next-action">
  <span>Core reading complete</span>
  <strong>Next required step · Guided practice</strong>
  <a href="../guided-practice/">Start guided practice →</a>
</div>
