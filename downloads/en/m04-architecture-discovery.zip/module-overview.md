<p class="ds-book-part">Part III — Naming and Replicated State</p>
<p class="ds-module-kicker">Chapter 8</p>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 8 of 12</span>
    <span>67% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 67%"></span></div>
</div>
<p class="ds-guiding-question">How do you find the right logical service when names stay stable but locations and membership change?</p>

Separate the thing you mean from where it happens to be running. Start with names, identifiers, and addresses; follow DNS-style indirection and caching; then move to dynamic registries, leases, stale membership, load selection, and decentralized lookup.

## Key ideas

- names, identifiers, and addresses
- flat, structured, and attribute/service naming
- DNS and caching
- service registries
- leases and membership
- discovery and load selection
- stale mappings
- consistent hashing
- Chord/Kademlia-style lookup as decentralized naming
- logical identity versus process incarnation

## Laboratory transition

Build a registry with leases and client-side selection, kill/replace workers, observe stale entries, then compare the centralized lookup path with a structured decentralized alternative.

## Start here

> **Before you read:** A service called payments restarts at a new address. Which identifier should stay stable, which value should change, and who is allowed to cache the old mapping?

**Bring forward:** Architecture, communication, and failure boundaries from Chapters 2–7.

**This chapter builds toward:** Naming and discovery designs that remain understandable when locations, membership, and caches change.

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>35 min–50 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>45 min–1 h 10 min</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>2 h–2 h 30 min · 7 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Read lesson →</a>
  <a class="ds-secondary-action" href="lab/">Open laboratory</a>
</div>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../downloads/en/m04-architecture-discovery.zip" download>Download chapter + laboratory for offline study (.zip)</a></p>

## What you will learn

- Distinguish a name, identifier, address, endpoint, and process incarnation.
- Explain flat, structured, and service-oriented naming using DNS and registries as concrete examples.
- Design registration, leases, caching, and endpoint selection for changing membership.
- Reason about stale discovery and the difference between naming authority and failure suspicion.
- Compare central/replicated directories with consistent-hash and structured decentralized lookup.

## Learn by working the question

1. Write your answer to **Start here** before opening the full lesson.
2. Read until the next prediction or trace, then stop and work it out before revealing the explanation.
3. Treat guided practice as a **practice bank**, not a speed worksheet. Work the core traces until you can meet the chapter's Practice target; return to the remaining cases for retrieval practice or instructor-assigned work.
4. Use the knowledge check to find gaps, then enter the laboratory with a falsifiable prediction and name the evidence that could contradict it.
5. Finish by explaining what the experiment established, what it did not establish, and how the result changes the evolving service.

<nav class="ds-sequence" aria-label="Course sequence">
<a class="ds-sequence-link" href="../m09-consensus/">← Coordination II — Mutual Exclusion, Elections, and Agreement</a>
<a class="ds-sequence-link next" href="../m08-replication-consistency/">Replication and Consistency →</a>
</nav>
