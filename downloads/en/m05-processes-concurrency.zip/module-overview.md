<p class="ds-book-part">Part I — Foundations and Architecture</p>
<p class="ds-module-kicker">Chapter 3</p>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 3 of 12</span>
    <span>25% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 25%"></span></div>
</div>
<p class="ds-guiding-question">Which execution boundaries isolate state, scheduling, resources, and failure?</p>

You already know processes, threads, and synchronization from Operating Systems. Revisit them here as boundaries that determine what can fail together, what can share memory, and what must communicate explicitly.

## Key ideas

- threads, goroutines, and processes
- shared-state synchronization
- race conditions and deadlocks
- concurrent servers
- processes versus distributed nodes
- containers and namespaces
- virtual machines and host failure domains
- placement and migration as architecture decisions

## Laboratory transition

Expose a race inside one service, repair it, then run independent instances as processes/containers and classify which failures remain shared.

## Start here

> **Before you read:** Four containers run on one laptop. How many independent process-failure domains exist? How many independent machine-failure domains exist?

**Bring forward:** Processes, threads or goroutines, synchronization, and virtual memory from Operating Systems.

**This chapter builds toward:** A precise boundary between local concurrency bugs and failures that require distributed coordination.

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>25 min–35 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>35 min–50 min</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>1 h 30 min–2 h · 5 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Read lesson →</a>
  <a class="ds-secondary-action" href="lab/">Open laboratory</a>
</div>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../downloads/en/m05-processes-concurrency.zip" download>Download chapter + laboratory for offline study (.zip)</a></p>

## What you will learn

- Implement a concurrent server and identify shared mutable state.
- Use the Go race detector to expose unsafe access.
- Distinguish a local mutex from distributed coordination.
- Explain process and container isolation boundaries.
- Diagnose deadlock, starvation, and overload in a service node.

## Learn by working the question

1. Write your answer to **Start here** before opening the full lesson.
2. Read until the next prediction or trace, then stop and work it out before revealing the explanation.
3. Treat guided practice as a **practice bank**, not a speed worksheet. Work the core traces until you can meet the chapter's Practice target; return to the remaining cases for retrieval practice or instructor-assigned work.
4. Use the knowledge check to find gaps, then enter the laboratory with a falsifiable prediction and name the evidence that could contradict it.
5. Finish by explaining what the experiment established, what it did not establish, and how the result changes the evolving service.

<nav class="ds-sequence" aria-label="Course sequence">
<a class="ds-sequence-link" href="../m02-ray-middleware/">← Architectures and Middleware</a>
<a class="ds-sequence-link next" href="../m03-rpc/">Communication I — Messages, RPC, and Remote Failure →</a>
</nav>
