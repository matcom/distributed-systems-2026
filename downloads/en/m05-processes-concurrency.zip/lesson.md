<p class="ds-book-part">Part I — Foundations and Architecture</p>
<div class="ds-lesson-banner">
  <div><span>Course step</span><strong>Chapter 3</strong></div>
  <div><span>Core reading</span><strong>25 min–35 min</strong></div>
  <div><span>Required path</span><strong>Read → Practice target → Check → Lab</strong></div>
</div>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 3 of 12</span>
    <span>25% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 25%"></span></div>
</div>

> **Guiding question:** Which execution boundaries isolate state, scheduling, resources, and failure?

## Before you read

> Four containers run on one laptop. How many independent process-failure domains exist? How many independent machine-failure domains exist?

Write a short answer first. You are not expected to be correct yet; you need a prediction you can revise as the chapter gives you better models and evidence.

**Use what you already know:** Processes, threads or goroutines, synchronization, and virtual memory from Operating Systems.

## Workload map

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>25 min–35 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>35 min–50 min</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>1 h 30 min–2 h · 5 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../../downloads/en/m05-processes-concurrency.zip" download>Download lesson + practice + lab for offline study (.zip)</a></p>

## Why this chapter matters

Distributed systems are often blamed on the network when the first bug is actually inside one node.

A service process may contain many concurrent handlers, timers, background loops, queues, caches, connection pools, retry workers, and shutdown paths. Those activities share memory and resources even before any distributed coordination begins.

The guiding question is:

> **What can go wrong inside one node before the network is even involved?**

This chapter connects the Operating Systems material you already know with distributed-service engineering. The distinction matters because the repair for a local race is not the repair for a distributed race.

A mutex can coordinate goroutines inside one process. It cannot make two independently failing machines agree.

## 1. A distributed node is still an ordinary concurrent program

Consider a small RPC server:

```text
listener
  ↓
accept/request loop
  ├── handler R1
  ├── handler R2
  ├── handler R3
  ├── heartbeat loop
  ├── cache cleanup loop
  └── shutdown/recovery logic
```

Even if the network behaves perfectly, these activities can interleave in unexpected ways.

Examples include:

- two handlers updating the same map;
- one goroutine closing a channel while another sends;
- shutdown racing with a background write;
- a retry worker duplicating a state transition;
- a queue growing without bound;
- a lock cycle producing deadlock.

Distributed correctness therefore depends on correct local concurrency at every participating node.

## 2. Concurrency and parallelism are related but different

Concurrency means several activities can be in progress during overlapping intervals.

Parallelism means several activities literally execute at the same physical time on different CPU cores or processors.

A single-core system can still be concurrent through interleaving:

```text
CPU time →
R1  ####      ####
R2      ####       ###
```

A multicore system may execute them simultaneously.

For correctness, both cases matter because the programmer should not depend on one lucky scheduling order unless synchronization establishes it.

## 3. Shared mutable state creates local ordering obligations

Suppose two handlers execute:

```text
counter = counter + 1
```

The operation is conceptually:

```text
read counter
compute +1
write counter
```

If both handlers read `10` before either writes, both may write `11`.

The intended result after two increments was `12`.

This is a lost update.

The key question is not merely “are there threads?” It is:

> **Which memory locations can several concurrent activities read or modify?**

A useful code-review habit is to identify shared mutable state explicitly:

```text
state                 owners/users
------------------------------------------------
request map           handlers + cleanup loop
worker registry       registration + expiry loop
connection pool       all outbound RPC paths
shutdown flag         main + signal handler
metrics counters      many goroutines
```

Only after identifying that state can we decide how it should be synchronized.

<figure class="ds-book-figure">
  <img src="../../../assets/book/m05-failure-boundaries.svg" alt="Threads, processes, containers, and hosts form different state and failure boundaries." loading="lazy" decoding="async" />
  <figcaption><span>Figure</span>Isolation is layered. A process crash, container failure, and host loss remove different sets of state and execution.</figcaption>
</figure>

## 4. Data races and higher-level race conditions are not identical

A **data race** in the Go memory-model sense occurs when concurrent accesses to the same variable conflict without the required synchronization, with at least one write.

Go's race detector instruments running code and reports races that actually occur in exercised execution paths.

This is extremely useful, but a race-free program can still contain a logical race condition.

Example:

```text
if balance >= 10:
    withdraw 10
```

Imagine each individual operation is protected so there is no unsynchronized memory access, but the **check** and **update** occur in different critical sections:

```text
lock
read balance = 10
unlock

... another handler does the same ...

lock
write balance = 0
unlock
```

The program may be data-race free while the higher-level invariant is broken.

Therefore:

> **The race detector finds important unsafe memory accesses; it does not prove the application invariant is correct.**

## 5. Mutexes protect local invariants

A mutex lets one execution hold exclusive access to a critical section.

For a local map:

```text
lock
lookup/update map
unlock
```

This can establish an invariant such as:

> no two goroutines mutate this map concurrently.

A mutex is appropriate when:

- the protected state lives inside one process;
- all relevant accesses use the same synchronization discipline;
- blocking while another goroutine holds the lock is acceptable.

But lock granularity matters.

One global lock can be easy to reason about and still destroy concurrency.

Many fine-grained locks can increase throughput while creating more ordering complexity.

The course values the simplest synchronization strategy that satisfies correctness and measured performance requirements.

## 6. Channels move synchronization into communication structure

Go channels allow goroutines to coordinate by sending values/events.

A common design is to make one goroutine own mutable state:

```text
handlers
  | requests
  v
state-owner goroutine
  |
  v
map/state
```

Now handlers do not mutate the map directly. They send commands to the owner.

This can simplify ownership reasoning because the mutable state has one local owner.

However, channels do not magically eliminate deadlock, starvation, queue growth, or bad protocol design.

A channel can block forever when:

- nobody receives;
- a receiver waits for a sender that itself waits for the receiver;
- shutdown closes components in the wrong order.

The useful question remains: **who owns the state and what ordering does the communication establish?**

## 7. Deadlock is circular waiting

A classic lock-order deadlock:

```text
G1 holds A, waits for B
G2 holds B, waits for A
```

Neither can progress.

Distributed systems later contain analogous wait cycles across machines, but first you should diagnose the local case.

Useful local strategies include:

- consistent lock ordering;
- avoiding holding locks across blocking I/O;
- reducing nested locking;
- using timeouts only as diagnostics/escape where semantically safe;
- designing clear ownership.

A timeout can make a deadlock appear to “recover” without fixing the broken ordering. That distinction should be explicit.

## 8. Starvation means progress is unfairly denied

A program can remain active while one request or goroutine rarely obtains the resource it needs.

Examples:

- a high-priority queue continuously delays low-priority work;
- one writer is repeatedly postponed by readers;
- a semaphore is monopolized by long jobs;
- a worker pool repeatedly selects the same class of task.

Starvation is a liveness problem, not necessarily a safety violation.

This terminology becomes useful later when evaluating distributed schedulers and consensus progress.

## 9. Goroutine leaks are resource leaks

A goroutine that waits forever on a channel, timer, RPC, or queue may never terminate even after the original request is gone.

One leak seems harmless. Thousands become a service failure.

Cancellation must therefore propagate through local call structure as well as RPC boundaries.

Typical questions:

- Who cancels background work?
- Who owns a timer?
- Who closes the channel?
- Can a blocked send observe cancellation?
- Does shutdown wait for all goroutines?

The same ownership discipline used for distributed state applies inside a process.

## 10. Bounded worker pools turn concurrency into an explicit resource policy

Starting one goroutine for every request can work at modest load, but unbounded concurrency eventually converts incoming work into memory and scheduler pressure.

A bounded worker pool says:

```text
incoming work
      ↓
bounded queue
      ↓
N workers
```

If arrival rate exceeds service rate, the system must decide what to do:

- block/admit slowly;
- reject;
- shed load;
- queue up to a bound;
- prioritize.

This is the beginning of backpressure.

Chapter 12 develops queueing and overload in depth. Chapter 3 establishes the local mechanism.

## 11. Concurrency limits are part of the service contract

Suppose a node has a database pool of 20 connections.

Allowing 1,000 concurrent handlers to all require database access does not create 1,000 units of useful parallelism. It can create 980 waiting goroutines plus queueing and deadline pressure.

Concurrency should often be bounded near the scarce resource.

Examples:

- CPU-intensive workers near CPU capacity;
- storage operations near disk/device queue capacity;
- outbound RPC calls near downstream limits;
- model inference near accelerator capacity.

The correct limit should be measured rather than copied from a framework default.

## 12. Never hold a local lock across a remote call without a strong reason

Consider:

```text
lock local state
call remote service
wait
unlock
```

The lock duration now depends on network and remote-service behavior.

A slow or partitioned peer can block unrelated local work.

Worse, two services can create a distributed wait cycle:

```text
A holds local lock → calls B
B holds local lock → calls A
```

Local locking has now been entangled with distributed failure.

Often the safer design is to capture the required local state, release the lock, perform remote work, then validate/update state afterward.

But doing so can introduce optimistic-concurrency questions. There is no universal recipe; the important rule is to recognize the coupling.

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosity</span>
  <strong>A distributed protocol can be correct on paper and still fail because one node has a local race</strong>
  <p>Duplicate suppression, leader state, membership, and queues are implemented by ordinary concurrent programs. A bad check-then-act interleaving inside one process can violate a distributed invariant before the network does anything unusual.</p>
  <p><strong>Try it:</strong> Construct two concurrent handlers that both observe a missing request ID and then both apply the same effect.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">More chapter curiosities →</a>
</aside>

## 13. A local mutex cannot implement distributed mutual exclusion across nodes

Suppose replicas A and B both hold a variable named `leader` protected by local mutexes.

Each mutex controls only its own process memory.

```text
A: mutex → leader=true
B: mutex → leader=true
```

Both programs can be individually race-free and globally inconsistent.

This is one of the most important transitions from Operating Systems to Distributed Systems:

> **Shared-memory synchronization orders accesses visible to one synchronization domain. Distributed coordination must order actions across independent failure domains.**

Later modules introduce leader election, consensus, leases, and distributed locks.

## 14. Process boundaries create failure and memory isolation

Separate processes do not normally share an address space.

This gives useful isolation:

- one process cannot directly mutate another process's ordinary memory;
- process crashes can be independent;
- permissions and resource controls can differ;
- communication must cross an explicit IPC/network boundary.

But process isolation is not absolute system isolation.

Processes may still share:

- files;
- kernel resources;
- network interfaces;
- storage devices;
- CPU/memory pressure;
- host-level failure.

Running three processes on one laptop gives three process failure domains but still one physical host failure domain.

The Warm-up introduced this distinction; Chapter 3 makes it architectural.

## 15. Containers package and isolate processes, not independent hardware

Containers commonly use operating-system mechanisms such as namespaces and cgroups to create controlled views of processes, filesystems, networking, and resources.

They are excellent for reproducible course clusters because you can run several named service instances with separate ports/filesystems/networks.

However:

> **Three containers on one kernel are not equivalent to three independent physical machines.**

A host kernel crash, out-of-memory event, disk failure, or laptop suspension can affect all of them.

For course experiments this is acceptable as long as the failure model is stated honestly.

## 16. Virtual machines provide a different isolation boundary

A virtual machine contains a guest OS and virtualized hardware environment.

Compared with containers, VMs usually provide a stronger separation between guest kernels at the cost of more overhead and operational complexity.

The course does not require you to rank one as universally better.

The relevant questions are:

- Which failure should be independent?
- Which resources should be isolated?
- How quickly must instances start?
- What does the local laboratory need to emulate?

For many assignments, plain processes or containers are enough.

## 17. Shutdown is a concurrency protocol

Graceful shutdown sounds simple:

```text
receive signal
stop server
exit
```

A real service may need to:

1. stop accepting new work;
2. mark itself unavailable for discovery;
3. allow in-flight requests to finish within a deadline;
4. cancel work that cannot finish;
5. flush durable state/logs;
6. stop background goroutines;
7. close resources;
8. exit.

The ordering matters.

If the process closes shared resources before handlers finish, requests can fail incorrectly.

If it waits forever, deployment and failure recovery can stall.

This makes shutdown a useful local protocol to test deliberately.

## 18. Crash-stop and graceful stop reveal different assumptions

A graceful stop executes cleanup code.

A crash-stop failure does not promise cleanup.

You should not demonstrate “fault tolerance” only with graceful termination if the system claims to tolerate crashes.

For example:

```text
SIGTERM + cleanup
```

and:

```text
kill -9 / abrupt process death
```

can expose very different behavior.

The later failure-model module formalizes this distinction.

## 19. Worked example — concurrent duplicate suppression

Return to Chapter 4.

The server contains a map:

```text
request_id → result
```

Two retries of the same logical operation arrive almost simultaneously.

Naive code:

```text
if R7 not in completed:
    apply effect
    completed[R7] = result
```

Both handlers can observe `R7` absent before either writes it.

Result:

```text
handler 1: check absent
handler 2: check absent
handler 1: apply
handler 2: apply
```

The distributed idempotency idea is correct, but the local implementation contains a race condition.

The repair might use:

- a mutex around the complete check/apply/record critical transition;
- one state-owner goroutine;
- transactional storage.

This example demonstrates why local and distributed correctness compose rather than replace one another.

## 20. Worked example — worker registry race

Return to Chapter 8.

One goroutine refreshes worker leases while another removes expired entries.

Without synchronization, the map can race.

Even with a mutex, a semantic race can remain if expiry logic uses an old timestamp or deletes a newly refreshed incarnation.

Correct local design may require the expiry operation to validate:

```text
node_id
incarnation
observed lease version/deadline
```

before deleting the record.

Again, `go test -race` helps with unsafe memory access, while invariant reasoning handles higher-level stale-state races.

## 21. Worked example — overload inside one healthy node

A server is alive, reachable, and not deadlocked.

Yet latency grows from 10 ms to 5 seconds.

Possible local cause:

```text
incoming = 1000 req/s
service capacity = 600 req/s
```

A queue grows continuously.

Clients time out and retry, adding more work.

Nothing about this execution requires packet loss or node failure.

A correct investigation checks:

- goroutine count;
- queue depth;
- CPU saturation;
- lock contention;
- downstream pools;
- request latency distribution.

“Node is up” is not equivalent to “node can make timely progress.”

## 22. Race detector: powerful evidence with a limited authority boundary

Go's race detector can be enabled with commands such as:

```bash
go test -race ./...
go run -race ./cmd/server
```

It detects races that occur in the execution paths actually exercised.

Therefore a clean race-detector run means:

> no instrumented data race was observed in that workload.

It does **not** prove:

- no race exists in unexecuted code;
- no deadlock exists;
- no semantic race exists;
- no distributed race exists;
- no performance bottleneck exists.

The course uses tools as evidence with explicit authority boundaries.

## 23. Historical perspective — from threads to service runtimes

Concurrent programming long predates cloud systems. Threads, locks, monitors, message passing, and processes established the basic vocabulary for coordinating activities inside machines.

Modern distributed-service runtimes add layers of concurrency:

```text
cluster
  ↓
processes/containers
  ↓
threads/goroutines
  ↓
async requests/background tasks
```

The historical lesson is that newer distributed abstractions do not eliminate older concurrency problems. They stack on top of them.

This is why systems courses should connect architecture, operating systems, networking, and distributed systems rather than teaching them as isolated worlds.

## 24. Common mistakes

### Mistake 1 — “Go channels prevent races automatically”

Only code that actually follows a safe ownership/synchronization discipline gains that benefit.

### Mistake 2 — “The race detector passed, therefore concurrency is correct”

The tool observes executed data races, not every logical invariant.

### Mistake 3 — protect each individual map operation but split one invariant across locks

Atomic map safety is not equivalent to atomic application state transition.

### Mistake 4 — use one global lock and ignore performance

Correctness comes first, but a lock held across expensive work can serialize the service unnecessarily.

### Mistake 5 — hold locks during remote calls

Remote delay can turn local synchronization into system-wide blocking.

### Mistake 6 — use a local mutex to “fix” two replicas

A local lock cannot order state transitions on another machine.

### Mistake 7 — treat containers as independent physical failure domains

Several containers can share one kernel and one host failure.

### Mistake 8 — test only graceful shutdown

A crash-tolerant claim requires abrupt-failure experiments too.

## Laboratory transition

The Chapter 3 laboratory starts from a concurrent service with shared request/worker state. First, you expose a data race, then repair it, then find a higher-level semantic race that survives the race detector. They also induce deadlock/overload and compare graceful shutdown with abrupt process failure.

The goal is to leave Chapter 3 with a precise rule:

> **Before blaming distribution, prove that each node's local state machine is itself safe, live enough, and observable.**

## Chapter summary

1. **Every distributed node is also a concurrent local program.**
2. **Concurrency creates interleavings even without physical parallel execution.**
3. **Shared mutable state requires an explicit synchronization/ownership discipline.**
4. **Data-race freedom is necessary for many programs but does not prove higher-level invariants.**
5. **Mutexes and channels coordinate within a local synchronization domain.**
6. **Deadlock, starvation, leaks, and overload are local liveness failures that can mimic network trouble.**
7. **Bounded concurrency and queues are resource policies, not mere implementation details.**
8. **Holding local locks across remote calls couples local progress to distributed failure.**
9. **A local mutex cannot establish agreement between independent nodes.**
10. **Processes, containers, VMs, and hosts create different isolation and failure boundaries.**
11. **Graceful shutdown and crash-stop failure exercise different paths.**
12. **Distributed correctness is built from correct local implementations plus correct cross-node protocols.**

The next chapter crosses the process boundary explicitly: a locally correct service still needs a request protocol whose timeout, retry, and duplicate semantics remain meaningful when the peer is remote.

<div class="ds-next-action">
  <span>Core reading complete</span>
  <strong>Next required step · Guided practice</strong>
  <a href="../guided-practice/">Start guided practice →</a>
</div>
