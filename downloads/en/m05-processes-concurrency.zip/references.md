> **Reference view.** This page is optional context; return to the [Lesson](../lesson/) for the required path.

## Essential

- **● Distributed Systems, 4th ed.** — Maarten van Steen and Andrew S. Tanenbaum. [book](https://www.distributed-systems.net/index.php/books/ds4/)
- **●● Data Race Detector** — The Go Project. [tool documentation](https://go.dev/doc/articles/race_detector)

## Recommended

- **●● Designing Data-Intensive Applications** — Martin Kleppmann. [book](https://dataintensive.net/)
- **● The Go Documentation** — The Go Project. [tool documentation](https://go.dev/doc/)

## Advanced

No additional item assigned yet.

## Tools & Practice

- **● Docker Documentation** — Docker. [tool documentation](https://docs.docker.com/)

## Explore

- **●●● 6.5840 Distributed Systems** — MIT PDOS. [course](https://pdos.csail.mit.edu/6.824/)
