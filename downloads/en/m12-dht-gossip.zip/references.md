> **Reference view.** This page is optional context; return to the [Lesson](../lesson/) for the required path.

## Essential

- **●● Chord: A Scalable Peer-to-peer Lookup Service for Internet Applications** — Stoica et al.. [paper](https://pdos.csail.mit.edu/papers/chord:sigcomm01/chord_sigcomm.pdf)

## Recommended

- **●●● Dynamo: Amazon's Highly Available Key-value Store** — DeCandia et al.. [paper](https://www.allthingsdistributed.com/files/amazon-dynamo-sosp2007.pdf)

## Advanced

- **●●● Kademlia: A Peer-to-peer Information System Based on the XOR Metric** — Maymounkov and Mazières. [paper](https://pdos.csail.mit.edu/~petar/papers/maymounkov-kademlia-lncs.pdf)

## Tools & Practice

- **● The Go Documentation** — The Go Project. [tool documentation](https://go.dev/doc/)

## Explore

- **●●● SWIM: Scalable Weakly-consistent Infection-style Process Group Membership Protocol** — Das, Gupta, Motivala. [paper](https://www.cs.cornell.edu/projects/Quicksilver/public_pdfs/SWIM.pdf)
