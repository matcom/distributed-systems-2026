<p class="ds-book-part">Part II — Communication and Coordination</p>
<p class="ds-module-kicker">Chapter 5</p>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 5 of 12</span>
    <span>42% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 42%"></span></div>
</div>
<p class="ds-guiding-question">How should information move when one direct request/response path is not enough?</p>

Not every distributed interaction is a synchronous RPC. Compare queued or event communication, group dissemination, gossip, and structured overlays by asking what each one assumes about destinations, delivery, ordering, membership, and convergence.

## Key ideas

- synchronous versus asynchronous communication
- message queues and publish/subscribe concepts
- group communication and multicast intuition
- gossip dissemination
- push, pull, and push-pull propagation
- overlay networks
- consistent hashing and structured lookup
- churn and membership dissemination
- delivery uncertainty and duplicate information

## Laboratory transition

Choose the gossip/dissemination track or the structured-overlay track. Introduce loss and churn, measure what reaches whom, and explain which guarantees are deterministic and which are probabilistic.

## Start here

> **Before you read:** A producer creates an event while every consumer is offline. Which communication models can still deliver it later, and what state must exist to make that possible?

**Bring forward:** Request/response semantics from Chapter 4 and the distinction between logical and physical communication paths.

**This chapter builds toward:** A vocabulary for synchronous calls, queued events, group dissemination, gossip, and overlay routing.

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>30 min–40 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>45 min–1 h</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>2 h–2 h 30 min · 9 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Read lesson →</a>
  <a class="ds-secondary-action" href="lab/">Open laboratory</a>
</div>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../downloads/en/m12-dht-gossip.zip" download>Download chapter + laboratory for offline study (.zip)</a></p>

## What you will learn

- Compare synchronous RPC with asynchronous, group, gossip, and overlay communication.
- State delivery, ordering, duplication, acknowledgement, and destination assumptions for a communication pattern.
- Explain push, pull, and push-pull gossip and trace a structured-overlay lookup.
- Implement a small dissemination or overlay mechanism and measure behavior under loss or churn.
- Explain which communication guarantees are deterministic and which are probabilistic or eventual.

## Learn by working the question

1. Write your answer to **Start here** before opening the full lesson.
2. Read until the next prediction or trace, then stop and work it out before revealing the explanation.
3. Treat guided practice as a **practice bank**, not a speed worksheet. Work the core traces until you can meet the chapter's Practice target; return to the remaining cases for retrieval practice or instructor-assigned work.
4. Use the knowledge check to find gaps, then enter the laboratory with a falsifiable prediction and name the evidence that could contradict it.
5. Finish by explaining what the experiment established, what it did not establish, and how the result changes the evolving service.

<nav class="ds-sequence" aria-label="Course sequence">
<a class="ds-sequence-link" href="../m03-rpc/">← Communication I — Messages, RPC, and Remote Failure</a>
<a class="ds-sequence-link next" href="../m06-time-causality/">Coordination I — Time, Events, and Causality →</a>
</nav>
