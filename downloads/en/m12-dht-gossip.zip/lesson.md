<p class="ds-book-part">Part II — Communication and Coordination</p>
<div class="ds-lesson-banner">
  <div><span>Course step</span><strong>Chapter 5</strong></div>
  <div><span>Core reading</span><strong>30 min–40 min</strong></div>
  <div><span>Required path</span><strong>Read → Practice target → Check → Lab</strong></div>
</div>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 5 of 12</span>
    <span>42% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 42%"></span></div>
</div>

> **Guiding question:** How should information move when one direct request/response path is not enough?

## Before you read

> A producer creates an event while every consumer is offline. Which communication models can still deliver it later, and what state must exist to make that possible?

Write a short answer first. You are not expected to be correct yet; you need a prediction you can revise as the chapter gives you better models and evidence.

**Use what you already know:** Request/response semantics from Chapter 4 and the distinction between logical and physical communication paths.

## Workload map

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>30 min–40 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>45 min–1 h</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>2 h–2 h 30 min · 9 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../../downloads/en/m12-dht-gossip.zip" download>Download lesson + practice + lab for offline study (.zip)</a></p>

## Why this chapter matters

RPC gives you a clear request/response conversation with a known destination. Many systems need different communication shapes:

- queue work for a consumer that may run later;
- publish an event to several interested components;
- disseminate membership or state to a changing group;
- reach many participants without one sender maintaining a direct channel to all of them;
- route through a logical overlay when no permanent directory is available.

Ask four questions before choosing a mechanism:

1. Do you know the destination now?
2. Must the sender wait for the receiver?
3. Is delivery to one participant or a group?
4. Do you require exact current knowledge, or is eventual/probabilistic dissemination acceptable?

A useful comparison is:

```text
direct RPC             → known peer, synchronous request/response
queue / event stream   → decouple producer from consumer timing
publish / subscribe    → one event, interested receivers
multicast intuition    → one logical send to a group
gossip                 → repeated peer exchange, probabilistic spread
structured overlay     → route toward a key/participant through logical neighbors
```

This chapter concentrates on the last two because they are easy to reproduce locally without depending on a hosted broker. Queue and publish/subscribe semantics remain part of the communication model: delivery, duplication, ordering, acknowledgement, and consumer identity must still be explicit.

---

## 1. Decentralization is not one property

A system may be decentralized in one dimension but centralized in another.

Ask separately:

- Who assigns identities?
- Who knows membership?
- Who decides placement?
- Who routes requests?
- Who stores data?
- Who decides conflicts?
- Who controls admission?

For example, a peer-to-peer storage network may have decentralized data placement but still rely on a small set of bootstrap nodes.

Likewise, a gossip membership service may distribute liveness knowledge but rely on a central authentication authority.

Avoid binary labels such as:

```text
centralized / decentralized
```

without identifying the mechanism being discussed.

---

<aside class="ds-book-note ds-history">
  <span class="ds-book-note-label">History</span>
  <strong>Peer-to-peer systems asked what happens when participants contribute the infrastructure instead of merely using it</strong>
  <p>Structured overlays such as Chord and Kademlia, together with swarming systems, explored scalable lookup, churn, decentralized membership, and direct use of participant storage and bandwidth.</p>
  <a class="ds-book-note-source" href="../../../history/peer-to-peer-dhts/">Read the design history →</a>
</aside>

## 2. Overlay networks create a logical topology

Physical/IP connectivity gives one topology:

```text
routers, subnets, paths
```

A decentralized application can construct another logical topology on top:

```text
peer A knows peer F and peer K
peer F knows peer B and peer M
...
```

This is an **overlay network**.

An overlay edge means:

> this application-level node knows how to contact that peer

not:

> these hosts are physically adjacent.

One overlay hop may traverse many IP routers.

This distinction matters when reasoning about latency: fewer overlay hops do not automatically mean shorter physical paths.

---

## 3. DHTs turn a distributed dictionary into a routing problem

A distributed hash table conceptually offers:

```text
PUT(key, value/location)
GET(key)
```

but no one node stores the whole mapping.

Instead:

1. keys are mapped into an identifier space;
2. nodes occupy positions/IDs in that space;
3. responsibility for key ranges is distributed;
4. each node stores a bounded routing table;
5. queries are forwarded toward the responsible node.

The core challenge is:

> locate the owner of an arbitrary identifier efficiently while each node knows only a fraction of the membership.

---

## 4. Consistent hashing provides the placement intuition

Chapter 11 introduced consistent hashing to reduce remapping when nodes change.

Imagine an identifier ring:

```text
0 -------------------------------- 2^m-1
```

Nodes and keys are assigned identifiers in that circular space.

A simple rule might be:

> key `k` belongs to the first node clockwise whose identifier is at least `k`.

Example:

```text
nodes: 10, 40, 70
```

Then keys in ranges map roughly as:

```text
(70,10] → node 10
(10,40] → node 40
(40,70] → node 70
```

The ring is an abstraction. It does not imply physical circular networking.

---

## 5. A ring with only successor pointers routes correctly but slowly

Suppose every node knows only its immediate successor.

To find key 65 from node 10:

```text
10 → 40 → 70
```

In a large ring, lookup may require walking through many nodes.

The routing table therefore needs **long-distance shortcuts**.

Chord's finger-table idea is one elegant solution.

---

## 6. Chord builds exponentially spaced routing shortcuts

In an `m`-bit identifier space, a Chord-style node `n` maintains entries associated with positions approximately:

```text
n + 2^0
n + 2^1
n + 2^2
...
```

mapped to responsible successors.

The exact table construction is less important than the geometric idea:

> know peers at increasing distances around the identifier space.

Then a lookup can make large progress first and increasingly fine progress near the target.

Under the idealized Chord assumptions, lookup length is logarithmic in the number of participating nodes.

You should interpret this as an architectural scaling property, not a guarantee of low Internet latency.

---

## 7. Worked Chord-style lookup

Suppose IDs are:

```text
4, 12, 20, 35, 52, 60
```

and we want the owner of key 50.

A node at 4 might know shortcuts including 12, 20, and 35.

It forwards toward the closest known predecessor of 50:

```text
4 → 35 → 52
```

Node 52 is the first successor of 50 and therefore owns the key under the chosen rule.

A different valid routing table may take a different path while preserving the same owner.

The testable questions are:

- Did lookup terminate?
- Did it find the correct owner?
- How many overlay hops occurred?
- How does hop count change as the network grows?

---

## 8. DHT node IDs and physical addresses are separate identities

A DHT node might have:

```text
logical node ID = 0x9f31...
network address = 192.0.2.18:7400
incarnation = 12
```

The logical position should not be confused with the current IP/port.

This reuses Chapter 8's separation:

```text
logical identity ≠ physical address
```

and Chapter 10's incarnation idea:

```text
same logical participant may restart as a new process instance
```

A routing table entry therefore often needs enough metadata to reject stale endpoints.

---

## 9. Joining changes responsibility boundaries

Suppose node 30 joins between nodes 20 and 40.

Before:

```text
(20,40] → node 40
```

After:

```text
(20,30] → node 30
(30,40] → node 40
```

Some keys/state must move or become newly replicated.

The join protocol must update routing/neighbor knowledge gradually without making lookups catastrophically incorrect.

Structured overlays therefore need **stabilization/maintenance**, not just a static routing formula.

---

## 10. Graceful departure and crash departure are different

A graceful node can tell neighbors:

```text
I am leaving; transfer these keys; replace these pointers
```

A crashed node says nothing.

Then peers need failure detection and redundancy.

This is where Chapter 10 returns:

- timeout is suspicion, not proof;
- false suspicion can remove a slow but correct peer;
- stale routing entries may persist;
- multiple successor/replica pointers can improve resilience.

---

## 11. Churn is continuous membership change

A peer-to-peer network may experience frequent:

```text
join
leave
crash
restart
address change
```

Collectively, this is **churn**.

A DHT must spend communication not only on useful lookups but also on maintaining routing and placement state.

So performance includes:

```text
lookup cost
+
maintenance cost
+
rebalancing/replication cost
```

A static-ring benchmark measures only part of the system.

---

## 12. Replication is usually needed because ownership alone is fragile

If a key has exactly one owner and that owner disappears, the mapping/data becomes unavailable.

DHT-based systems therefore commonly replicate values or metadata across several nearby/selected peers.

Possible policy:

```text
primary owner + next r successors
```

or another placement rule.

This reconnects to Chapter 9:

- how many copies?
- synchronous or asynchronous?
- what consistency?
- how are conflicting versions reconciled?

A DHT answers **where** data should be found. It does not automatically answer the full consistency problem.

---

## 13. Kademlia uses XOR distance rather than a ring-successor relation

Kademlia maps node and key identifiers into the same space but defines distance using bitwise XOR:

```text
d(a,b) = a XOR b
```

This creates useful prefix/bucket structure.

A node stores contacts grouped by distance ranges and performs iterative/parallel searches toward IDs progressively closer to the target.

The details differ from Chord, but the high-level goal is similar:

> route toward an identifier using only partial membership knowledge.

Kademlia is especially influential in real peer-to-peer discovery/content systems.

The course does not require implementing both Chord and Kademlia.

You should understand the contrast between:

```text
Chord-style ring/range ownership
```

and:

```text
Kademlia-style XOR metric/buckets
```

---

## 14. DHT routing is not ordinary IP routing

IP routing decides how packets move toward a network address.

DHT routing decides which application peer is responsible for a logical key and which known peer should receive the next application-level query.

A DHT lookup like:

```text
peer 10 → peer 35 → peer 52
```

may correspond physically to:

```text
host A → many Internet routers → host B
host B → many Internet routers → host C
```

This course intentionally connects the Network course to Distributed Systems here.

---

## 15. Routing correctness and routing efficiency are separate properties

A lookup algorithm may always find the right owner but require O(N) hops.

Another may usually use O(log N) hops but temporarily fail under stale routing state.

Therefore evaluate:

```text
correct-owner rate
lookup success rate
hop count
latency
maintenance traffic
```

separately.

Do not reduce evaluation to a single average lookup time.

---

## 16. Gossip solves dissemination rather than exact lookup

Now change the problem.

Suppose every node wants approximate/current membership information:

```text
who is alive?
what version/configuration do peers know?
which nodes have recently joined?
```

A DHT lookup structure may be unnecessary.

A gossip protocol uses repeated peer-to-peer exchanges.

A simple push model:

```text
every interval:
    choose random peer
    send new information
```

Over repeated rounds, information spreads through the population similarly to an epidemic.

---

## 17. Push, pull, and push-pull gossip

### Push

A node sends information it knows to another peer.

### Pull

A node asks a peer for information it is missing.

### Push-pull

Both exchange summaries/updates.

Different variants trade bandwidth, convergence speed, and duplicate traffic.

The central property is probabilistic dissemination rather than one exact routing path.

---

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosity</span>
  <strong>Gossip works partly because nobody has to know the exact same membership view at the exact same time</strong>
  <p>Epidemic dissemination accepts temporary disagreement and uses repeated peer exchange to spread information. This weak synchronization can scale better than requiring one central, immediately authoritative membership table for every change.</p>
  <p><strong>Try it:</strong> Simulate one membership update spreading through eight nodes when each informed node contacts one random peer per round.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">More chapter curiosities →</a>
</aside>

## 18. Gossip convergence is probabilistic and measurable

Suppose one node learns event `E` at round 0.

Track:

```text
round 0: 1 informed node
round 1: 2
round 2: 4
...
```

Collisions and repeated contacts mean the count will not simply double forever.

Measure:

- rounds until 50% informed;
- rounds until 90%;
- rounds until all reachable nodes informed;
- messages sent;
- effect of fanout;
- effect of loss.

This is an excellent lab because the result is statistical/probabilistic rather than one deterministic trace.

---

## 19. Gossip naturally tolerates some message loss

If update E is sent only once through one path, loss may permanently remove it.

Gossip repeatedly creates alternative dissemination paths.

A lost message delays convergence but does not necessarily destroy it.

This resilience comes with redundancy:

```text
many duplicate/overlapping exchanges
```

The system trades bandwidth for robustness and decentralized propagation.

---

## 20. Gossip can spread stale or incorrect information too

Decentralized dissemination does not make information true.

If one peer announces:

```text
node X is dead
```

other peers need a rule for whether and how to accept that claim.

Membership protocols therefore often attach:

- incarnation numbers;
- status transitions;
- timestamps/logical counters;
- suspicion phases;
- indirect probes.

This reconnects to Chapter 10 failure detectors.

---

## 21. SWIM combines failure detection with gossip-style membership dissemination

SWIM is a classic scalable membership design.

Its central architectural separation is useful pedagogically:

```text
failure detection
+
membership dissemination
```

A node probes another member. If direct communication fails, it may ask other peers to perform indirect probes before escalating suspicion.

Membership changes then disseminate through protocol traffic/gossip-like mechanisms.

The objective is scalable membership with bounded per-node overhead rather than every node pinging every other node continuously.

You do not need to reproduce the full SWIM protocol, but it is an excellent comparison for the lab's gossip membership option.

---

## 22. Suspicion improves the false-positive trade-off

Instead of moving directly:

```text
ALIVE → DEAD
```

on one timeout, a membership protocol may use:

```text
ALIVE → SUSPECT → DEAD
```

During SUSPECT, contrary evidence or a higher incarnation can refute the suspicion.

This does not create perfect failure detection.

It gives the protocol time/opportunity to correct uncertainty before removing membership.

---

## 23. Incarnation numbers distinguish old rumors from current process state

Suppose gossip contains:

```text
node A incarnation 7 = SUSPECT
```

but A has restarted/reasserted itself as:

```text
node A incarnation 8 = ALIVE
```

Peers need an ordering rule so the stale suspicion does not overwrite the newer incarnation.

This is the same stale-process problem introduced in Chapter 8/Chapter 10, now at decentralized scale.

---

## 24. Central registry, DHT, and gossip answer different questions well

### Central/replicated registry

Good when:

- authoritative membership is important;
- central operational control is acceptable;
- queries need rich metadata/filtering;
- cluster scale is moderate.

### DHT

Good when:

- key-based placement/lookup is central;
- no full membership table should be required everywhere;
- decentralized routing is desired;
- churn must be handled structurally.

### Gossip membership

Good when:

- approximate/eventually convergent membership/state dissemination is acceptable;
- every change need not go through one authority;
- scalable failure/member information is important.

A system may combine them.

For example:

```text
gossip discovers live nodes
+
DHT routes keys
+
replication stores values
```

---

## 25. Decentralized does not mean coordination-free

Even decentralized systems need rules for:

- identity;
- membership conflicts;
- key ownership;
- replica reconciliation;
- malicious peers;
- software versioning.

Removing one central server distributes those responsibilities; it does not eliminate them.

This is why decentralized designs can be operationally harder even when they avoid one central bottleneck.

---

## 26. Bootstrap is an unavoidable practical question

How does a brand-new peer discover its first peer?

Possible answers:

- configured seed list;
- DNS seeds;
- local multicast;
- previously cached peers;
- manual invitation;
- well-known bootstrap service.

A bootstrap service can be centralized without remaining on the critical path after joining.

You should distinguish:

```text
bootstrap dependency
```

from:

```text
per-operation central dependency
```

---

## 27. Worked example — DHT join

Initial ring:

```text
10 → 40 → 70 → 10
```

Node 25 joins.

Before:

```text
(10,40] owned by 40
```

After:

```text
(10,25] owned by 25
(25,40] owned by 40
```

Required actions may include:

1. 25 discovers an existing peer;
2. 25 finds its successor 40;
3. predecessor/successor relations update;
4. relevant key range transfers or becomes available at 25;
5. routing tables converge over stabilization rounds.

During transition, some peers may still route according to the old topology.

A correct design must define how these stale routes are handled.

---

## 28. Worked example — gossip membership under loss

Ten nodes begin with one update `E` known only by node A.

Fanout = 1 per round.

Now introduce 20% message loss.

A single broadcast tree could lose E along an essential branch.

Repeated randomized gossip creates new opportunities each round.

The experiment should not expect an identical sequence every run.

Instead report a distribution:

```text
median rounds to 90%
p95 rounds to 90%
total messages
```

with a fixed random seed available for deterministic debugging.

---

## 29. Worked example — false suspicion and refutation

Nodes A, B, C.

B cannot directly reach A due to transient loss.

B marks A SUSPECT and gossips:

```text
A incarnation 5 SUSPECT
```

A receives/refutes the suspicion by announcing:

```text
A incarnation 6 ALIVE
```

Peers compare incarnation information and keep the newer status.

This example connects:

- timeout uncertainty;
- logical incarnation ordering;
- gossip propagation;
- recovery from false suspicion.

---

## 30. Security becomes harder when membership is decentralized

A centralized registry can enforce admission at one boundary.

A peer-to-peer overlay must consider:

- forged node IDs;
- Sybil identities;
- malicious routing responses;
- poisoned membership rumors;
- content corruption;
- eclipse attacks.

Chapter 12 addresses adversarial/Byzantine behavior more directly.

For Chapter 5, you need only state the trust assumption:

> Are all peers assumed non-malicious but crash-prone, or can peers lie?

The basic lab assumes crash/omission faults, not Byzantine adversaries.

---

## 31. The historical course's DHT emphasis becomes one option rather than the whole decentralized story

The previous course material devoted substantial attention to Chord, Pastry, and Kademlia-style DHT structures.

Those ideas remain valuable because they teach:

- structured overlays;
- partial routing tables;
- logarithmic lookup reasoning;
- churn;
- decentralized ownership.

The redesigned course reduces algorithm taxonomy and asks you to connect DHTs to a wider design space:

```text
central registry
DHT
consistent-hash ownership map
gossip membership
replicated directory
```

The goal is architectural choice, not memorizing every historical overlay.

---

## 32. Final-project examples

### P05 — Peer-to-Peer Chunked File Distribution

A DHT can locate file/chunk metadata without a permanent central tracker. Gossip can spread peer availability or swarm information.

### P06 — Distributed Agent and Capability Platform

A DHT could locate agents/capabilities by key, while gossip could spread approximate membership. A central registry remains a valid alternative if stronger authority/filtering is desired.

### P08 — Decentralized Secure Messaging

Peer discovery and store-and-forward routing may benefit from decentralized membership/lookup, but identity/authentication complicate the trust model.

### P16 — Distributed Object Storage

Consistent-hash/DHT-style placement can determine object ownership and rebalancing.

### P20 — Edge Content Cache

Gossip may disseminate cache/member status, while consistent hashing can place cache responsibility.

---

## 33. AI-assisted implementation: what to verify

Agents can easily generate a ring or gossip loop that works in a static demo.

The important tests are around change.

For a DHT implementation, verify:

- correct owner after join;
- correct owner after graceful leave;
- lookup under stale routing entries;
- failure of an intermediate peer;
- hop-count behavior as N grows;
- data/metadata movement after ownership change.

For gossip, verify:

- eventual propagation with a fixed seed;
- statistical convergence over many runs;
- loss effects;
- false suspicion/refutation;
- incarnation ordering;
- bounded per-node message rate.

A generated implementation that passes only a static five-node happy path has not demonstrated the chapter's objectives.

---

## 34. Common mistakes

### Mistake 1 — confuse overlay hops with physical network hops

They are different layers.

### Mistake 2 — assume consistent hashing itself performs routing

Placement and routing are related but distinct mechanisms.

### Mistake 3 — implement only static DHT lookup

Joins, departures, stale routes, and churn are where distributed behavior appears.

### Mistake 4 — call DHT replication “consistent” without defining a model

DHT ownership does not solve replica consistency.

### Mistake 5 — use gossip when exact current membership is required immediately

Gossip naturally exposes eventual/probabilistic knowledge.

### Mistake 6 — declare a peer DEAD on one timeout

Transient delay/loss creates false suspicion.

### Mistake 7 — ignore process incarnation

Old failure rumors can incorrectly kill a restarted peer.

### Mistake 8 — benchmark one deterministic gossip run

Randomized dissemination should be evaluated statistically as well as with reproducible seeds.

### Mistake 9 — say “decentralized means no central components anywhere”

Bootstrap, identity, administration, or trust roots may still be centralized.

### Mistake 10 — choose DHT/gossip because they sound advanced

A replicated registry may be simpler and more correct for a small controlled cluster.

---

## Laboratory transition

The laboratory has a common comparison plus two implementation tracks.

Every student must:

1. model a central registry baseline;
2. compare its assumptions with decentralized alternatives;
3. implement either a small structured DHT **or** gossip membership;
4. introduce joins/departures/loss/churn;
5. measure lookup cost or convergence cost;
6. explain stale-state behavior;
7. state the trust model.

### Track A — DHT

Build a small ring/structured overlay with:

- stable node IDs;
- lookup;
- join;
- departure/failure handling;
- basic stabilization;
- optional replication.

### Track B — Gossip membership

Build:

- peer sampling;
- ALIVE/SUSPECT/DEAD-style status;
- incarnation/version ordering;
- repeated dissemination;
- configurable fanout/loss;
- convergence metrics.

The target is not a production P2P network.

The target is to understand the trade:

```text
central authority and direct lookup
        versus
partial decentralized knowledge and ongoing maintenance
```

---

## Chapter summary

Decentralized systems replace one complete directory with distributed partial knowledge.

DHTs structure that partial knowledge so key lookup can progress toward an owner efficiently.

Gossip spreads membership/state probabilistically through repeated peer exchanges.

Both introduce new costs:

```text
stale state
maintenance traffic
churn handling
bootstrap
failure suspicion
security/trust complexity
```

They are not automatically better than a registry.

The correct design depends on which property the application actually needs:

> **exact authoritative lookup, structured decentralized key routing, or scalable eventual dissemination.**

Chapter 9 now asks a related but different question: if replicas update independently while disconnected, can the *data itself* be designed to converge without coordinating every write?

<div class="ds-next-action">
  <span>Core reading complete</span>
  <strong>Next required step · Guided practice</strong>
  <a href="../guided-practice/">Start guided practice →</a>
</div>
