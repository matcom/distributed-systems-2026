"""Choice-based deterministic contract for M12.

Set TRACK to "dht" or "gossip". Public tests for the other track are skipped.
The network/process implementation remains the student's design.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List

TRACK = None  # TODO: choose "dht" or "gossip"
RING_SIZE = 256


@dataclass(frozen=True)
class Node:
    node_id: int
    endpoint: str
    incarnation: int = 1


def ring_owner(node_ids: Iterable[int], key_id: int, ring_size: int = RING_SIZE) -> int:
    """Return the first clockwise node >= key_id, wrapping at ring end."""
    raise NotImplementedError("TODO: implement first-successor ownership")


def clockwise_distance(start: int, end: int, ring_size: int = RING_SIZE) -> int:
    raise NotImplementedError("TODO: implement ring distance")


def route_progress(current: int, next_hop: int, target: int, ring_size: int = RING_SIZE) -> bool:
    """Return whether next_hop is strictly closer clockwise to target than current."""
    raise NotImplementedError("TODO: implement routing-progress predicate")


@dataclass(frozen=True)
class MembershipRecord:
    node_id: str
    incarnation: int
    status: str  # ALIVE, SUSPECT, DEAD


def merge_membership(records: Iterable[MembershipRecord]) -> Dict[str, MembershipRecord]:
    """Merge records deterministically.

    Higher incarnation wins. Within one incarnation use ALIVE < SUSPECT < DEAD
    as the declared status precedence for this exercise.
    """
    raise NotImplementedError("TODO: implement deterministic membership merge")


def disseminate(initial_views: Dict[str, Dict[str, MembershipRecord]], exchanges: List[tuple[str, str]]):
    """Apply deterministic pairwise gossip exchanges and return final views."""
    raise NotImplementedError("TODO: merge both participants on every exchange")
