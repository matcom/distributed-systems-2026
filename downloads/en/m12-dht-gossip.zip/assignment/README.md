# Laboratory — DHTs, Gossip, and Decentralized Systems

## Target

Compare centralized discovery with decentralized partial knowledge, then implement and evaluate **one** of two tracks:

- **Track A — structured DHT lookup/placement**, or
- **Track B — gossip membership/dissemination**.

This lab is Ray-free.

## Main question

> What information can each node know locally, how does that information become stale, and what maintenance work is required so the system still delivers information, locates peers/data, or converges membership under churn?

## Required Part 0 — compare communication semantics

Before choosing a decentralized track, trace the same logical update through two communication models.

### Direct request/response

Use a small local request/response path:

```text
producer → receiver → response
```

Record what the producer knows after a successful response and what becomes ambiguous after a timeout.

### Asynchronous delivery

Model or implement a minimal local queue/mailbox:

```text
producer → durable/pending message → consumer → acknowledgement
```

You do not need RabbitMQ, Kafka, or any hosted broker. A small local process or provided starter abstraction is enough.

Create this execution:

1. producer submits message 81;
2. consumer receives and applies it;
3. consumer stops before acknowledging;
4. message 81 is delivered again.

Before running it, predict whether the application effect will happen once or twice.

Record:

- message ID;
- delivery attempts;
- acknowledgement state;
- application-state transitions.

Then make repeated delivery safe with an idempotent operation or explicit duplicate suppression.

Finish Part 0 by comparing:

| Question | Request/response | Asynchronous delivery |
|---|---|---|
| sender waits for | | |
| destination known at send time | | |
| pending work stored by | | |
| timeout ambiguity | | |
| duplicate/redelivery risk | | |
| natural fan-out | | |

The rest of the lab asks how communication works when knowledge of membership or destination is itself distributed.

## Common baseline — registry model

Before either implementation track, model the same discovery problem using an Chapter 8-style registry.

For example:

```text
REGISTER(node, endpoint, metadata)
LOOKUP(key/capability/node)
HEARTBEAT/lease
```

You do not need to rebuild the complete Chapter 8 lab. Use it as a comparison architecture.

Record:

- who holds complete membership;
- lookup message path;
- failure dependency;
- stale-entry policy;
- per-membership-change communication.

Then explain what your decentralized track removes and what new maintenance it introduces.

---

# Track A — Structured DHT

## A1. Identifier space

Choose a small deterministic identifier space suitable for local tests.

Example:

```text
0..255
```

Assign stable logical IDs to nodes and hash/map keys into the same space.

Keep separate fields for:

```text
node_id
network endpoint
incarnation
```

## A2. Ownership rule

Define exactly which node owns key identifier `k`.

A sufficient Chord-like rule is:

> first live successor clockwise from `k`.

Write tests for boundary cases, including keys equal to node IDs and wrap-around near zero.

## A3. Static lookup baseline

Start with at least 8 nodes.

First implement correct lookup using minimal successor knowledge if useful.

Measure:

```text
lookup success rate
mean/median overlay hops
p95 overlay hops
```

for a fixed set of lookups.

## A4. Routing shortcuts

Add Chord-style finger/shortcut entries or another documented structured routing table.

Repeat the same lookups.

Compare hop count, not only wall-clock latency.

Explain why fewer overlay hops may still map to arbitrary physical Internet paths in a real deployment.

## A5. Node join

Add one node between two existing identifiers.

Demonstrate:

- predecessor/successor update;
- ownership-range change;
- key/metadata movement if implemented;
- temporary stale routing entries;
- stabilization/convergence.

Record how many maintenance messages were required.

## A6. Graceful leave

Remove one node with notification/state handoff.

Verify affected keys remain locatable according to the declared policy.

## A7. Crash departure

Kill a node without graceful handoff.

Use timeout/suspicion and successor/routing redundancy as appropriate.

Required evidence:

```text
failure occurs
first peer suspects
routing/ownership repair begins
lookups recover
```

Do not claim perfect crash detection.

## A8. Stale route experiment

Freeze one node's routing table while the topology changes elsewhere.

Run lookups through it.

Classify outcomes:

- successful via stale-but-correct forwarding;
- redirect/repair;
- temporary failure;
- incorrect owner.

The final category is a correctness defect unless the protocol's transient semantics explicitly permit it and repair it without violating stored-state guarantees.

## A9. Churn experiment

Run a deterministic sequence of joins/leaves/crashes while issuing lookups.

Measure:

```text
lookup success rate during churn
hop-count distribution
maintenance messages
recovery/stabilization time
```

Use a fixed seed if membership events are randomized.

## A10. Optional replication extension

Replicate each key/value/location record to one or more additional owners.

If attempted, state the consistency model. Do not write “replicated therefore consistent.”

---

# Track B — Gossip Membership

## B1. Initial membership

Start at least 10 local peer processes or simulated nodes from a small bootstrap seed list.

Each node maintains a local membership view such as:

```text
node_id
incarnation
status
endpoint
last evidence
```

## B2. Gossip dissemination

Implement configurable:

```text
round interval
fanout
random seed
```

Use push, pull, or push-pull; document the choice.

Introduce one update known initially by one node.

Track number/percentage of informed nodes per round.

## B3. Convergence baseline

Run the same experiment across multiple random seeds.

Report at least:

```text
median rounds to 50%
median rounds to 90%
p95 rounds to 90% or equivalent
total messages
```

Do not evaluate probabilistic dissemination using only one run.

## B4. Message loss

Inject configurable loss into gossip exchanges.

Repeat the convergence experiment.

Explain how repeated dissemination provides alternative paths and what extra message cost pays for this resilience.

## B5. Member failure

Stop one member.

Implement a failure-detector path appropriate to the reduced lab, for example:

```text
ALIVE → SUSPECT → DEAD
```

A direct timeout should create suspicion rather than unquestioned ground truth.

## B6. Indirect evidence

Where practical, ask one or more other peers to probe a suspected target before escalating.

Compare false-suspicion behavior with direct-only probing.

## B7. Incarnation refutation

Create:

```text
node A incarnation 7 = SUSPECT
```

then let A reassert/restart as:

```text
node A incarnation 8 = ALIVE
```

Verify stale incarnation-7 rumors cannot overwrite incarnation 8.

## B8. Partition and heal

Split membership into two reachable groups.

Allow local membership views to evolve.

Heal the partition and observe convergence.

The report must show that different nodes can legitimately hold different membership views during the partition.

## B9. Churn experiment

Repeatedly join/restart/stop nodes while gossip runs.

Measure:

```text
membership convergence lag
messages per node/time unit
false suspicions
recovery/refutation time
```

## B10. Optional payload extension

Gossip one additional small metadata item such as:

- load estimate;
- capability;
- software version;
- cache presence.

State whether this metadata is authoritative or approximate.

---

# Common Step C1 — Compare registry, DHT, and gossip

Every submission must complete this table using evidence and architecture reasoning:

| Property | Registry | DHT | Gossip |
|---|---|---|---|
| exact key lookup | | | |
| rich metadata query | | | |
| full membership at one node | | | |
| central runtime dependency | | | |
| churn maintenance | | | |
| stale-state behavior | | | |
| failure detection model | | | |
| per-node state | | | |

Your implemented track should be discussed in more detail than the two comparison-only designs.

---

# Common Step C2 — Trust model

State whether nodes are assumed:

```text
correct except crash/omission
```

or whether malicious behavior is in scope.

The required lab assumes non-Byzantine peers.

Explain one attack that would become possible if a peer could lie about:

- identity;
- ownership/routing;
- membership status.

Chapter 12 will address that stronger failure model.

---

# Common Step C3 — AI audit

If an AI assistant contributed, ask it to identify one weakness under membership change.

For DHT track, inspect for:

- static-only routing;
- stale endpoint reuse;
- incorrect wrap-around ownership;
- join that moves no data/metadata;
- crash treated like graceful leave.

For gossip track, inspect for:

- one timeout directly marks DEAD;
- stale rumors overwrite newer incarnations;
- unbounded message fanout;
- one run treated as convergence proof;
- all local views assumed identical at every instant.

Verify one finding experimentally.

---

# Transparent-test target

The intended public tests are documented under:

```text
tests/official/README.md
```

Executable public tests now live under `tests/official/`, with a choice-based DHT/gossip adapter in `starter/src/`. You select one track explicitly; deterministic ownership/merge invariants are tested while multi-process churn, loss, and convergence remain evidence-based.

No hidden cases are planned.

You add deterministic cases under `tests/student/` and may add statistical experiment scripts separately.

---

# Submission

Submit:

- source code;
- track declaration;
- topology/bootstrap configuration;
- reproducible commands;
- `REPORT.md`;
- machine-readable lookup/gossip traces;
- measurement data;
- public/student test descriptions/cases;
- AI-use disclosure.

# Success criterion

A strong submission can say either:

> “This structured overlay finds the correct owner using bounded partial routing state, repairs membership/ownership under the tested churn events, and exhibits this measured lookup/maintenance cost.”

or:

> “This gossip membership protocol converges probabilistically under the tested loss/churn model, distinguishes suspicion from truth, rejects stale incarnations, and exhibits this measured convergence/message cost.”

In both cases, you must explain why a simpler registry would or would not be preferable for the same problem.