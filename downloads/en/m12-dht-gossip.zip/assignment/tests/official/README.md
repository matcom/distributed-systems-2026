# Planned Public Tests — M12 DHTs, Gossip, and Decentralized Systems

These cases define the intended transparent test surface. No hidden cases are planned.

Executable public tests are provided in this directory together with the choice-based starter adapter under `starter/src/`. Students declare either the DHT or gossip track; public tests for the unselected track are skipped while track selection itself is mandatory. Multi-process churn/convergence experiments remain evidence-based.

# Common tests

## C1 — stable logical identity fields

Verify node logical ID is not implicitly replaced by endpoint/port and that an incarnation/version field can distinguish restarted process state where the implementation uses one.

## C2 — deterministic bootstrap/config parsing

Given fixed configuration and seed, nodes start with the expected initial peers/topology.

---

# Track A — DHT tests

## A1 — ownership boundaries

Known keys map to the correct first-successor/declared owner, including wrap-around and equality boundaries.

## A2 — static lookup correctness

Every known key lookup reaches the declared owner in a stable topology.

## A3 — routing progress

For structured shortcuts, each forwarding step must make progress under the declared metric/ring rule and terminate rather than loop indefinitely.

## A4 — join changes ownership correctly

After adding a node, only the expected ownership interval moves under the chosen placement rule.

## A5 — graceful leave preserves lookup

After a planned departure/state handoff, affected keys remain locatable.

## A6 — crash does not equal graceful leave

The implementation must require detection/repair rather than assuming departure notification occurred.

## A7 — stale route behavior

A stale routing entry must not cause an infinite loop or silently return a known-wrong authoritative owner after the topology has converged.

## A8 — churn convergence

After a deterministic join/leave sequence and sufficient stabilization, all tested keys resolve to the expected current owners.

## A9 — routing metrics

Lookup tracing exposes overlay hop count so efficiency can be measured independently of wall-clock timing.

---

# Track B — Gossip tests

## B1 — one update disseminates

With a fixed no-loss seed and sufficient rounds, one initial update reaches every reachable member.

## B2 — membership merge is deterministic

Given the same set of membership records, merge order does not produce contradictory final status under the declared version/incarnation rule.

## B3 — newer incarnation wins

An ALIVE record with a higher incarnation/version must not be overwritten by an older SUSPECT/DEAD rumor.

## B4 — one timeout does not bypass declared suspicion policy

Where the track specifies ALIVE→SUSPECT→DEAD, a single direct timeout must not jump directly to irreversible DEAD without the declared conditions.

## B5 — loss delays rather than deterministically destroys dissemination

With a fixed seed/loss schedule that still leaves successful later exchanges, updates eventually propagate according to the experiment's configured horizon.

## B6 — partitioned views may differ

During a partition, local membership views are allowed to diverge; the test verifies the implementation does not assume one instantly shared membership table.

## B7 — heal converges

After communication resumes and sufficient rounds pass, membership versions/statuses converge under the merge rule.

## B8 — message accounting

The implementation exposes enough counters/logs to measure per-round/per-node gossip traffic.

---

# Student extensions

Useful additions include:

- DHT wrap-around corner cases;
- failed intermediate lookup peer;
- repeated joins at nearby IDs;
- fixed-seed churn simulation;
- gossip fanout 1 vs 3;
- several loss rates;
- repeated false suspicion/refutation;
- stale incarnation arriving after restart;
- bootstrap peer failure after initial join.

Statistical performance/convergence claims should be evaluated by experiment scripts in addition to deterministic unit cases.