import unittest

import decentralized as impl
from decentralized import MembershipRecord


class TrackSelectionTests(unittest.TestCase):
    def test_track_is_declared(self):
        self.assertIn(impl.TRACK, {"dht", "gossip"})


@unittest.skipUnless(impl.TRACK == "dht", "DHT track not selected")
class DhtTrackTests(unittest.TestCase):
    def test_first_successor_and_wraparound(self):
        nodes = [10, 80, 200]
        self.assertEqual(impl.ring_owner(nodes, 10), 10)
        self.assertEqual(impl.ring_owner(nodes, 11), 80)
        self.assertEqual(impl.ring_owner(nodes, 201), 10)

    def test_join_moves_only_expected_interval(self):
        before = [10, 200]
        after = [10, 80, 200]
        moved = [key for key in range(256) if impl.ring_owner(before, key) != impl.ring_owner(after, key)]
        self.assertTrue(moved)
        self.assertTrue(all(11 <= key <= 80 for key in moved))

    def test_clockwise_distance_wraps(self):
        self.assertEqual(impl.clockwise_distance(250, 10), 16)
        self.assertEqual(impl.clockwise_distance(10, 80), 70)

    def test_route_progress_requires_strict_improvement(self):
        self.assertTrue(impl.route_progress(10, 80, 200))
        self.assertFalse(impl.route_progress(10, 10, 200))


@unittest.skipUnless(impl.TRACK == "gossip", "Gossip track not selected")
class GossipTrackTests(unittest.TestCase):
    def test_newer_incarnation_wins(self):
        merged = impl.merge_membership([
            MembershipRecord("n1", 1, "DEAD"),
            MembershipRecord("n1", 2, "ALIVE"),
        ])
        self.assertEqual(merged["n1"], MembershipRecord("n1", 2, "ALIVE"))

    def test_same_incarnation_status_precedence_is_deterministic(self):
        records = [
            MembershipRecord("n1", 3, "ALIVE"),
            MembershipRecord("n1", 3, "SUSPECT"),
        ]
        self.assertEqual(impl.merge_membership(records), impl.merge_membership(reversed(records)))
        self.assertEqual(impl.merge_membership(records)["n1"].status, "SUSPECT")

    def test_deterministic_exchange_disseminates_update(self):
        alive = MembershipRecord("n1", 1, "ALIVE")
        views = {"a": {"n1": alive}, "b": {}, "c": {}}
        final = impl.disseminate(views, [("a", "b"), ("b", "c")])
        self.assertEqual(final["c"]["n1"], alive)

    def test_partitioned_views_need_not_be_identical_before_exchange(self):
        alive = MembershipRecord("n1", 1, "ALIVE")
        views = {"a": {"n1": alive}, "b": {}}
        final = impl.disseminate(views, [])
        self.assertNotEqual(final["a"], final["b"])


if __name__ == "__main__":
    unittest.main()
