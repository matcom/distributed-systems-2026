# Laboratory Report — DHTs, Gossip, and Decentralized Systems

## 1. Environment

Document:

- OS/platform;
- language/runtime version;
- node/process count;
- selected implementation track;
- bootstrap configuration;
- exact startup/teardown commands;
- random-seed handling if applicable.

## 2. Registry baseline

Describe the equivalent centralized/replicated registry design.

State:

- who owns complete membership/index state;
- lookup path;
- stale-entry behavior;
- failure dependency;
- membership maintenance cost.

## 3. Decentralization scope

For your implementation, classify whether each is centralized or decentralized:

- bootstrap;
- identity;
- membership;
- routing;
- placement;
- data/state storage;
- trust/admission.

Avoid using “decentralized” as one undifferentiated label.

---

# Track A report — DHT

## A1. Identifier and ownership model

Document:

- identifier space;
- node-ID rule;
- key-ID rule;
- ownership rule;
- node ID / endpoint / incarnation separation.

## A2. Static lookup

Report:

```text
node count
lookup count
lookup success rate
median overlay hops
p95 overlay hops
```

Include at least one traced lookup.

## A3. Routing-table design

Describe successor/finger/bucket/shortcut state.

Compare lookup cost before/after shortcuts if implemented incrementally.

## A4. Join

Document:

- joining ID;
- changed predecessor/successor relationships;
- moved ownership range;
- transferred key/metadata state;
- stale routes observed;
- stabilization duration/messages.

## A5. Graceful leave vs crash

Compare the two executions and state why crash recovery requires suspicion/redundancy rather than notification.

## A6. Stale-route experiment

Provide:

- stale table state;
- lookup target;
- actual owner;
- routing trace;
- final result;
- repair behavior.

## A7. Churn measurements

Report:

- membership event sequence;
- lookup success during churn;
- hop-count distribution;
- maintenance-message count;
- stabilization/recovery intervals.

## A8. Replication extension, if implemented

State placement and consistency semantics separately.

---

# Track B report — Gossip

## B1. Membership record

Document fields such as:

```text
node_id
incarnation
status
endpoint
```

and the merge/precedence rule.

## B2. Dissemination algorithm

State:

- push/pull/push-pull;
- fanout;
- round interval;
- peer-selection policy;
- random seed.

## B3. Baseline convergence

Across multiple runs report:

```text
rounds to 50%
rounds to 90%
rounds to full reachable convergence
messages sent
```

Use median/p95 or another justified distribution summary.

## B4. Loss experiment

Record loss rate and compare convergence/message cost with baseline.

## B5. Failure suspicion

Show:

```text
ALIVE → SUSPECT → DEAD
```

or the equivalent model.

Document direct/indirect evidence used.

## B6. Incarnation refutation

Provide one trace where a newer ALIVE incarnation defeats an older SUSPECT/DEAD rumor.

## B7. Partition/heal

Compare local membership views during partition and after healing.

## B8. Churn measurements

Report:

- membership changes;
- convergence lag;
- false suspicions;
- messages per node/time interval;
- recovery/refutation time.

---

# Common analysis

## 4. Registry vs DHT vs gossip

Complete:

| Property | Registry | DHT | Gossip |
|---|---|---|---|
| exact lookup | | | |
| rich query | | | |
| central runtime dependency | | | |
| per-node state | | | |
| stale-state behavior | | | |
| churn handling | | | |
| maintenance traffic | | | |
| authoritative membership | | | |

## 5. Overlay vs physical network

Explain why measured overlay hop count is not equal to IP-router hop count.

## 6. Failure model

State what peers are allowed to do:

- crash;
- omit messages;
- restart;
- become partitioned;
- behave maliciously or not.

## 7. Trust boundary

Describe one failure/attack that the crash-fault design would not handle if peers could lie.

## 8. AI-use disclosure

Record:

- tools used;
- tasks delegated;
- algorithm code affected;
- experiments used to verify generated suggestions;
- at least one AI suggestion corrected/rejected/tested.

## 9. Limits

State what the experiment does not prove, including production Internet latency, Internet-scale churn, Byzantine resistance, or global performance if all peers run on one host.

## 10. Final technical claim

Write one paragraph answering:

> Why is the selected decentralized mechanism appropriate for this lookup/membership problem, how does it behave when knowledge becomes stale, and what measured maintenance/convergence cost does it introduce?