<p class="ds-book-part">Part I — Foundations and Architecture</p>
<p class="ds-module-kicker">Chapter 2</p>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 2 of 12</span>
    <span>17% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 17%"></span></div>
</div>
<p class="ds-guiding-question">Where should distributed responsibilities live, and what does middleware decide for you?</p>

Compare client/server, layered, service-oriented, event-driven, peer-to-peer, and hybrid structures before you depend on a framework. Then use Ray as a concrete middleware example: build something productive quickly and map every capability the runtime supplies on your behalf.

## Key ideas

- architectural responsibility and placement
- client/server and multi-tier systems
- service-oriented and event-driven structure
- peer-to-peer and hybrid designs
- middleware as an abstraction boundary
- Ray tasks, actors, object references, scheduling, and retries
- middleware dependency maps

## Laboratory transition

Convert a small sequential worker program into Ray tasks/actors. Kill workers, observe the result, and record which architectural responsibilities belong to your application and which belong to the runtime.

## Start here

> **Before you read:** Two systems expose the same API: one client/server service and one peer-to-peer design. Which responsibilities must move when there is no permanent server?

**Bring forward:** The failure boundaries from Chapter 1 and the idea that components communicate through explicit interfaces.

**This chapter builds toward:** The ability to see architecture and middleware as explicit allocations of responsibility rather than framework magic.

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>40 min–55 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>45 min–1 h</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>1 h 30 min–2 h · 6 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Read lesson →</a>
  <a class="ds-secondary-action" href="lab/">Open laboratory</a>
</div>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../downloads/en/m02-ray-middleware.zip" download>Download chapter + laboratory for offline study (.zip)</a></p>

## What you will learn

- Compare client/server, layered, service-oriented, event-driven, peer-to-peer, and hybrid responsibility placement.
- Use Ray tasks and actors to distribute a small workload without treating the runtime as magic.
- Distinguish application responsibilities from middleware scheduling, communication, object, and failure responsibilities.
- Observe scheduling and failure behavior rather than assuming it.
- Produce an architecture and middleware dependency map that can guide a later native redesign.

## Learn by working the question

1. Write your answer to **Start here** before opening the full lesson.
2. Read until the next prediction or trace, then stop and work it out before revealing the explanation.
3. Treat guided practice as a **practice bank**, not a speed worksheet. Work the core traces until you can meet the chapter's Practice target; return to the remaining cases for retrieval practice or instructor-assigned work.
4. Use the knowledge check to find gaps, then enter the laboratory with a falsifiable prediction and name the evidence that could contradict it.
5. Finish by explaining what the experiment established, what it did not establish, and how the result changes the evolving service.

<nav class="ds-sequence" aria-label="Course sequence">
<a class="ds-sequence-link" href="../m01-distributed-systems/">← Thinking in Distributed Systems</a>
<a class="ds-sequence-link next" href="../m05-processes-concurrency/">Processes, Virtualization, and Distributed Execution →</a>
</nav>
