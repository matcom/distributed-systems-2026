<p class="ds-book-part">Part I — Foundations and Architecture</p>
<div class="ds-lesson-banner">
  <div><span>Course step</span><strong>Chapter 2</strong></div>
  <div><span>Core reading</span><strong>40 min–55 min</strong></div>
  <div><span>Required path</span><strong>Read → Practice target → Check → Lab</strong></div>
</div>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 2 of 12</span>
    <span>17% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 17%"></span></div>
</div>

> **Guiding question:** Where should distributed responsibilities live, and what does middleware decide for you?

## Before you read

> Two systems expose the same API: one client/server service and one peer-to-peer design. Which responsibilities must move when there is no permanent server?

Write a short answer first. You are not expected to be correct yet; you need a prediction you can revise as the chapter gives you better models and evidence.

**Use what you already know:** The failure boundaries from Chapter 1 and the idea that components communicate through explicit interfaces.

## Workload map

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>40 min–55 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>45 min–1 h</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>1 h 30 min–2 h · 6 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../../downloads/en/m02-ray-middleware.zip" download>Download lesson + practice + lab for offline study (.zip)</a></p>

## Why this chapter matters

Before choosing a runtime, decide where responsibility belongs. A client/server design, a multi-tier service, an event-driven system, and a peer-to-peer overlay can expose similar application behavior while placing state, discovery, scheduling, and failure handling in very different places.

Use a simple architecture checklist throughout this chapter:

- who owns authoritative state;
- who initiates communication;
- who discovers whom;
- who schedules work;
- what can fail independently;
- which responsibility belongs to the application and which belongs to middleware.

Ray is the concrete middleware example, not the definition of distributed architecture.

## Architecture first: decide where responsibility lives

Before a framework hides anything, draw the system as responsibilities and channels.

### Client/server

A client initiates work and a service endpoint accepts it:

```text
client → service
```

This centralizes a **role**, not necessarily one machine. The service may have many replicas behind one logical name. The useful question is not “is there a server?” but “which component owns authoritative decisions for this operation?”

### Layered or multi-tier

A larger service may separate interface, coordination, and storage roles:

```text
client → API → worker/service layer → state
```

Each boundary can scale or fail differently. A layer is useful when it hides a coherent responsibility; it becomes harmful when it only adds another network hop without clarifying ownership.

### Event-driven

A producer may publish work or events without waiting for a particular consumer:

```text
producer → event/queue → consumer(s)
```

This changes timing and durability assumptions. The producer may finish before any consumer acts, so acknowledgement now means something different from an RPC response.

### Peer-to-peer

Peers may both request and provide work:

```text
peer A ↔ peer B ↔ peer C
```

Now discovery, placement, and membership can no longer be assumed to belong to one permanent service. Later chapters revisit this when studying dissemination and decentralized lookup.

### Hybrid systems are normal

Real systems combine these shapes. A peer-to-peer data plane may still use a centralized identity service. A microservice architecture may publish events but use synchronous RPC for some operations. Do not label the whole system with one architectural word and stop reasoning.

> **Pause and predict.** Your service needs dynamic workers, durable job state, and low-latency status queries. Which responsibility would you centralize first, and which could remain distributed without creating an unnecessary coordination problem?

Once the responsibility map is visible, middleware becomes easier to evaluate: you can ask exactly which boxes, channels, and policies the runtime is implementing for you.

Distributed systems contain a large amount of machinery before the application itself does anything useful:

- processes must exist somewhere;
- work must be scheduled;
- arguments must move to workers;
- results must be represented before they are locally available;
- stateful services need identities and lifecycles;
- failures need policies;
- resource requirements need placement decisions;
- evidence must be collected from several processes.

A distributed runtime can make much of this appear simple.

With Ray, an ordinary Python function can become a distributed task using a small syntactic change:

```python
import ray

@ray.remote
def square(x):
    return x * x

ref = square.remote(12)
result = ray.get(ref)
```

This convenience is exactly why Ray is useful in the course—and exactly why we remove it later.

Chapter 2 is not a course in the Ray ecosystem. We use **Ray Core** as a temporary microscope for distributed middleware. The goal is to experience the abstraction, inspect what it provides, and build a vocabulary for replacing only the required mechanisms later.

<aside class="ds-book-note ds-history">
  <span class="ds-book-note-label">History</span>
  <strong>RPC made distributed programs easier to write by hiding the network—and made failure semantics easier to forget</strong>
  <p>Remote procedure call turned messages into familiar-looking function calls, but timeouts, duplicate execution, retries, and partial failure ensured that a remote call could never truly behave like a local one.</p>
  <a class="ds-book-note-source" href="../../../history/rpc-transparency-and-failure/">Read the design history →</a>
</aside>

## 1. Middleware sits between application intent and distributed mechanisms

Suppose an application wants to say:

```text
run function F on available resources and give me the result later
```

Without middleware, the application might need to implement:

```text
worker discovery
      ↓
select endpoint
      ↓
serialize arguments
      ↓
send request
      ↓
track job identity
      ↓
worker executes
      ↓
store/serialize result
      ↓
handle crash or timeout
      ↓
retrieve result
```

Middleware gives the programmer a higher-level programming model.

The important distinction is:

```text
application abstraction ≠ underlying mechanism
```

Ray's API does not eliminate scheduling, networking, serialization, process management, data movement, or failure. It **takes responsibility for implementing policy and mechanism around those concerns**.

Keep asking one question:

> “What responsibility did I just delegate?”

## 3. Ray's core mental model

For this course, think in terms of five concepts:

```text
Driver / application process
          │
          ├── submits Tasks
          ├── creates Actors
          └── holds ObjectRefs
                    │
              Ray runtime
          ┌─────────┼─────────┐
          ▼         ▼         ▼
       worker     actor     worker
       process    process    process
          │         │         │
          └──── remote objects ────┘
```

### Driver

The Python program that initializes Ray and submits work.

### Task

An asynchronously executing remote function.

### Actor

A stateful worker associated with an instance of a remote class.

### ObjectRef

A reference to a remote result/object whose value may not yet be locally available.

### Runtime/cluster

The infrastructure that manages workers, scheduling, object data, process lifecycles, metadata, and failure behavior.

These are programming abstractions. Later in the course we will replace selected abstractions with explicit protocols and services.

## 4. A Ray task is not simply “call this IP address”

Consider:

```python
@ray.remote
def transform(x):
    return x + 1

ref = transform.remote(41)
```

The application did **not** specify:

- a worker address;
- a TCP connection;
- a serialization format;
- a request ID;
- a result endpoint;
- a scheduling queue;
- a retry loop.

Instead, the runtime receives a unit of work and schedules it.

Current Ray documentation describes tasks as asynchronous remote functions whose placement is chosen by the scheduler based on factors such as logical resource requirements, scheduling strategy, and locations of task arguments. ([Ray Tasks](https://docs.ray.io/en/latest/ray-core/tasks.html))

This gives us an important comparison:

```text
RPC:
client chooses a service endpoint and invokes an operation there

Ray task:
application submits work; runtime chooses where a suitable worker executes it
```

The boundaries can overlap in real systems, but the programming models emphasize different responsibilities.

## 5. `.remote()` changes both place and time

An ordinary call:

```python
value = transform(41)
```

is synchronous unless the function itself creates concurrency.

A Ray remote call:

```python
ref = transform.remote(41)
```

returns an `ObjectRef` rather than waiting for the function's value.

This changes the dependency graph.

Sequential code:

```text
call A
  ↓
wait for A
  ↓
call B
  ↓
wait for B
```

Remote submissions can express:

```text
submit A ─────┐
              ├─ execute concurrently
submit B ─────┘
       ↓
wait when value is actually needed
```

The speedup does not come from `@ray.remote` itself. It comes from exposing enough independent work for available resources to execute concurrently.

## 6. Object references are distributed futures

Ray's current documentation describes remote objects as values stored anywhere in the cluster and `ObjectRef`s as references/IDs used without immediately materializing the value locally. Remote objects are cached in a distributed shared-memory object store, with an object store on each node. ([Ray Objects](https://docs.ray.io/en/latest/ray-core/objects.html))

Think of:

```python
ref = work.remote(data)
```

as creating a dependency handle:

```text
ObjectRef
   │
   └── “the value produced by this remote work”
```

Only when code needs the concrete value might it use:

```python
value = ray.get(ref)
```

This distinction matters because a reference can move through a computation graph without the driver repeatedly receiving and resending the entire value.

### A common performance mistake

This code exposes concurrency:

```python
refs = [work.remote(x) for x in values]
results = ray.get(refs)
```

This code may accidentally serialize work:

```python
results = []
for x in values:
    results.append(ray.get(work.remote(x)))
```

The second pattern submits one task and waits before submitting the next.

> **Pause and predict.** If each task sleeps for one second and you have four available workers, how should the two patterns differ for four independent tasks?

The laboratory measures this rather than accepting the prediction on faith.

## 7. `ray.wait` exposes partial completion

Sometimes an application should not block until **all** results are ready.

A runtime can expose whichever tasks have completed and allow the application to continue consuming work incrementally.

Conceptually:

```text
refs = [A, B, C, D]

finished first: C
finished next:  A
still running:  B, D
```

This is useful for:

- streaming progress;
- speculative work;
- bounded in-flight requests;
- responding to the fastest available result;
- implementing backpressure at the application level.

The general distributed-systems lesson is broader than one Ray API:

> **A future/reference separates submission from completion.**

We will see the same idea in asynchronous RPC, queues, job IDs, and distributed workflow systems.

## 8. Data movement does not disappear because Python syntax is clean

Suppose `dataset` is hundreds of megabytes:

```python
ref = train.remote(dataset)
```

The worker needs access to the data somehow.

Ray may store or transfer object data through its object-management mechanisms, and placement decisions can consider where task arguments are located. ([Ray Tasks](https://docs.ray.io/en/latest/ray-core/tasks.html), [Ray Objects](https://docs.ray.io/en/latest/ray-core/objects.html))

The application code may not explicitly call `send()`.

But bytes still move.

This creates a valuable performance question:

```text
move computation to data?
        or
move data to computation?
```

That question reappears in:

- distributed databases;
- object stores;
- sharded search;
- machine-learning training;
- edge/CDN systems;
- final projects.

## 9. Actors make stateful workers explicit

A task is naturally modeled as a function over arguments.

Many applications need state that persists across multiple operations:

```python
@ray.remote
class Counter:
    def __init__(self):
        self.value = 0

    def increment(self):
        self.value += 1
        return self.value
```

Creating the actor:

```python
counter = Counter.remote()
```

creates a handle to a stateful remote worker.

Calls become:

```python
ref = counter.increment.remote()
```

Ray documentation describes an actor as a stateful worker/service: creating an actor starts a worker dedicated to that actor, and actor methods can access and mutate its local state. ([Ray Key Concepts](https://docs.ray.io/en/latest/ray-core/key-concepts.html))

This is a powerful abstraction because it maps naturally to many distributed roles:

- coordinator;
- worker registry;
- stateful model server;
- game participant;
- cache node;
- shard;
- scheduler.

But an actor also creates new questions.

## 10. Actor state is local state unless you make it durable or replicated

Consider the `Counter` actor above.

Where is `self.value`?

Inside the actor process's memory.

If the actor disappears and the runtime creates a fresh replacement, the value does not magically become durable application state unless the design explicitly preserves/reconstructs it.

This is one of the most important lessons of Chapter 2:

```text
stateful abstraction ≠ durable replicated state
```

Later, Phase 2 of the final project forces you to decide whether state should live in:

- one process memory;
- local disk;
- a replicated log;
- an object store;
- a sharded database;
- CRDT replicas;
- another explicit mechanism.

## 11. Actor serialization can hide a local synchronization policy

By default, a normal Ray actor is single-threaded for actor method execution; Ray also supports async actors and explicit concurrency mechanisms. ([Ray method API](https://docs.ray.io/en/latest/ray-core/api/doc/ray.method.html))

For the introductory lab, ordinary actors are useful because state mutations can be easier to reason about than shared state across arbitrary task workers.

But do not generalize this into:

> “Actors guarantee one global order.”

They do not establish a universal order across all actors or all independent tasks.

If two actors communicate or several clients submit operations concurrently, distributed ordering questions remain.

## 12. A worker process and an actor are related but not identical concepts

Ray workers are processes that execute work.

For ordinary tasks, workers can execute multiple tasks over their lifetime.

For an actor, Ray dedicates a worker process to that actor instance. ([Ray Actors](https://docs.ray.io/en/latest/ray-core/actors.html))

This distinction helps you separate:

```text
physical/runtime execution process
             from
application-level stateful actor identity
```

The same distinction appears later between:

- OS process and Raft node identity;
- container and service identity;
- machine and shard identity.

## 13. Scheduling is a policy decision the middleware makes for you

When a remote task is submitted, something must answer:

> **Where should this work run?**

Ray supports logical resource requirements such as CPU, GPU, and custom resources. Its scheduler uses these requirements when selecting a node. Current Ray documentation emphasizes that these are **logical resources used for admission/scheduling**, not a universal enforcement mechanism for physical resource usage. ([Ray Resources](https://docs.ray.io/en/latest/ray-core/scheduling/resources.html))

Example:

```python
@ray.remote(num_cpus=2)
def expensive_job(x):
    ...
```

This says something about scheduling eligibility.

It does not make a Python function incapable of using more CPU through every possible mechanism.

The systems lesson is:

```text
resource declaration
        ↓
scheduling policy
        ↓
placement
```

is different from:

```text
OS / container resource enforcement
```

Chapter 3 revisits isolation and Chapter 12 revisits load, queues, and performance.

## 14. Placement reveals architecture even when the runtime chooses it

Imagine three nodes:

```text
Node A: 4 CPU
Node B: 4 CPU
Node C: 1 GPU + 4 CPU
```

A GPU task should only run where its declared requirement can be satisfied.

A group of tightly communicating actors may benefit from being placed together; fault tolerance may instead motivate spreading replicas across failure domains.

Ray includes placement mechanisms and scheduling strategies for such cases.

The important course question is not to memorize every Ray option.

It is to identify the general tension:

```text
locality / low communication cost
              versus
failure independence / load distribution
```

This tension appears again in replicated storage and datacenter systems.

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosity</span>
  <strong>One line of Ray can imply scheduling, serialization, data movement, process selection, and failure policy</strong>
  <p>A remote task call is intentionally compact syntax. The middleware's value is that it hides a large distributed control path; the course uses that convenience first and then asks you to identify every hidden dependency before Ray is removed.</p>
  <p><strong>Try it:</strong> For one `f.remote(x)` call, write the minimum sequence of hidden steps that must occur before the caller can obtain the result.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">More chapter curiosities →</a>
</aside>

## 15. Failure semantics are part of the middleware contract

One of the strongest reasons to use Ray pedagogically is that it already makes policy choices about failure.

Current stable Ray documentation states that tasks which fail because the worker dies unexpectedly are retried automatically up to a configurable maximum; the current default is three retries for ordinary tasks. Application-level Python exceptions are not retried by default unless configured. ([Ray Task Fault Tolerance](https://docs.ray.io/en/latest/ray-core/fault_tolerance/tasks.html))

For actors, the default is different: actors are not automatically restarted and actor tasks are not automatically retried unless `max_restarts` and `max_task_retries` are configured. ([Ray Actors](https://docs.ray.io/en/latest/ray-core/actors.html))

This difference is not trivia.

It demonstrates that:

> **“retry on failure” is a policy with semantics, not a natural law of distributed execution.**

## 16. Retrying a task is safe only if repeating its effects is safe

Suppose a task is pure:

```python
@ray.remote
def square(x):
    return x * x
```

Repeating it produces the same logical result.

Now consider:

```python
@ray.remote
def charge_credit_card(order):
    ...
```

If the worker charges the card and crashes before the result becomes available, an automatic retry could charge again unless the external operation is idempotent or deduplicated.

The runtime cannot infer every application-level side effect.

This is the bridge to Chapter 4:

```text
runtime retry
      +
non-idempotent side effect
      ↓
possible duplicate effect
```

The lab therefore asks you to distinguish:

- deterministic computation;
- application exception;
- worker crash;
- external side effect.

## 17. Object recovery introduces lineage and recomputation

Ray can recover some lost object data by reconstructing lineage and re-executing the task that produced the object, subject to important constraints. The current documentation notes, among other limitations, that reconstructability depends on how the object was produced and on the producing/owning context. ([Ray Object Fault Tolerance](https://docs.ray.io/en/latest/ray-core/fault_tolerance/objects.html))

The course-level idea is more general:

```text
lost data
  ↓
restore from replica?
recompute from lineage?
reload from durable storage?
fail the request?
```

Different systems choose different recovery strategies.

Ray gives you a concrete example before you implement durability and replication directly.

## 18. “The task succeeded” and “the application succeeded” are different claims

A Ray task may execute its Python function successfully while the larger application still violates a requirement.

Examples:

- two tasks both update an external non-idempotent service;
- the result remains only in transient memory when the specification requires durability;
- a stateful actor becomes a single point of failure;
- tasks finish, but the driver loses metadata needed to interpret the outputs;
- all tasks execute on one node, violating an intended failure-domain requirement;
- a retry changes an external system twice.

Middleware can provide useful mechanisms without understanding every application invariant.

This is why the final project evaluates **system guarantees**, not the mere presence of Ray primitives.

## 19. Observability should expose the abstraction boundary

Ray provides runtime information about tasks, actors, and their execution state through its observability tooling, State APIs, logs, and dashboard facilities.

Use this to answer questions such as:

- Which process executed this task?
- Did two tasks overlap in time?
- Which actor died?
- Was a task retried?
- Where did an object live?
- What resources were requested?

Then compare what the runtime knows with what the **application** knows.

For example:

```text
Runtime: task attempt #2 finished successfully
Application: request R appears twice in external audit log
```

Both facts can be true.

The correct diagnosis crosses the abstraction boundary.

## 20. Worked example: sequential versus parallel tasks

Assume four independent inputs and a one-second function.

### Sequential Python

```python
results = [slow(x) for x in range(4)]
```

Approximate dependency shape:

```text
A → B → C → D
```

### Remote submission, immediate `get`

```python
results = [ray.get(slow.remote(x)) for x in range(4)]
```

Still approximately:

```text
A → wait → B → wait → C → wait → D
```

### Submit all, then retrieve

```python
refs = [slow.remote(x) for x in range(4)]
results = ray.get(refs)
```

Dependency shape:

```text
A ─┐
B ─┼─ available workers
C ─┼─ may execute concurrently
D ─┘
```

The lab measures elapsed time and records actual worker PIDs so you can see both concurrency and scheduling.

## 21. Worked example: task or actor?

Suppose the application counts processed jobs.

### Task approach

```python
@ray.remote
def process(job):
    return result
```

Each task can be conceptually independent.

A separate service must own the count if it matters.

### Actor approach

```python
@ray.remote
class Worker:
    def __init__(self):
        self.completed = 0

    def process(self, job):
        ...
        self.completed += 1
```

Now the count is local actor state.

Questions immediately appear:

- What if the actor dies?
- Does the count need to survive?
- Is one actor a bottleneck?
- Can several actors have independent counts?
- Who aggregates them?

The “right” abstraction follows from the required state semantics.

## 22. Worked example: hidden dependencies in a tiny Ray application

Consider:

```python
@ray.remote
def resize(image):
    return transformed

refs = [resize.remote(img) for img in images]
outputs = ray.get(refs)
```

The apparent application logic is tiny.

A middleware dependency map might reveal:

| Application requirement | Ray responsibility in Phase 1 |
|---|---|
| find execution capacity | scheduler / workers |
| dispatch work | remote task runtime |
| serialize input | runtime serialization |
| make input accessible | object/data movement |
| represent pending result | `ObjectRef` |
| execute concurrently | worker scheduling |
| surface worker crash | task fault handling |
| collect result | object retrieval |
| observe task state | logs/state/dashboard |

This table is one of the most important artifacts in the entire final-project methodology.

## 23. The middleware dependency map is not a list of Ray APIs

A weak map says:

```text
uses ray.remote
uses ray.get
uses actors
```

A useful map starts from **requirements**:

| Requirement | Ray mechanism | Assumption | Native question |
|---|---|---|---|
| distribute independent jobs | tasks | jobs are serializable | how are jobs sent to workers? |
| preserve worker-local state | actor | actor process remains useful | should state be durable? |
| choose a worker | scheduler | declared resources represent need | what scheduling policy is required? |
| survive worker crash | task retry | repeated execution is safe | how will duplicates be handled? |
| refer to remote result | ObjectRef | runtime tracks dependency | where will native results live? |

The fourth column becomes the Phase 2 design agenda.

## 24. Final-project Phase 1 should optimize learning, not architecture sophistication

The purpose of the Ray prototype is to understand the domain quickly.

A good Phase 1 answer:

- implements the core functional path;
- runs on several Ray workers or actors;
- demonstrates at least one failure/concurrency behavior;
- freezes an external behavioral contract;
- documents middleware dependencies;
- identifies questions for the native design.

A poor Phase 1 answer spends most of the project engineering advanced Ray-specific infrastructure that will immediately be removed.

Keep the Ray version intentionally small.

## 25. The Ray removal boundary is a design exercise

After Phase 1, you do **not** translate every Ray feature line by line.

Instead:

```text
Ray prototype
     ↓
behavioral contract
     ↓
requirements + dependency map
     ↓
architectural alternatives
     ↓
minimum justified native mechanisms
```

For example:

| Phase 1 | Native Phase 2 possibility |
|---|---|
| Ray task | explicit gRPC worker operation |
| actor | long-running Go service |
| ObjectRef | job ID + result store |
| Ray scheduler | central queue / work stealing / static assignment |
| runtime membership | registry / gossip / configuration bootstrap |
| task retries | explicit timeout, retry, and deduplication |
| actor state | persistent database / replicated log / local state |

Different projects should produce different answers.

If every group recreates the same generic scheduler and registry, the methodology has failed to use the application domain as a design constraint.

## 26. What Ray should *not* teach students

Do not leave Chapter 2 with these conclusions:

### “Distribution is one decorator”

The decorator selects an abstraction. The runtime still implements many distributed mechanisms.

### “ObjectRef is durable storage”

A reference to a remote object is not automatically the application's durable storage guarantee.

### “Actor means replicated service”

An actor is a stateful remote worker, not automatically a replicated state machine.

### “Retries mean exactly-once”

Repeating execution can repeat side effects.

### “Resource requests are security/isolation”

Scheduling resources and operating-system enforcement are different concerns.

### “If Ray handles it, we do not need to understand it”

The rest of the course exists precisely to understand and explicitly build the mechanisms hidden here.

## 29. AI coding agents make the abstraction lesson even more important

A coding agent can generate a Ray solution extremely quickly.

That is acceptable in this course.

The educational question moves from:

> “Did you remember the syntax of `@ray.remote`?”

into:

> “Can you identify what the generated system depends on, test its failure behavior, and redesign the solution without Ray?”

You may use AI to:

- generate the first prototype;
- inspect Ray APIs;
- propose experiments;
- analyze logs;
- critique the dependency map.

But Phase 1 is not complete until you can explain each runtime capability that matters to the project.

## 30. Common mistakes

### Calling `ray.get()` immediately after every submission

This can accidentally serialize independent work and destroy expected parallelism.

### Using actors for all state because actors are convenient

Ask whether the state must survive actor failure or be shared across actors. If yes, actor-local memory may not satisfy the requirement.

### Assuming task retry is always safe

External side effects and non-idempotent operations may be duplicated.

### Treating scheduler placement as deterministic

Unless placement is constrained, the runtime is allowed to choose among eligible resources. Tests should not depend unnecessarily on a specific worker.

### Confusing logical resource requests with hard isolation

A scheduling declaration is not the same as an OS-enforced quota.

### Measuring only “the Ray version is faster”

Ray introduces overhead as well as parallelism. Use a workload large enough to reveal meaningful scheduling/concurrency behavior and identify the measurement boundary.

### Building the final project entirely around Ray internals

Phase 1 should expose the application problem. The course is not asking you to become a Ray maintainer.

### Bringing Ray back after the removal boundary

Once Phase 2 begins, scheduling, communication, discovery, persistence, retries, and other required mechanisms must be explicit in the native design rather than hidden behind Ray again.

## 31. A checklist before removing Ray

For the Phase 1 prototype, answer:

### Execution

- What is a task?
- What is an actor?
- Which operations are concurrent?
- Which operations are serialized?

### Data

- Which values become remote objects?
- Which values move between workers?
- Which state is actor-local?
- Which data is actually durable?

### Scheduling

- What resource constraints are declared?
- Does placement matter to correctness or only performance?
- What happens if one node has no capacity?

### Failure

- Which task failures are retried?
- Which actor failures are restarted?
- Are repeated operations safe?
- What application state survives?

### Observability

- How can you prove which worker executed a task?
- How can you see a retry?
- Which application request maps to which runtime task?

### Native redesign

- Which Ray capability is genuinely required by this project?
- Which capability can be omitted entirely?
- Which guarantee must become stronger than the Ray prototype?

## Chapter summary

Ray lets us experience a compact distributed programming model before implementing the underlying mechanisms directly.

The core lessons are:

1. **Middleware delegates distributed responsibilities; it does not eliminate them.**
2. **Ray tasks express asynchronous remote work whose placement is selected by the runtime.**
3. **`ObjectRef` separates submission/dependency from local availability of a value.**
4. **Actors provide stateful remote workers, not automatically durable or replicated state.**
5. **Data placement and movement still matter even when code does not explicitly send bytes.**
6. **Logical resources influence scheduling and are distinct from hard resource isolation.**
7. **Failure and retry semantics are part of the middleware contract.**
8. **Automatic retry can duplicate application-level side effects.**
9. **Runtime success and application correctness are different claims.**
10. **The middleware dependency map turns Phase 1 convenience into Phase 2 design questions.**
11. **Ray is intentionally removed after the prototype so you must own the required mechanisms.**

The desired progression is:

```text
“I can distribute this with Ray.”
              ↓
“I can explain what Ray provided.”
              ↓
“I know which of those mechanisms my problem actually needs.”
              ↓
“I can build and defend those mechanisms without Ray.”
```

<div class="ds-next-action">
  <span>Core reading complete</span>
  <strong>Next required step · Guided practice</strong>
  <a href="../guided-practice/">Start guided practice →</a>
</div>
