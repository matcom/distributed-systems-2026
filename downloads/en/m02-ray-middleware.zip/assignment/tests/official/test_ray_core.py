import unittest

from dependency_map import REQUIRED_REQUIREMENTS, validate_dependency_map
from ray_lab import (
    build_counter,
    build_task,
    completion_order,
    pure_work,
    ray_available,
    start_local_ray,
    stop_ray,
)


class RayIndependentTests(unittest.TestCase):
    def test_pure_work_is_deterministic_and_reports_pid(self):
        result = pure_work(21)
        self.assertEqual(result["result"], 42)
        self.assertEqual(result["value"], 21)
        self.assertIsInstance(result["pid"], int)

    def test_negative_delay_is_rejected(self):
        with self.assertRaises(ValueError):
            pure_work(1, delay_s=-0.1)

    def test_dependency_map_validator_is_transparent(self):
        rows = [
            {
                "requirement": requirement,
                "ray_provides": "visible description",
                "assumption": "visible assumption",
                "native_question": "visible question",
            }
            for requirement in REQUIRED_REQUIREMENTS
        ]
        self.assertEqual(validate_dependency_map(rows), [])

        incomplete = rows[:-1]
        problems = validate_dependency_map(incomplete)
        self.assertTrue(any("observability" in problem for problem in problems))


@unittest.skipUnless(ray_available(), "Ray is not installed; Ray-specific cases skipped")
class RayIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ray = start_local_ray(num_cpus=2)

    @classmethod
    def tearDownClass(cls):
        stop_ray()

    def test_remote_task_result_contains_worker_identity(self):
        task = build_task(max_retries=1)
        result = self.ray.get(task.remote(7))
        self.assertEqual(result["result"], 14)
        self.assertIsInstance(result["pid"], int)

    def test_actor_state_changes_across_calls(self):
        Counter = build_counter(max_restarts=0, max_task_retries=0)
        actor = Counter.remote()
        first = self.ray.get(actor.process.remote(3))
        second = self.ray.get(actor.process.remote(4))
        self.assertEqual((first["count"], second["count"]), (1, 2))
        self.assertEqual(self.ray.get(actor.count.remote()), 2)
        self.assertEqual(first["pid"], second["pid"])

    def test_completion_order_can_differ_from_submission_order(self):
        order = completion_order([(1, 0.20), (2, 0.01)])
        self.assertEqual(order[0], 2)
        self.assertCountEqual(order, [1, 2])


if __name__ == "__main__":
    unittest.main()
