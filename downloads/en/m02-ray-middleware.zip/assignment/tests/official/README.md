# Transparent official cases

The suite is executable and split deliberately into two layers.

## Always-executable cases

These do not require importing Ray:

- deterministic pure-work result and PID evidence;
- rejection of invalid delay values;
- completeness of the middleware dependency-map structure.

## Ray integration cases

When Ray is installed, the same visible suite also checks:

- a remote task returns the expected result and worker PID;
- actor state changes across method calls and remains in one actor process;
- `ray.wait` can expose completion order without assuming submission order.

The starter constructs remote functions and actors explicitly so retry/restart policy is visible in the code. Timing checks use clearly separated delays rather than exact performance thresholds.

If Ray is unavailable, only the Ray-specific cases are marked **skipped**. This lets the rest of the course repository remain testable on lightweight machines without pretending the Ray behavior was verified.

Add your own cases under `tests/student/`.

No hidden tests are used.
