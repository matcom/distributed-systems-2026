# Laboratory — Distributed Middleware with Ray

## Purpose

This laboratory gives you a productive distributed programming model **before** you implement the mechanisms yourself.

You will take a small sequential workload and express it using Ray tasks and actors. You will then inspect where work ran, compare sequential and concurrent execution, kill workers/actors, observe retry behavior, and produce a middleware dependency map.

The goal is not to become a Ray expert.

The goal is to be able to say:

> **“This application requirement looks simple because Ray is currently responsible for these distributed mechanisms.”**

## Course version

The course material is written against the current Ray 2.x Core API. For reproducible course environments, use the version pinned by the module when a `requirements.txt` is provided.

Do not use Ray Train, Ray Serve, RLlib, or other high-level libraries for the required exercise. We want the Core abstractions to remain visible.

## Setup

Create a virtual environment if possible:

```bash
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install --upgrade pip
python3 -m pip install 'ray==2.58.0'
```

Verify:

```bash
python3 -c 'import ray; print(ray.__version__)'
```

If the course repository later updates its pinned version, use the version declared by the assignment rather than silently mixing environments.

## Part A — Sequential baseline

Start with a deterministic workload containing several independent jobs.

Each job should:

- receive an integer/job ID;
- sleep for a configurable interval so concurrency is visible;
- return a deterministic result;
- report the process PID that executed it.

For example, four one-second jobs executed sequentially should take roughly four seconds plus overhead.

Record:

- number of jobs;
- sleep/work duration;
- elapsed time;
- process IDs;
- ordering of completion.

Do not grade the experiment on exact timing. The important property is dependency/concurrency structure.

## Part B — Ray tasks

Convert the worker function into a Ray remote task.

Submit all jobs before retrieving results.

Conceptually:

```text
Driver
  ├── submit J1 ──> worker
  ├── submit J2 ──> worker
  ├── submit J3 ──> worker
  └── submit J4 ──> worker
```

Collect:

- result;
- worker PID;
- elapsed time;
- task/job identity.

Answer:

1. Which part of the program chose the worker?
2. Which part serialized and transported arguments/results?
3. What did `.remote()` return immediately?
4. At what point did your driver actually need the values?

## Part C — The accidental serialization experiment

Compare these conceptual patterns:

```python
refs = [work.remote(x) for x in jobs]
results = ray.get(refs)
```

and:

```python
results = []
for x in jobs:
    results.append(ray.get(work.remote(x)))
```

Predict the elapsed-time difference before running them.

Explain why the second version can lose most of the parallelism even though every call uses Ray.

This is an important systems lesson:

> **Using distributed primitives does not guarantee that the dependency graph contains useful concurrency.**

## Part D — Observe completion incrementally

Use `ray.wait` or an equivalent Core pattern to consume results as they become available.

Make jobs take different durations so completion order differs from submission order.

Record:

```text
submission order
completion order
worker PID for each job
```

Explain why a future/ObjectRef is useful even before its value exists locally.

## Part E — Stateful actor

Create a simple stateful actor such as a worker that counts completed jobs.

The actor should expose operations equivalent to:

```text
process(job)
count()
```

Issue several method calls and inspect the actor's PID.

Answer:

- Where does the counter live?
- Does the counter automatically exist on another node?
- Is it durable if the actor process disappears?
- Why is this abstraction convenient?
- Which later course mechanism might be needed if the counter must survive a crash?

## Part F — Resource-aware scheduling

Declare a logical resource requirement for one task or actor.

Examples may use CPU resources or a harmless custom resource.

Observe which jobs are allowed to execute given the declared capacity.

Explain the difference between:

```text
Ray logical scheduling resource
```

and:

```text
operating-system-enforced CPU/memory isolation
```

Do not claim that a logical resource declaration is a security boundary.

## Part G — Worker failure and task retry

Use a task whose first attempt can terminate its worker process in a controlled way, or follow the instructor-provided failure helper.

Configure a small retry count explicitly rather than relying only on defaults.

Before running, predict:

```text
attempt 1 → worker dies
attempt 2 → ?
```

Collect runtime/application evidence showing whether a retry occurred.

Then classify the task:

### Safe-to-repeat example

A deterministic calculation such as hashing or squaring an input.

### Dangerous-to-repeat example

An external side effect such as “append another payment,” “send another email,” or “increment a non-deduplicated external counter.”

You do not need to perform a real dangerous external side effect. Model it locally and explain the duplicate-effect risk.

## Part H — Actor failure

Terminate an actor and observe what happens to subsequent method calls under the configured restart/retry policy.

Compare this with ordinary task failure.

The report must not simply say:

> “Ray handles failures.”

It must state **which failure, what policy was configured, which state survived, and what the application observed**.

## Part I — Data movement thought experiment

Create a moderately sized Python object and make more than one task use it.

You do not need a huge dataset.

Draw the conceptual paths under two designs:

```text
Driver sends independent values to tasks
```

versus:

```text
Driver creates/references shared remote object
Tasks depend on ObjectRef
```

Explain why the second design can change data-movement behavior.

Avoid drawing conclusions from tiny timing differences on localhost. Focus first on ownership and dependency structure.

## Part J — Build the middleware dependency map

This is a mandatory deliverable.

Create a table with at least these rows:

| Requirement | What Ray provides in this lab | Important assumption/configuration | Native question |
|---|---|---|---|
| remote execution | | | |
| worker selection | | | |
| pending result | | | |
| stateful worker | | | |
| data movement | | | |
| resource scheduling | | | |
| failure reporting/retry | | | |
| observability | | | |

Do not write only API names.

For example, “`ray.get`” is not a requirement. “Retrieve a result that may have been produced on another worker” is a requirement.

## Part K — Mini Ray-removal design exercise

Choose one small Ray program from the lab and answer:

> If Ray disappeared tomorrow, what is the **minimum** native architecture needed to preserve this program's behavior?

Possible replacements may include:

- explicit worker addresses;
- a central scheduler;
- HTTP/gRPC;
- a job ID;
- a result store;
- heartbeats;
- request retries;
- durable local files.

Do **not** implement the replacement yet.

The point is to practice the reasoning required after Phase 1 of the final project.

## Transparent tests

The starter code under `starter/src/` keeps the Ray surface intentionally small:

- one pure worker function;
- one explicit remote-task builder with a visible retry setting;
- one stateful counter actor;
- one `ray.wait` completion-order helper;
- one dependency-map validator.

The public suite under `tests/official/` has two layers:

1. **Ray-independent structural cases** always run and verify the pure operation plus the middleware dependency-map contract.
2. **Ray integration cases** run when Ray is installed and verify remote task results/worker identity, actor state across calls, and completion handling without assuming deterministic worker placement.

If Ray is not installed, those Ray integration cases are reported as skipped rather than falsely reported as passed. On the supported Chapter 2 environment they should execute in local Ray mode; no cloud cluster is required.

Useful student additions include:

- another completion-order case;
- a resource-option experiment;
- a controlled pure-task retry;
- validation that your driver submits work before collecting all results;
- an additional dependency-map requirement justified by your application.

No hidden cases are planned.

## Required report

Complete `REPORT.md` with:

1. environment and Ray version;
2. sequential vs task timing/worker evidence;
3. accidental-serialization result;
4. incremental completion observation;
5. actor state analysis;
6. one scheduling/resource observation;
7. one task-failure/retry experiment;
8. one actor-failure experiment;
9. the complete middleware dependency map;
10. the mini Ray-removal design;
11. AI-use disclosure.

## Assessment emphasis

The strongest submission is not the one using the largest number of Ray features.

It is the one that can explain:

```text
application requirement
       ↓
Ray abstraction
       ↓
hidden distributed responsibility
       ↓
observed failure behavior
       ↓
native design question
```

## Ray boundary

Ray remains available for **Phase 1 of the final project**.

After that phase it is removed from the runtime. Do not design this lab around Ray-specific features you would have to reproduce later unless those features illuminate a distributed mechanism the course actually intends to study.

## AI use

AI assistants and coding agents are permitted.

If an agent generates the Ray implementation, you must still be able to identify tasks, actors, object references, state ownership, scheduling assumptions, and failure semantics during review.