"""Small local-Ray demonstration for Chapter 2."""

from __future__ import annotations

import json

from ray_lab import build_counter, build_task, start_local_ray, stop_ray


def main() -> None:
    ray = start_local_ray(num_cpus=2)
    task = build_task(max_retries=1)

    refs = [task.remote(value, 0.1) for value in (1, 2, 3, 4)]
    print("task results")
    print(json.dumps(ray.get(refs), indent=2, sort_keys=True))

    Counter = build_counter(max_restarts=0, max_task_retries=0)
    counter = Counter.remote()
    ray.get([counter.process.remote(value) for value in (10, 20, 30)])
    print("actor count", ray.get(counter.count.remote()))
    print("actor pid", ray.get(counter.pid.remote()))

    stop_ray()


if __name__ == "__main__":
    main()
