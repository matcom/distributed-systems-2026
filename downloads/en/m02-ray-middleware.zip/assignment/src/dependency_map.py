"""Machine-checkable structure for the Chapter 2 middleware dependency map."""

from __future__ import annotations

REQUIRED_REQUIREMENTS = (
    "remote execution",
    "worker selection",
    "pending result",
    "stateful worker",
    "data movement",
    "resource scheduling",
    "failure reporting/retry",
    "observability",
)


def validate_dependency_map(rows: list[dict[str, str]]) -> list[str]:
    """Return human-readable problems; an empty list means the map is complete."""

    problems: list[str] = []
    by_requirement = {
        row.get("requirement", "").strip().lower(): row
        for row in rows
    }

    for requirement in REQUIRED_REQUIREMENTS:
        row = by_requirement.get(requirement)
        if row is None:
            problems.append(f"missing requirement: {requirement}")
            continue
        for field in ("ray_provides", "assumption", "native_question"):
            if not row.get(field, "").strip():
                problems.append(f"{requirement}: missing {field}")

    return problems
