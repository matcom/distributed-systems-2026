"""Minimal Ray Core teaching helpers for Chapter 2.

The module imports even when Ray is unavailable so the rest of the course
repository can still be validated on lightweight machines.
"""

from __future__ import annotations

import importlib.util
import os
import time
from typing import Iterable


def ray_available() -> bool:
    return importlib.util.find_spec("ray") is not None


def require_ray():
    if not ray_available():
        raise RuntimeError("Ray is not installed in this environment")
    import ray

    return ray


def pure_work(value: int, delay_s: float = 0.0) -> dict[str, object]:
    if delay_s < 0:
        raise ValueError("delay_s must be non-negative")
    if delay_s:
        time.sleep(delay_s)
    return {
        "value": value,
        "result": value * 2,
        "pid": os.getpid(),
    }


def build_task(*, max_retries: int = 0):
    if max_retries < 0:
        raise ValueError("max_retries must be non-negative")
    ray = require_ray()
    return ray.remote(max_retries=max_retries)(pure_work)


class Counter:
    def __init__(self) -> None:
        self._count = 0

    def process(self, value: int) -> dict[str, int]:
        self._count += 1
        return {
            "value": value,
            "result": value * 2,
            "count": self._count,
            "pid": os.getpid(),
        }

    def count(self) -> int:
        return self._count

    def pid(self) -> int:
        return os.getpid()


def build_counter(*, max_restarts: int = 0, max_task_retries: int = 0):
    if max_restarts < 0 or max_task_retries < 0:
        raise ValueError("restart/retry counts must be non-negative")
    ray = require_ray()
    return ray.remote(
        max_restarts=max_restarts,
        max_task_retries=max_task_retries,
    )(Counter)


def start_local_ray(*, num_cpus: int = 2):
    if num_cpus <= 0:
        raise ValueError("num_cpus must be positive")
    ray = require_ray()
    if not ray.is_initialized():
        ray.init(
            num_cpus=num_cpus,
            include_dashboard=False,
            ignore_reinit_error=True,
            log_to_driver=False,
        )
    return ray


def stop_ray() -> None:
    if not ray_available():
        return
    import ray

    if ray.is_initialized():
        ray.shutdown()


def run_task_batch(values: Iterable[int], *, max_retries: int = 0) -> list[dict[str, object]]:
    ray = start_local_ray()
    task = build_task(max_retries=max_retries)
    refs = [task.remote(value) for value in values]
    return ray.get(refs)


def completion_order(jobs: Iterable[tuple[int, float]]) -> list[int]:
    ray = start_local_ray()
    task = build_task()
    pending = {
        task.remote(value, delay_s): value
        for value, delay_s in jobs
    }
    completed: list[int] = []
    while pending:
        ready, _ = ray.wait(list(pending), num_returns=1)
        ref = ready[0]
        completed.append(pending.pop(ref))
        ray.get(ref)
    return completed
