# M02 Laboratory Report

## Environment

- Python version:
- Ray version:
- CPU/resources visible to Ray:
- Git revision / dirty state:

## Sequential vs Ray tasks

| Mode | Jobs | Nominal work/job | Elapsed time | Worker PIDs | Notes |
|---|---:|---:|---:|---|---|
| Sequential | | | | | |
| Submit-all tasks | | | | | |
| Immediate `ray.get` loop | | | | | |

Explain the dependency structure that produced the timing difference.

## Incremental completion

- Submission order:
- Completion order:
- What `ObjectRef` allowed the driver to do:

## Actor experiment

- Actor PID:
- State stored by actor:
- What survives actor death:
- What does not survive actor death:
- Why an actor is useful here:

## Resource-aware scheduling

- Declared logical resources:
- Observed placement/concurrency:
- Why this is not equivalent to OS-enforced isolation:

## Task failure and retry

### Prediction

### Configuration

### Evidence

### Is repeated execution safe here? Why?

## Actor failure

### Configured restart/retry policy

### Observation

### State consequences

## Middleware dependency map

| Requirement | What Ray provides | Assumption/configuration | Native question |
|---|---|---|---|
| remote execution | | | |
| worker selection | | | |
| pending result | | | |
| stateful worker | | | |
| data movement | | | |
| resource scheduling | | | |
| failure reporting/retry | | | |
| observability | | | |

## Mini Ray-removal design

Choose one lab application and sketch the minimum architecture needed to preserve its behavior without Ray.

## Student-authored transparent test

Describe the case and why it matters.

## AI-use disclosure

```yaml
ai_use:
  used: false
  tools: []
  activities: []
  verification: []
```

## Final answer

In your own words: **How much distributed-systems machinery was hidden behind the Ray program you wrote?**