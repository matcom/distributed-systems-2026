> **Reference view.** This page is optional context; return to the [Lesson](../lesson/) for the required path.

## Essential

- **● Ray Core Walkthrough** — Ray Project. [documentation](https://docs.ray.io/en/latest/ray-core/walkthrough.html)

## Recommended

- **●●● Ray: A Distributed Framework for Emerging AI Applications** — Philipp Moritz et al.. [paper](https://www.usenix.org/conference/osdi18/presentation/moritz)

## Advanced

No additional item assigned yet.

## Tools & Practice

- **●● Ray Core Documentation** — Ray Project. [documentation](https://docs.ray.io/en/latest/ray-core/)

## Explore

- **●●● Ray Architecture Whitepapers** — Ray Project. [architecture notes](https://docs.ray.io/en/latest/ray-contribute/whitepaper.html)
