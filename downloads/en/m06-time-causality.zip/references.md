> **Reference view.** This page is optional context; return to the [Lesson](../lesson/) for the required path.

## Essential

- **●● Time, Clocks, and the Ordering of Events in a Distributed System** — Leslie Lamport. [paper](https://lamport.azurewebsites.net/pubs/time-clocks.pdf)

## Recommended

- **●●● Virtual Time and Global States of Distributed Systems** — Friedemann Mattern. [paper](https://www.vs.inf.ethz.ch/publ/papers/VirtTimeGlobStates.pdf)

## Advanced

No additional item assigned yet.

## Tools & Practice

- **●● OpenTelemetry Documentation** — OpenTelemetry project. [tool documentation](https://opentelemetry.io/docs/)

## Explore

- **●●● Concurrent and Distributed Systems** — University of Cambridge. [course](https://www.cl.cam.ac.uk/teaching/)
