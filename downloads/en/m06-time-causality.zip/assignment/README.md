# Laboratory — Time, Causality, and Distributed Events

## Target

Instrument three communicating processes with wall-clock timestamps, monotonic local durations, Lamport clocks, and vector clocks; then reconstruct the causal execution from shuffled logs whose physical timestamps intentionally disagree.

The central lesson is:

> **Clock readings are observations. Causality comes from program order, message edges, and transitivity.**

## Required process topology

Use three independent processes:

```text
P1 -> P2 -> P3
 \           ^
  \----------/
```

Each process must support:

- a stable node ID;
- an incarnation ID generated at process start;
- named local events;
- send/receive of messages carrying message IDs;
- Lamport timestamp metadata;
- vector-clock metadata;
- a configurable artificial wall-clock display offset.

The artificial offset changes only the **reported wall timestamp**. It must not delay execution or modify logical-clock rules.

## Required trace schema

Each event record should contain enough information to answer different questions explicitly. A suitable schema includes:

```text
node_id
incarnation_id
event_id
event_type
message_id (when applicable)
peer_id (when applicable)
wall_time
monotonic_elapsed_ms
lamport
vector
```

You may add fields, but explain what each field proves.

## Step 1 — Baseline execution

Run one deterministic workflow with no artificial clock offset.

For example:

```text
P1: local A
P1: send M1 to P2
P2: receive M1
P2: local B
P3: local C
P2: send M2 to P3
P3: receive M2
P1: send M3 to P3
P3: receive M3
```

Before execution, draw the expected happened-before edges.

Do **not** assign timestamps by intuition. Derive them from the algorithm.

## Step 2 — Add contradictory wall clocks

Run the same workflow with artificial offsets such as:

```text
P1: +250 ms
P2: -300 ms
P3: +100 ms
```

Choose offsets large enough that at least one receive record appears to have an earlier wall-clock timestamp than its matching send record.

Document one contradiction such as:

```text
wall-time sort:
receive M1
send M1
```

Then explain why message identity still establishes:

```text
send(M1) -> receive(M1)
```

Do not "fix" the logs by manually editing timestamps.

## Step 3 — Implement Lamport clocks

Use one consistent convention. A common choice is:

- increment before each local/send event;
- attach current value to a sent message;
- on receive, set `L = max(L_local, L_message) + 1`.

Repeat the workflow.

Verify for every message:

```text
L(send) < L(receive)
```

Your report must also include two events where one has a smaller Lamport timestamp but no causal path exists between them. This demonstrates why the converse does not hold.

## Step 4 — Implement vector clocks

Use one component per participating process.

A simple rule set is:

- increment the local component for a local/send event;
- attach the full vector to a sent message;
- on receive, merge by component-wise maximum and then increment the receiver's component.

Repeat the workflow.

Find and report:

1. one pair `a -> b` where `V(a) < V(b)` component-wise;
2. one pair whose vectors are incomparable and therefore represent causal concurrency.

## Step 5 — Construct deliberate concurrency

Make P1 and P3 perform independent local events before either receives information derived from the other.

Record their vectors.

Explain why neither vector dominates the other.

Do not call the events concurrent merely because their wall timestamps are close.

## Step 6 — Shuffle the trace

Combine all trace records and randomly or deterministically shuffle their line order.

Using only the trace fields, reconstruct a valid causal graph.

Your reconstruction must use:

- local event sequence or explicit local predecessor information;
- message ID send/receive pairs;
- Lamport/vector sanity checks.

Wall-clock sorting may be displayed as a comparison, but it cannot be the primary reconstruction algorithm.

## Step 7 — Compare three orderings

For the same execution, produce three views:

### Wall-time order

Sort by reported physical timestamp.

Mark any impossible-looking send/receive inversions.

### Lamport total order

Sort by:

```text
(lamport, node_id, event_id)
```

or another stable tie breaker.

Explain that this is a deterministic total order, not proof that every earlier event caused every later event.

### Causal partial order

Draw or tabulate only edges justified by happened-before.

This is the most important representation in the lab.

## Step 8 — Causal replica example

Start two logical replicas from a common vector version.

Disconnect their communication and perform one update on each.

Record vectors such as:

```text
A: [2,0]
B: [1,1]
```

After reconnection, show that the versions are incomparable.

Then answer separately:

- Can the system detect that the writes are concurrent?
- Does the vector clock determine which application value should win?

The expected conceptual distinction is **detection versus resolution**.

## Step 9 — Local duration versus wall clock

Measure one local operation using a monotonic elapsed timer and also print wall-clock start/end timestamps.

Artificially perturb only the displayed wall clock.

Explain why elapsed duration should not be reconstructed by blindly subtracting independently adjustable wall-clock timestamps.

## Step 10 — Lease thought experiment

Suppose a worker advertises a lease valid for 15 seconds.

Explain why a Lamport clock cannot answer "have 15 seconds elapsed?"

Then identify:

- the appropriate local elapsed-time mechanism;
- the distributed uncertainty that still remains when another node decides whether the lease is valid.

This prepares Chapter 10 and later coordination work.

## Step 11 — AI-audited reconstruction

Give an AI assistant a shuffled subset of your trace and ask it to reconstruct causality.

Audit every claimed edge.

For one AI conclusion, classify the reasoning as:

- valid causal edge;
- unsupported inference from wall time;
- unsupported inference from Lamport magnitude;
- insufficient evidence.

Your audit, not the model answer, is the assessed artifact.

## Transparent-test target

Executable public tests now live under `tests/official/`, with Lamport/vector-clock primitives in `starter/src/`. They verify deterministic logical-clock transitions and causal comparisons; shuffled-trace reconstruction, wall-clock skew, and duration evidence remain experimental.

The public cases to be implemented are listed in `tests/official/README.md`. Once the scaffold exists, `make test` should execute the same visible official tests plus any student tests under `tests/student/`.

No hidden tests are planned.

## Report requirements

Complete `REPORT.md` with:

- the event topology;
- one wall-clock contradiction;
- complete Lamport assignments for one execution;
- complete vector assignments for one execution;
- one causally ordered pair;
- one genuinely concurrent pair;
- shuffled-trace reconstruction;
- wall/Lamport/causal order comparison;
- causal replica conflict example;
- AI-audit result.

Screenshots alone are insufficient when the structured trace can be submitted directly.

## AI use

AI assistants and coding agents are permitted unless an instructor explicitly marks a checkpoint as AI-independent.

You remain responsible for every clock update and causal claim. A generated diagram is not evidence unless you can derive the edges represented in it.