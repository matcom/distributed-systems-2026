# Planned Public Tests — M06

Executable public tests are provided in this directory together with the starter logical-clock adapter under `starter/src/`. They cover the deterministic Lamport/vector-clock core; trace reconstruction and timing experiments remain evidence-based. No hidden cases are planned.

## Lamport-clock cases

1. Local events monotonically increase the local Lamport value.
2. Sent messages carry the sender's current Lamport timestamp.
3. Receiving a message with timestamp greater than the local value performs `max(local, received) + 1`.
4. Receiving a message with a smaller timestamp still increments the receiver's clock.
5. Every tested send/receive pair satisfies `L(send) < L(receive)`.

## Vector-clock cases

6. A local event increments only the local component.
7. Send carries the complete current vector.
8. Receive performs component-wise maximum followed by receiver increment.
9. Component-wise dominance identifies the tested causal pair.
10. Incomparability identifies the tested concurrent pair.
11. Equal vector metadata is not by itself treated as global event identity.

## Trace cases

12. Trace records include stable node/incarnation/event identifiers.
13. Send and receive records can be paired by message ID even when wall-clock order is contradictory.
14. A shuffled trace can be reconstructed without sorting primarily by wall time.
15. Artificial wall-clock offsets do not modify logical-clock transitions.
16. Monotonic duration reporting remains non-negative under artificial wall-clock display skew.

## Conceptual boundary cases

17. The implementation does not infer happened-before solely from `L(a) < L(b)`.
18. Lease expiration logic, if present in the exercise harness, uses elapsed-time semantics rather than Lamport-clock magnitude.

Students should add at least one additional trace or vector-clock case under `tests/student/` that exercises a concurrent execution not present in the official examples.
