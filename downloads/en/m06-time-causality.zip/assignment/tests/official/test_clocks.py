import unittest

from clocks import LamportClock, VectorClock, causally_before, concurrent


class LamportClockTests(unittest.TestCase):
    def test_local_events_are_monotonic(self):
        clock = LamportClock()
        self.assertEqual(clock.local_event(), 1)
        self.assertEqual(clock.local_event(), 2)

    def test_send_advances_and_carries_timestamp(self):
        clock = LamportClock(4)
        self.assertEqual(clock.send(), 5)
        self.assertEqual(clock.value, 5)

    def test_receive_uses_max_plus_one(self):
        clock = LamportClock(3)
        self.assertEqual(clock.receive(10), 11)
        self.assertEqual(clock.receive(2), 12)

    def test_send_precedes_receive(self):
        sender = LamportClock()
        receiver = LamportClock()
        sent = sender.send()
        received = receiver.receive(sent)
        self.assertLess(sent, received)


class VectorClockTests(unittest.TestCase):
    def test_local_event_increments_only_local_component(self):
        clock = VectorClock(3, 1)
        self.assertEqual(clock.local_event(), (0, 1, 0))

    def test_send_and_receive(self):
        a = VectorClock(3, 0)
        b = VectorClock(3, 1)
        msg = a.send()
        self.assertEqual(msg, (1, 0, 0))
        self.assertEqual(b.receive(msg), (1, 1, 0))

    def test_causal_dominance(self):
        self.assertTrue(causally_before((1, 0, 0), (1, 1, 0)))
        self.assertFalse(causally_before((1, 1, 0), (1, 0, 0)))

    def test_incomparability_means_concurrent(self):
        self.assertTrue(concurrent((1, 0, 0), (0, 1, 0)))
        self.assertFalse(concurrent((1, 0, 0), (1, 1, 0)))

    def test_equal_vectors_are_not_causally_before_or_concurrent(self):
        self.assertFalse(causally_before((1, 2), (1, 2)))
        self.assertFalse(concurrent((1, 2), (1, 2)))

    def test_shape_mismatch_is_rejected(self):
        with self.assertRaises(ValueError):
            causally_before((1, 2), (1, 2, 3))


if __name__ == "__main__":
    unittest.main()
