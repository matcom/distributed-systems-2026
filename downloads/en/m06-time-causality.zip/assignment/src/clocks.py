"""Logical-clock primitives for M06."""

from dataclasses import dataclass
from typing import Iterable, Tuple


@dataclass
class LamportClock:
    value: int = 0

    def local_event(self) -> int:
        """Advance for a local event and return the new timestamp."""
        raise NotImplementedError("TODO: implement local Lamport transition")

    def send(self) -> int:
        """Advance for a send event and return the timestamp carried by the message."""
        raise NotImplementedError("TODO: implement send Lamport transition")

    def receive(self, remote_timestamp: int) -> int:
        """Apply max(local, remote)+1 and return the new local timestamp."""
        raise NotImplementedError("TODO: implement receive Lamport transition")


class VectorClock:
    def __init__(self, size: int, node_index: int):
        if size <= 0 or not 0 <= node_index < size:
            raise ValueError("invalid vector clock shape")
        self.node_index = node_index
        self.values = [0] * size

    def local_event(self) -> Tuple[int, ...]:
        raise NotImplementedError("TODO: increment only the local component")

    def send(self) -> Tuple[int, ...]:
        raise NotImplementedError("TODO: advance local component and return message vector")

    def receive(self, remote: Iterable[int]) -> Tuple[int, ...]:
        """Merge component-wise max, then increment the receiver component."""
        raise NotImplementedError("TODO: implement vector-clock receive")

    def snapshot(self) -> Tuple[int, ...]:
        return tuple(self.values)


def causally_before(left: Iterable[int], right: Iterable[int]) -> bool:
    """Return True iff left < right in the vector-clock partial order."""
    raise NotImplementedError("TODO: implement vector-clock dominance")


def concurrent(left: Iterable[int], right: Iterable[int]) -> bool:
    """Return True iff neither vector causally precedes the other."""
    raise NotImplementedError("TODO: implement incomparability")
