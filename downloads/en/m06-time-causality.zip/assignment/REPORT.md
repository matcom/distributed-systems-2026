# M06 Laboratory Report — Time, Causality, and Distributed Events

## 1. Environment and process topology

Record the three node IDs, incarnation IDs, process-start commands, and the message topology used in the experiment.

## 2. Predicted happened-before graph

Draw or tabulate the causal edges before running the program.

## 3. Wall-clock contradiction

Provide one send/receive pair whose reported wall timestamps appear reversed.

Explain what this says about clocks and what it does **not** change about causality.

## 4. Lamport execution

Provide a table:

| Event | Node | Event type | Message ID | Lamport timestamp |
|---|---|---|---|---:|
| | | | | |

Verify every `send(m) -> receive(m)` pair.

Then give one pair with `L(a) < L(b)` but no causal path from `a` to `b`.

## 5. Vector-clock execution

Provide the vector timestamp for every event in the selected execution.

Include:

- one pair where one vector dominates the other;
- one incomparable pair;
- the component-wise reasoning for both.

## 6. Shuffled-trace reconstruction

Attach or reference the shuffled trace. Reconstruct a valid partial-order graph and explain which evidence establishes each edge.

## 7. Three ordering views

Compare:

- wall-time order;
- deterministic Lamport total order;
- causal partial order.

State one conclusion that is valid in one view but invalid in another.

## 8. Concurrent replica updates

Record the two divergent version vectors and explain:

- why the versions are concurrent;
- what the clock metadata can detect;
- what application policy is still required to resolve the conflict.

## 9. Duration measurement

Compare monotonic elapsed duration with displayed wall-clock timestamps for one operation. Explain which source is appropriate for a timeout.

## 10. Lease analysis

Explain why logical clocks cannot expire a 15-second lease and state the remaining distributed uncertainty even when local monotonic time is used.

## 11. AI audit

- tool, if any:
- trace subset given to the tool:
- one causal claim it made:
- classification:
- evidence used to verify/refute:

## 12. Conclusion

Answer the guiding question: **If clocks disagree, how can we still reason about what happened before what?**
