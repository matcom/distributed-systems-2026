<p class="ds-book-part">Part II — Communication and Coordination</p>
<p class="ds-module-kicker">Chapter 6</p>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 6 of 12</span>
    <span>50% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 50%"></span></div>
</div>
<p class="ds-guiding-question">If clocks disagree, how can you still reason about what happened before what?</p>

Use physical clocks when they are useful, but keep their uncertainty visible. Work through bounded synchronization, then switch to message-based causal order when wall-clock timestamps cannot establish the story you need.

## Key ideas

- physical clocks, drift, and synchronization error
- Cristian-style request/response synchronization
- NTP intuition and limits
- happened-before
- Lamport logical clocks
- vector clocks
- causal order
- concurrent events
- event traces

## Laboratory transition

Instrument three communicating processes with wall-clock offsets, Lamport timestamps, and vector clocks. Shuffle the logs and reconstruct the causal execution.

## Start here

> **Before you read:** Node B logs a receive at 09:59:59.900 for a message Node A says it sent at 10:00:00.100. Which fact do you trust: the timestamps or the message edge?

**Bring forward:** Message traces and request identifiers from the communication chapters.

**This chapter builds toward:** Causal reasoning that remains valid when wall clocks disagree.

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>25 min–35 min</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>35 min–50 min</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>1 h 30 min–2 h · 10 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Read lesson →</a>
  <a class="ds-secondary-action" href="lab/">Open laboratory</a>
</div>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../downloads/en/m06-time-causality.zip" download>Download chapter + laboratory for offline study (.zip)</a></p>

## What you will learn

- Explain why wall-clock timestamps cannot establish all causal relationships.
- Compute Lamport timestamps for a distributed execution.
- Use vector clocks to distinguish causality from concurrency.
- Instrument messages with logical time.
- Reconstruct and explain a multi-process execution from traces.

## Learn by working the question

1. Write your answer to **Start here** before opening the full lesson.
2. Read until the next prediction or trace, then stop and work it out before revealing the explanation.
3. Treat guided practice as a **practice bank**, not a speed worksheet. Work the core traces until you can meet the chapter's Practice target; return to the remaining cases for retrieval practice or instructor-assigned work.
4. Use the knowledge check to find gaps, then enter the laboratory with a falsifiable prediction and name the evidence that could contradict it.
5. Finish by explaining what the experiment established, what it did not establish, and how the result changes the evolving service.

<nav class="ds-sequence" aria-label="Course sequence">
<a class="ds-sequence-link" href="../m12-dht-gossip/">← Communication II — Messaging, Dissemination, and Overlays</a>
<a class="ds-sequence-link next" href="../m09-consensus/">Coordination II — Mutual Exclusion, Elections, and Agreement →</a>
</nav>
