<p class="ds-book-part">Part III — Naming and Replicated State</p>
<div class="ds-lesson-banner">
  <div><span>Course step</span><strong>Chapter 9</strong></div>
  <div><span>Core reading</span><strong>45 min–1 h</strong></div>
  <div><span>Required path</span><strong>Read → Practice target → Check → Lab</strong></div>
</div>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 9 of 12</span>
    <span>75% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 75%"></span></div>
</div>

> **Guiding question:** When several nodes hold the same logical data, which histories may a client observe?

## Before you read

> A write returns OK from replica R1. A later read from R2 returns the old value. Is the system wrong? State the guarantee you assumed before answering.

Write a short answer first. You are not expected to be correct yet; you need a prediction you can revise as the chapter gives you better models and evidence.

**Use what you already know:** Causality, quorum intuition, naming/membership, and explicit client operation histories.

## Workload map

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>45 min–1 h</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>1 h–1 h 30 min</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>2 h 30 min–3 h 30 min · 9 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<p class="ds-workload-note"><strong>Core scope:</strong> Use the lab's explicit core path: Steps 1–7, one client-session anomaly from Step 8 or 9, then Steps 10–17. The second session anomaly is retrieval/extension work.</p>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../../downloads/en/m08-replication-consistency.zip" download>Download lesson + practice + lab for offline study (.zip)</a></p>

## Why this chapter matters

Replication sounds like a simple reliability idea:

> Keep more than one copy.

But the moment two nodes can store the same logical data, a new question appears:

> **Which copy represents the truth?**

Suppose a client writes:

```text
x = 7
```

to replica A.

Replica B still stores:

```text
x = 6
```

for 200 ms.

During that interval:

- Is the system incorrect?
- May a reader observe 6?
- Must a writer wait until B is updated?
- What happens if A crashes before B receives the new value?
- What if A and B become partitioned and both continue accepting writes?

Those questions cannot be answered by the word *replicated*.

They require an explicit **consistency model**, replication protocol, failure model, and availability policy.

The guiding question is:

> **When several nodes store the same logical data, what does it mean for the copies to agree?**

This chapter develops the vocabulary needed to answer that question precisely.

---

## 1. Why replicate at all?

Replication can serve several different goals.

### Availability

If one copy becomes unavailable, another may serve the request.

### Durability

If one storage device or process fails, acknowledged data may survive elsewhere.

### Read capacity

Several replicas may answer read traffic in parallel.

### Geographic locality

Copies can be placed closer to users.

### Fault isolation

Copies in independent failure domains reduce the chance of simultaneous loss.

### Operational flexibility

A system can maintain service while one replica is repaired, upgraded, or moved.

These benefits are real—but every additional writable copy creates coordination questions.

> **Pause and predict.** Three replicas all contain the same value at 10:00. Does that prove they will remain consistent after two clients write concurrently at 10:01?

No. Replication state at one instant says nothing about the protocol governing future changes.

---

<aside class="ds-book-note ds-history">
  <span class="ds-book-note-label">History</span>
  <strong>Why distributed systems needed an ordering concept that did not depend on synchronized clocks</strong>
  <p>Lamport's happened-before relation shifted the field from asking for one perfectly shared clock to asking which events could have influenced which other events.</p>
  <a class="ds-book-note-source" href="../../../history/lamport-time-and-causality/">Read the design history →</a>
</aside>

## 2. Replication creates two separate correctness questions

A useful distinction is:

### Durability question

> After the system acknowledges a write, under which failures can the value still be recovered?

### Consistency question

> Which values may clients observe, and in what order?

A system may be durable but weakly consistent.

For example, three asynchronous replicas may eventually preserve every update while temporarily returning stale values.

A system may also be strongly consistent but unavailable during some failures.

These are different dimensions.

---

## 3. Start with a single logical register

Many consistency ideas become easier if we first imagine one variable:

```text
x
```

Clients perform:

```text
write(x, value)
read(x) -> value
```

A distributed implementation may place copies on:

```text
R1 R2 R3
```

The visible history consists of operation invocations and responses, for example:

```text
C1: write(x,1) -------- ok
C2:            read(x) ----> 1
```

or:

```text
C1: write(x,1) -------- ok
C2:            read(x) ----> 0
```

Consistency models constrain which histories are allowed.

This is a better way to learn consistency than by treating models as adjectives.

---

## 4. Primary/backup gives one node write authority

A simple architecture assigns one **primary** or leader-like replica responsibility for writes.

```text
          Client
            |
            v
         Primary
        /       \
       v         v
   Backup 1   Backup 2
```

The primary can establish one write order locally and propagate it to backups.

This simplifies conflicting-write handling because backups do not independently invent authoritative orders.

But now several new questions appear:

- When does the primary acknowledge?
- How many backups must receive a write first?
- Can backups serve reads?
- What happens if the primary fails?
- How is a new primary chosen safely?

Chapter 7 will address the final question more rigorously with consensus.

---

<figure class="ds-book-figure">
  <img src="../../../assets/book/m08-replica-histories.svg" alt="Two replicas expose different read histories after one acknowledged write." loading="lazy" decoding="async" />
  <figcaption><span>Figure</span>The final stored value is not enough to name a consistency model. Consistency constrains the histories clients are allowed to observe.</figcaption>
</figure>

## 5. Synchronous replication couples acknowledgement to copies

In a synchronous-style policy, the writer waits for some replication condition before acknowledging.

For example:

```text
Client -> Primary -> Backup
                  <- ACK
Client <- OK
```

Now an acknowledged value exists on more than one node.

Potential benefit:

```text
stronger durability after primary failure
```

Potential cost:

```text
write latency includes remote communication
availability depends on required replicas
```

If the backup is slow, the client's write is slow.

If the backup is unreachable and policy requires it, writes may stop.

This is one of the first places where replication, latency, and availability directly trade off.

---

## 6. Asynchronous replication acknowledges earlier

An asynchronous primary may acknowledge after changing local durable state and replicate later.

```text
Client -> Primary
Client <- OK
Primary ----later----> Backup
```

Benefits include:

- lower write latency;
- less dependence on replica responsiveness.

But consider:

```text
Client write x=7
Primary stores x=7
Primary replies OK
Primary crashes
Backup still has x=6
```

If the primary's storage is lost permanently, an acknowledged write may disappear.

Therefore a project must state what “durable after acknowledgement” means.

The course common baseline requires acknowledged durable state to survive the allowed single-storage-node failure. A purely local asynchronous acknowledgement may fail that requirement unless another durability mechanism exists.

---

## 7. Replica reads create stale-read decisions

Suppose the primary has:

```text
x = 7
```

while a lagging backup still has:

```text
x = 6
```

If clients may read from either, a read can return stale data.

This may be acceptable or unacceptable depending on the claimed model.

Examples:

- product recommendation count: perhaps acceptable briefly;
- account balance immediately after a transfer: potentially dangerous;
- coordination lock state: often unacceptable.

Consistency is therefore an application-facing contract, not merely an internal database parameter.

---

## 8. Linearizability respects real-time precedence

Informally, **linearizability** requires each operation to appear to take effect atomically at some instant between invocation and response, while respecting real-time ordering of non-overlapping operations.

Consider:

```text
C1: write(x,1) ---- OK
C2:                    read(x) ----> 0
```

If C2's read begins only after C1's write has completed, returning the older value violates linearizability.

A linearizable history should be explainable as one legal single-copy order that also respects these real-time precedence constraints.

This model is especially useful for coordination-like state because clients can reason approximately as if one current copy existed.

The cost is often additional coordination or restricted availability under failures.

---

## 9. Overlapping operations leave ordering freedom

Suppose:

```text
C1: write(x,1) ----------- OK
C2:      read(x) ----> 0
```

The operations overlap in real time.

Linearizability may allow the read to be ordered before the write's linearization point.

This is important when analyzing histories.

Do not assume that invocation time alone fixes the operation order when intervals overlap.

A correct classification should reason about complete invocation/response intervals.

---

## 10. Sequential consistency preserves process order but not real-time precedence

**Sequential consistency** asks whether operations can be arranged into one total order that:

- is legal for the object;
- preserves each individual process/client's program order.

Unlike linearizability, it does not require that this total order respect real-time precedence between different clients in the same way.

This means some histories that violate linearizability can still be sequentially consistent.

Example idea:

```text
C1 completes write(x,1)
C2 later in wall time reads x=0
```

If the model has no cross-client real-time requirement and a valid sequential ordering can place C2's read before C1's write while preserving each client's own order, the history may satisfy sequential consistency but not linearizability.

This distinction is subtle and worth working through with histories rather than slogans.

---

## 11. Causal consistency preserves cause before effect

Chapter 6 introduced happened-before.

Causal consistency uses a related idea: if operation B may have been influenced by operation A, replicas should not expose B without respecting the causal dependency on A.

Example:

```text
Alice publishes post A
Bob reads A
Bob publishes reply B referencing A
```

Causal relationship:

```text
A -> B
```

A replica should not show Bob's reply B while still hiding the causally prior post A, assuming both operations belong to the replicated causal history being modeled.

But an independent post C may be concurrent with A/B and different replicas may temporarily order C differently.

Causal consistency therefore preserves meaningful dependency without necessarily creating one global total order for every concurrent event.

---

## 12. Eventual consistency is a convergence promise, not a precise read-order model by itself

The phrase **eventual consistency** is often used too loosely.

A useful basic statement is:

> If no new updates occur and communication/recovery continues, replicas eventually converge to compatible/equivalent state.

That does **not** by itself tell us:

- which stale values may be read before convergence;
- how concurrent writes are resolved;
- whether users read their own writes;
- whether versions can appear to go backward;
- how long convergence takes.

Therefore “eventually consistent” is often only part of the user-visible contract.

A convergence-oriented extension later in this chapter uses CRDT ideas to make some independent updates merge safely.

---

## 13. Client-centric consistency captures useful session guarantees

When replicas may be stale, systems often provide guarantees from the perspective of one client/session.

Four classic examples are useful.

### Read-your-writes

After a client successfully writes value v, its subsequent reads should not return an older state that omits that write.

### Monotonic reads

Once a client has observed version v2, it should not later observe an older version v1.

### Monotonic writes

A client's writes should be applied in an order compatible with that client's program order.

### Writes-follow-reads

If a client reads version v and then issues a write dependent on it, the write should be applied in a context that includes that observed version.

These guarantees can make weakly consistent systems much easier for applications to use without requiring global linearizability.

---

## 14. A stale replica can break read-your-writes

Example:

```text
C -> R1: write x=9 -> OK
C -> R2: read x -> 8
```

If R2 has not received the write, the client does not read its own write.

Possible remedies include:

- sticky sessions;
- read from primary;
- wait until selected replica reaches a required version;
- carry version/session metadata;
- quorum read.

The correct choice depends on architecture.

---

## 15. Monotonic reads prevent time travel within one session

Suppose a client first reads from a fresh replica:

```text
version 12
```

then is load-balanced to a stale replica:

```text
version 9
```

Without a monotonic-read guarantee, the user may observe state apparently moving backward.

For some applications this is merely confusing; for others it can break correctness assumptions.

Again, the load balancer, discovery system, and consistency mechanism interact.

---

## 16. Quorums trade replica counts against overlap

Suppose an item is replicated on N nodes.

A common quorum model defines:

```text
W = number of replicas participating in a write
R = number of replicas consulted for a read
```

A familiar overlap condition is:

```text
R + W > N
```

which ensures every read quorum intersects every write quorum.

For two write quorums to intersect, a related condition is often:

```text
2W > N
```

But quorum overlap by itself does not magically produce linearizability.

The protocol still needs rules for:

- version selection;
- concurrent writes;
- read repair;
- failed operations;
- ordering/epochs;
- what counts as a completed write.

Quorum arithmetic is one ingredient, not the whole algorithm.

---

## 17. Worked quorum example — N=3

Let:

```text
N=3
W=2
R=2
```

Then:

```text
R + W = 4 > 3
2W = 4 > 3
```

A write waits for two replicas.

A read consults two replicas.

This gives intersection under the assumed replica set.

Availability implications:

- one replica can be unavailable while a two-node write/read quorum still exists;
- two unavailable replicas prevent quorum progress.

But if a partition splits replicas 2+1, only the side with two replicas can form a quorum under this rule.

This prepares the CAP discussion.

---

## 18. Read-one/write-all emphasizes reads at the cost of write availability

Consider:

```text
N=3
R=1
W=3
```

Reads may be cheap and available from any current replica.

Writes require all three replicas.

One unavailable replica blocks writes.

This is a concrete example of why there is no universally best quorum choice.

The operation mix and failure requirements matter.

---

## 19. Write-one/read-all shifts the trade-off

Now:

```text
N=3
W=1
R=3
```

Writes can complete with one replica, but reads require all replicas to determine the latest state under a simplistic scheme.

This has different latency/availability behavior.

Again, real systems often use more sophisticated protocols, but the arithmetic exposes the design tension.

---

## 20. Leaderless replication permits more independent writes

In a leaderless-style architecture, clients or coordinators may send writes to several replicas without one permanent primary serializing every operation.

Potential benefits:

- no fixed primary bottleneck;
- flexible availability;
- geographically distributed writes.

New problems include:

- concurrent versions;
- conflict detection;
- conflict resolution;
- hinted handoff/repair;
- stale reads;
- version metadata.

The Dynamo paper is historically important because it made many of these trade-offs concrete for a highly available key/value service.

---

## 21. Anti-entropy repairs replicas after divergence

A replica that missed writes must eventually discover and repair missing state.

Possible mechanisms include:

- periodic version comparison;
- Merkle-tree summaries;
- log exchange;
- read repair;
- background synchronization;
- snapshot transfer.

The exact mechanism is system-specific.

But the general requirement is the same one introduced in Chapter 10:

> **Recovery after communication heals is part of replication correctness.**

---

## 22. Read repair uses a read to discover disagreement

Suppose a quorum read receives:

```text
R1: version 8
R2: version 8
R3: version 6
```

The reader/coordinator can return version 8 and optionally repair R3.

This may improve convergence opportunistically.

But it also means a read operation can trigger network writes/repair work.

The apparent simplicity of `GET` can hide substantial distributed coordination.

---

## 23. Conflict resolution requires semantics

Suppose disconnected replicas accept:

```text
A: shopping cart adds book
B: shopping cart adds pen
```

A naive last-writer-wins strategy might discard one update depending on timestamps.

A set-union-like merge could preserve both additions.

Now consider:

```text
A: account balance = 100
B: account balance = 200
```

Union is meaningless.

Conflict resolution depends on the data type and application invariants.

CRDT merge laws formalize one important version of this idea.

### CRDTs move part of the coordination problem into the data type

A **Conflict-free Replicated Data Type (CRDT)** is designed so replicas can accept some updates independently and later merge without inventing an ad-hoc winner.

Consider a grow-only counter with three replicas. Instead of storing one scalar, each replica keeps one component per replica:

```text
A: [3,0,0]
B: [0,2,0]
C: [0,0,4]
```

The visible value is the sum. Merge takes the component-wise maximum:

```text
merge([3,0,0], [0,2,0]) = [3,2,0]
```

Repeated or reordered merge messages do not change the final result because the merge is:

- **commutative** — order does not matter;
- **associative** — grouping does not matter;
- **idempotent** — merging the same state again does not add a second effect.

Those properties are powerful because unreliable dissemination can duplicate and reorder state.

But a CRDT does not remove every coordination need.

Suppose the invariant is:

```text
bank balance must never go below zero
```

Two disconnected replicas may each see enough balance to approve a withdrawal and together violate the global invariant. Convergence after the fact does not repair the fact that an invalid operation was already accepted.

> **Pause and predict.** Which property is stronger: “all replicas eventually converge” or “the invariant was never violated”? They are different claims. CRDTs help with convergence; application invariants determine whether coordination can safely be avoided.

Use CRDTs when the data semantics support independent progress and a mathematically safe merge. Do not choose them merely because the system is replicated.

---

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosity</span>
  <strong>Adding replicas can make writes less available if acknowledgement requires too many of them</strong>
  <p>Replication creates redundancy, but the protocol decides whether that redundancy helps availability. A write that waits for every replica can block on one slow copy even though other copies are healthy.</p>
  <p><strong>Try it:</strong> Compare write availability for a three-replica system requiring 1, 2, or 3 acknowledgements under one replica failure.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">More chapter curiosities →</a>
</aside>

## 24. Last-writer-wins is a policy, not truth

A common conflict policy chooses the update with the largest timestamp.

This can be simple, but it assumes the timestamp comparison is meaningful and that discarding the other update is acceptable.

Chapter 6 showed why physical clocks can disagree.

Therefore a system using wall-clock last-writer-wins should be explicit about:

- clock assumptions;
- tie breaking;
- whether data loss from concurrent updates is acceptable.

The phrase “last” may mean **largest chosen timestamp**, not actual causal last event.

---

## 25. Replication lag turns load balancing into a consistency mechanism

Suppose read traffic is balanced across three replicas with different update lag.

```text
R1 fresh
R2 100 ms behind
R3 2 s behind
```

A client may observe:

```text
version 10
version 12
version 9
```

simply because requests hit different replicas.

Thus Chapter 8 service discovery/load balancing and Chapter 9 consistency are not independent topics.

A system must decide whether any healthy replica may answer any read.

---

## 26. Linearizable reads often need authority or validation

A replica cannot safely return a “current” value merely because it has recently received updates.

Depending on protocol, a linearizable read may require:

- reading through the current leader;
- confirming leadership/term authority;
- obtaining a quorum;
- using leases with justified timing assumptions;
- another mechanism proving that no later committed write must be observed.

Chapter 7/Chapter 10 develop this in the context of consensus-backed state machines.

The lesson here is simple:

> **Strong read semantics require evidence about current ordering/authority, not just a local copy.**

---

## 27. Partition behavior must be part of the API contract

Suppose N=3 replicas split:

```text
R1 R2   X   R3
```

What should R3 do with a write request?

Possible policies:

### Reject/block the write

Preserve one-authority/quorum safety but reduce availability to clients connected only to R3.

### Accept the write independently

Remain available, but create divergent state that later requires reconciliation.

Both designs can be legitimate for different applications.

The unacceptable design is leaving the behavior implicit.

---

## 28. CAP is about partitions forcing a choice between particular guarantees

The CAP theorem is often reduced incorrectly to:

> “Pick any two of consistency, availability, partition tolerance.”

That slogan hides important definitions.

The Gilbert-Lynch formulation concerns systems faced with network partitions and specific notions of:

- consistency roughly corresponding to atomic/linearizable behavior;
- availability requiring every request to a non-failing node eventually receive a response;
- partition tolerance meaning the system must continue to satisfy its specification despite message loss/partition between nodes.

The useful engineering interpretation is:

> **When communication is partitioned, a replicated service cannot simultaneously guarantee both linearizable single-copy behavior and an always-successful response from every reachable non-failing replica.**

Outside partitions, systems still make many latency, durability, and consistency trade-offs. CAP does not classify all design choices.

---

## 29. Partition tolerance is not normally optional in a distributed system

If a system uses a real network, communication failures can happen whether the designer wants them or not.

Therefore “choose CA and ignore P” is usually a misleading way to reason about a system that must operate across independently failing nodes.

A better question is:

> When the partition happens, what do we do?

- refuse some operations;
- serve stale reads;
- accept divergent writes;
- use a quorum;
- degrade to read-only;
- queue work for later.

Make the behavior testable.

---

## 30. Availability is operation-specific

During a partition, a system may still provide:

```text
GET -> available
PUT -> unavailable
```

or:

```text
local reads -> available but possibly stale
strong reads -> unavailable
```

Thus a project should avoid one binary “available/unavailable” label when different operations have different guarantees.

This is especially important in final-project evaluation.

---

## 31. Durability acknowledgement must name the replica condition

Consider three storage nodes.

A project says:

> “A successful PUT is durable.”

Ask:

> Durable against what?

A precise contract might be:

> A successful PUT has been persisted on at least two distinct configured storage nodes and survives permanent loss of any one of them.

Now the claim has:

- acknowledgement condition;
- failure model;
- measurable invariant.

This is exactly the common project baseline.

---

## 32. Read consistency and write durability can be configured separately

A system could synchronously persist a write to two replicas for durability, then still allow stale reads from a third lagging replica.

Therefore:

```text
write durability != read linearizability
```

Likewise, a system could route all reads through a leader for strong semantics while asynchronously backing up data in a way that risks recent acknowledged writes under catastrophic failure.

Do not infer one property from the other.

---

## 33. Worked history — stale read after completed write

Initial state:

```text
x=0 on R1,R2
```

History:

```text
C1 -> R1: write x=1
R1 -> C1: OK
C2 -> R2: read x
R2 -> C2: 0
```

Assume C2's read begins after C1 receives OK.

This history violates linearizability if the logical register is claimed to be linearizable.

Could it be acceptable under asynchronous eventual replication?

Yes, if the contract permits stale reads and the replicas later converge.

Same execution, different consistency contract.

---

## 34. Worked history — overlapping read

Initial state x=0.

```text
C1: write x=1 ------------- OK
C2:       read x -> 0
```

The read overlaps the write.

A linearizable explanation may place the read before the write's linearization point.

Therefore returning 0 is not automatically a violation.

You must reason from operation intervals.

---

## 35. Worked history — read-your-writes violation

```text
C1 -> R1: write x=5 -> OK
C1 -> R2: read x -> 4
```

Even if the system only promises eventual convergence globally, it may choose to provide a read-your-writes session guarantee.

This history violates that session guarantee.

A useful repair might be to route C1 to a replica known to have version 5 or newer.

---

## 36. Worked history — monotonic-read violation

```text
C1 -> R1: read x(version=12)
C1 -> R2: read x(version=9)
```

The client has observed a later version and then an earlier version.

This violates monotonic reads.

The values themselves may both be legitimate replica states at different times. The violation is about **session observation order**.

---

## 37. Worked history — concurrent writes under partition

Initial state:

```text
x=0
```

Partition:

```text
R1   X   R2
```

Client A writes:

```text
x=1 at R1
```

Client B writes:

```text
x=2 at R2
```

Both sides acknowledge.

After healing, there is no single obvious value unless the protocol defines ordering or conflict resolution.

Possible policies:

- choose one via total-order metadata;
- reject one retrospectively (often difficult/user-visible);
- merge if data type permits;
- preserve siblings/conflicts for application resolution.

This is why availability during partition has consequences after the partition.

---

## 38. Worked quorum history

N=3, W=2, R=2.

Write x=8 reaches R1 and R2; R3 misses it.

Read consults R2 and R3:

```text
R2 -> x=8, version 11
R3 -> x=7, version 10
```

The read quorum intersects the completed write quorum at R2.

If version/order metadata lets the coordinator identify version 11 as newer, it can return x=8 and optionally repair R3.

But notice the hidden assumptions:

- version metadata is trustworthy/comparable;
- write completion is defined consistently;
- concurrent writes have a rule;
- membership N is stable or safely reconfigured.

The arithmetic alone is not the whole protocol.

---

## 39. Membership changes complicate quorum reasoning

Suppose a three-replica set changes from:

```text
{A,B,C}
```

to:

```text
{C,D,E}
```

If different clients use different membership views, quorums chosen from the two configurations may fail to intersect in the intended way.

Safe reconfiguration therefore becomes a coordination problem.

This is another reason Chapter 8 discovery/membership and Chapter 7 consensus are connected to storage correctness.

The Chapter 9 lab can keep membership static; you should still know this boundary.

---

## 40. Consistency testing analyzes histories, not only final state

Suppose after a test all replicas end at:

```text
x=10
```

Does that prove linearizability?

No.

During execution, clients may have observed forbidden intermediate histories.

Correctness analysis therefore records:

```text
operation invocation
operation response
client identity
value/version
relevant timing/causal metadata
```

and checks the **history** against the claimed model.

Tools such as Jepsen are valuable because they combine fault injection with history checking rather than testing only final convergence.

---

## 41. Eventual convergence can coexist with bad intermediate behavior

Two replicas may diverge during a partition and later converge perfectly.

That proves a convergence property under the tested scenario.

It does not prove:

- users never saw stale data;
- no update was lost;
- read-your-writes held;
- operations were linearizable;
- duplicates never occurred.

Be precise about which property each experiment validates.

---

## 42. Replication has a cost even without failures

Normal-case replication consumes:

- network bandwidth;
- storage;
- CPU/serialization;
- coordination messages;
- acknowledgement latency;
- background repair work.

Therefore replication factor should follow a failure/durability goal, not a reflexive “more copies is better” rule.

A five-replica system may provide lower write availability than a three-replica system if the write policy requires all five.

---

## 43. Geographic replication magnifies latency decisions

A synchronous copy across a distant region can add significant propagation/queueing time to every write.

An asynchronous remote copy lowers latency but creates a window of lag or potential loss depending on the local durability model.

This connects directly to the networking course:

> Distance, RTT, and congestion become consistency/availability design inputs.

---

## 45. Historical perspective — from primary copies to highly available stores

Replication predates modern cloud systems. File systems, databases, telecom systems, and fault-tolerant computers all explored keeping redundant copies.

What changed at Internet/cloud scale was the combination of:

- large failure domains;
- geographic distribution;
- commodity machines;
- high request volume;
- application-specific tolerance for stale/conflicting state.

Systems such as Amazon Dynamo made highly available, leaderless-style replication and eventual conflict handling widely discussed in mainstream distributed-system design.

The historical lesson is not that one architecture replaced another.

It is that **different applications choose different points in the consistency/availability/latency space**.

---

## 46. Common mistakes

### Mistake 1 — “Replicated” means strongly consistent

Copies can disagree temporarily or permanently depending on protocol.

### Mistake 2 — “Three copies” means acknowledged writes survive one failure

Only if acknowledgement required appropriate durable copies before success.

### Mistake 3 — quorum arithmetic alone guarantees linearizability

Intersection is necessary for many quorum protocols but ordering/version/operation rules still matter.

### Mistake 4 — eventual consistency means random or incorrect forever

It usually includes some convergence expectation once updates and failures stop, but intermediate guarantees must still be specified.

### Mistake 5 — CAP means choose any two forever

The key tension appears under partition and depends on specific definitions of consistency and availability.

### Mistake 6 — partition tolerance can simply be turned off

Real distributed communication can fail; the design still needs defined partition behavior.

### Mistake 7 — last-writer-wins identifies actual causal last writer

Clock-based ordering can be arbitrary under skew/concurrency.

### Mistake 8 — final replica equality proves strong consistency

Intermediate client-visible history matters.

### Mistake 9 — read replicas are free performance

Replica lag can expose stale or non-monotonic observations.

### Mistake 10 — recovery is only reconnecting the process

State synchronization and safe reintegration may still be required.

---

## Laboratory transition

The Chapter 9 laboratory builds a three-replica key/value service and intentionally creates histories that look different under different guarantees.

You will compare at least two replication strategies and produce:

- a stale-read history;
- a completed-write durability test;
- a quorum read/write experiment;
- a partition with explicitly chosen write behavior;
- a recovery/repair trace;
- a client-centric consistency violation and repair;
- a short history classification under linearizable, sequential, causal, or eventual expectations.

The goal is not to build a production database.

It is to learn to make this sentence precise:

> “Our replicas are consistent.”

---

## Chapter summary

1. **Replication provides availability, durability, locality, and capacity only under explicit protocols and failure assumptions.**
2. **Durability and consistency are separate properties.**
3. **Primary/backup simplifies write ordering but creates authority/failover questions.**
4. **Synchronous replication increases acknowledgement dependence on remote replicas; asynchronous replication creates lag/loss windows.**
5. **Consistency models are constraints on observable histories.**
6. **Linearizability respects real-time precedence for non-overlapping operations; sequential consistency preserves process order without the same real-time constraint.**
7. **Causal consistency preserves cause-before-effect while allowing freedom among concurrent operations.**
8. **Eventual consistency/convergence does not fully specify intermediate client observations.**
9. **Client-centric guarantees such as read-your-writes and monotonic reads can improve usability without global linearizability.**
10. **Quorums use overlap to connect reads and writes, but arithmetic is only one part of a correct protocol.**
11. **Partitions force explicit choices about which operations remain available and what state may diverge.**
12. **CAP is best understood as a partition-time incompatibility between particular consistency and availability guarantees, not a universal “pick two” menu.**
13. **Recovery/anti-entropy is part of replication correctness.**
14. **Testing consistency requires histories, not only final replica equality.**

The next modules will ask how a set of replicas can agree on one evolving operation order and execute it as a fault-tolerant service.

<div class="ds-next-action">
  <span>Core reading complete</span>
  <strong>Next required step · Guided practice</strong>
  <a href="../guided-practice/">Start guided practice →</a>
</div>
