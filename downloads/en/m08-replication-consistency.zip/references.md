> **Reference view.** This page is optional context; return to the [Lesson](../lesson/) for the required path.

## Essential

- **●● Designing Data-Intensive Applications** — Martin Kleppmann. [book](https://dataintensive.net/)

## Recommended

- **●●● Brewer's Conjecture and the Feasibility of Consistent, Available, Partition-Tolerant Web Services** — Seth Gilbert and Nancy Lynch. [paper](https://users.ece.cmu.edu/~adrian/731-sp04/readings/GL-cap.pdf)

## Advanced

- **●●● Dynamo: Amazon's Highly Available Key-value Store** — DeCandia et al.. [paper](https://www.allthingsdistributed.com/files/amazon-dynamo-sosp2007.pdf)

## Tools & Practice

- **●●● Jepsen** — Kyle Kingsbury et al.. [testing resource](https://jepsen.io/)

## Explore

- **●●● 6.5840 Distributed Systems** — MIT PDOS. [course](https://pdos.csail.mit.edu/6.824/)
