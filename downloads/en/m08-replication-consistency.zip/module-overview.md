<p class="ds-book-part">Part III — Naming and Replicated State</p>
<p class="ds-module-kicker">Chapter 9</p>
<div class="ds-progress" aria-label="Course progress">
  <div class="ds-progress-meta">
    <span>Chapter 9 of 12</span>
    <span>75% through the course sequence</span>
  </div>
  <div class="ds-progress-track"><span style="width: 75%"></span></div>
</div>
<p class="ds-guiding-question">When several nodes hold the same logical data, which histories may a client observe?</p>

Replicate a small service and create stale reads, conflicting writes, and a partition. Use the resulting histories to define the guarantee instead of starting from labels. Then compare stronger coordination with convergence-oriented designs such as CRDTs.

## Key ideas

- reasons to replicate
- primary/backup and leaderless replication
- synchronous and asynchronous propagation
- quorums
- linearizability
- sequential and causal consistency
- client/session guarantees
- eventual consistency and convergence
- CAP trade-offs
- CRDT intuition and merge laws

## Laboratory transition

Run a replicated key/value service under lag, conflict, and partition. Classify the observed histories, then explain whether convergence alone would be sufficient for the application invariant.

## Start here

> **Before you read:** A write returns OK from replica R1. A later read from R2 returns the old value. Is the system wrong? State the guarantee you assumed before answering.

**Bring forward:** Causality, quorum intuition, naming/membership, and explicit client operation histories.

**This chapter builds toward:** The ability to classify histories and choose between coordinated replication and convergence-oriented data semantics.

<div class="ds-workload ds-workload-three" aria-label="Core workload">
  <div><span>Core · read</span><strong>Cohesive lesson</strong><small>45 min–1 h</small></div>
  <div><span>Core · practice</span><strong>Practice target + check</strong><small>1 h–1 h 30 min</small></div>
  <div><span>Core · lab</span><strong>Evidence laboratory</strong><small>2 h 30 min–3 h 30 min · 9 public tests + evidence</small></div>
</div>
<p class="ds-workload-note"><strong>Practice / challenge bank:</strong> The guided-practice and knowledge-check pages identify the exact core cases. The remaining cases, optional extensions, and advanced references are not part of the core workload unless your instructor assigns them.</p>
<p class="ds-workload-note"><strong>Core scope:</strong> Use the lab's explicit core path: Steps 1–7, one client-session anomaly from Step 8 or 9, then Steps 10–17. The second session anomaly is retrieval/extension work.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Read lesson →</a>
  <a class="ds-secondary-action" href="lab/">Open laboratory</a>
</div>
<p class="ds-offline-link"><span>OFFLINE</span><a href="../../downloads/en/m08-replication-consistency.zip" download>Download chapter + laboratory for offline study (.zip)</a></p>

## What you will learn

- Explain why replication creates consistency questions rather than only reliability benefits.
- Classify observable histories under linearizable, sequential, causal, session, and eventual guarantees.
- Compare primary/backup, synchronous/asynchronous, quorum, and leaderless replication.
- Create and analyze stale-read, conflicting-write, and partition histories.
- Explain when convergence-oriented merge rules such as CRDTs fit the application invariant.

## Learn by working the question

1. Write your answer to **Start here** before opening the full lesson.
2. Read until the next prediction or trace, then stop and work it out before revealing the explanation.
3. Treat guided practice as a **practice bank**, not a speed worksheet. Work the core traces until you can meet the chapter's Practice target; return to the remaining cases for retrieval practice or instructor-assigned work.
4. Use the knowledge check to find gaps, then enter the laboratory with a falsifiable prediction and name the evidence that could contradict it.
5. Finish by explaining what the experiment established, what it did not establish, and how the result changes the evolving service.

<nav class="ds-sequence" aria-label="Course sequence">
<a class="ds-sequence-link" href="../m04-architecture-discovery/">← Naming, Discovery, and Decentralized Lookup</a>
<a class="ds-sequence-link next" href="../m07-failures/">Fault Tolerance I — Failure Models, Resilience, and Recovery →</a>
</nav>
