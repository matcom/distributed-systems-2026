# Laboratory — Replication and Consistency Models

## Target

Build a small three-replica key/value service, compare at least two replication policies, intentionally create stale reads and conflicting histories, then classify what the system actually guarantees.

The project is not to build a production database. The goal is to make claims such as “durable,” “linearizable,” “eventually consistent,” or “available during partition” experimentally precise.

## Core completion path

Complete Steps 1–7, **choose one** client-session anomaly from Step 8 or Step 9, then complete Steps 10–17.

If time permits, run the second session-anomaly case as an extension. The goal is to reason correctly about a client-visible history, not to maximize the number of nearly identical traces.

## Required topology

Use three independent service processes:

```text
R1   R2   R3
```

and one or more clients.

The service must support a minimal interface equivalent to:

```text
PUT key value request_id
GET key
STATE key
```

Every stored version should expose enough metadata for the experiment to distinguish replica states.

A simple monotonically increasing primary version, `(epoch,counter)`, or another documented comparable version is sufficient for the baseline lab. Do not use unsynchronized wall-clock timestamps as the only correctness mechanism.

## Required replication policies

Implement or configure at least two small policies.

A recommended pair is:

### Policy A — asynchronous primary/backup

- one primary accepts writes;
- primary acknowledges according to an explicitly stated condition;
- backups receive writes later/asynchronously;
- reads may be directed to individual replicas for experiments.

### Policy B — quorum-style replication

For N=3, use a documented choice such as:

```text
W=2
R=2
```

A different pair is acceptable if its properties are justified.

The lab does not yet require full automatic leader election; a statically configured primary is acceptable. Chapter 7 addresses consensus.

## Step 1 — Establish single-replica semantics

Run one logical register/key without replication.

Record a clean history:

```text
PUT x 1
GET x -> 1
```

Capture invocation and response events with:

- client ID;
- operation ID/request ID;
- target replica(s);
- value/version;
- invocation time;
- response time.

This becomes the baseline history format used in later steps.

## Step 2 — Start three replicas

Start R1/R2/R3 with clearly separate state directories or in-memory state identities.

Record:

- node ID;
- incarnation ID;
- role;
- endpoint;
- current version for key `x`.

Verify that clients can address replicas individually for experiments even if the normal service path uses one logical endpoint.

## Step 3 — Asynchronous stale read

Use Policy A.

Artificially delay replication from the primary to one backup.

Run:

```text
C1 -> primary: PUT x=1
primary -> C1: OK
C2 -> delayed backup: GET x
```

Arrange the experiment so the read begins after C1 receives `OK` but before the backup has applied the write.

Record the complete operation intervals.

If the backup returns the older value, classify the history:

- under a linearizable-register claim;
- under an asynchronous eventually convergent claim.

The answer must refer to the history, not simply the architecture name.

## Step 4 — Acknowledgement/durability test

State Policy A's acknowledgement rule precisely.

Example variants:

```text
A1: acknowledge after primary memory only
A2: acknowledge after primary durable state
A3: acknowledge after primary + one backup durable state
```

Use the variant appropriate to the implementation.

Then simulate loss of one storage/service node immediately after acknowledgement.

Answer:

- Is the acknowledged value recoverable?
- Which exact failure did the experiment test?
- Does this satisfy the course's common durable-acknowledgement baseline?

Do not claim physical-disk durability if the entire experiment uses volatile memory. State the actual boundary.

## Step 5 — Synchronous/quorum write latency

Use Policy B or strengthen the primary acknowledgement rule so success waits for multiple replicas.

Measure normal write latency under:

```text
no added delay
50 ms delay to one replica
300 ms delay to one replica
one replica unavailable
```

Explain which replica responses are on the critical path to acknowledgement.

## Step 6 — Quorum read

Create:

```text
R1: x=5 version=10
R2: x=5 version=10
R3: x=4 version=9
```

Perform an R=2 read that includes one fresh and one stale replica.

The client/coordinator must use the documented version rule to select the result.

Record:

- which replicas participated;
- versions returned;
- result selected;
- whether repair was triggered.

## Step 7 — Read repair

If supported, repair the stale replica discovered during the quorum read.

Measure:

```text
repair detection time
repair completion time
```

Then verify replica state.

If the implementation does not perform automatic read repair, implement a small explicit repair step or analyze the required mechanism.

## Step 8 — Client-session option A: read-your-writes violation

Using a lagging replica, create:

```text
C1 writes version V
C1 later reads an older version from another replica
```

This violates read-your-writes.

Implement one repair strategy, for example:

- sticky primary/session routing;
- client carries minimum required version;
- quorum read;
- wait until selected replica catches up.

Repeat the history and show the session guarantee now holds for the tested execution.

## Step 9 — Client-session option B: monotonic-read violation

Create a session that reads:

```text
version 12
then version 9
```

through replica switching.

Explain why this is distinct from read-your-writes.

Then implement or describe a mechanism that prevents backward session versions.

## Step 10 — 2+1 network partition

Partition:

```text
R1 R2   X   R3
```

All processes should remain alive.

Test reads and writes from clients attached to each side.

The submission must state expected behavior **before** running the experiment.

For a quorum-oriented strongly consistent policy, the expected result may be:

```text
majority side: can form quorum
minority side: refuses strong write
```

For an explicitly available/conflict-resolving policy, both sides may accept updates, but Phase 10/11 must then preserve both conflicting states until a reconciliation rule runs.

Do not switch policies after seeing the result merely to make the test pass.

## Step 11 — Conflicting writes under partition

If the chosen policy allows writes on both sides, create two conflicting updates to the same key.

Record the version metadata.

After healing, state how the implementation resolves or represents the conflict.

Possible educational policies include:

- deterministic version/epoch order;
- preserve siblings for explicit resolution;
- application merge for a mergeable data type.

If the chosen strong/quorum policy correctly refuses the minority write, document that behavior instead and explain which availability was sacrificed.

## Step 12 — Heal and recover

Remove the partition.

Measure distinct milestones:

```text
connectivity restored
membership/health restored
missing version detected
state transferred/reconciled
replica safe for claimed reads
```

Define which milestone counts as **replica recovery time** in your report.

## Step 13 — History classification

Select at least four recorded histories and classify each against relevant guarantees.

Include:

1. one non-overlapping write/read pair;
2. one overlapping write/read pair;
3. one session read-your-writes or monotonic-read case;
4. one partition history.

For linearizability, construct or reject a legal single-copy order that respects real-time precedence.

Do not classify only from final values.

## Step 14 — CAP statement

Using your actual partition experiment, write one operational CAP statement.

Good form:

> During a partition that separates one replica from the other two, strongly consistent writes sent only to the isolated replica are rejected because it cannot obtain the required quorum; this preserves the single-copy write rule at the cost of write availability for clients connected only to that replica.

Avoid:

> “We chose CP.”

The operational statement is more informative.

## Step 15 — Compare the two replication policies

Summarize:

| Property | Policy A | Policy B |
|---|---|---|
| normal write latency | | |
| stale-read behavior | | |
| acknowledged-write survival | | |
| one-replica failure | | |
| minority partition writes | | |
| recovery mechanism | | |
| implementation complexity | | |

No policy is expected to dominate every row.

## Step 16 — Convergence-oriented mini-experiment

Before translating the result to the final project, implement or use a small local state-based grow-only counter.

Use at least three logical replicas. Each replica increments only its own component and merges by component-wise maximum.

Create this sequence:

1. disconnect the replicas logically;
2. increment different replicas independently;
3. exchange states in different orders;
4. deliver at least one state twice;
5. verify all replicas converge after all states are exchanged.

Record the merge order and final states.

Then test the important limit: write one invariant that this data type **does not** guarantee. Do not report “CRDT = no coordination needed.” Report the narrower claim that the merge is order/duplication tolerant for the operations represented by this data type.

If your final project has no mergeable state, say so and explain why coordinated replication is a better fit.

## Step 17 — Final-project translation

Choose one final-project topic and identify what its “replicated state” would be.

Examples:

- P10 media streaming: media chunks vs catalog metadata;
- P13 event log: partitions, offsets, metadata;
- P18 authoritative DNS: replicated zone state, stale-replica behavior, and a stronger update path than ordinary query serving;
- P20 edge cache: origin truth vs stale edge copies.

State which consistency guarantee that state actually needs rather than reflexively choosing linearizability for everything.

## Transparent-test target

Executable public tests now live under `tests/official/`, with deterministic quorum/version/session/history helpers in `starter/src/`. They verify portable consistency invariants; real replica lag, durability, partition, repair, and convergence behavior still require the controlled experiments above.

The public cases are documented in `tests/official/README.md`. `make test` runs only visible official tests plus student cases under `tests/student/`.

No hidden tests are planned.

## AI use

AI assistants and coding agents are permitted.

For the required AI audit, give an assistant one operation history and ask it whether the history is linearizable. Verify the answer manually by constructing a legal sequential history or showing why none exists.

Record any unsupported use of wall-clock order, final-state reasoning, or consistency slogans.

## Report

Complete `REPORT.md` with:

- both replication policies;
- precise acknowledgement conditions;
- histories with invocation/response intervals;
- stale-read and session-consistency evidence;
- quorum calculations;
- partition behavior;
- recovery/repair metrics;
- operational CAP statement;
- policy comparison;
- AI-audited history classification.