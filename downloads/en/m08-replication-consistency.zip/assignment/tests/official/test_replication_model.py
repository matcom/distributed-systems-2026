import unittest

from replication_model import (
    VersionedValue,
    newest,
    satisfies_minimum,
    stale_read_is_linearizable,
    write_quorum_available,
)


class ReplicationModelTests(unittest.TestCase):
    def test_two_of_three_can_satisfy_w2(self):
        self.assertTrue(write_quorum_available(2, 2))
        self.assertTrue(write_quorum_available(3, 2))

    def test_one_of_three_cannot_claim_w2(self):
        self.assertFalse(write_quorum_available(1, 2))

    def test_newest_selects_highest_version(self):
        values = [VersionedValue(1, "old"), VersionedValue(3, "new"), VersionedValue(2, "mid")]
        self.assertEqual(newest(values), VersionedValue(3, "new"))

    def test_empty_newest_is_none(self):
        self.assertIsNone(newest([]))

    def test_conflicting_equal_highest_version_is_not_silently_resolved(self):
        with self.assertRaises(ValueError):
            newest([VersionedValue(5, "A"), VersionedValue(5, "B")])

    def test_session_minimum_rejects_older_version(self):
        self.assertFalse(satisfies_minimum(VersionedValue(4, "x"), 5))
        self.assertTrue(satisfies_minimum(VersionedValue(5, "x"), 5))
        self.assertTrue(satisfies_minimum(VersionedValue(6, "x"), 5))

    def test_completed_write_followed_by_stale_read_is_not_linearizable(self):
        self.assertFalse(stale_read_is_linearizable(True, read_version=1, written_version=2))

    def test_overlapping_read_may_return_old_version(self):
        self.assertTrue(stale_read_is_linearizable(False, read_version=1, written_version=2))

    def test_completed_write_followed_by_new_version_is_linearizable(self):
        self.assertTrue(stale_read_is_linearizable(True, read_version=2, written_version=2))


if __name__ == "__main__":
    unittest.main()
