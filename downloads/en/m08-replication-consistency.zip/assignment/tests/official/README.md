# Planned Public Tests — M08

Executable public tests are provided in this directory together with the starter replication/consistency adapter under `starter/src/`. They cover deterministic quorum, version-selection, session-minimum, and simple history-classification invariants; multi-process replication experiments remain evidence-based. No hidden cases are planned.

## Basic replication cases

1. A successful single-replica PUT can be read from that replica.
2. The configured primary/backup policy propagates versions to backups according to its documented mode.
3. The asynchronous policy can expose a controlled stale backup before replication catches up.
4. The synchronous/quorum policy does not acknowledge until its documented write condition is met.

## Version and read cases

5. Replica state exposes comparable version metadata according to the declared version scheme.
6. A quorum read selects the newest unambiguous version among the participating replicas.
7. A stale replica can be repaired to the selected version where read repair is implemented.
8. The implementation does not use unsynchronized wall-clock time as the sole correctness rule for ordering concurrent versions.

## Durability cases

9. A write claimed durable against one configured storage-node failure remains recoverable after one participating storage/service node is removed, within the actual persistence boundary of the lab.
10. The report/test metadata states whether persistence is memory-only, process-durable, or storage-durable rather than overstating the result.

## Client-centric cases

11. The initial directed-replica scenario can demonstrate a read-your-writes violation where intentionally configured.
12. The repaired session policy prevents returning a version older than the client's required minimum.
13. A monotonic-read policy does not let one session move from a known newer version to an older version.

## Partition cases

14. In an N=3, W=2 configuration, a 2-replica side can form the required write quorum.
15. A 1-replica side cannot claim a W=2 successful write.
16. If an alternate explicitly available/conflict-preserving policy is implemented, both partition sides retain enough version/conflict information for later reconciliation rather than silently overwriting one update.
17. Healing a partition eventually restores the declared convergence/repair condition.

## History cases

18. The public stale-read history is identified as non-linearizable when the read begins after the successful write response yet returns the previous value.
19. The public overlapping history is not rejected merely because a read returns the old value while overlapping a write.
20. Final replica equality is not used as the sole test for linearizable history correctness.

Students should add at least one case under `tests/student/` for a consistency/session/failure history not included above.
