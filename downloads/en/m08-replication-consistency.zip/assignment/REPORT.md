# M08 Laboratory Report — Replication and Consistency Models

## 1. Environment and replica topology

Record all node IDs, roles, endpoints, state locations, version representation, and exact startup commands.

## 2. Replication policies

Describe Policy A and Policy B precisely.

For each, state:

- write target(s);
- acknowledgement condition;
- read target(s);
- version-selection rule;
- repair behavior;
- expected partition behavior.

## 3. Baseline history

Provide one single-replica operation history with invocation and response times.

## 4. Stale-read history

Record the asynchronous replication experiment.

| Operation | Client | Target | Invocation | Response | Value/version |
|---|---|---|---:|---:|---|
| | | | | | |

Classify the history under the claimed linearizable and eventual/convergent expectations.

## 5. Durable acknowledgement

State exactly what persisted before the write returned success.

Describe the node-loss experiment and whether the value remained recoverable.

State the actual durability boundary demonstrated by the environment.

## 6. Replication latency

| Added fault | Policy | Write latency | Replicas acknowledged | Result |
|---|---|---:|---|---|
| none | | | | |
| 50 ms delay | | | | |
| 300 ms delay | | | | |
| one replica unavailable | | | | |

Explain which communication is on the acknowledgement critical path.

## 7. Quorum calculation

Record N, R, W and evaluate:

```text
R + W > N
2W > N
```

Explain what those intersections provide and what they do not provide by themselves.

## 8. Quorum read and repair

List replica versions returned, chosen result, and any read-repair action.

## 9. Read-your-writes / monotonic-read experiment

Provide the violating history, the session guarantee affected, the repair mechanism, and the repeated history after repair.

## 10. Partition experiment

Describe the 2+1 topology and complete:

| Operation | Majority side | Minority side | Reason |
|---|---|---|---|
| read | | | |
| write | | | |

State the expected policy before giving the observed result.

## 11. Conflicting-write or refused-write evidence

If both sides accept writes, show the concurrent/conflicting versions and reconciliation rule.

If the minority refuses writes, show the refusal and explain the safety property preserved.

## 12. Recovery

Record separate timestamps/milestones for:

- connectivity restored;
- peer/replica healthy;
- missing state identified;
- repair/reconciliation completed;
- replica eligible for the claimed service level.

Define the recovery metric used.

## 13. History classification

For at least four histories, state whether each satisfies or violates the relevant model and justify from operation intervals/causal order rather than from final state alone.

## 14. Operational CAP statement

Write a concrete statement about the exact read/write behavior observed during your partition. Do not submit only a two-letter CAP label.

## 15. Policy comparison

| Property | Policy A | Policy B |
|---|---|---|
| normal write latency | | |
| stale reads | | |
| durable acknowledgement | | |
| one-node loss | | |
| minority partition | | |
| repair | | |
| complexity | | |

## 16. AI audit

- tool, if any:
- history supplied:
- model classification:
- manual linearization/rejection:
- incorrect or unsupported reasoning found:

## 17. Final-project translation

Choose one final project and state:

- what state would be replicated;
- desired durability;
- desired read/write consistency;
- behavior during partition;
- expected repair mechanism.

## 18. Conclusion

Answer the guiding question: **When several nodes store the same logical data, what does it mean for the copies to agree?**
