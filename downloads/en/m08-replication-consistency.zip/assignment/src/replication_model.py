"""Small consistency/quorum model for M08 public tests."""

from dataclasses import dataclass
from typing import Iterable, Optional


@dataclass(frozen=True)
class VersionedValue:
    version: int
    value: object


def write_quorum_available(reachable_replicas: int, write_quorum: int) -> bool:
    """Return whether the currently reachable replicas can satisfy W."""
    raise NotImplementedError("TODO: implement write-quorum availability")


def newest(values: Iterable[VersionedValue]) -> Optional[VersionedValue]:
    """Return the unique highest-version value, or None for empty input.

    If two different values claim the same highest version, raise ValueError
    rather than silently resolving an ambiguous conflict.
    """
    raise NotImplementedError("TODO: implement version selection")


def satisfies_minimum(candidate: VersionedValue, minimum_version: int) -> bool:
    """Client-session helper used for read-your-writes/monotonic reads."""
    raise NotImplementedError("TODO: enforce the client's minimum version")


def stale_read_is_linearizable(write_completed_before_read: bool, read_version: int, written_version: int) -> bool:
    """Classify the simple one-write/one-read history used in the lab.

    If a write completed before the read began, returning an older version is
    non-linearizable. Overlap leaves room for either old or new value.
    """
    raise NotImplementedError("TODO: classify the simple history")
