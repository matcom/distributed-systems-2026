> **Vista de referencia.** Esta página ofrece contexto opcional; vuelve a la [Lección](../lesson/) para la ruta obligatoria.

## Esencial

- **●● Designing Data-Intensive Applications** — Martin Kleppmann. [book](https://dataintensive.net/)

## Recomendado

- **●●● Brewer's Conjecture and the Feasibility of Consistent, Available, Partition-Tolerant Web Services** — Seth Gilbert and Nancy Lynch. [paper](https://users.ece.cmu.edu/~adrian/731-sp04/readings/GL-cap.pdf)

## Avanzado

- **●●● Dynamo: Amazon's Highly Available Key-value Store** — DeCandia et al.. [paper](https://www.allthingsdistributed.com/files/amazon-dynamo-sosp2007.pdf)

## Herramientas y práctica

- **●●● Jepsen** — Kyle Kingsbury et al.. [testing resource](https://jepsen.io/)

## Explora

- **●●● 6.5840 Distributed Systems** — MIT PDOS. [course](https://pdos.csail.mit.edu/6.824/)
