<p class="ds-book-part">Parte III — Nombres y estado replicado</p>
<div class="ds-lesson-banner">
  <div><span>Paso del curso</span><strong>Capítulo 9</strong></div>
  <div><span>Lectura esencial</span><strong>45 min–1 h</strong></div>
  <div><span>Ruta obligatoria</span><strong>Leer → Objetivo de práctica → Comprobar → Laboratorio</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 9 de 12</span>
    <span>75% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 75%"></span></div>
</div>

> **Pregunta guía:** Cuando varios nodos mantienen los mismos datos lógicos, ¿qué historiales puede observar un cliente?

## Antes de leer

> Una escritura devuelve OK desde la réplica R1. Una lectura posterior desde R2 devuelve el valor anterior. ¿Está mal el sistema? Indica primero qué garantía asumiste.

Escribe primero una respuesta breve. No necesitas acertar todavía: necesitas una predicción que puedas revisar a medida que el capítulo te dé mejores modelos y evidencia.

**Usa lo que ya sabes:** Causalidad, intuición sobre quórums, nombres/membresía e historiales explícitos de operaciones de cliente.

## Mapa de carga de trabajo

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>45 min–1 h</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>1 h–1 h 30 min</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>2 h 30 min–3 h 30 min · 9 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<p class="ds-workload-note"><strong>Alcance esencial:</strong> Usa la ruta esencial explícita del laboratorio: Pasos 1–7, una anomalía de sesión entre el Paso 8 o 9, y después Pasos 10–17. La segunda anomalía queda como práctica de recuperación o extensión.</p>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../../downloads/es/m08-replication-consistency.zip" download>Descargar lección + práctica + laboratorio para estudio sin conexión (.zip)</a></p>

## Por qué importa este capítulo

Replicar parece una idea simple de fiabilidad:

> Conserva más de una copia.

Pero en cuanto dos nodos pueden almacenar los mismos datos lógicos aparece una nueva pregunta:

> **¿Qué copia representa la verdad?**

Supón que un cliente escribe:

```text
x = 7
```

en la réplica A.

La réplica B todavía almacena:

```text
x = 6
```

durante 200 ms.

En ese intervalo:

- ¿es incorrecto el sistema?
- ¿puede un lector observar 6?
- ¿debe un escritor esperar hasta que B se actualice?
- ¿qué ocurre si A cae antes de que B reciba el nuevo valor?
- ¿qué pasa si A y B quedan particionadas y ambas siguen aceptando escrituras?

La palabra *replicado* no responde esas preguntas.

Necesitamos un **modelo de consistencia**, un protocolo de replicación, un modelo de fallos y una política de disponibilidad explícitos.

La pregunta guía es:

> **Cuando varios nodos almacenan los mismos datos lógicos, ¿qué significa que las copias estén de acuerdo?**

Este capítulo desarrolla el vocabulario necesario para responder con precisión.

---

## 1. ¿Por qué replicar?

La replicación puede perseguir objetivos diferentes.

### Disponibilidad

Si una copia deja de estar disponible, otra puede atender la solicitud.

### Durabilidad

Si falla un dispositivo o proceso, datos ya reconocidos pueden sobrevivir en otra copia.

### Capacidad de lectura

Varias réplicas pueden responder lecturas en paralelo.

### Localidad geográfica

Las copias pueden colocarse cerca de los usuarios.

### Aislamiento de fallos

Copias en dominios de fallo independientes reducen la probabilidad de pérdida simultánea.

### Flexibilidad operacional

El sistema puede seguir ofreciendo servicio mientras una réplica se repara, actualiza o mueve.

Todos esos beneficios son reales, pero cada copia adicional con capacidad de escritura introduce preguntas de coordinación.

> **Detente y predice.** Tres réplicas contienen exactamente el mismo valor a las 10:00. ¿Demuestra eso que seguirán siendo consistentes después de que dos clientes escriban concurrentemente a las 10:01?

No. Que el estado coincida en un instante no dice nada sobre el protocolo que gobierna los cambios futuros.

---

<aside class="ds-book-note ds-history">
  <span class="ds-book-note-label">Historia</span>
  <strong>Por qué los sistemas distribuidos necesitaban un concepto de orden que no dependiera de relojes sincronizados</strong>
  <p>La relación sucedió-antes de Lamport desplazó la pregunta desde buscar un reloj perfectamente compartido hacia determinar qué eventos pudieron influir en otros.</p>
  <a class="ds-book-note-source" href="../../../history/lamport-time-and-causality/">Lee la historia del diseño →</a>
</aside>

## 2. La replicación crea dos preguntas de corrección distintas

Una distinción útil es:

### Pregunta de durabilidad

> Después de que el sistema reconoce una escritura, ¿frente a qué fallos puede recuperarse todavía el valor?

### Pregunta de consistencia

> ¿Qué valores pueden observar los clientes y en qué orden?

Un sistema puede ser durable y débilmente consistente.

Por ejemplo, tres réplicas asíncronas pueden preservar finalmente cada actualización y, mientras tanto, devolver valores obsoletos.

También puede ser fuertemente consistente, pero no estar disponible ante algunos fallos.

Son dimensiones diferentes.

---

## 3. Empieza con un único registro lógico

Muchas ideas de consistencia se entienden mejor imaginando primero una variable:

```text
x
```

Los clientes realizan:

```text
write(x, value)
read(x) -> value
```

Una implementación distribuida puede guardar copias en:

```text
R1 R2 R3
```

La historia visible contiene invocaciones y respuestas:

```text
C1: write(x,1) -------- ok
C2:            read(x) ----> 1
```

o:

```text
C1: write(x,1) -------- ok
C2:            read(x) ----> 0
```

Los modelos de consistencia restringen qué historias son admisibles.

Es mejor aprender consistencia mediante historias que tratándola como una lista de adjetivos.

---

## 4. Primary/backup concede autoridad de escritura a un nodo

Una arquitectura sencilla asigna a una réplica **primaria** o similar a líder la responsabilidad de las escrituras.

```text
          Cliente
             |
             v
          Primary
         /       \
        v         v
    Backup 1   Backup 2
```

El primary puede establecer localmente un único orden de escrituras y propagarlo a las copias.

Esto simplifica conflictos porque los backups no inventan órdenes autoritativos independientes.

Pero aparecen preguntas nuevas:

- ¿cuándo reconoce el primary una escritura?
- ¿cuántos backups deben recibirla antes?
- ¿pueden los backups servir lecturas?
- ¿qué ocurre si falla el primary?
- ¿cómo se elige de forma segura uno nuevo?

El capítulo de consenso responde con mayor rigor la última pregunta.

---

<figure class="ds-book-figure">
  <img src="../../../../assets/book/m08-replica-histories-es.svg" alt="Dos réplicas exponen historias de lectura distintas después de una escritura confirmada." loading="lazy" decoding="async" />
  <figcaption><span>Figura</span>El valor final almacenado no basta para nombrar un modelo de consistencia. La consistencia restringe las historias que los clientes pueden observar.</figcaption>
</figure>

## 5. La replicación síncrona acopla el reconocimiento a las copias

En una política de estilo síncrono, el escritor espera a que se cumpla cierta condición de replicación antes de reconocer.

Por ejemplo:

```text
Cliente -> Primary -> Backup
                   <- ACK
Cliente <- OK
```

Ahora un valor reconocido existe en más de un nodo.

Beneficio potencial:

```text
mayor durabilidad tras la caída del primary
```

Coste potencial:

```text
la latencia de escritura incluye comunicación remota
la disponibilidad depende de las réplicas requeridas
```

Si el backup es lento, la escritura del cliente es lenta.

Si no es alcanzable y la política lo exige, las escrituras pueden detenerse.

Aquí aparece de forma directa el compromiso entre replicación, latencia y disponibilidad.

---

## 6. La replicación asíncrona reconoce antes

Un primary asíncrono puede reconocer tras cambiar su estado durable local y replicar después.

```text
Cliente -> Primary
Cliente <- OK
Primary ----después----> Backup
```

Ventajas:

- menor latencia de escritura;
- menor dependencia de la capacidad de respuesta de otras réplicas.

Pero considera:

```text
cliente escribe x=7
Primary almacena x=7
Primary responde OK
Primary cae
Backup aún tiene x=6
```

Si se pierde de forma permanente el almacenamiento del primary, puede desaparecer una escritura que ya había sido reconocida.

Por tanto, el proyecto debe declarar qué significa «durable después del reconocimiento».

La línea base del curso exige que el estado durable reconocido sobreviva al fallo permitido de un nodo de almacenamiento. Reconocer solo una copia local asíncrona puede incumplirlo si no existe otro mecanismo de durabilidad.

---

## 7. Leer de réplicas introduce decisiones sobre lecturas obsoletas

Supón que el primary tiene:

```text
x = 7
```

y un backup retrasado todavía:

```text
x = 6
```

Si los clientes pueden leer de cualquiera, pueden observar datos obsoletos.

Puede ser aceptable o no según el contrato.

Ejemplos:

- contador de recomendaciones: quizá aceptable durante poco tiempo;
- saldo justo después de una transferencia: potencialmente peligroso;
- estado de un lock de coordinación: normalmente inaceptable.

La consistencia es un contrato visible para la aplicación, no solo un parámetro interno de la base de datos.

---

## 8. La linealizabilidad respeta precedencia de tiempo real

Informalmente, la **linealizabilidad** exige que cada operación parezca ocurrir de forma atómica en algún instante entre su invocación y su respuesta, respetando el orden real de operaciones que no se solapan.

Considera:

```text
C1: write(x,1) ---- OK
C2:                    read(x) ----> 0
```

Si la lectura de C2 comienza únicamente después de haber terminado la escritura de C1, devolver el valor antiguo viola linealizabilidad.

Una historia linealizable debe poder explicarse como un único orden legal de una sola copia que, además, respete esa precedencia temporal.

Este modelo es especialmente útil para estado de coordinación porque los clientes pueden razonar aproximadamente como si existiera una sola copia actual.

Su coste suele ser mayor coordinación o disponibilidad restringida durante fallos.

---

## 9. Las operaciones solapadas dejan libertad de orden

Supón:

```text
C1: write(x,1) ----------- OK
C2:      read(x) ----> 0
```

Las operaciones se solapan en tiempo real.

La linealizabilidad puede colocar la lectura antes del punto de linealización de la escritura.

Esto es importante al analizar historias.

No supongas que el instante de invocación fija por sí solo el orden cuando los intervalos se solapan.

Una clasificación correcta debe considerar invocación y respuesta completas.

---

## 10. La consistencia secuencial conserva el orden de cada proceso, no la precedencia real entre procesos

La **consistencia secuencial** pregunta si las operaciones pueden organizarse en un orden total que:

- sea legal para el objeto;
- preserve el orden de programa de cada cliente/proceso.

A diferencia de la linealizabilidad, no exige de la misma forma que el orden total respete la precedencia temporal real entre clientes diferentes.

Por eso algunas historias que violan linealizabilidad pueden seguir siendo secuencialmente consistentes.

Idea de ejemplo:

```text
C1 termina write(x,1)
C2, más tarde según reloj, lee x=0
```

Si el modelo no exige precedencia real entre clientes y existe un orden secuencial válido que coloque la lectura de C2 antes de la escritura de C1 respetando el orden interno de cada cliente, la historia puede ser secuencialmente consistente aunque no linealizable.

La distinción es sutil y conviene trabajarla sobre historias concretas.

---

## 11. La consistencia causal preserva causa antes que efecto

El Capítulo 6 introdujo la relación happened-before.

La consistencia causal usa una idea relacionada: si la operación B pudo estar influida por A, las réplicas no deberían exponer B ignorando la dependencia causal con A.

Ejemplo:

```text
Alice publica el post A
Bob lee A
Bob publica la respuesta B que referencia A
```

Relación causal:

```text
A -> B
```

Una réplica no debería mostrar la respuesta B de Bob mientras todavía oculta el post A causalmente anterior, suponiendo que ambas operaciones pertenecen al historial causal replicado.

Sin embargo, un post independiente C puede ser concurrente con A/B y las réplicas pueden ordenar C de forma temporalmente distinta.

La consistencia causal preserva dependencias significativas sin imponer necesariamente un orden total global a todos los eventos concurrentes.

---

## 12. Consistencia eventual es una promesa de convergencia, no un modelo completo de orden de lecturas

La expresión **consistencia eventual** se usa con demasiada imprecisión.

Una afirmación básica útil es:

> Si dejan de producirse nuevas actualizaciones y la comunicación/recuperación continúa, las réplicas terminan convergiendo a estados compatibles o equivalentes.

Eso no dice por sí mismo:

- qué valores obsoletos pueden leerse antes de converger;
- cómo se resuelven escrituras concurrentes;
- si los usuarios leen sus propias escrituras;
- si las versiones pueden parecer retroceder;
- cuánto tarda la convergencia.

Por tanto, «eventualmente consistente» suele ser solo una parte del contrato visible.

Más adelante en este mismo capítulo, las ideas de CRDT muestran cómo ciertas actualizaciones independientes pueden fusionarse de forma segura.

---

## 13. La consistencia centrada en el cliente expresa garantías útiles de sesión

Cuando las réplicas pueden estar obsoletas, el sistema puede ofrecer garantías desde el punto de vista de un cliente o sesión.

Cuatro ejemplos clásicos:

### Lee tus propias escrituras (*read-your-writes*)

Después de una escritura satisfactoria de v, las lecturas posteriores del mismo cliente no deberían devolver un estado anterior que omita esa escritura.

### Lecturas monótonas

Una vez que el cliente observó la versión v2, no debería observar después una versión anterior v1.

### Escrituras monótonas

Las escrituras de un cliente deben aplicarse en un orden compatible con su orden de programa.

### Escrituras que siguen lecturas

Si un cliente lee una versión v y emite después una escritura dependiente, esa escritura debe aplicarse en un contexto que incluya la versión observada.

Estas garantías pueden hacer mucho más usable un sistema débilmente consistente sin imponer linealizabilidad global.

---

## 14. Una réplica obsoleta puede romper read-your-writes

Ejemplo:

```text
C -> R1: write x=9 -> OK
C -> R2: read x -> 8
```

Si R2 no recibió aún la escritura, el cliente no lee su propia escritura.

Posibles soluciones:

- sesiones pegajosas;
- leer del primary;
- esperar a que la réplica seleccionada alcance cierta versión;
- transportar metadatos de versión/sesión;
- lectura por quórum.

La elección depende de la arquitectura.

---

## 15. Las lecturas monótonas evitan «viajar al pasado» dentro de una sesión

Supón que primero se lee de una réplica fresca:

```text
versión 12
```

y después el balanceador dirige al cliente a una réplica obsoleta:

```text
versión 9
```

Sin una garantía de lecturas monótonas, el usuario puede observar que el estado parece retroceder.

Para algunas aplicaciones solo resulta confuso; para otras rompe supuestos de corrección.

Balanceador, descubrimiento y mecanismo de consistencia interactúan.

---

## 16. Los quórums intercambian número de réplicas por intersección

Supón un dato replicado en N nodos.

Un modelo común define:

```text
W = número de réplicas participantes en una escritura
R = número de réplicas consultadas en una lectura
```

Una condición de intersección conocida es:

```text
R + W > N
```

que garantiza que cada quórum de lectura intersecta cada quórum de escritura.

Para que dos quórums de escritura se intersecten, suele utilizarse:

```text
2W > N
```

Pero la intersección, por sí sola, no produce mágicamente linealizabilidad.

El protocolo todavía necesita reglas para:

- seleccionar versiones;
- manejar escrituras concurrentes;
- reparar lecturas;
- manejar operaciones fallidas;
- ordenar epochs/versiones;
- definir qué significa una escritura completada.

La aritmética de quórums es un ingrediente, no el algoritmo completo.

---

## 17. Ejemplo de quórum — N=3

Supón:

```text
N=3
W=2
R=2
```

Entonces:

```text
R + W = 4 > 3
2W = 4 > 3
```

Una escritura espera a dos réplicas.

Una lectura consulta dos réplicas.

Esto proporciona intersección bajo el conjunto de réplicas asumido.

Implicaciones de disponibilidad:

- con una réplica caída todavía puede existir un quórum de dos;
- con dos réplicas caídas no puede progresar el quórum.

Si una partición separa 2+1 réplicas, solo el lado de dos puede formar quórum.

Esto prepara la discusión de CAP.

---

## 18. Read-one/write-all favorece lecturas y sacrifica disponibilidad de escritura

Considera:

```text
N=3
R=1
W=3
```

Las lecturas pueden ser baratas y atenderse desde cualquier réplica actual.

Las escrituras requieren las tres.

Una sola réplica no disponible bloquea escrituras.

Es un ejemplo concreto de por qué no existe una elección de quórum universalmente mejor.

Importan la mezcla de operaciones y los requisitos de fallo.

---

## 19. Write-one/read-all desplaza el compromiso

Ahora:

```text
N=3
W=1
R=3
```

Las escrituras pueden completar con una réplica, pero las lecturas necesitan las tres para identificar el estado más reciente bajo un esquema simplista.

La latencia y disponibilidad cambian.

Los sistemas reales usan protocolos más sofisticados, pero la aritmética deja visible la tensión de diseño.

---

## 20. La replicación sin líder permite más escrituras independientes

En una arquitectura *leaderless*, clientes o coordinadores pueden enviar escrituras a varias réplicas sin que un primary permanente serialice cada operación.

Beneficios posibles:

- sin cuello de botella fijo de primary;
- disponibilidad flexible;
- escrituras geográficamente distribuidas.

Problemas nuevos:

- versiones concurrentes;
- detección de conflictos;
- resolución de conflictos;
- reparación/hinted handoff;
- lecturas obsoletas;
- metadatos de versión.

El trabajo sobre Amazon Dynamo es históricamente importante porque hizo concretos estos compromisos en un almacén clave/valor de alta disponibilidad.

---

## 21. Anti-entropy repara réplicas después de divergir

Una réplica que perdió escrituras debe descubrir y reparar finalmente el estado faltante.

Mecanismos posibles:

- comparación periódica de versiones;
- resúmenes mediante Merkle trees;
- intercambio de logs;
- read repair;
- sincronización en segundo plano;
- transferencia de instantáneas.

El mecanismo exacto depende del sistema.

El requisito general es el mismo introducido en recuperación:

> **La reparación después de restablecer comunicación forma parte de la corrección de la replicación.**

---

## 22. Read repair usa una lectura para descubrir desacuerdo

Supón que una lectura por quórum recibe:

```text
R1: versión 8
R2: versión 8
R3: versión 6
```

El lector/coordinador puede devolver la versión 8 y opcionalmente reparar R3.

Así la convergencia puede mejorar oportunistamente.

Pero también significa que una operación aparentemente de solo lectura puede generar escrituras y tráfico de reparación.

La sencillez de `GET` puede ocultar coordinación distribuida considerable.

---

## 23. La resolución de conflictos necesita semántica

Supón que réplicas desconectadas aceptan:

```text
A: carrito añade libro
B: carrito añade bolígrafo
```

Una política ingenua last-writer-wins puede descartar una actualización según los timestamps.

Una unión de conjuntos podría preservar ambas adiciones.

Considera ahora:

```text
A: saldo = 100
B: saldo = 200
```

La unión no tiene sentido.

La resolución depende del tipo de dato y de los invariantes de la aplicación.

Las leyes de fusión de los CRDT formalizan una versión importante de esta idea.

### Los CRDT desplazan parte del problema de coordinación al tipo de dato

Un **Conflict-free Replicated Data Type (CRDT)** se diseña para que algunas actualizaciones puedan aceptarse independientemente y fusionarse después sin inventar un ganador ad hoc.

Considera un contador solo creciente con tres réplicas. En vez de un único escalar, cada réplica mantiene un componente por réplica:

```text
A: [3,0,0]
B: [0,2,0]
C: [0,0,4]
```

El valor visible es la suma. La fusión toma el máximo por componente:

```text
merge([3,0,0], [0,2,0]) = [3,2,0]
```

Mensajes de fusión repetidos o reordenados no cambian el resultado final porque la operación es:

- **conmutativa** — el orden no importa;
- **asociativa** — la agrupación no importa;
- **idempotente** — fusionar de nuevo el mismo estado no añade un segundo efecto.

Estas propiedades son poderosas porque la diseminación no fiable puede duplicar y reordenar estado.

Pero un CRDT no elimina toda necesidad de coordinación.

Supón el invariante:

```text
el saldo bancario nunca debe ser negativo
```

Dos réplicas desconectadas pueden creer, cada una, que existe saldo suficiente para autorizar un retiro y violar conjuntamente el invariante global. Converger después no repara el hecho de que ya se aceptó una operación inválida.

> **Detente y predice.** ¿Qué es más fuerte: «todas las réplicas terminan convergiendo» o «el invariante nunca fue violado»? Son afirmaciones distintas. Los CRDT ayudan a la convergencia; los invariantes determinan cuándo puede evitarse coordinación con seguridad.

Usa CRDT cuando la semántica de los datos permita progreso independiente y una fusión matemáticamente segura. No los elijas simplemente porque el sistema esté replicado.

---

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosidad</span>
  <strong>Añadir réplicas puede reducir disponibilidad de escritura si el ack exige demasiadas</strong>
  <p>La replicación crea redundancia, pero el protocolo decide si esa redundancia ayuda. Esperar a todas las copias puede bloquear por una sola réplica lenta.</p>
  <p><strong>Pruébalo:</strong> Compara una configuración de tres réplicas que requiera 1, 2 o 3 acknowledgements cuando una réplica falla.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">Más curiosidades del capítulo →</a>
</aside>

## 24. Last-writer-wins es una política, no la verdad

Una política habitual elige la actualización con el timestamp mayor.

Puede ser sencilla, pero presupone que la comparación temporal es significativa y que descartar la otra actualización es aceptable.

El capítulo de tiempo mostró por qué los relojes físicos pueden discrepar.

Un sistema que usa last-writer-wins basado en reloj de pared debe declarar:

- supuestos sobre relojes;
- desempates;
- si es aceptable perder actualizaciones concurrentes.

«Último» puede significar **mayor timestamp elegido**, no el último evento causal real.

---

## 25. El lag de replicación convierte el balanceo en un mecanismo de consistencia

Supón tráfico de lectura balanceado entre tres réplicas con retrasos diferentes:

```text
R1 fresca
R2 retrasada 100 ms
R3 retrasada 2 s
```

Un cliente puede observar:

```text
versión 10
versión 12
versión 9
```

simplemente porque sus solicitudes llegan a réplicas distintas.

Así, descubrimiento/balanceo y consistencia no son temas independientes.

El sistema debe decidir si cualquier réplica saludable puede responder cualquier lectura.

---

## 26. Las lecturas linealizables suelen necesitar autoridad o validación

Una réplica no puede devolver con seguridad un valor «actual» solo porque haya recibido actualizaciones recientemente.

Según el protocolo, una lectura linealizable puede requerir:

- leer a través del líder actual;
- confirmar autoridad de liderazgo/term;
- obtener un quórum;
- usar leases con supuestos temporales justificados;
- otro mecanismo que demuestre que no existe una escritura posterior confirmada que deba observarse.

El trabajo de consenso y máquinas de estado desarrolla esta idea.

La lección es sencilla:

> **Una semántica fuerte de lectura exige evidencia sobre orden/autoridad actuales, no solo una copia local.**

---

## 27. El comportamiento durante particiones debe formar parte del contrato de API

Supón N=3 dividido:

```text
R1 R2   X   R3
```

¿Qué debe hacer R3 ante una escritura?

Políticas posibles:

### Rechazar o bloquear

Preserva seguridad de quórum/autoridad única, pero reduce disponibilidad para clientes conectados solo con R3.

### Aceptar independientemente

Mantiene disponibilidad, pero crea estado divergente que deberá reconciliarse.

Ambos diseños pueden ser legítimos para aplicaciones diferentes.

Lo inaceptable es dejar el comportamiento implícito.

---

## 28. CAP trata de una elección forzada por las particiones entre garantías concretas

CAP suele reducirse incorrectamente a:

> «Escoge dos entre consistencia, disponibilidad y tolerancia a particiones».

Ese eslogan oculta definiciones importantes.

La formulación de Gilbert y Lynch considera sistemas bajo particiones de red y nociones específicas de:

- consistencia aproximadamente equivalente a comportamiento atómico/linealizable;
- disponibilidad, donde toda solicitud dirigida a un nodo no fallido termina recibiendo respuesta;
- tolerancia a particiones, donde el sistema debe cumplir su especificación pese a pérdida de mensajes o partición entre nodos.

Interpretación útil:

> **Cuando la comunicación está particionada, un servicio replicado no puede garantizar simultáneamente comportamiento linealizable de una sola copia y una respuesta siempre satisfactoria desde cada réplica no fallida alcanzable.**

Fuera de particiones siguen existiendo múltiples compromisos de latencia, durabilidad y consistencia. CAP no clasifica todas las decisiones de diseño.

---

## 29. La tolerancia a particiones normalmente no es opcional

Si el sistema usa una red real, los fallos de comunicación pueden suceder aunque el diseñador no los desee.

Por eso «elegir CA e ignorar P» suele ser una forma engañosa de razonar sobre nodos que pueden fallar de forma independiente.

Una pregunta mejor es:

> Cuando ocurra la partición, ¿qué hacemos?

- rechazar algunas operaciones;
- servir lecturas obsoletas;
- aceptar escrituras divergentes;
- usar quórum;
- degradar a solo lectura;
- encolar trabajo para más tarde.

Haz que el comportamiento sea comprobable.

---

## 30. La disponibilidad es específica de cada operación

Durante una partición, un sistema podría ofrecer:

```text
GET -> disponible
PUT -> no disponible
```

o:

```text
lecturas locales -> disponibles, quizá obsoletas
lecturas fuertes -> no disponibles
```

Por eso evita una etiqueta binaria «disponible/no disponible» cuando las operaciones tienen garantías distintas.

Es especialmente importante en la evaluación de proyectos.

---

## 31. Un reconocimiento de durabilidad debe nombrar la condición de réplicas

Considera tres nodos de almacenamiento.

Un proyecto dice:

> «Un PUT satisfactorio es durable».

Pregunta:

> ¿Durable frente a qué?

Un contrato preciso podría ser:

> Un PUT satisfactorio se ha persistido en al menos dos nodos de almacenamiento configurados distintos y sobrevive a la pérdida permanente de cualquiera de ellos.

Ahora la afirmación contiene:

- condición de reconocimiento;
- modelo de fallo;
- invariante medible.

Es exactamente el tipo de precisión que exige la línea base del proyecto.

---

## 32. La consistencia de lectura y la durabilidad de escritura pueden configurarse por separado

Un sistema podría persistir síncronamente una escritura en dos réplicas para durabilidad y permitir aún lecturas obsoletas desde una tercera.

Por tanto:

```text
durabilidad de escritura != linealizabilidad de lectura
```

También podría encaminar todas las lecturas por un líder para semántica fuerte y hacer backups asíncronos que pongan en riesgo escrituras recientes ante un fallo catastrófico.

No infieras una propiedad de la otra.

---

## 33. Historia trabajada — lectura obsoleta después de una escritura completada

Estado inicial:

```text
x=0 en R1,R2
```

Historia:

```text
C1 -> R1: write x=1
R1 -> C1: OK
C2 -> R2: read x
R2 -> C2: 0
```

Supón que la lectura de C2 comienza después de que C1 reciba OK.

La historia viola linealizabilidad si el registro lógico se declara linealizable.

¿Podría ser aceptable con replicación eventual asíncrona?

Sí, si el contrato permite lecturas obsoletas y las réplicas convergen después.

Misma ejecución, contrato diferente.

---

## 34. Historia trabajada — lectura solapada

Estado inicial x=0.

```text
C1: write x=1 ------------- OK
C2:       read x -> 0
```

La lectura se solapa con la escritura.

Una explicación linealizable puede colocar la lectura antes del punto de linealización de la escritura.

Por tanto, devolver 0 no es automáticamente una violación.

Hay que razonar a partir de los intervalos.

---

## 35. Historia trabajada — violación de read-your-writes

```text
C1 -> R1: write x=5 -> OK
C1 -> R2: read x -> 4
```

Aunque el sistema solo prometa convergencia eventual global, puede ofrecer read-your-writes en cada sesión.

Esta historia viola esa garantía.

Una reparación útil sería enviar C1 a una réplica que se sabe que tiene la versión 5 o superior.

---

## 36. Historia trabajada — violación de lecturas monótonas

```text
C1 -> R1: read x(version=12)
C1 -> R2: read x(version=9)
```

El cliente observa primero una versión posterior y luego una anterior.

Viola lecturas monótonas.

Ambos valores pueden ser estados legítimos de réplicas en momentos distintos. La violación está en el **orden de observación de la sesión**.

---

## 37. Historia trabajada — escrituras concurrentes durante una partición

Estado inicial:

```text
x=0
```

Partición:

```text
R1   X   R2
```

El cliente A escribe:

```text
x=1 en R1
```

El cliente B escribe:

```text
x=2 en R2
```

Ambos lados reconocen.

Después de reparar la partición no existe un valor obvio si el protocolo no define orden o resolución de conflictos.

Políticas posibles:

- elegir uno mediante metadatos de orden total;
- rechazar uno retrospectivamente, normalmente difícil y visible;
- fusionar si el tipo de dato lo permite;
- conservar versiones hermanas/conflictos para que la aplicación decida.

La disponibilidad durante la partición tiene consecuencias después.

---

## 38. Historia trabajada de quórum

N=3, W=2, R=2.

La escritura x=8 alcanza R1 y R2; R3 la pierde.

Una lectura consulta R2 y R3:

```text
R2 -> x=8, versión 11
R3 -> x=7, versión 10
```

El quórum de lectura intersecta el quórum de escritura completada en R2.

Si los metadatos de orden permiten reconocer la versión 11 como más reciente, el coordinador puede devolver x=8 y opcionalmente reparar R3.

Pero observa los supuestos ocultos:

- los metadatos son comparables y fiables;
- la finalización de escritura está definida consistentemente;
- existe una regla para escrituras concurrentes;
- la membresía N es estable o se reconfigura de forma segura.

La aritmética no constituye todo el protocolo.

---

## 39. Los cambios de membresía complican el razonamiento de quórum

Supón que un conjunto de tres cambia de:

```text
{A,B,C}
```

a:

```text
{C,D,E}
```

Si distintos clientes usan vistas de membresía diferentes, los quórums de ambas configuraciones pueden dejar de intersectarse como se pretendía.

La reconfiguración segura se convierte en un problema de coordinación.

Esto conecta descubrimiento/membresía y consenso con la corrección del almacenamiento.

El laboratorio puede mantener membresía estática, pero debes conocer este límite.

---

## 40. Las pruebas de consistencia analizan historias, no solo estado final

Supón que después de una prueba todas las réplicas terminan en:

```text
x=10
```

¿Demuestra linealizabilidad?

No.

Durante la ejecución los clientes pueden haber observado historias prohibidas.

El análisis debe registrar:

```text
invocación de operación
respuesta de operación
identidad del cliente
valor/versión
metadatos temporales/causales relevantes
```

y comprobar la **historia** frente al modelo declarado.

Herramientas como Jepsen son valiosas porque combinan inyección de fallos con comprobación de historias, no solo convergencia final.

---

## 41. La convergencia eventual puede coexistir con mal comportamiento intermedio

Dos réplicas pueden divergir durante una partición y converger perfectamente después.

Eso demuestra una propiedad de convergencia bajo el escenario probado.

No demuestra:

- que los usuarios nunca vieron datos obsoletos;
- que ninguna actualización se perdió;
- que read-your-writes se mantuvo;
- que las operaciones fueron linealizables;
- que nunca hubo duplicados.

Sé preciso sobre qué valida cada experimento.

---

## 42. La replicación tiene coste incluso sin fallos

En el caso normal consume:

- ancho de banda;
- almacenamiento;
- CPU/serialización;
- mensajes de coordinación;
- latencia de reconocimiento;
- trabajo de reparación en segundo plano.

El factor de replicación debe seguir un objetivo de fallo/durabilidad, no una regla «más copias es mejor».

Cinco réplicas pueden ofrecer menor disponibilidad de escritura que tres si la política exige las cinco.

---

## 43. La replicación geográfica magnifica decisiones de latencia

Una copia síncrona a otra región puede añadir una RTT considerable a cada escritura.

Una copia remota asíncrona reduce latencia, pero crea una ventana de lag o pérdida potencial según el modelo de durabilidad local.

Conexión directa con Redes:

> Distancia, RTT y congestión se convierten en entradas del diseño de consistencia y disponibilidad.

---

## 45. Perspectiva histórica — de copias primarias a almacenes altamente disponibles

La replicación es anterior a la nube moderna. Sistemas de archivos, bases de datos, telecomunicaciones y computación tolerante a fallos ya exploraban copias redundantes.

A escala de Internet/nube se combinan:

- grandes dominios de fallo;
- distribución geográfica;
- máquinas de propósito general;
- alta tasa de solicitudes;
- tolerancias específicas de aplicación a estado obsoleto o conflictivo.

Sistemas como Amazon Dynamo hicieron populares los compromisos de replicación sin líder, alta disponibilidad y resolución eventual de conflictos.

La lección histórica no es que una arquitectura sustituya a otra.

Es que **aplicaciones diferentes eligen puntos diferentes en el espacio consistencia/disponibilidad/latencia**.

---

## 46. Errores comunes

### Error 1 — «Replicado» significa fuertemente consistente

Las copias pueden discrepar temporal o permanentemente según el protocolo.

### Error 2 — «Tres copias» significa que una escritura reconocida sobrevive a un fallo

Solo si el reconocimiento exigió suficientes copias durables antes del éxito.

### Error 3 — la aritmética de quórum garantiza linealizabilidad

La intersección es necesaria en muchos protocolos, pero todavía importan orden, versiones y reglas de operación.

### Error 4 — consistencia eventual significa comportamiento aleatorio o incorrecto para siempre

Normalmente existe una expectativa de convergencia cuando cesan actualizaciones y fallos, pero deben especificarse las garantías intermedias.

### Error 5 — CAP significa escoger dos para siempre

La tensión clave aparece durante particiones y depende de definiciones concretas.

### Error 6 — la tolerancia a particiones puede desactivarse

La comunicación real puede fallar; el diseño necesita comportamiento definido.

### Error 7 — last-writer-wins identifica al último escritor causal real

El orden basado en relojes puede ser arbitrario ante skew y concurrencia.

### Error 8 — igualdad final de réplicas demuestra consistencia fuerte

Importa la historia intermedia visible para clientes.

### Error 9 — réplicas de lectura son rendimiento gratuito

El lag puede exponer lecturas obsoletas o no monótonas.

### Error 10 — recuperación es solo reconectar el proceso

Puede faltar sincronizar estado y reintegrarlo con seguridad.

---

## Transición al laboratorio

El laboratorio del Capítulo 9 construye un servicio clave/valor de tres réplicas e introduce historias que se ven diferentes bajo garantías distintas.

Compararás al menos dos estrategias y producirás:

- una historia de lectura obsoleta;
- una prueba de durabilidad de escritura completada;
- un experimento de lectura/escritura por quórum;
- una partición con política explícita de escritura;
- una traza de recuperación/reparación;
- una violación y reparación de consistencia centrada en el cliente;
- una breve clasificación de historia bajo expectativas linealizables, secuenciales, causales o eventuales.

El objetivo no es construir una base de datos de producción.

Es aprender a hacer precisa esta frase:

> «Nuestras réplicas son consistentes».

---

## Resumen del capítulo

1. **La replicación aporta disponibilidad, durabilidad, localidad y capacidad solo bajo protocolos y supuestos de fallo explícitos.**
2. **Durabilidad y consistencia son propiedades diferentes.**
3. **Primary/backup simplifica el orden de escrituras, pero crea preguntas de autoridad y failover.**
4. **La replicación síncrona aumenta la dependencia del reconocimiento respecto a otras réplicas; la asíncrona crea ventanas de lag o pérdida.**
5. **Los modelos de consistencia restringen historias observables.**
6. **La linealizabilidad respeta precedencia real de operaciones no solapadas; la consistencia secuencial preserva orden de proceso sin la misma exigencia temporal.**
7. **La consistencia causal conserva causa antes que efecto y deja libertad entre operaciones concurrentes.**
8. **Consistencia/convergencia eventual no especifica por completo las observaciones intermedias.**
9. **Garantías centradas en el cliente, como read-your-writes y lecturas monótonas, mejoran usabilidad sin linealizabilidad global.**
10. **Los quórums usan intersección para relacionar lecturas y escrituras, pero la aritmética es solo una parte del protocolo correcto.**
11. **Las particiones fuerzan decisiones explícitas sobre qué operaciones siguen disponibles y qué estado puede divergir.**
12. **CAP se entiende mejor como incompatibilidad durante particiones entre ciertas garantías de consistencia y disponibilidad, no como un menú universal de «elige dos».**
13. **Recuperación y anti-entropy forman parte de la corrección de la replicación.**
14. **Probar consistencia requiere historias, no solo igualdad final de las réplicas.**

Los capítulos siguientes preguntan cómo un conjunto de réplicas puede acordar un único orden evolutivo de operaciones y ejecutarlo como servicio tolerante a fallos.

<div class="ds-next-action">
  <span>Lectura esencial completada</span>
  <strong>Siguiente paso obligatorio · Práctica guiada</strong>
  <a href="../guided-practice/">Comenzar práctica guiada →</a>
</div>
