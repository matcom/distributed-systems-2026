<div class="ds-lesson-banner">
  <div><span>Laboratorio obligatorio</span><strong>Capítulo 9</strong></div>
  <div><span>Modelo de evidencia</span><strong>predecir → ejecutar → observar → explicar</strong></div>
  <div><span>Verificación</span><strong>9 pruebas públicas transparentes + evidencia</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 9 de 12</span>
    <span>75% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 75%"></span></div>
</div>
<p class="ds-back-link"><a href="../quick-check/">← Volver a la comprobación</a></p>

> **Antes de comenzar:** Completa los pasos de práctica guiada y comprobación de conocimientos. Ya deberías poder formular una predicción y nombrar la evidencia que la apoyaría o contradeciría. Si no, [vuelve a la comprobación](../quick-check/) y revisa la lección donde haga falta.

## Objetivo

Construye un pequeño servicio clave/valor de tres réplicas, compara al menos dos políticas de replicación, crea intencionadamente lecturas obsoletas e historias conflictivas y clasifica qué garantiza realmente el sistema.

El objetivo no es construir una base de datos de producción. Es hacer experimentalmente precisas afirmaciones como «durable», «linealizable», «eventualmente consistente» o «disponible durante una partición».

## Ruta esencial

Completa los Pasos 1–7, **elige una** anomalía de sesión entre el Paso 8 y el Paso 9 y después completa los Pasos 10–17.

Si tienes tiempo, ejecuta la segunda anomalía como extensión. El objetivo es razonar correctamente sobre una historia visible para el cliente, no maximizar el número de trazas casi idénticas.

## Topología requerida

Usa tres procesos de servicio independientes:

```text
R1   R2   R3
```

y uno o más clientes.

El servicio debe soportar una interfaz mínima equivalente a:

```text
PUT key value request_id
GET key
STATE key
```

Cada versión almacenada debe exponer suficientes metadatos para distinguir estados de réplica durante los experimentos.

Para el laboratorio base basta una versión monotónica del primary, `(epoch,counter)` u otra versión comparable y documentada. No uses timestamps de reloj de pared no sincronizados como único mecanismo de corrección.

## Políticas de replicación requeridas

Implementa o configura al menos dos políticas pequeñas.

Una pareja recomendada es:

### Política A — primary/backup asíncrona

- un primary acepta escrituras;
- el primary reconoce según una condición explícita;
- los backups reciben escrituras después/asíncronamente;
- para los experimentos, las lecturas pueden dirigirse a réplicas concretas.

### Política B — replicación por quórum

Para N=3 usa una elección documentada como:

```text
W=2
R=2
```

Otra pareja es válida si justificas sus propiedades.

El laboratorio todavía no exige elección automática de líder; se acepta un primary configurado estáticamente. El capítulo de consenso aborda esa cuestión.

## Paso 1 — establece semántica de una sola réplica

Ejecuta un único registro/clave sin replicación.

Registra una historia limpia:

```text
PUT x 1
GET x -> 1
```

Captura invocación y respuesta con:

- ID de cliente;
- ID de operación/solicitud;
- réplica(s) objetivo;
- valor/versión;
- instante de invocación;
- instante de respuesta.

Este será el formato base de historia para los pasos posteriores.

## Paso 2 — inicia tres réplicas

Inicia R1/R2/R3 con directorios de estado claramente separados o identidades de memoria diferentes.

Registra:

- ID de nodo;
- ID de encarnación;
- rol;
- endpoint;
- versión actual de la clave `x`.

Verifica que los clientes puedan dirigirse a réplicas individuales durante los experimentos aunque el camino normal utilice un endpoint lógico.

## Paso 3 — lectura obsoleta asíncrona

Usa la Política A.

Retrasa artificialmente la replicación desde el primary hacia un backup.

Ejecuta:

```text
C1 -> primary: PUT x=1
primary -> C1: OK
C2 -> backup retrasado: GET x
```

Organiza el experimento para que la lectura comience después de que C1 reciba `OK`, pero antes de que el backup aplique la escritura.

Registra los intervalos completos.

Si el backup devuelve el valor anterior, clasifica la historia:

- bajo una afirmación de registro linealizable;
- bajo una afirmación de replicación asíncrona eventualmente convergente.

La respuesta debe referirse a la historia, no al nombre de la arquitectura.

## Paso 4 — prueba de reconocimiento y durabilidad

Declara exactamente la regla de reconocimiento de la Política A.

Variantes posibles:

```text
A1: reconocer después de memoria del primary
A2: reconocer después de estado durable del primary
A3: reconocer después de primary + un backup durable
```

Usa la variante que corresponda a tu implementación.

Después simula la pérdida de un nodo de servicio/almacenamiento inmediatamente después del reconocimiento.

Responde:

- ¿puede recuperarse el valor reconocido?
- ¿qué fallo exacto probaste?
- ¿cumple la línea base común de reconocimiento durable del curso?

No afirmes durabilidad de disco físico si todo el experimento usa memoria volátil. Declara el límite real.

## Paso 5 — latencia de escritura síncrona/por quórum

Usa la Política B o fortalece el reconocimiento del primary para esperar varias réplicas.

Mide la latencia normal de escritura con:

```text
sin retraso añadido
50 ms de retraso a una réplica
300 ms de retraso a una réplica
una réplica no disponible
```

Explica qué respuestas están en el camino crítico del reconocimiento.

## Paso 6 — lectura por quórum

Crea:

```text
R1: x=5 version=10
R2: x=5 version=10
R3: x=4 version=9
```

Ejecuta una lectura R=2 que incluya una réplica fresca y una obsoleta.

El cliente/coordinador debe usar la regla de versión documentada para elegir el resultado.

Registra:

- réplicas participantes;
- versiones devueltas;
- resultado seleccionado;
- si se inició reparación.

## Paso 7 — read repair

Si lo soportas, repara la réplica obsoleta descubierta durante la lectura de quórum.

Mide:

```text
instante de detección de reparación
instante de finalización
```

Después verifica el estado.

Si no hay read repair automático, implementa un paso explícito pequeño o analiza el mecanismo necesario.

## Paso 8 — opción de sesión A: violación de read-your-writes

Usando una réplica retrasada, crea:

```text
C1 escribe versión V
C1 lee después una versión anterior en otra réplica
```

Esto viola read-your-writes.

Implementa una reparación, por ejemplo:

- routing pegajoso a primary/sesión;
- el cliente transporta una versión mínima requerida;
- lectura por quórum;
- esperar a que la réplica seleccionada se ponga al día.

Repite la historia y demuestra que la garantía se mantiene en la ejecución probada.

## Paso 9 — opción de sesión B: violación de lectura monótona

Crea una sesión que lea:

```text
versión 12
después versión 9
```

mediante cambio de réplica.

Explica por qué es distinto de read-your-writes.

Implementa o describe un mecanismo que impida retroceder de versión dentro de la sesión.

## Paso 10 — partición 2+1

Particiona:

```text
R1 R2   X   R3
```

Todos los procesos deben seguir vivos.

Prueba lecturas y escrituras desde clientes conectados a ambos lados.

Declara el comportamiento esperado **antes** de ejecutar.

En una política fuerte orientada a quórum, puede esperarse:

```text
lado mayoritario: puede formar quórum
lado minoritario: rechaza escritura fuerte
```

En una política explícitamente disponible y orientada a conflictos, ambos lados pueden aceptar actualizaciones, pero los pasos siguientes deben conservar los estados conflictivos hasta aplicar una regla de reconciliación.

No cambies de política después de ver el resultado solo para que la prueba «pase».

## Paso 11 — escrituras conflictivas durante la partición

Si la política permite escribir en ambos lados, crea dos actualizaciones conflictivas de la misma clave.

Registra sus metadatos de versión.

Al reparar la partición, declara cómo se resuelve o representa el conflicto.

Políticas educativas posibles:

- orden determinista por versión/epoch;
- conservar versiones hermanas para resolución explícita;
- fusión de aplicación para un tipo de dato fusionable.

Si la política de quórum rechaza correctamente la escritura minoritaria, documenta ese comportamiento y explica qué disponibilidad se sacrificó.

## Paso 12 — repara y recupera

Elimina la partición.

Mide hitos separados:

```text
conectividad restaurada
membresía/salud restaurada
versión faltante detectada
estado transferido/reconciliado
réplica segura para las lecturas declaradas
```

Define qué hito cuenta como **tiempo de recuperación de réplica** en el informe.

## Paso 13 — clasificación de historias

Selecciona al menos cuatro historias registradas y clasifícalas frente a garantías relevantes.

Incluye:

1. una escritura/lectura no solapadas;
2. una escritura/lectura solapadas;
3. un caso de read-your-writes o lectura monótona;
4. una historia durante partición.

Para linealizabilidad, construye o rechaza un orden legal de una sola copia que respete precedencia real.

No clasifiques solo por los valores finales.

## Paso 14 — formulación CAP

A partir de tu partición real, escribe una afirmación CAP operacional.

Buena forma:

> Durante una partición que aísla una réplica de las otras dos, las escrituras fuertemente consistentes enviadas solo a la réplica aislada se rechazan porque no puede obtener el quórum requerido; así se conserva la regla de escritura de una sola copia sacrificando disponibilidad para clientes conectados únicamente a esa réplica.

Evita:

> «Elegimos CP».

La afirmación operacional informa más.

## Paso 15 — compara las dos políticas

Resume:

| Propiedad | Política A | Política B |
|---|---|---|
| latencia normal de escritura | | |
| comportamiento de lecturas obsoletas | | |
| supervivencia de escritura reconocida | | |
| fallo de una réplica | | |
| escrituras en partición minoritaria | | |
| mecanismo de recuperación | | |
| complejidad de implementación | | |

No se espera que una política domine cada fila.

## Paso 16 — mini experimento orientado a convergencia

Antes de trasladar la idea al proyecto final, implementa o usa un pequeño contador grow-only basado en estado.

Usa al menos tres réplicas lógicas. Cada réplica incrementa solo su componente y fusiona usando máximo por componente.

Ejecuta:

1. desconecta lógicamente las réplicas;
2. incrementa réplicas diferentes de forma independiente;
3. intercambia estados en órdenes distintos;
4. entrega al menos un estado dos veces;
5. verifica que todas convergen después de intercambiar todos los estados.

Registra el orden de fusión y los estados finales.

Después prueba el límite importante: escribe un invariante que este tipo de dato **no** garantice. No informes «CRDT = no se necesita coordinación». Formula la afirmación más estrecha: la fusión tolera orden y duplicación para las operaciones representadas por este tipo.

Si tu proyecto final no tiene estado fusionable, indícalo y explica por qué encaja mejor una replicación coordinada.

## Paso 17 — traducción al proyecto final

Elige un proyecto final e identifica cuál sería su «estado replicado».

Ejemplos:

- P10 media streaming: chunks frente a metadatos de catálogo;
- P13 event log: particiones, offsets y metadatos;
- P18 DNS autoritativo: estado de zona replicado, comportamiento de réplica obsoleta y un camino de actualización más fuerte que el serving de consultas;
- P20 edge cache: verdad del origen frente a copias obsoletas del edge.

Indica qué garantía de consistencia necesita realmente ese estado en vez de elegir linealizabilidad por reflejo.

## Objetivo de pruebas transparentes

Las pruebas públicas ejecutables viven en `tests/official/`, con helpers deterministas de quórum/versión/sesión/historia en `starter/src/`. Verifican invariantes portables; lag real, durabilidad, partición, reparación y convergencia requieren todavía los experimentos controlados anteriores.

Los casos están documentados en `tests/official/README.md`. `make test` ejecuta únicamente las pruebas oficiales visibles y las del estudiante en `tests/student/`.

No se planean pruebas ocultas.

## Uso de IA

Se permiten asistentes y agentes de programación con IA.

Para la auditoría requerida, proporciona a un asistente una historia de operaciones y pregúntale si es linealizable. Verifica manualmente construyendo una historia secuencial legal o demostrando que no existe.

Registra cualquier uso injustificado del orden por reloj de pared, razonamiento solo por estado final o eslóganes de consistencia.

## Informe

Completa `REPORT.md` con:

- ambas políticas de replicación;
- condiciones precisas de reconocimiento;
- historias con intervalos de invocación/respuesta;
- evidencia de lectura obsoleta y consistencia de sesión;
- cálculos de quórum;
- comportamiento durante partición;
- métricas de recuperación/reparación;
- afirmación CAP operacional;
- comparación de políticas;
- clasificación de historia auditada con IA.

## Termina el capítulo

Reproduce el resultado importante desde un inicio limpio. Después vuelve a tu predicción inicial: explica qué cambió, qué evidencia provocó el cambio y qué incertidumbre queda. Un comando exitoso o una captura no bastan cuando la afirmación trata de retries, orden, durabilidad, consistencia, recovery, seguridad o rendimiento.

<div class="ds-next-action">
  <span>Capítulo completo</span>
  <strong>Continuar el curso</strong>
  <a href="../../m07-failures/">Tolerancia a fallos I — Modelos de fallo, resiliencia y recuperación →</a>
</div>

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../../m04-architecture-discovery/">← Nombres, descubrimiento y búsqueda descentralizada</a>
<a class="ds-sequence-link next" href="../../m07-failures/">Tolerancia a fallos I — Modelos de fallo, resiliencia y recuperación →</a>
</nav>
