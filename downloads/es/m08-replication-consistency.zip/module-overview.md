<p class="ds-book-part">Parte III — Nombres y estado replicado</p>
<p class="ds-module-kicker">Capítulo 9</p>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 9 de 12</span>
    <span>75% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 75%"></span></div>
</div>
<p class="ds-guiding-question">Cuando varios nodos mantienen los mismos datos lógicos, ¿qué historiales puede observar un cliente?</p>

Replica un servicio pequeño y provoca lecturas obsoletas, escrituras en conflicto y una partición. Usa los historiales resultantes para definir la garantía, en lugar de empezar por etiquetas. Después compara coordinación fuerte con diseños orientados a convergencia, como CRDT.

## Ideas clave

- razones para replicar;
- primario/respaldo y replicación sin líder;
- propagación síncrona y asíncrona;
- quórums;
- linearizability;
- consistencia secuencial y causal;
- garantías de sesión;
- consistencia eventual y convergencia;
- compromisos CAP;
- intuición CRDT y leyes de merge.

## Transición al laboratorio

Ejecuta un servicio clave/valor replicado bajo lag, conflictos y particiones. Clasifica los historiales observados y explica después si la convergencia por sí sola sería suficiente para el invariante de la aplicación.

## Empieza aquí

> **Antes de leer:** Una escritura devuelve OK desde la réplica R1. Una lectura posterior desde R2 devuelve el valor anterior. ¿Está mal el sistema? Indica primero qué garantía asumiste.

**Trae contigo:** Causalidad, intuición sobre quórums, nombres/membresía e historiales explícitos de operaciones de cliente.

**Este capítulo te prepara para:** La capacidad de clasificar historiales y elegir entre replicación coordinada y semánticas de datos orientadas a la convergencia.

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>45 min–1 h</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>1 h–1 h 30 min</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>2 h 30 min–3 h 30 min · 9 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<p class="ds-workload-note"><strong>Alcance esencial:</strong> Usa la ruta esencial explícita del laboratorio: Pasos 1–7, una anomalía de sesión entre el Paso 8 o 9, y después Pasos 10–17. La segunda anomalía queda como práctica de recuperación o extensión.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Leer lección →</a>
  <a class="ds-secondary-action" href="lab/">Abrir laboratorio</a>
</div>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../downloads/es/m08-replication-consistency.zip" download>Descargar capítulo + laboratorio para estudio sin conexión (.zip)</a></p>

## Qué aprenderás

- Explica por qué la replicación crea preguntas de consistencia y no solo beneficios de confiabilidad.
- Clasifica historiales observables bajo garantías linealizables, secuenciales, causales, de sesión y eventuales.
- Compara replicación primario/respaldo, síncrona/asíncrona, por quórums y sin líder.
- Crea y analiza historiales con lecturas obsoletas, escrituras en conflicto y particiones.
- Explica cuándo reglas de mezcla orientadas a la convergencia, como los CRDT, encajan con el invariante de la aplicación.

## Aprende trabajando la pregunta

1. Escribe tu respuesta a **Empieza aquí** antes de abrir la lección completa.
2. Lee hasta la siguiente predicción o traza; detente y resuélvela antes de revelar la explicación.
3. Trata la práctica guiada como un **banco de práctica**, no como una hoja para completar deprisa. Trabaja las trazas centrales hasta alcanzar el objetivo de práctica y vuelve después a los casos restantes.
4. Usa la comprobación para detectar vacíos y entra al laboratorio con una predicción falsable y con la evidencia que podría contradecirla.
5. Termina explicando qué estableció el experimento, qué no estableció y cómo cambia tu explicación del servicio acumulativo.

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../m04-architecture-discovery/">← Nombres, descubrimiento y búsqueda descentralizada</a>
<a class="ds-sequence-link next" href="../m07-failures/">Tolerancia a fallos I — Modelos de fallo, resiliencia y recuperación →</a>
</nav>
