<p class="ds-book-part">Parte II — Comunicación y coordinación</p>
<p class="ds-module-kicker">Capítulo 7</p>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 7 de 12</span>
    <span>58% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 58%"></span></div>
</div>
<p class="ds-guiding-question">¿Cuándo el orden, el acceso exclusivo, la elección de líder y el consenso requieren mecanismos diferentes?</p>

Empieza por el problema más pequeño: quién puede actuar ahora. Después separa elegir un coordinador de preservar decisiones anteriores y llega finalmente a consenso sobre una secuencia replicada.

## Ideas clave

- exclusión mutua distribuida;
- coordinador central, permisos y token;
- elecciones Bully y ring;
- elección de líder ≠ consenso;
- acuerdo, validez y terminación;
- quórums e intersección de mayorías;
- términos, votos y logs en Raft;
- reglas de commit;
- safety frente a liveness;
- exploración determinista de planificaciones.

## Transición al laboratorio

Trabaja primero trazas de exclusión y elección. Después construye un núcleo Raft pequeño, somételo a particiones y logs en conflicto y usa un explorador acotado para generar una traza que viole un invariante cuando el modelo es incorrecto.

## Empieza aquí

> **Antes de leer:** Un algoritmo decide quién coordina; otro evita que dos nodos entren a la vez en una sección crítica; otro hace que varias réplicas acuerden un log. ¿Por qué no son el mismo problema?

**Trae contigo:** La causalidad del Capítulo 6 y la diferencia entre silencio y fallo vista en ejemplos anteriores de tiempos de espera.

**Este capítulo te prepara para:** Una progresión desde exclusión mutua y elecciones hasta acuerdo replicado basado en quórums.

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>45 min–1 h</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>1 h–1 h 30 min</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>3 h–4 h · 14 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<p class="ds-workload-note"><strong>Alcance esencial:</strong> Este es intencionalmente el capítulo de coordinación más pesado. La ruta esencial del laboratorio es el calentamiento obligatorio, Checkpoints A–B, Pasos C–F, exploración acotada de schedules en el Paso I, pruebas transparentes e informe; los Pasos G–H siguen siendo extensiones.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Leer lección →</a>
  <a class="ds-secondary-action" href="lab/">Abrir laboratorio</a>
</div>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../downloads/es/m09-consensus.zip" download>Descargar capítulo + laboratorio para estudio sin conexión (.zip)</a></p>

## Qué aprenderás

- Distingue exclusión mutua distribuida, elección de líder y consenso como problemas de coordinación diferentes.
- Compara mecanismos centralizados, de permisos/tokens y elecciones clásicas según sus supuestos y comportamiento ante fallos.
- Explica acuerdo, validez, terminación, intersección de quórums y la separación entre safety (seguridad) y liveness (vivacidad).
- Implementa y razona sobre elecciones estilo Raft, términos, logs replicados y reglas de commit.
- Usa invariantes explícitos y exploración acotada de planificaciones para revelar historiales de coordinación inseguros y explicar por qué elegir un líder no basta para hacer seguro el estado replicado.

## Aprende trabajando la pregunta

1. Escribe tu respuesta a **Empieza aquí** antes de abrir la lección completa.
2. Lee hasta la siguiente predicción o traza; detente y resuélvela antes de revelar la explicación.
3. Trata la práctica guiada como un **banco de práctica**, no como una hoja para completar deprisa. Trabaja las trazas centrales hasta alcanzar el objetivo de práctica y vuelve después a los casos restantes.
4. Usa la comprobación para detectar vacíos y entra al laboratorio con una predicción falsable y con la evidencia que podría contradecirla.
5. Termina explicando qué estableció el experimento, qué no estableció y cómo cambia tu explicación del servicio acumulativo.

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../m06-time-causality/">← Coordinación I — Tiempo, eventos y causalidad</a>
<a class="ds-sequence-link next" href="../m04-architecture-discovery/">Nombres, descubrimiento y búsqueda descentralizada →</a>
</nav>
