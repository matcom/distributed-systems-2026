<div class="ds-lesson-banner">
  <div><span>Laboratorio obligatorio</span><strong>Capítulo 7</strong></div>
  <div><span>Modelo de evidencia</span><strong>predecir → ejecutar → observar → explicar</strong></div>
  <div><span>Verificación</span><strong>14 pruebas públicas transparentes + evidencia</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 7 de 12</span>
    <span>58% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 58%"></span></div>
</div>
<p class="ds-back-link"><a href="../quick-check/">← Volver a la comprobación</a></p>

> **Antes de comenzar:** Completa los pasos de práctica guiada y comprobación de conocimientos. Ya deberías poder formular una predicción y nombrar la evidencia que la apoyaría o contradeciría. Si no, [vuelve a la comprobación](../quick-check/) y revisa la lección donde haga falta.

## Objetivo

Implementa un núcleo pequeño de consenso estilo Raft en dos checkpoints: primero elección de líder y después acuerdo sobre un log replicado. Ejecuta un clúster de cinco nodos bajo votos divididos, crashes, particiones minoría/mayoría, candidates obsoletos y sufijos de log en conflicto.

El objetivo no es rendimiento de Raft de producción. El objetivo es preservar invariantes explícitos de safety mientras la planificación de mensajes se vuelve hostil.

## Ruta esencial de finalización

La ruta obligatoria incluye el calentamiento de coordinación, Checkpoints A–B, Pasos C–F, la exploración acotada de planificaciones del Paso I, las pruebas transparentes y el informe.

Los Pasos G–H son **extensiones**. Úsalos para comparar, discutir o practicar adicionalmente; no son necesarios para demostrar los resultados esenciales del capítulo.

## Calentamiento obligatorio — demuestra qué problema de coordinación estás resolviendo

Antes de implementar Raft, trabaja tres trazas cortas con los mismos cinco nodos lógicos.

### Traza 1 — exclusión mutua

Elige un diseño de concesión central o uno basado en token. Muestra una entrada normal en la sección crítica y un crash del coordinador o poseedor del token.

Registra:

- qué establece la autoridad exclusiva;
- qué evento amenaza liveness;
- qué acción de recuperación podría crear accidentalmente dos autoridades.

### Traza 2 — elección clásica

Usa IDs de nodos ordenados y traza una elección estilo Bully o basada en anillo después de que el coordinador actual deje de ser alcanzable.

Mantén después vivo al coordinador anterior dentro de una partición minoritaria.

Declara explícitamente:

```text
coordinador nuevo seleccionado != historia anterior de aplicación reconciliada
```

### Traza 3 — requisito de acuerdo

Asigna al coordinador antiguo y al nuevo comandos propuestos en conflicto para la misma posición lógica.

Escribe el invariante que necesitas antes de que un comando pueda convertirse en autoritativo.

Solo entonces comienza los checkpoints de Raft. El objetivo del calentamiento es que Raft responda a un problema que ya puedes formular, en vez de aparecer como una colección de terms y RPCs.

## Alcance

Obligatorio:

- clúster configurable de cinco nodos;
- roles follower/candidate/leader;
- terms crecientes monótonamente;
- `currentTerm` y `votedFor` persistentes según el modelo de crash-recovery;
- election timeout aleatorio;
- request/response de RequestVote;
- retirada ante evidencia de un term mayor;
- entradas del log con índice, term y payload del comando;
- request/response de AppendEntries;
- comprobación de consistencia del prefijo;
- progreso de replicación por follower;
- reparación de sufijos no committed en conflicto;
- commit basado en mayoría siguiendo la regla de Raft para el term actual;
- salida o handoff de `commitIndex` para el Capítulo 10.

No obligatorio en el Capítulo 7:

- snapshots;
- reconfiguración de membership;
- optimización del retroceso ante conflictos;
- lecturas mediante leases;
- motor de persistencia de producción;
- tolerancia bizantina;
- máquina de estados KV completa para clientes.

## Estado observable obligatorio

Cada nodo debe hacer visible mediante logs estructurados, un endpoint de depuración o ambos:

```text
node_id
incarnation_id
role
current_term
voted_for
leader_id if known
last_log_index
last_log_term
commit_index
```

Los líderes deben exponer además información suficiente para inspeccionar:

```text
next_index[peer]
match_index[peer]
```

No imprimas todos los heartbeats con máxima verbosidad por defecto. Prefiere transiciones significativas.

## Checkpoint A — Elección de líder

### Paso A1 — baseline de followers

Inicia cinco followers con logs vacíos o equivalentes.

Verifica que todos comienzan con el mismo term/estado inicial configurado y sin líder elegido.

Registra el estado de persistencia al arrancar.

### Paso A2 — una elección limpia

Permite que expire primero el election timeout de un follower.

Registra:

```text
incremento de term
transición a candidate
autovoto
mensajes RequestVote
votos concedidos/rechazados
mayoría alcanzada
transición a leader
```

Antes de ejecutar, predice el número mínimo de votos necesario.

### Paso A3 — un voto por term

Provoca dos candidates dentro del mismo term.

Verifica que cada votante concede como máximo un voto.

Reinicia un votante después de haber concedido un voto y demuestra que crash-recovery no permite un segundo voto dentro del mismo term si el estado persistente está configurado correctamente.

Declara el límite de persistencia que implementaste realmente.

### Paso A4 — voto dividido

Manipula el timing de la elección para que dos candidates dividan los votos y ninguno forme mayoría.

Objetivo de ejemplo:

```text
A <- A,B
C <- C,D
E indeciso o dividido por timing
```

Confirma que ningún líder se elige sin mayoría.

Permite después que comience un term posterior y que finalmente se elija un líder.

Mide el tiempo de recuperación de la elección desde el term sin resolver hasta un liderazgo estable.

### Paso A5 — evidencia de term mayor

Toma un líder en term T y entrega un mensaje válido que contenga term `T+1` o mayor.

Verifica que el líder o candidate obsoleto actualiza su term y pasa a follower según corresponde.

### Paso A6 — log de candidate obsoleto

Prepara:

```text
A/B: log más nuevo
C: log más antiguo
```

Permite que C inicie una elección con un term actual mayor.

Verifica que A/B rechazan el voto porque el log de C no está suficientemente actualizado.

Esta prueba establece que la elección está acoplada a la safety del log replicado.

## Checkpoint B — Replicación del log

### Paso B1 — añadir un comando

Con un líder estable, envía un comando ficticio como:

```text
SET x 1
```

El payload del Capítulo 7 todavía no tiene que modificar estado de aplicación.

Observa:

```text
append del líder
AppendEntries a followers
validación del prefijo por followers
replicación exitosa
actualización de matchIndex
avance de commitIndex
```

### Paso B2 — commit por mayoría

Para N=5, retrasa o aísla dos followers mientras permites la comunicación entre el líder y otros dos followers.

Envía un comando del term actual.

Verifica que puede quedar committed después de replicarse en una mayoría de tres.

Aísla después otro follower para que solo dos nodos sigan conectados y demuestra que un comando nuevo no queda committed.

### Paso B3 — follower retrasado

Mantén desconectado un follower mientras varias entradas quedan committed en la mayoría.

Reconéctalo.

Observa cómo el líder lo lleva hasta el prefijo actual.

Mide tiempo de catch-up y número de intentos AppendEntries.

### Paso B4 — sufijo en conflicto

Crea o inyecta un log controlado de follower con un sufijo obsoleto no committed, por ejemplo:

```text
leader:   1:t1 2:t1 3:t2 4:t4 5:t4
follower: 1:t1 2:t1 3:t2 4:t3 5:t3 6:t3
```

Verifica que el follower rechaza un prefijo incompatible y que el líder termina encontrando el punto coincidente y reemplaza únicamente el sufijo no committed en conflicto.

El log final del follower debe coincidir con el del líder en todo el rango replicado.

### Paso B5 — líder antiguo en partición minoritaria

Comienza con A como líder.

Partición:

```text
A B   X   C D E
```

Mantén vivos todos los procesos.

Envía el comando X al antiguo líder A y el comando Y al lado mayoritario después de que elija un líder de term más reciente.

Antes de ejecutar, predice:

- si A puede añadir X localmente;
- si A puede hacer commit de X;
- si C/D/E pueden elegir un nuevo líder;
- si Y puede quedar committed;
- qué debe ocurrir con X no committed después de reparar la partición.

Captura la traza completa.

### Paso B6 — reparar y reconciliar

Restaura la comunicación.

Verifica:

- el líder antiguo descubre el term más reciente y deja de ser líder;
- la historia committed por la mayoría sobrevive;
- los sufijos obsoletos o en conflicto no committed se reparan;
- todos los nodos terminan acordando el prefijo committed.

Define recuperación como algo más que volver a conectar la red.

## Paso C — Auditoría de la regla de commit

Construye un estado de log/terms en el que una entrada de un term anterior aparece en una mayoría, pero el líder actual todavía no ha committed una entrada de su term actual que cubra ese prefijo.

Explica por qué la implementación debe seguir la regla de commit de Raft en lugar de marcar directamente como committed cualquier entrada antigua presente en mayoría.

El harness ejecutable puede ofrecerlo como fixture determinista de estado cuando esté disponible.

## Paso D — `commitIndex` frente a estado de aplicación

Expón las entradas committed, pero todavía no implementes toda la aplicación KV.

Crea un stream o método explícito de handoff:

```text
CommittedEntry{index, term, command}
```

que el Capítulo 10 pueda consumir.

Esto refuerza:

```text
el módulo de consenso decide el orden
el módulo de máquina de estados ejecuta los comandos
```

## Paso E — Ambigüedad de la respuesta al cliente

Envía la solicitud lógica R7 al líder.

Haz que R7 quede committed y después pierde o retén la respuesta al cliente.

El cliente debe observar un timeout o un resultado desconocido aunque la capa de consenso sepa que R7 está committed.

**No** resuelvas todavía la aplicación duplicada en el Capítulo 7. Registra el problema para el Capítulo 10.

## Paso F — Tabla de invariantes de safety

Para cada experimento de fallo, completa:

| Escenario | Election safety | Safety del prefijo committed | Liveness/progreso | Evidencia |
|---|---|---|---|---|
| voto dividido | | | | |
| un crash | | | | |
| líder antiguo en minoría | | | | |
| candidate obsoleto | | | | |
| sufijo en conflicto | | | | |
| retraso severo | | | | |

Un clúster correcto puede dejar temporalmente de progresar y seguir preservando safety.

## Extensión G — Comparación conceptual Raft/Paxos

No se exige implementar Paxos.

Usa las lecturas para comparar:

```text
epoch / term / ballot
intersección de quórums
preservación de decisiones anteriores
optimización mediante líder estable
decisiones repetidas del log
```

No describas Paxos simplemente como «Raft más difícil».

## Extensión H — Traza de consenso auditada con IA

Entrega a un asistente de IA una traza que contenga:

- dos terms;
- un cambio de líder;
- una entrada no committed del líder antiguo;
- una entrada posterior committed.

Pregunta qué entradas están committed y por qué.

Audita cada respuesta contra:

- tamaño de la mayoría;
- term;
- frescura del log;
- regla de commit;
- transiciones de rol.

Se evalúa tu auditoría basada en invariantes.

## Paso I — Exploración acotada de planificaciones

Un clúster vivo solo muestra un orden de eventos cada vez. Usa el pequeño explorador de planificaciones incluido para hacer reproducible un fallo de invariante sin depender del timing real.

Ejecuta:

```bash
python3 starter/src/vote_schedule_demo.py
```

El primer modelo trata un voto concedido como volátil después de un reinicio. El explorador permuta un conjunto finito de eventos y debe encontrar un orden en el que un nodo concede votos a dos candidates dentro del mismo term.

Compáralo con el modelo de voto durable, donde el mismo conjunto acotado de eventos no debe producir ese contraejemplo.

Registra:

```text
invariante
conjunto de eventos
estados explorados
traza del contraejemplo, si existe
supuesto del modelo que causó o corrigió la violación
```

Crea después un caso pequeño propio. Mantén el estado abstracto. Buenos objetivos incluyen dos procesos que creen poseer autoridad exclusiva, un líder obsoleto que actúa después de recibir evidencia de un term mayor o una entrada aplicada antes de que el modelo la considere committed.

Este es un modelo docente acotado, no una demostración del protocolo completo. Declara qué espacio de eventos/estado exploraste y qué queda fuera del modelo.

## Objetivo de pruebas transparentes

Las pruebas públicas ejecutables viven en `tests/official/`, con un modelo determinista de razonamiento Raft y un explorador acotado de planificaciones en `starter/src/`. Verifican elección, prefijos de log, reparación de sufijos, regla de commit y pequeños comportamientos de planificaciones/invariantes; el protocolo completo de timing y particiones de cinco nodos sigue evaluándose mediante evidencia.

Todos los casos públicos están documentados en `tests/official/README.md`. `make test` ejecuta únicamente esas pruebas oficiales visibles y los casos del estudiante en `tests/student/`.

No se planifican pruebas ocultas.

## Uso de IA

Se permiten asistentes de IA y agentes de programación.

El consenso es especialmente vulnerable a código generado que parece plausible pero es inseguro. Sigues siendo responsable de cada transición de term, voto, log y commit y debes poder explicar y modificar la implementación durante la revisión.

## Informe

Completa `REPORT.md` con:

- modelo de estado y persistencia;
- traza de elección limpia;
- voto dividido;
- prueba de voto con crash/reinicio;
- elección de candidate obsoleto;
- partición mayoría/minoría;
- reparación de sufijo en conflicto;
- razonamiento sobre la regla de commit;
- tabla de safety/liveness;
- ambigüedad de respuesta al cliente;
- auditoría de la traza con IA.

## Termina el capítulo

Reproduce el resultado importante desde un inicio limpio. Después vuelve a tu predicción inicial: explica qué cambió, qué evidencia provocó el cambio y qué incertidumbre queda. Un comando exitoso o una captura no bastan cuando la afirmación trata de retries, orden, durabilidad, consistencia, recovery, seguridad o rendimiento.

<div class="ds-next-action">
  <span>Capítulo completo</span>
  <strong>Continuar el curso</strong>
  <a href="../../m04-architecture-discovery/">Nombres, descubrimiento y búsqueda descentralizada →</a>
</div>

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../../m06-time-causality/">← Coordinación I — Tiempo, eventos y causalidad</a>
<a class="ds-sequence-link next" href="../../m04-architecture-discovery/">Nombres, descubrimiento y búsqueda descentralizada →</a>
</nav>
