<div class="ds-lesson-banner">
  <div><span>Laboratorio obligatorio</span><strong>Capítulo 11</strong></div>
  <div><span>Modelo de evidencia</span><strong>predecir → ejecutar → observar → explicar</strong></div>
  <div><span>Verificación</span><strong>10 pruebas públicas transparentes + evidencia</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 11 de 12</span>
    <span>92% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 92%"></span></div>
</div>
<p class="ds-back-link"><a href="../quick-check/">← Volver a la comprobación</a></p>

> **Antes de comenzar:** Completa los pasos de práctica guiada y comprobación de conocimientos. Ya deberías poder formular una predicción y nombrar la evidencia que la apoyaría o contradeciría. Si no, [vuelve a la comprobación](../quick-check/) y revisa la lección donde haga falta.

## Objetivo

Construye un pequeño servicio particionado, mide la diferencia entre operaciones locales y entre shards, implementa un protocolo 2PC simplificado y después recorre ventanas de crash del coordinador y los participantes, además de una comparación de saga/rebalanceo.

Este laboratorio no usa Ray.

## Pregunta principal

> Cuando una operación lógica cruza varios shards con propietarios independientes, ¿qué estado debe conservar cada participante para que el sistema todavía pueda alcanzar un único resultado coherente después de fallos?

## Ruta esencial de completamiento

Completa los Pasos 1–14 y la campaña de fallos del Paso 16. El Paso 15 (rendimiento con hot-shard o scatter/gather) es una **extensión** salvo que el profesor lo asigne. El Paso 17 solo es obligatorio si un agente de IA contribuyó a la implementación.

Trata los Pasos 12–14 como checkpoints acotados de comparación/recuperación, no como una invitación a construir tres sistemas de producción adicionales. El artefacto esencial sigue siendo un pequeño servicio con shards cuyo comportamiento transaccional, de recuperación y de propiedad puedas explicar a partir de evidencia.

## Modelo de servicio recomendado

Usa un pequeño servicio de cuentas o clave/valor con al menos dos shards.

Una API conveniente es:

```text
GET(key)
PUT(key,value)
TRANSFER(from_key,to_key,amount)
```

o un modelo equivalente con una operación claramente local y un invariante claramente entre shards.

Los logs estructurados deben exponer:

```text
transaction_id
shard_id
ownership_epoch
phase
participant_vote
global_decision
```

## Invariantes requeridos

Escríbelos antes de implementar:

1. Cada clave/rango tiene un único propietario declarado para un epoch de propiedad.
2. Una operación local afecta solo a su shard propietario.
3. Una transacción entre shards que termina alcanza una única decisión global COMMIT/ABORT.
4. Un participante PREPARED no olvida su promesa YES dentro del modelo de reinicio declarado.
5. Mensajes duplicados del protocolo no duplican efectos lógicos.
6. El rebalanceo no pierde silenciosamente escrituras alrededor del corte de propiedad.

---

## Paso 1 — particiona los datos

Implementa al menos dos shards y una política determinista de routing.

Opciones:

- por rangos;
- por hash;
- consciente de la aplicación.

Para cada clave el router debe poder explicar:

```text
key → shard
```

### Evidencia requerida

Proporciona:

- configuración de routing;
- al menos seis claves de ejemplo;
- shard elegido;
- un argumento que relacione la clave de partición con la carga.

---

## Paso 2 — establece una línea base local

Ejecuta operaciones que toquen un solo shard.

Mide al menos:

```text
latencia de solicitud
mensajes/RPC remotos
número de autoridades participantes
```

Cuando sea práctico, repite suficiente para observar una distribución y no un único timestamp.

Registra mediana y p95 si el harness lo soporta.

---

## Paso 3 — crea identidad estable de transacción

Toda operación entre shards necesita un ID estable, por ejemplo:

```text
T42
```

Cada participante debe tratar los mensajes repetidos de T42 como una misma transacción lógica.

Registra transiciones:

```text
T42 NEW
T42 PREPARED
T42 COMMITTED
T42 ABORTED
```

No generes un ID nuevo solo porque se reintentó un RPC.

---

## Paso 4 — implementa PREPARE simplificado

El coordinador identifica participantes y envía:

```text
PREPARE T42 ...
```

Cada participante debe:

1. validar precondiciones locales;
2. reservar/bloquear o comprobar versiones según tu modelo;
3. persistir/registrar PREPARED antes de prometer YES bajo el modelo de crash declarado;
4. responder YES o NO.

### Experimento requerido

Fuerza a un participante a votar NO.

Verifica que el resultado global sea ABORT y que ningún participante exponga un resultado parcial confirmado.

---

## Paso 5 — implementa la decisión global

Si todos votan YES, el coordinador registra una decisión COMMIT durable o lógicamente recuperable **antes** de tratar la transacción como globalmente confirmada.

En caso contrario registra ABORT.

Después envía la decisión a los participantes.

### Experimento normal requerido

Ejecuta una transferencia entre shards satisfactoria.

Muestra una traza equivalente a:

```text
PREPARE A
PREPARE B
YES A
YES B
GLOBAL COMMIT
COMMIT A
COMMIT B
```

Verifica el invariante de aplicación.

---

## Paso 6 — compara coste local y entre shards

Ejecuta cargas equivalentes cuando sea posible:

```text
operación local
operación entre shards
```

Compara:

- número de rondas del protocolo;
- participantes requeridos;
- mediana de latencia;
- p95;
- exposición a fallos.

Explica estructuralmente la diferencia, no solo los números.

---

## Paso 7 — mensajes de protocolo duplicados

Duplica deliberadamente, según aplique:

```text
PREPARE T42
COMMIT T42
ABORT T43
```

### Resultado requerido

Los mensajes repetidos del mismo ID no deben crear:

- reservas duplicadas;
- débitos/créditos duplicados;
- estados finales contradictorios.

Los logs deben mostrar que el duplicado fue reconocido.

---

## Paso 8 — crash del coordinador antes de la decisión global

Primer checkpoint de fallo requerido.

Ejecuta:

```text
1. los participantes votan YES
2. el coordinador cae antes de registrar COMMIT/ABORT
```

Los participantes PREPARED no deben inventar una decisión a partir del silencio.

### Evidencia requerida

Muestra:

- estado PREPARED persistido/recuperable;
- locks/recursos todavía retenidos si tu aislamiento los usa;
- imposibilidad de inferir con seguridad COMMIT o ABORT;
- procedimiento de recuperación.

### Conclusión requerida

Explica por qué esto es **bloqueo**, no una violación de seguridad.

---

## Paso 9 — crash después de COMMIT durable

Segundo checkpoint requerido.

Ejecuta:

```text
1. todos votan YES
2. el coordinador registra COMMIT
3. envía COMMIT a un solo participante
4. el coordinador cae
```

Después de reiniciar:

```text
cargar decisión de T
retransmitir el mismo COMMIT
los participantes restantes terminan
```

### Evidencia requerida

Demuestra que el coordinador no elige una decisión diferente tras reiniciar.

---

## Paso 10 — crash de participante mientras está PREPARED

Mata un participante después de su YES y antes de conocer la decisión final.

Reinícialo.

### Comportamiento requerido

Debe reconstruir:

```text
ID de transacción
estado PREPARED
reserva/cambio local necesario
```

y seguir pudiendo obedecer la decisión global recuperada.

Si tu implementación reducida no persiste ese estado, declara la limitación y demuéstrala con una simulación determinista de reinicio.

---

## Paso 11 — un timeout no es una decisión

Retrasa los mensajes de decisión coordinador→participante hasta que expire la espera local.

Verifica que, si ya votó YES, el participante no convierta silenciosamente:

```text
decisión desconocida
```

en:

```text
ABORT
```

Documenta cómo representa/maneja una transacción preparada sin resolver.

---

## Paso 12 — experimento de aislamiento/concurrencia

Ejecuta dos transacciones entre shards que toquen al menos una clave común.

Usa tu política:

- lock por clave;
- lock por transacción;
- validación optimista de versión;
- otra opción justificada.

### Evidencia requerida

Muestra si:

- una espera;
- una aborta/reintenta;
- ambas pueden progresar de forma segura.

Declara el aislamiento realmente implementado. No presentes 2PC como si fuera el mecanismo de aislamiento.

---

## Paso 13 — comparación con saga

Implementa o simula un workflow de tres pasos cuyo último paso pueda fallar.

Ejemplo:

```text
reservar recurso A
reservar recurso B
crear registro final
```

Ante el fallo final, ejecuta compensaciones.

### Análisis requerido

| Propiedad | Atomic commit estilo 2PC | Workflow estilo saga |
|---|---|---|
| estados intermedios visibles | | |
| bloqueo de participantes | | |
| compensación requerida | | |
| adecuado para acciones externas/largas | | |

Inyecta un timeout en una compensación y explica cómo un ID estable evita efectos duplicados cuando sea posible.

---

## Paso 14 — experimento de rebalanceo

Mueve una partición/rango de A a B.

Introduce un epoch/version explícito:

```text
epoch 7: R pertenece a A
epoch 8: R pertenece a B
```

### Experimento requerido

Ejecuta escrituras durante la migración.

Demuestra tu regla de corte, por ejemplo:

```text
snapshot/copia en límite K
capturar cambios incrementales
activar epoch 8
rechazar/redirigir escrituras con epoch 7
```

u otro diseño coherente.

### Evidencia requerida

Demuestra que un router obsoleto no crea silenciosamente un segundo propietario autoritativo después del corte.

---

## Paso 15 — hot shard o scatter/gather

Elige una opción.

### Hot shard

Genera una carga donde una clave/rango reciba una fracción desproporcionada de solicitudes. Mide desequilibrio de cola/latencia.

### Scatter/gather

Emite una consulta que necesite todos los shards. Retrasa uno y mide el impacto sobre la latencia extremo a extremo.

Explica cómo el particionamiento determina ese resultado.

---

## Paso 16 — campaña de fallos

Incluye como mínimo:

```text
F1  participante vota NO
F2  PREPARE/COMMIT duplicados
F3  crash del coordinador antes de la decisión
F4  crash después de COMMIT durable
F5  crash de participante mientras PREPARED
F6  decisión retrasada / timeout del participante
F7  transacciones concurrentes conflictivas
F8  routing obsoleto durante rebalanceo
```

Para cada uno proporciona:

```text
predicción
punto de fallo
estado recuperable
resultado observado
juicio de atomicidad/aislamiento
comportamiento de recuperación
```

---

## Paso 17 — auditoría de IA

Si participó un agente de IA, pídele explícitamente analizar las ventanas de crash de las máquinas de estados de coordinador y participante.

Busca errores frecuentes:

- respuesta YES antes de hacer durable PREPARED;
- devolver COMMIT global al cliente antes de que la decisión sea recuperable;
- abortar unilateralmente después de timeout estando PREPARED;
- crear un ID nuevo al reintentar;
- aplicar otra vez la mutación ante COMMIT duplicado;
- perder la transacción PREPARED tras reiniciar.

Documenta al menos un problema que verificaste, corregiste o rechazaste.

---

## Objetivo de pruebas transparentes

Los casos públicos están documentados en:

```text
tests/official/README.md
```

Las pruebas ejecutables viven en `tests/official/`, con helpers deterministas de routing y máquina de estados 2PC en `starter/src/`. Verifican epochs de propiedad, decisiones estables e idempotencia de mensajes; las ventanas reales de crash y el rebalanceo siguen evaluándose mediante evidencia.

No se planean casos ocultos.

Puedes añadir pruebas en `tests/student/`.

---

## Entrega

Incluye:

- código fuente;
- configuración de routing/propiedad;
- instrucciones reproducibles;
- `REPORT.md`;
- trazas de transacciones legibles por máquinas;
- pruebas públicas y propias;
- declaración de uso de IA.

## Criterio de éxito

Una entrega satisfactoria puede afirmar con precisión:

> Estos datos pertenecen a estos shards; estas operaciones siguen siendo locales; esta operación cruza estos participantes; este estado durable sostiene una única decisión global 2PC bajo el modelo de crash probado; y este workflow alternativo usa compensación en lugar de fingir atomicidad.

## Termina el capítulo

Reproduce el resultado importante desde un inicio limpio. Después vuelve a tu predicción inicial: explica qué cambió, qué evidencia provocó el cambio y qué incertidumbre queda. Un comando exitoso o una captura no bastan cuando la afirmación trata de retries, orden, durabilidad, consistencia, recovery, seguridad o rendimiento.

<div class="ds-next-action">
  <span>Capítulo completo</span>
  <strong>Continuar el curso</strong>
  <a href="../../m15-security-byzantine/">Seguridad, confianza y operación de sistemas distribuidos →</a>
</div>

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../../m07-failures/">← Tolerancia a fallos I — Modelos de fallo, resiliencia y recuperación</a>
<a class="ds-sequence-link next" href="../../m15-security-byzantine/">Seguridad, confianza y operación de sistemas distribuidos →</a>
</nav>
