> **Vista de referencia.** Esta página ofrece contexto opcional; vuelve a la [Lección](../lesson/) para la ruta obligatoria.

## Esencial

- **●●● Notes on Data Base Operating Systems** — Jim Gray. [classic reference](https://jimgray.azurewebsites.net/papers/DBOS.pdf)

## Recomendado

- **●●● Consistent Hashing and Random Trees** — David Karger et al.. [paper](https://www.cs.princeton.edu/courses/archive/fall09/cos518/papers/chash.pdf)
- **●● Designing Data-Intensive Applications** — Martin Kleppmann. [book](https://dataintensive.net/)

## Avanzado

- **●●● Spanner: Google's Globally-Distributed Database** — Corbett et al.. [paper](https://research.google/pubs/spanner-googles-globally-distributed-database/)
- **●●● Dynamo: Amazon's Highly Available Key-value Store** — DeCandia et al.. [paper](https://www.allthingsdistributed.com/files/amazon-dynamo-sosp2007.pdf)

## Herramientas y práctica

- **● The Go Documentation** — The Go Project. [tool documentation](https://go.dev/doc/)

## Explora

- **●●● 6.5840 Distributed Systems** — MIT PDOS. [course](https://pdos.csail.mit.edu/6.824/)
