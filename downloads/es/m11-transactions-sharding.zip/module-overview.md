<p class="ds-book-part">Parte IV — Tolerancia a fallos</p>
<p class="ds-module-kicker">Capítulo 11</p>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 11 de 12</span>
    <span>92% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 92%"></span></div>
</div>
<p class="ds-guiding-question">¿Qué ocurre cuando una operación lógica modifica estado perteneciente a varias máquinas que pueden fallar de forma independiente?</p>

Particionar el estado crea varias autoridades. Una transición que antes era local puede necesitar ahora commit atómico, registros durables de recuperación, replay, compensación, transferencia de estado o cambio de ownership. Traza los puntos de crash antes de elegir el mecanismo.

## Ideas clave

- particionamiento y sharding;
- hashing consistente y ownership;
- decisiones durables;
- two-phase commit;
- estado prepared y blocking;
- recuperación de coordinador/participante;
- replay y mensajes de protocolo duplicados;
- sagas y compensación;
- snapshots/state transfer;
- rebalanceo y operaciones cross-shard.

## Transición al laboratorio

Particiona el servicio, añade una operación cross-owner, mata el coordinador en varios puntos del protocolo, reinícialo y usa evidencia durable para justificar el resultado final.

## Empieza aquí

> **Antes de leer:** Una transferencia debita un shard y debe acreditar otro. El coordinador falla después de preparar el débito. ¿Qué hechos deben ser durables antes de que cualquier participante pueda decidir?

**Trae contigo:** Razonamiento sobre replicación, acuerdo y recuperación tras fallos.

**Este capítulo te prepara para:** Un modelo de recuperación para operaciones que atraviesan estado perteneciente a autoridades independientes.

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>35 min–50 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>50 min–1 h 15 min</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>2 h 30 min–3 h 30 min · 10 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<p class="ds-workload-note"><strong>Alcance esencial:</strong> La ruta esencial del laboratorio son los Pasos 1–14 más la campaña de fallos del Paso 16. El Paso 15 es una extensión de rendimiento y la auditoría de IA solo es obligatoria si se usó IA. Los Pasos 12–14 son checkpoints acotados de comparación/recuperación, no sistemas de producción separados.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Leer lección →</a>
  <a class="ds-secondary-action" href="lab/">Abrir laboratorio</a>
</div>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../downloads/es/m11-transactions-sharding.zip" download>Descargar capítulo + laboratorio para estudio sin conexión (.zip)</a></p>

## Qué aprenderás

- Explica cómo el particionamiento convierte un sistema lógico en varias autoridades de estado.
- Compara operaciones locales y operaciones entre varios propietarios e identifica cuándo se necesita coordinación atómica.
- Traza two-phase commit a través de fallos del coordinador/participantes y recuperación durable.
- Compara commit atómico bloqueante con flujos de trabajo basados en sagas/compensaciones.
- Razona sobre snapshots/transferencia de estado, mensajes de protocolo duplicados, rebalanceo y movimiento de propiedad.

## Aprende trabajando la pregunta

1. Escribe tu respuesta a **Empieza aquí** antes de abrir la lección completa.
2. Lee hasta la siguiente predicción o traza; detente y resuélvela antes de revelar la explicación.
3. Trata la práctica guiada como un **banco de práctica**, no como una hoja para completar deprisa. Trabaja las trazas centrales hasta alcanzar el objetivo de práctica y vuelve después a los casos restantes.
4. Usa la comprobación para detectar vacíos y entra al laboratorio con una predicción falsable y con la evidencia que podría contradecirla.
5. Termina explicando qué estableció el experimento, qué no estableció y cómo cambia tu explicación del servicio acumulativo.

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../m07-failures/">← Tolerancia a fallos I — Modelos de fallo, resiliencia y recuperación</a>
<a class="ds-sequence-link next" href="../m15-security-byzantine/">Seguridad, confianza y operación de sistemas distribuidos →</a>
</nav>
