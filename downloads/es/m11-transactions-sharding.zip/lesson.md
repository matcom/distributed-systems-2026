<p class="ds-book-part">Parte IV — Tolerancia a fallos</p>
<div class="ds-lesson-banner">
  <div><span>Paso del curso</span><strong>Capítulo 11</strong></div>
  <div><span>Lectura esencial</span><strong>35 min–50 min</strong></div>
  <div><span>Ruta obligatoria</span><strong>Leer → Objetivo de práctica → Comprobar → Laboratorio</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 11 de 12</span>
    <span>92% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 92%"></span></div>
</div>

> **Pregunta guía:** ¿Qué ocurre cuando una operación lógica modifica estado perteneciente a varias máquinas que pueden fallar de forma independiente?

## Antes de leer

> Una transferencia debita un shard y debe acreditar otro. El coordinador falla después de preparar el débito. ¿Qué hechos deben ser durables antes de que cualquier participante pueda decidir?

Escribe primero una respuesta breve. No necesitas acertar todavía: necesitas una predicción que puedas revisar a medida que el capítulo te dé mejores modelos y evidencia.

**Usa lo que ya sabes:** Razonamiento sobre replicación, acuerdo y recuperación tras fallos.

## Mapa de carga de trabajo

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>35 min–50 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>50 min–1 h 15 min</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>2 h 30 min–3 h 30 min · 10 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<p class="ds-workload-note"><strong>Alcance esencial:</strong> La ruta esencial del laboratorio son los Pasos 1–14 más la campaña de fallos del Paso 16. El Paso 15 es una extensión de rendimiento y la auditoría de IA solo es obligatoria si se usó IA. Los Pasos 12–14 son checkpoints acotados de comparación/recuperación, no sistemas de producción separados.</p>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../../downloads/es/m11-transactions-sharding.zip" download>Descargar lección + práctica + laboratorio para estudio sin conexión (.zip)</a></p>

## Por qué importa este capítulo

El trabajo anterior de coordinación y replicación nos dio una máquina de estados fuertemente ordenada y replicada. Esa arquitectura es poderosa, pero los sistemas reales suelen crecer más allá de un único grupo de estado.

Los datos pueden dividirse porque:

- un solo nodo no puede contenerlos todos;
- un único líder no soporta todas las escrituras;
- conviene atender a los usuarios cerca de sus datos;
- las cargas se separan de forma natural;
- equipos o servicios independientes poseen estado distinto.

Cuando el estado se particiona, una operación que toca **una sola partición** puede seguir siendo relativamente simple. Una operación que afecta a **varias particiones con autoridades independientes** se convierte en un problema de coordinación.

La pregunta guía es:

> **¿Qué ocurre cuando una operación lógica debe cambiar estado propiedad de varias máquinas?**

La progresión del capítulo es:

```text
particionar los datos
        ↓
encaminar operaciones
        ↓
observar el coste local frente al coste entre shards
        ↓
coordinar cambios atómicos entre shards
        ↓
recuperar o compensar cuando fallan participantes
```

---

## 1. Particionar convierte un sistema en varias autoridades

Supón un servicio clave/valor con:

```text
A, B, C, D, E, F
```

Un único grupo replicado podría poseer las seis claves.

Con sharding podríamos tener:

```text
Shard 1: A, B
Shard 2: C, D
Shard 3: E, F
```

Cada shard puede, a su vez, estar replicado mediante las técnicas de coordinación y recuperación ya estudiadas.

Aparecen dos niveles:

```text
dataset lógico
   ↓ dividido en shards
varias autoridades de shard
   ↓ cada una puede estar replicada
varias réplicas por shard
```

Replicación y particionamiento resuelven problemas distintos.

**Replicar** crea copias adicionales del mismo estado lógico.

**Particionar/shardear** divide estados lógicos distintos entre propietarios.

Los sistemas reales suelen combinar ambos.

---

<aside class="ds-book-note ds-history">
  <span class="ds-book-note-label">Historia</span>
  <strong>Las transacciones distribuidas convirtieron un único punto local de commit en un protocolo entre máquinas</strong>
  <p>Cuando una operación lógica comenzó a modificar estado propiedad de varias máquinas, la atomicidad pasó a requerir votos durables, coordinadores, reglas de recuperación y aceptar bloqueo o mecanismos de coordinación más fuertes.</p>
  <a class="ds-book-note-source" href="../../../history/transactions-atomic-commit/">Lee la historia del diseño →</a>
</aside>

## 2. La clave de partición es una decisión arquitectónica

Una estrategia de particionamiento responde:

> Dado un objeto u operación, ¿qué shard lo posee?

### Particionamiento por rangos

```text
A–F → shard 1
G–M → shard 2
N–Z → shard 3
```

Ventajas:

- range scans naturales;
- interpretación humana sencilla.

Riesgos:

- rangos desiguales;
- rangos calientes;
- complejidad de rebalanceo.

### Particionamiento por hash

```text
shard = hash(key) mod N
```

Ventajas:

- suele distribuir bien claves aparentemente aleatorias.

Riesgos:

- las consultas por rango se dispersan;
- cambiar `N` remapea muchas claves con módulo ingenuo.

### Particionamiento consciente de la aplicación

Ejemplos:

```text
user_id
account_id
organization_id
region
project_id
```

Puede mantener juntos datos que interactúan con frecuencia.

La mejor clave de partición depende del patrón de acceso, no de la elegancia abstracta.

---

## 3. Un buen particionamiento intenta hacer locales las operaciones comunes

Considera un sistema de mensajería particionado por `conversation_id`.

La mayoría de las operaciones sobre una conversación puede permanecer dentro de un shard.

Si el mismo sistema se particionara por ID de mensaje, reconstruir una conversación podría requerir consultar muchos shards.

La clave de partición determina cuántas veces pagará el sistema el coste de la coordinación entre shards.

Objetivo útil:

> **Coloca los datos de modo que el límite de corrección más frecuente coincida con un único límite de propiedad.**

No elimina todas las operaciones distribuidas, pero puede convertirlas en excepcionales.

---

## 4. Las operaciones locales y entre shards tienen costes diferentes

Una operación local puede recorrer:

```text
cliente
  ↓
router
  ↓
líder del shard
  ↓
commit replicado
```

Una operación entre shards puede implicar:

```text
cliente/coordinador
      ↓
   shard A
      +
   shard B
      +
quizá shard C
```

Cada shard tiene:

- sus propios líderes/réplicas;
- su latencia de red;
- su estado de fallo;
- sus locks o validaciones;
- su propia decisión local.

El participante requerido más lento puede dominar la latencia.

Por eso el laboratorio mide por separado caminos locales y entre shards.

---

## 5. Ejemplo: transferencia entre cuentas de shards distintos

Supón que la cuenta A está en shard 1 y la cuenta B en shard 2.

Queremos:

```text
TRANSFER 10 from A to B
```

El invariante deseado es:

```text
A disminuye 10
Y
B aumenta 10
```

y no:

```text
A disminuye, B queda igual
```

ni:

```text
A queda igual, B aumenta
```

Si ambas cuentas pertenecieran a una sola máquina de estados fuertemente ordenada, la transferencia podría ser un único comando determinista.

En dos shards existen dos autoridades.

Necesitamos un protocolo para una decisión atómica que las abarque.

---

## 6. Atomic commit busca todo-o-nada entre participantes

Un protocolo de commit atómico debe conseguir:

```text
todos los shards participantes COMMIT
```

o:

```text
todos ABORT
```

para la misma transacción lógica.

No es lo mismo que consenso.

Consenso hace que varios nodos acuerden un valor o secuencia pese a fallos.

Atomic commit coordina a participantes que poseen estados locales independientes para decidir si una transacción distribuida puede confirmar.

Un sistema puede usar consenso **dentro de cada shard** y 2PC **entre shards**.

Esta composición es común y conceptualmente importante.

---

## 7. Two-phase commit — estructura básica

2PC tiene dos fases amplias.

### Fase 1 — prepare/vote

El coordinador pregunta:

```text
¿Puedes confirmar la transacción T?
```

Cada participante valida condiciones locales y responde:

```text
YES / PREPARED
```

o:

```text
NO / ABORT
```

### Fase 2 — decisión global

Si todos los participantes requeridos votan YES:

```text
COMMIT
```

En caso contrario:

```text
ABORT
```

Después se comunica la decisión.

```text
             coordinador
             /         \
        PREPARE       PREPARE
          ↓              ↓
       shard A         shard B
          │ YES          │ YES
          └──────┬───────┘
                 ↓
              COMMIT
              /    \
             ↓      ↓
          shard A  shard B
```

---

## 8. PREPARED es un estado durable real

Un participante que responde YES no puede olvidar casualmente esa promesa.

Votar YES significa, aproximadamente:

> He validado la transacción y he conservado suficiente estado y recursos para poder obedecer un COMMIT posterior.

El estado preparado puede contener:

- ID de transacción;
- cambios previstos;
- locks o reservas;
- voto durable;
- información suficiente para terminar COMMIT o ABORT después de reiniciar.

Un participante no debe votar YES y perder toda esta información ante un crash.

Si lo hace, el argumento de atomicidad global deja de ser válido.

---

## 9. Por qué 2PC puede bloquear

Supón que ambos participantes votan YES.

El coordinador cae antes de que conozcan la decisión final.

A sabe:

```text
voté YES
```

pero puede no saber si:

```text
el coordinador ya decidió COMMIT
```

o:

```text
todavía no había decidido
```

Si A aborta unilateralmente mientras B termina aprendiendo COMMIT, se rompe la atomicidad.

Un participante preparado puede tener que esperar hasta recuperar la decisión autoritativa.

Este es el problema clásico de bloqueo de 2PC.

La lección no es «2PC es malo».

Es:

> **La atomicidad entre autoridades independientes crea dependencia de recuperar una decisión global.**

---

## 10. El fallo del coordinador tiene varias ventanas distintas

Debes poder seguir al menos estas.

### Ventana A — antes de cualquier PREPARE

Ningún participante prometió nada. Abortar es simple.

### Ventana B — después de algunos PREPARE

Algunos pueden estar preparados y otros ni siquiera conocer T.

### Ventana C — después de todos los YES, antes de decisión global durable

Los participantes pueden bloquear esperando recuperación.

### Ventana D — después de COMMIT durable, antes de comunicarlo a todos

La recuperación debe redescubrir y retransmitir el mismo COMMIT.

### Ventana E — después de que algunos participantes confirman y otros todavía no conocen la decisión

La transacción está globalmente confirmada; los participantes retrasados deben aprender y aplicar esa misma decisión.

El informe debe identificar qué estado durable hace posible cada recuperación.

---

## 11. Los IDs de transacción cumplen el papel de los IDs de solicitud

Los capítulos de RPC y fallos usaron identidad lógica estable.

Las transacciones distribuidas necesitan la misma disciplina.

Cada participante debe reconocer `T42` como una sola transacción a través de:

- reintentos;
- reinicio del coordinador;
- PREPARE duplicado;
- COMMIT duplicado;
- ABORT duplicado.

Siempre que sea posible, los mensajes deben ser idempotentes respecto a un ID estable.

```text
PREPARE T42
PREPARE T42 otra vez
```

no debe crear dos reservas independientes.

---

## 12. 2PC y consenso resuelven fallos distintos

Supón que cada shard es una máquina de estados replicada:

```text
Shard A = grupo Raft A1,A2,A3
Shard B = grupo Raft B1,B2,B3
```

El coordinador 2PC pregunta a **las autoridades de shard** si pueden preparar/confirmar.

Raft dentro de A hace que el estado transaccional local de A sobreviva al fallo de una réplica.

Raft dentro de B hace lo mismo.

2PC coordina la decisión todo-o-nada entre A y B.

Por tanto:

```text
Raft/Paxos
→ acuerdo dentro de una autoridad replicada
```

mientras:

```text
2PC
→ decisión atómica entre participantes de una transacción
```

No son sustitutos.

---

## 13. Locks y aislamiento son problemas separados del atomic commit

2PC responde si todos confirman o abortan.

No define por sí mismo toda la política de concurrencia/aislamiento.

Supón dos transferencias concurrentes que modifican la misma cuenta.

Los participantes siguen necesitando:

- locking;
- validación optimista;
- comprobaciones de versión;
- scheduling serializable;
- otra política de control de concurrencia.

Una implementación educativa puede usar un lock por clave o por transacción, pero debe decir qué anomalías concurrentes evita.

No confundas:

```text
commit atómico
```

con:

```text
ejecución serializable
```

Son propiedades diferentes.

---

## 14. Two-phase locking y two-phase commit no son el mismo «2P»

Puede confundirse:

- 2PL: two-phase locking, disciplina de control de concurrencia;
- 2PC: two-phase commit, protocolo distribuido de commit atómico.

Pueden combinarse, pero resuelven problemas distintos.

Un sistema sencillo puede hacer:

```text
adquirir/mantener locks
        ↓
PREPARE 2PC
        ↓
decisión global
        ↓
COMMIT/ABORT
        ↓
liberar locks
```

Mantener locks mientras se espera recuperar al coordinador explica por qué transacciones preparadas bloqueadas pueden dañar disponibilidad.

---

## 15. Un timeout no significa que abortar sea seguro

Vuelve la lección central de RPC.

Un participante envía YES y espera la decisión global.

Se agota el tiempo de espera.

¿Puede abortar sin más?

No necesariamente.

El coordinador puede haber decidido COMMIT de manera durable.

El timeout significa:

```text
no conozco ahora la decisión
```

no:

```text
no existe una decisión COMMIT
```

Es el mismo límite epistemológico recurrente en el curso.

---

## 16. La recuperación necesita un registro autoritativo de la transacción

Un coordinador recuperable persiste suficiente información para reconstruir el estado:

```text
T42:
  participants = [A,B]
  phase = decided
  decision = COMMIT
```

Tras reiniciar puede retransmitir COMMIT hasta que los participantes reconozcan.

Un participante puede persistir:

```text
T42:
  state = PREPARED
  intended_change = ...
```

y no olvidar su promesa.

El almacenamiento puede ser simple en el curso, pero la semántica de recuperación debe ser explícita.

---

## 17. Las decisiones heurísticas son peligrosas

Bajo presión operacional puede resultar tentador dejar que un participante bloqueado decida localmente después de un timeout:

```text
si PREPARED durante > 30 s:
    abortar localmente
```

Puede devolver disponibilidad local, pero romper atomicidad si COMMIT ya había sido decidido en otro lugar.

Esas decisiones «heurísticas» cambian el contrato de corrección.

Si un proyecto las usa, el compromiso debe declararse y probarse.

---

## 18. Las sagas resuelven un problema empresarial diferente

No todo workflow multi-servicio necesita una transacción atómica.

Considera:

```text
reservar vuelo
reservar hotel
registrar conferencia
```

Mantener los tres servicios en PREPARED hasta un commit atómico puede ser irrealista.

Una saga divide el workflow en pasos locales ya confirmados y acciones de compensación.

```text
reservar vuelo       ✓
reservar hotel       ✓
registrar evento     ✗
        ↓
compensar/cancelar hotel
compensar/cancelar vuelo
```

El sistema puede atravesar estados intermedios visibles.

La garantía no es «todo el mundo cambió atómicamente».

El objetivo es un camino controlado de recuperación a nivel de negocio.

---

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosidad</span>
  <strong>La transacción distribuida más barata suele ser la que el modelo de datos evita</strong>
  <p>Operaciones dentro de un shard usan una autoridad; invariantes cross-shard necesitan más comunicación, estado durable y recuperación.</p>
  <p><strong>Pruébalo:</strong> Elige una partition key para cinco operaciones y maximiza cuántas permanecen single-shard.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">Más curiosidades del capítulo →</a>
</aside>

## 19. Compensar no es hacer rollback

Un rollback de base de datos puede hacer desaparecer una transacción local no confirmada como si nunca hubiera ocurrido.

Una compensación es otra acción real.

Por ejemplo:

```text
cobrar tarjeta $50
```

seguido por:

```text
reembolsar tarjeta $50
```

no es históricamente idéntico a no haber cobrado.

Puede haber:

- comisiones;
- notificaciones;
- registros de auditoría;
- observaciones externas;
- efectos temporales.

Por tanto, la semántica de saga debe describirse a nivel de aplicación.

---

## 20. Orquestación y coreografía son dos estilos de saga

### Orquestación

Un coordinador indica a cada paso qué hacer.

```text
coordinador de workflow
   ↓ reservar vuelo
   ↓ reservar hotel
   ↓ registrar
   ↓ compensar si hace falta
```

Ventajas:

- estado explícito del workflow;
- razonamiento global más sencillo.

Riesgos:

- el coordinador se vuelve una dependencia importante;
- la lógica puede centralizarse demasiado.

### Coreografía

Los servicios reaccionan a eventos.

```text
flight_booked
       ↓
reacciona servicio de hotel
       ↓
hotel_booked
       ↓
reacciona registro
```

Ventajas:

- acoplamiento menor;
- composición orientada a eventos.

Riesgos:

- más difícil observar y razonar sobre el workflow global;
- caminos de compensación más implícitos.

Ambos estilos pueden ser apropiados en proyectos.

---

## 21. Consistent hashing reduce el remapeo al cambiar membresía

El hash ingenuo:

```text
hash(key) mod N
```

puede remapear gran parte de las claves al cambiar `N`.

Consistent hashing coloca claves y nodos en un espacio lógico de identificadores, representado a menudo como un anillo.

Una clave se asigna a la siguiente posición de nodo según la regla elegida.

Cuando un nodo entra o sale, solo debe moverse una parte del espacio.

Esto conecta con las DHT, pero aquí el foco es **placement de datos y rebalanceo**, no routing descentralizado.

---

## 22. Los nodos virtuales mejoran la distribución de carga

Un nodo físico puede poseer varias posiciones o particiones virtuales:

```text
A físico posee A1,A2,A3,...
B físico posee B1,B2,B3,...
```

Cuando cambia la capacidad, pueden moverse algunas particiones virtuales sin remodelar todo el dataset.

La misma idea aparece con nombres como tokens, partitions, ranges o tablets.

---

## 23. Rebalancear es un problema de corrección, no solo de copiar bytes

Supón que el rango R se mueve de A a B mientras los clientes continúan escribiendo.

Una secuencia ingenua:

```text
copiar datos antiguos A → B
cambiar routing
```

puede perder escrituras que ocurrieron durante la copia.

Una migración correcta necesita un protocolo de transición.

Opciones:

- pausar brevemente escrituras;
- registrar una posición de corte del log;
- transferir snapshot más cambios incrementales;
- hacer temporalmente dual-write bajo una sola autoridad;
- encaminar mediante un coordinador de migración.

Debes indicar cuándo cambia la propiedad y cómo se manejan las escrituras alrededor del corte.

---

## 24. Los metadatos de routing también son estado distribuido

Con datos particionados, clientes/routers deben saber:

```text
¿qué shard posee K?
```

Ese mapeo puede quedar obsoleto.

Después de rebalancear, un cliente puede enviar al shard antiguo.

El antiguo puede:

- redirigir;
- devolver una versión más nueva del mapeo;
- reenviar temporalmente;
- rechazar y obligar a refrescar.

Los metadatos deben tener versión, epoch o encarnación para detectar propiedad obsoleta en vez de aceptarla silenciosamente.

---

## 25. Los hot shards rompen el escalado horizontal nominal

Un reparto uniforme de claves no implica carga uniforme.

Si una cuenta famosa recibe 30 % del tráfico, hash por `user_id` puede concentrar toda esa carga en un shard.

Es un problema de **hot key/hot shard**.

Mitigaciones posibles:

- caché;
- réplicas de lectura;
- dividir objetos calientes;
- agregación específica;
- particiones más finas;
- routing consciente de carga.

La solución depende de si esa clave necesita orden fuerte.

---

## 26. Scatter/gather intercambia sencillez por fan-out

Si una consulta no incluye la clave de partición, quizá deba preguntar a muchos shards.

Ejemplo:

```text
SELECT all users WHERE age > 40
```

cuando se particiona por `user_id`.

```text
router de consulta
  ├→ shard 1
  ├→ shard 2
  └→ shard 3
       ↓
fusionar resultados
```

La latencia depende ahora de varios shards y uno lento puede dominar la cola.

Esto conecta con observabilidad/rendimiento.

---

## 27. El trabajo entre shards amplifica la exposición a fallos

Una operación local puede depender de un único shard.

Una operación entre cinco participantes necesita que todos alcancen estados relevantes del protocolo.

Más dependencias crean más oportunidades de:

- retraso;
- timeout;
- reintentos;
- progreso parcial;
- retención de locks;
- fallo del coordinador.

Otra razón para diseñar placement alrededor de límites transaccionales frecuentes.

---

## 28. Ejemplo trabajado — transferencia 2PC satisfactoria

Estado inicial:

```text
Shard A: cuenta A = 100
Shard B: cuenta B = 40
```

Transacción:

```text
T7: transferir 30 A → B
```

Prepare:

```text
Coordinador → A: PREPARE T7 debit 30
A valida saldo, reserva/bloquea, persiste PREPARED, vota YES

Coordinador → B: PREPARE T7 credit 30
B valida, persiste PREPARED, vota YES
```

Decisión:

```text
Coordinador registra de forma durable COMMIT T7
```

Finalización:

```text
Coordinador → A: COMMIT T7
A aplica débito y libera recursos

Coordinador → B: COMMIT T7
B aplica crédito y libera recursos
```

Final:

```text
A = 70
B = 70
```

Los COMMIT duplicados deben ser inocuos gracias a la identidad estable.

---

## 29. Ejemplo trabajado — el coordinador cae después de decidir COMMIT

```text
A PREPARED YES
B PREPARED YES
coordinador registra COMMIT durable
coordinador envía COMMIT solo a A
A confirma
coordinador cae antes de comunicar con B
```

B permanece PREPARED.

Tras recuperar el coordinador:

```text
cargar decisión durable COMMIT T7
retransmitir COMMIT a B
B confirma
```

La atomicidad termina restaurándose porque la decisión autoritativa sobrevivió.

El intervalo donde A aplicó y B todavía no puede quedar oculto o controlado según la semántica de aislamiento.

---

## 30. Ejemplo trabajado — el coordinador cae antes de la decisión global

```text
A vota YES
B vota YES
coordinador cae antes de decidir de forma durable
```

A y B saben que prometieron confirmar si se les ordena, pero no pueden inferir el resultado global del silencio.

Pueden bloquear hasta recuperar coordinador o decisión.

Es la principal debilidad de vivacidad del 2PC clásico.

---

## 31. Ejemplo trabajado — compensación de saga

Workflow:

```text
reservar hotel   ✓
cobrar tarjeta   ✓
emitir ticket    ✗
```

Compensación:

```text
reembolsar tarjeta
cancelar reserva de hotel
```

Preguntas:

- ¿qué ocurre si expira la llamada de reembolso?
- ¿puede fallar la cancelación?
- ¿son idempotentes las compensaciones?
- ¿cómo se persiste el progreso?
- ¿qué pasa si el proceso cae después de compensar correctamente, pero antes de registrar el éxito?

Una saga reutiliza inmediatamente la semántica de reintentos y el estado durable de workflow.

---

## 32. Transacciones y particiones crean decisiones explícitas de disponibilidad

Durante una partición, una transacción entre shards puede no contactar con un participante necesario.

Si la atomicidad es obligatoria, el coordinador no puede confirmar solo la mitad alcanzable.

La disponibilidad disminuye.

Otra aplicación puede elegir saga o workflow eventual que acepte estados intermedios y permita más progreso independiente.

La arquitectura correcta depende del invariante empresarial.

---

## 33. El proyecto final no debe añadir 2PC solo para parecer distribuido

Un diseño pobre crea artificialmente muchos servicios y usa 2PC en todas partes.

Un mejor diseño pregunta:

> ¿Qué invariante cruza realmente límites de propiedad independientes?

Casos donde puede importar:

- transferencia entre cuentas;
- reserva de capacidad en dos recursos;
- mover atómicamente un objeto entre namespaces;
- confirmar resultado de torneo y ranking entre shards.

Casos donde saga/workflow eventual puede encajar mejor:

- notificaciones después de un cambio durable;
- etapas de transcodificación;
- workflows externos largos;
- pipelines de crawling e indexado.

---

## 34. Conexión con el catálogo de proyectos

### P07 — Calendario distribuido

Crear una reunión para varios usuarios puede modelarse como estado coordinado de varios propietarios o como invitaciones/aceptaciones.

### P09 — Almacén de archivos por etiquetas

Contenido y metadatos pueden pertenecer a shards distintos; mover o borrar cruza límites.

### P13 — Event log replicado

Topics/particiones son shards naturales. El estado de consumidores y operaciones multi-partición introducen coordinación.

### P16 — Object storage distribuido

Placement, rebalanceo, propiedad de metadatos y movimiento de objetos vuelven central el particionamiento.

### P19 — Vector search distribuido

Las colecciones pueden shardearse y las consultas hacer scatter/gather.

---

## 35. Ingeniería asistida con IA: el código transaccional es engañosamente fácil de generar

Un agente puede producir rápidamente un coordinador 2PC que parezca de libro.

Las preguntas difíciles están en las ventanas de crash y las promesas durables.

Debes poder responder:

- ¿qué registro exacto existe antes de decir YES?
- ¿se puede reintentar PREPARE con seguridad?
- ¿se puede reintentar COMMIT?
- ¿qué ocurre si el coordinador cae después de decidir pero antes de avisar a todos?
- ¿qué ocurre si un participante cae mientras está preparado?
- ¿qué locks/recursos permanecen retenidos?
- ¿cómo se identifica la transacción tras reiniciar?
- ¿qué permite concluir un timeout?

Un buen ejercicio es pedir una estrategia de «recuperación tras timeout» y comprobar si viola atomicidad permitiendo a un participante PREPARED abortar unilateralmente.

---

## 36. Errores comunes

### Error 1 — confundir replicación con particionamiento

Copias del mismo dato y división de datos diferentes resuelven problemas distintos.

### Error 2 — escoger clave de partición sin estudiar accesos

Puede transformar cada operación común en scatter/gather o transacción distribuida.

### Error 3 — decir «2PC garantiza consistencia»

2PC es atomic commit; no define toda propiedad de aislamiento o consistencia.

### Error 4 — no persistir PREPARED

Un voto YES es una promesa que debe sobrevivir al modelo de crash declarado.

### Error 5 — abortar tras timeout después de votar YES

El silencio no demuestra que el coordinador no haya decidido COMMIT.

### Error 6 — tratar compensación como rollback

Las compensaciones son operaciones reales y visibles.

### Error 7 — ignorar mensajes duplicados

La identidad estable debe hacer seguros PREPARE/COMMIT/ABORT repetidos.

### Error 8 — rebalancear copiando una vez y cambiando el router

Las escrituras concurrentes durante la migración pueden perderse o dirigirse mal.

### Error 9 — asumir que claves equilibradas implican carga equilibrada

Una hot key puede dominar un shard.

### Error 10 — usar transacción global cuando la propiedad local podría evitarla

Cambiar la arquitectura puede eliminar coordinación con más eficacia que optimizarla.

---

## Transición al laboratorio

El laboratorio construye un servicio pequeño con al menos dos shards, mide operaciones locales frente a operaciones entre shards, implementa un 2PC simplificado y recorre ventanas de fallo del coordinador y los participantes.

No necesitas construir una base de datos completa. Necesitas poder demostrar mediante trazas:

```text
qué shard posee cada dato
qué estado durable existe antes de cada promesa
qué decisión global se tomó
cómo sobrevive esa decisión a crash/reintento
cómo se evita perder escrituras durante rebalanceo
```

El objetivo final es reconocer que, con frecuencia, la mejor optimización de una transacción distribuida es cambiar el placement para que la transacción deje de ser distribuida.

<div class="ds-next-action">
  <span>Lectura esencial completada</span>
  <strong>Siguiente paso obligatorio · Práctica guiada</strong>
  <a href="../guided-practice/">Comenzar práctica guiada →</a>
</div>
