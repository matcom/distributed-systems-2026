<div class="ds-lesson-banner">
  <div><span>Laboratorio obligatorio</span><strong>Capítulo 6</strong></div>
  <div><span>Modelo de evidencia</span><strong>predecir → ejecutar → observar → explicar</strong></div>
  <div><span>Verificación</span><strong>10 pruebas públicas transparentes + evidencia</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 6 de 12</span>
    <span>50% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 50%"></span></div>
</div>
<p class="ds-back-link"><a href="../quick-check/">← Volver a la comprobación</a></p>

> **Antes de comenzar:** Completa los pasos de práctica guiada y comprobación de conocimientos. Ya deberías poder formular una predicción y nombrar la evidencia que la apoyaría o contradeciría. Si no, [vuelve a la comprobación](../quick-check/) y revisa la lección donde haga falta.

## Objetivo

Instrumenta tres procesos que se comunican usando timestamps de reloj de pared, duraciones monotónicas locales, relojes de Lamport y relojes vectoriales; después reconstruye la ejecución causal a partir de logs desordenados cuyos relojes físicos discrepan deliberadamente.

Lección central:

> **Las lecturas de reloj son observaciones. La causalidad proviene del orden local, las aristas de mensajes y la transitividad.**

## Topología requerida

Usa tres procesos independientes:

```text
P1 -> P2 -> P3
 \           ^
  \----------/
```

Cada proceso debe tener:

- ID estable de nodo;
- ID de encarnación generado al iniciar;
- eventos locales con nombre;
- envío/recepción con IDs de mensaje;
- timestamp Lamport;
- vector clock;
- offset artificial configurable para el wall time mostrado.

El offset solo cambia el **timestamp de pared informado**. No debe retrasar la ejecución ni modificar reglas lógicas.

## Esquema de traza

Un registro apropiado incluye:

```text
node_id
incarnation_id
event_id
event_type
message_id (cuando corresponda)
peer_id (cuando corresponda)
wall_time
monotonic_elapsed_ms
lamport
vector
```

Puedes añadir campos, pero explica qué prueba cada uno.

## Paso 1 — ejecución base

Ejecuta un workflow determinista sin offset artificial.

Por ejemplo:

```text
P1: local A
P1: send M1 to P2
P2: receive M1
P2: local B
P3: local C
P2: send M2 to P3
P3: receive M2
P1: send M3 to P3
P3: receive M3
```

Antes, dibuja las aristas happened-before esperadas.

No asignes timestamps «por intuición». Derívalos del algoritmo.

## Paso 2 — relojes de pared contradictorios

Repite con offsets como:

```text
P1: +250 ms
P2: -300 ms
P3: +100 ms
```

Elige valores que produzcan al menos una recepción con wall time anterior al envío correspondiente.

Documenta:

```text
orden por wall time:
receive M1
send M1
```

y explica por qué la identidad de M1 demuestra:

```text
send(M1) -> receive(M1)
```

No edites manualmente los timestamps para «arreglar» el log.

## Paso 3 — implementa Lamport

Usa una convención coherente, por ejemplo:

- incrementa antes de evento local/envío;
- adjunta el valor al mensaje;
- al recibir: `L=max(L_local,L_message)+1`.

Repite el workflow.

Verifica para todo mensaje:

```text
L(send) < L(receive)
```

Incluye también dos eventos donde uno tenga Lamport menor sin existir camino causal entre ellos. Eso demuestra que el recíproco no vale.

## Paso 4 — implementa vectores

Usa una componente por proceso:

- incrementa la componente local en evento local/envío;
- adjunta el vector;
- al recibir, máximo por componente y después incrementa la componente del receptor.

Encuentra:

1. un par `a→b` con `V(a)<V(b)`;
2. un par con vectores incomparables y, por tanto, causalmente concurrente.

## Paso 5 — crea concurrencia deliberada

Haz que P1 y P3 realicen eventos locales independientes antes de recibir información derivada del otro.

Registra los vectores.

Explica por qué ninguno domina.

No llames concurrentes a los eventos solo porque sus wall timestamps estén próximos.

## Paso 6 — desordena la traza

Combina todos los registros y desordena las líneas de forma aleatoria o determinista.

Reconstruye un grafo causal válido usando:

- secuencia local o predecesor explícito;
- pares send/receive por ID de mensaje;
- Lamport/vector como comprobaciones de coherencia.

El orden por wall time puede mostrarse como comparación, pero no puede ser el algoritmo principal.

## Paso 7 — compara tres órdenes

### Orden por wall time

Marca inversiones aparentes imposibles de send/receive.

### Orden total Lamport

Ordena por:

```text
(lamport, node_id, event_id)
```

u otro desempate estable.

Explica que es un total order determinista y **no** demuestra que cada evento anterior causara al posterior.

### Orden parcial causal

Dibuja o tabula únicamente aristas justificadas por happened-before.

Esta es la vista más importante.

## Paso 8 — ejemplo causal de réplicas

Parte dos réplicas lógicas de una versión vectorial común.

Desconéctalas y actualiza una vez cada una.

Obtén vectores como:

```text
A: [2,0]
B: [1,1]
```

Tras reconectar, muestra que son incomparables.

Responde por separado:

- ¿detecta el sistema que las escrituras son concurrentes?
- ¿determina el vector qué valor debe ganar?

La distinción requerida es **detección frente a resolución**.

## Paso 9 — duración local frente a wall clock

Mide una operación local con temporizador monotónico y también imprime wall start/end.

Perturba únicamente el wall time mostrado.

Explica por qué no debe calcularse duración restando ciegamente timestamps de pared ajustables.

## Paso 10 — experimento mental de lease

Un worker anuncia un lease válido 15 s.

Explica por qué Lamport no puede responder «¿han pasado 15 s?».

Identifica:

- mecanismo local adecuado para duración;
- incertidumbre distribuida que permanece cuando otro nodo decide validez.

Esto prepara el capítulo de fallos.

## Paso 11 — reconstrucción auditada con IA

Da a un asistente un subconjunto desordenado de tu traza.

Audita cada arista que proponga.

Para una conclusión clasifica el razonamiento:

- arista causal válida;
- inferencia no justificada por wall time;
- inferencia no justificada por magnitud Lamport;
- evidencia insuficiente.

Tu auditoría, no la respuesta del modelo, es el artefacto evaluado.

## Pruebas transparentes

Las pruebas públicas están en `tests/official/`, con primitivas Lamport/vector en `starter/src/`. Verifican transiciones deterministas y comparaciones causales; reconstrucción de trazas, skew de wall clock y medición de duración siguen siendo experimentales.

Los casos están documentados en `tests/official/README.md`. `make test` debe ejecutar esas mismas pruebas visibles y las del estudiante.

No se planean pruebas ocultas.

## Informe

Completa `REPORT.md` con:

- topología de eventos;
- una contradicción de wall time;
- asignación Lamport completa;
- asignación vectorial completa;
- un par causal;
- un par genuinamente concurrente;
- reconstrucción de traza desordenada;
- comparación wall/Lamport/causal;
- conflicto causal de réplicas;
- auditoría de IA.

Las capturas no sustituyen la traza estructurada.

## Uso de IA

Se permiten asistentes y agentes salvo checkpoint marcado como independiente.

Sigues siendo responsable de cada actualización de reloj y afirmación causal. Un diagrama generado no es evidencia si no puedes derivar sus aristas.

## Termina el capítulo

Reproduce el resultado importante desde un inicio limpio. Después vuelve a tu predicción inicial: explica qué cambió, qué evidencia provocó el cambio y qué incertidumbre queda. Un comando exitoso o una captura no bastan cuando la afirmación trata de retries, orden, durabilidad, consistencia, recovery, seguridad o rendimiento.

<div class="ds-next-action">
  <span>Capítulo completo</span>
  <strong>Continuar el curso</strong>
  <a href="../../m09-consensus/">Coordinación II — Exclusión mutua, elecciones y acuerdo →</a>
</div>

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../../m12-dht-gossip/">← Comunicación II — Mensajería, diseminación y overlays</a>
<a class="ds-sequence-link next" href="../../m09-consensus/">Coordinación II — Exclusión mutua, elecciones y acuerdo →</a>
</nav>
