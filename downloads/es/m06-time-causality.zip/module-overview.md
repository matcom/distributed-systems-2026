<p class="ds-book-part">Parte II — Comunicación y coordinación</p>
<p class="ds-module-kicker">Capítulo 6</p>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 6 de 12</span>
    <span>50% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 50%"></span></div>
</div>
<p class="ds-guiding-question">Si los relojes no coinciden, ¿cómo puedes seguir razonando sobre qué ocurrió antes que qué?</p>

Usa relojes físicos cuando aporten información, pero mantén visible su incertidumbre. Trabaja sincronización acotada y pasa después al orden causal basado en mensajes cuando los timestamps de pared no basten.

## Ideas clave

- relojes físicos, drift y error de sincronización;
- sincronización estilo Cristian;
- intuición y límites de NTP;
- happened-before;
- relojes lógicos de Lamport;
- relojes vectoriales;
- orden causal;
- eventos concurrentes;
- trazas de eventos.

## Transición al laboratorio

Instrumenta tres procesos con offsets de reloj de pared, Lamport y vector clocks. Mezcla sus logs y reconstruye la ejecución causal.

## Empieza aquí

> **Antes de leer:** El nodo B registra la recepción a las 09:59:59.900 de un mensaje que el nodo A dice haber enviado a las 10:00:00.100. ¿Qué hecho confías más: las marcas de tiempo o la arista del mensaje?

**Trae contigo:** Trazas de mensajes e identificadores de solicitud de los capítulos de comunicación.

**Este capítulo te prepara para:** Un razonamiento causal que siga siendo válido cuando los relojes de pared no coinciden.

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>25 min–35 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>35 min–50 min</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>1 h 30 min–2 h · 10 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Leer lección →</a>
  <a class="ds-secondary-action" href="lab/">Abrir laboratorio</a>
</div>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../downloads/es/m06-time-causality.zip" download>Descargar capítulo + laboratorio para estudio sin conexión (.zip)</a></p>

## Qué aprenderás

- Explica por qué las marcas de tiempo de reloj de pared no pueden establecer todas las relaciones causales.
- Calcula marcas de tiempo de Lamport para una ejecución distribuida.
- Usa relojes vectoriales para distinguir causalidad de concurrencia.
- Instrumenta mensajes con tiempo lógico.
- Reconstruye y explica una ejecución multiproceso a partir de trazas.

## Aprende trabajando la pregunta

1. Escribe tu respuesta a **Empieza aquí** antes de abrir la lección completa.
2. Lee hasta la siguiente predicción o traza; detente y resuélvela antes de revelar la explicación.
3. Trata la práctica guiada como un **banco de práctica**, no como una hoja para completar deprisa. Trabaja las trazas centrales hasta alcanzar el objetivo de práctica y vuelve después a los casos restantes.
4. Usa la comprobación para detectar vacíos y entra al laboratorio con una predicción falsable y con la evidencia que podría contradecirla.
5. Termina explicando qué estableció el experimento, qué no estableció y cómo cambia tu explicación del servicio acumulativo.

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../m12-dht-gossip/">← Comunicación II — Mensajería, diseminación y overlays</a>
<a class="ds-sequence-link next" href="../m09-consensus/">Coordinación II — Exclusión mutua, elecciones y acuerdo →</a>
</nav>
