<p class="ds-book-part">Parte II — Comunicación y coordinación</p>
<div class="ds-lesson-banner">
  <div><span>Paso del curso</span><strong>Capítulo 6</strong></div>
  <div><span>Lectura esencial</span><strong>25 min–35 min</strong></div>
  <div><span>Ruta obligatoria</span><strong>Leer → Objetivo de práctica → Comprobar → Laboratorio</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 6 de 12</span>
    <span>50% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 50%"></span></div>
</div>

> **Pregunta guía:** Si los relojes no coinciden, ¿cómo puedes seguir razonando sobre qué ocurrió antes que qué?

## Antes de leer

> El nodo B registra la recepción a las 09:59:59.900 de un mensaje que el nodo A dice haber enviado a las 10:00:00.100. ¿Qué hecho confías más: las marcas de tiempo o la arista del mensaje?

Escribe primero una respuesta breve. No necesitas acertar todavía: necesitas una predicción que puedas revisar a medida que el capítulo te dé mejores modelos y evidencia.

**Usa lo que ya sabes:** Trazas de mensajes e identificadores de solicitud de los capítulos de comunicación.

## Mapa de carga de trabajo

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>25 min–35 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>35 min–50 min</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>1 h 30 min–2 h · 10 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../../downloads/es/m06-time-causality.zip" download>Descargar lección + práctica + laboratorio para estudio sin conexión (.zip)</a></p>

## Por qué importa este capítulo

Los logs nos invitan a creer que los timestamps cuentan la historia completa.

```text
10:00:01.120 nodo A envió solicitud
10:00:01.115 nodo B recibió solicitud
```

¿B recibió la solicitud antes de que A la enviara?

Casi seguro que no. Los relojes discrepan.

Los sistemas distribuidos no comparten un reloj físico perfecto. Los mensajes tardan, los relojes derivan, la sincronización es imperfecta y las correcciones de reloj pueden cambiar la relación entre tiempo local y tiempo real.

Aun así, los algoritmos necesitan responder:

- ¿X pudo influir causalmente en Y?
- ¿dos actualizaciones fueron concurrentes?
- ¿qué mensaje debe procesarse primero?
- ¿esta traza es compatible con el protocolo?
- ¿una versión desciende de otra?

Pregunta guía:

> **Si los relojes discrepan, ¿cómo podemos razonar todavía sobre qué ocurrió antes que qué?**

La respuesta empieza separando **tiempo físico** de **orden causal**.

## 1. Los relojes físicos miden tiempo localmente

Cada máquina tiene un reloj mantenido por hardware y mecanismos del sistema operativo.

Aunque dos relojes estén sincronizados inicialmente, no avanzan a una velocidad exactamente idéntica para siempre.

Modelo útil:

```text
tiempo real t
   ↓
A informa C_A(t)
B informa C_B(t)
```

Si sus tasas difieren, el offset cambia.

### Offset y deriva

**Offset**: diferencia actual entre un reloj y una referencia.

**Deriva/skew**: diferencia entre las velocidades de los relojes a lo largo del tiempo.

Los protocolos de sincronización reducen periódicamente el offset, pero no convierten la comunicación en instantánea ni la medición en perfecta.

<aside class="ds-book-note ds-history">
  <span class="ds-book-note-label">Historia</span>
  <strong>Por qué los sistemas distribuidos necesitaban un concepto de orden que no dependiera de relojes sincronizados</strong>
  <p>La relación sucedió-antes de Lamport desplazó la pregunta desde buscar un reloj perfectamente compartido hacia determinar qué eventos pudieron influir en otros.</p>
  <a class="ds-book-note-source" href="../../../history/lamport-time-and-causality/">Lee la historia del diseño →</a>
</aside>

## 2. El retraso de red introduce incertidumbre al sincronizar relojes

Supón que C pregunta a S por la hora:

```text
C -- request --> S
C <-- time ----- S
```

Si la ida y vuelta tarda 100 ms, C no sabe exactamente qué fracción ocurrió antes o después del timestamp generado por S.

Un algoritmo puede estimar suponiendo retraso aproximadamente simétrico, pero las colas variables hacen incierto el error real.

Por eso debe hablarse de sincronización física junto con un **límite de error o un supuesto**, no como igualdad perfecta.

## 3. NTP mejora los relojes; no crea un orden global de transacciones

NTP es valioso para:

- logs legibles;
- validez de certificados;
- monitorización;
- correlación aproximada de eventos;
- políticas basadas en tiempo.

Pero los relojes sincronizados no son un mecanismo universal para ordenar transiciones distribuidas.

Persisten:

- error residual;
- retrasos asimétricos;
- deriva entre sincronizaciones;
- correcciones;
- eventos más cercanos que la incertidumbre disponible.

Si un sistema exige causalidad o consistencia, necesita un mecanismo diseñado para esa garantía.

<figure class="ds-book-figure">
  <img src="../../../../assets/book/m06-causality-es.svg" alt="Los mensajes establecen orden causal aunque los relojes de pared no coincidan." loading="lazy" decoding="async" />
  <figcaption><span>Figura</span>La causalidad sigue el orden local y los mensajes. Las marcas de reloj son mediciones útiles, no la definición de sucedió-antes.</figcaption>
</figure>

## 4. Las correcciones del reloj de pared sorprenden a los programas

El tiempo civil puede corregirse cuando el sistema detecta error.

Eso separa dos necesidades.

### Tiempo humano

> ¿A qué hora UTC ocurrió aproximadamente?

### Duración

> ¿Cuánto tardó esta operación?

Los sistemas operativos ofrecen relojes monotónicos para medir tiempo transcurrido incluso si se corrige el reloj de pared.

Regla del curso:

> **Mide latencia con tiempo monotónico. Usa wall clock para contexto humano entre máquinas, con sus limitaciones.**

## 5. La causalidad hace una pregunta distinta al tiempo físico

La idea de Lamport fue observar que muchos algoritmos no necesitan la hora física exacta. Necesitan saber si un evento pudo influir en otro.

Definimos *happened-before*:

```text
a → b
```

cuando se aplica alguna regla.

### Regla 1 — orden local

Si `a` y `b` ocurren en el mismo proceso y `a` se ejecuta antes:

```text
a → b
```

### Regla 2 — mensaje

Si `a` es enviar un mensaje y `b` recibir **ese mismo mensaje**:

```text
a → b
```

### Regla 3 — transitividad

Si:

```text
a → b
b → c
```

entonces:

```text
a → c
```

Así obtenemos un orden parcial independiente de relojes físicos sincronizados.

## 6. Concurrencia significa que ninguno precede causalmente al otro

Si no puede establecerse ni:

```text
a → b
```

ni:

```text
b → a
```

los eventos son concurrentes en sentido causal:

```text
a || b
```

No significa que ocurrieron exactamente en el mismo instante físico.

Significa que no existe un camino causal entre ellos en la ejecución observada.

Dos réplicas desconectadas pueden escribir con varios segundos de diferencia y, aun así, producir actualizaciones causalmente concurrentes si ninguna conocía la otra.

## 7. Un grafo causal suele ser más fiel que ordenar logs por timestamp

Considera:

```text
P1: a ---- send m ---------------- d
               \
P2:        b ---- receive m ---- c ---- send n
                                      \
P3:                           e ---- receive n ---- f
```

Sabemos:

```text
a → send(m)
send(m) → receive(m)
receive(m) → c
c → send(n)
send(n) → receive(n)
receive(n) → f
```

La transitividad añade relaciones.

Pero otros pares pueden seguir siendo concurrentes. Ordenar por wall clock puede ocultar esa estructura si los relojes discrepan.

## 8. Los relojes de Lamport codifican happened-before en un escalar

Cada proceso mantiene un contador lógico.

Reglas:

1. incrementa antes de cada evento relevante;
2. incluye el valor al enviar;
3. al recibir `T`:

```text
clock = max(local_clock, T) + 1
```

Garantía:

> Si `a → b`, entonces `L(a) < L(b)`.

Pero el recíproco no vale.

```text
L(a) < L(b)
```

no demuestra `a → b`.

Eventos concurrentes pueden recibir valores distintos.

## 9. Ejemplo trabajado — Lamport

Tres procesos empiezan en 0.

```text
P1: local a, send m a P2
P2: local b, receive m, send n a P3
P3: local c, receive n
```

Una asignación válida:

### P1

```text
a:       L=1
send m:  L=2
```

### P2

```text
b:       L=1
receive m(2):
         L=max(1,2)+1=3
send n:  L=4
```

### P3

```text
c:       L=1
receive n(4):
         L=max(1,4)+1=5
```

Se conserva:

```text
send(m)=2 < receive(m)=3
receive(m)=3 < send(n)=4 < receive(n)=5
```

Que `P1:a` y `P2:b` tengan ambos 1 no significa que sean el mismo evento ni simultáneos.

## 10. Lamport no identifica concurrencia por sí solo

Supón:

```text
P1 a: L=4
P2 b: L=9
```

No podemos concluir `a → b`.

Los contadores pueden haber avanzado independientemente.

Los relojes de Lamport ofrecen un escalar compatible con causalidad, pero no conservan suficiente información para decidir si dos eventos con valores diferentes están relacionados.

Esto motiva los vectores.

## 11. Los relojes vectoriales registran conocimiento causal por proceso

Con N procesos, el vector tiene N componentes.

Para tres:

```text
[V1,V2,V3]
```

`Pi` incrementa su componente en un evento.

Al enviar, transporta el vector.

Al recibir:

```text
V_local = max_componentwise(V_local, V_message)
V_local[i] += 1
```

La convención exacta de incrementos debe ser coherente.

## 12. Comparar vectores distingue causalidad y concurrencia

Definimos `A < B` cuando cada componente de A es ≤ al correspondiente de B y al menos uno es estrictamente menor.

Entonces:

```text
A < B
```

indica que el evento A precede causalmente a B.

Si ninguno domina:

```text
A = [3,1,0]
B = [2,4,0]
```

A sabe más de P1 y B más de P2.

```text
A || B
```

Esta información no cabe en un único contador de Lamport.

## 13. Ejemplo trabajado — escrituras concurrentes de réplicas

Dos réplicas parten de:

```text
A: [1,0]
B: [1,0]
```

Se desconectan.

A escribe:

```text
[2,0]
```

B escribe independientemente:

```text
[1,1]
```

Ninguno domina.

Los vectores detectan que son concurrentes.

No dicen **cómo** resolver el conflicto. Solo dicen que ninguna versión es descendiente causal de la otra.

Eso será central en replicación y diseños tipo Dynamo.

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosidad</span>
  <strong>Un log puede mostrar la respuesta antes de la solicitud sin que exista viaje temporal</strong>
  <p>Los relojes físicos de máquinas distintas pueden discrepar; message IDs y happened-before conservan la dirección causal aunque wall time parezca invertido.</p>
  <p><strong>Pruébalo:</strong> Usa dos offsets artificiales para que un receive tenga timestamp físico menor que su send.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">Más curiosidades del capítulo →</a>
</aside>

## 14. Los relojes lógicos ordenan conocimiento, no duración física

Una diferencia de Lamport de 100 no significa 100 ms.

Un componente vectorial de 50 no significa 50 s.

Los relojes lógicos codifican orden de eventos.

No sirven para medir latencia.

A la inversa, el tiempo físico aproxima tiempo real pero no captura automáticamente causalidad.

## 15. Puede construirse un orden total cuando la aplicación lo necesita

Algunos algoritmos necesitan desempate determinista.

Una regla habitual:

```text
(Lamport timestamp, process ID)
```

Por ejemplo:

```text
(7,P1) < (7,P2)
```

Esto crea un orden total.

Pero si los eventos eran concurrentes, ordenar por ID no crea causalidad. El sistema **elige** un orden para coordinación.

## 16. El orden de entrega es una garantía separada del mecanismo de reloj

### FIFO

Mensajes de un mismo emisor llegan a un mismo receptor en orden de envío.

### Orden causal

Si A precede causalmente a B, un receptor no debe observar B antes del A relevante.

### Orden total

Todos los receptores observan mensajes en un mismo orden global.

Son garantías distintas.

Un timestamp puede ayudar a implementarlas o analizarlas, pero adjuntarlo no hace que la red entregue en ese orden. El protocolo necesita buffering, coordinación u otro mecanismo.

## 17. La consistencia causal usa happened-before para restringir réplicas

Ejemplo:

1. Alice publica A.
2. Bob lee A.
3. Bob publica B: «Estoy de acuerdo con A».

```text
A → Bob lee A → B
```

Un sistema causal debería evitar mostrar B a un usuario que todavía no puede observar A cuando la semántica exige conservar esa dependencia.

Una publicación C independiente puede ser concurrente y aparecer en órdenes diferentes.

Así se preservan dependencias relevantes sin ordenar globalmente todo.

## 18. Los logs necesitan relojes, identificadores y topología

Un registro distribuido útil puede contener:

```text
node_id
process/incarnation
request_id
trace_id/span_id
event_type
wall_time
monotonic_since_start
Lamport/vector cuando haga falta
peer/message_id
```

Ningún campo cuenta por sí solo toda la historia.

- **Wall time**: cronología humana aproximada.
- **Duración monotónica**: tiempo transcurrido local.
- **Request/trace IDs**: correlación de workflow.
- **Tiempo lógico**: orden causal.

Recoge la mínima evidencia que permita responder la pregunta.

## 19. Ejemplo trabajado — wall clocks contradictorios

Logs:

```text
A 10:00:02.400 send R7 to B
B 10:00:02.250 receive R7 from A
```

Ordenar por wall time sugiere recepción antes del envío.

Pero la identidad del mensaje prueba:

```text
send(R7) → receive(R7)
```

Si el mensaje lleva Lamport 14 y B lo recibe en 20, la relación lógica sigue siendo coherente aunque los relojes físicos tengan offset.

No se trata de «arreglar el log». Se trata de saber qué evidencia tiene autoridad para qué afirmación.

## 20. Ejemplo trabajado — reconstruir tres procesos

```text
P1: a, send m, d
P2: b, receive m, c, send n
P3: e, receive n, f
```

- ¿`a → c`? Sí, por orden local y m.
- ¿`b → send(m)`? No se proporciona camino.
- ¿`d → f`? No necesariamente.
- ¿`c → f`? Sí, mediante n.
- ¿d y e son concurrentes? Posiblemente, salvo mensajes adicionales.

La habilidad es justificar cada respuesta mediante un camino, no por posición visual.

## 21. Los relojes lógicos no implementan leases temporales

Un lease de 15 segundos necesita tiempo transcurrido físico.

Lamport no dice que hayan pasado 15 s.

Un sistema puede necesitar simultáneamente:

- duración monotónica para expiración local;
- wall time aproximado para contexto operacional;
- tiempo lógico para causalidad;
- epochs/terms para cambios de autoridad.

Los terms de Raft son epochs lógicos, no timestamps de pared.

## 22. Más capacidad para distinguir historia requiere más metadatos

Lamport usa un escalar.

El vector clásico usa una componente por participante.

En un sistema con millones de clientes dinámicos un vector completo puede ser impráctico.

Existen compromisos:

- version vectors por réplica;
- dotted version vectors;
- hybrid logical clocks;
- metadatos acotados con garantías más débiles;
- secuenciación central cuando encaja.

Principio:

> **Para distinguir más tipos de historia, el sistema debe conservar más información o coordinar más.**

Este compromiso aparece también al depurar. Un wall timestamp añade contexto humano con pocos bytes, pero no distingue causalidad. Un Lamport scalar conserva una restricción parcial. Un vector conserva más conocimiento y crece con el conjunto de participantes. Un trace con IDs padre/hijo puede reconstruir el camino de una solicitud concreta sin representar toda la causalidad global.

Por eso debes escoger metadatos según la pregunta:

```text
¿cuánto tardó localmente?      → monotonic
¿aprox. cuándo ocurrió?        → wall time
¿qué mensaje produjo cuál?     → message/trace ID
¿pudo A influir en B?          → aristas causal/logical time
¿son versiones concurrentes?   → vector/version metadata
```

## 23. Perspectiva histórica — 1978

El artículo de Lamport *Time, Clocks, and the Ordering of Events in a Distributed System* fue fundamental porque replanteó tiempo como un problema de orden.

Happened-before sigue siendo vocabulario básico en sincronización, replicación, debugging y consistencia.

El trabajo posterior sobre vectores permitió distinguir mejor causalidad de concurrencia.

La lección histórica no es que el tiempo físico dejara de importar. Es que **tiempo físico y orden causal son abstracciones diferentes**.

## 24. Errores comunes

### Error 1 — ordenar logs por wall clock y llamarlo causalidad

El offset puede invertir aparentemente envío y recepción.

### Error 2 — asumir que NTP hace idénticos los relojes

Reduce error; no elimina incertidumbre.

### Error 3 — medir duración con wall time ajustable

Usa un reloj monotónico.

### Error 4 — inferir causalidad en ambos sentidos a partir de Lamport

`a → b` implica `L(a)<L(b)`, pero el recíproco no.

### Error 5 — confundir concurrente con simultáneo

Concurrente significa ausencia de camino causal.

### Error 6 — ordenar vectores lexicográficamente

La comparación correcta usa dominancia componente a componente.

### Error 7 — adjuntar timestamp y asumir que eso impone orden de entrega

La información no sustituye al protocolo.

### Error 8 — usar Lamport para segundos transcurridos

La distancia lógica no es duración física.

## 25. Conexión con RPC y descubrimiento

El Capítulo 4 introdujo IDs de solicitud y timestamps locales.

Este capítulo añade causalidad:

```text
cliente send R7
      ↓
servidor receive R7
      ↓
servidor send R8
      ↓
downstream receive R8
```

Aunque los relojes físicos discrepen, los mensajes establecen happened-before.

El capítulo de descubrimiento añadió identidad/encarnación de nodos. Los metadatos lógicos ayudan a distinguir estado nuevo de observaciones antiguas retrasadas.

La traza crece así:

```text
Calentamiento: eventos observables
RPC: identidad lógica de solicitud
Descubrimiento: identidad/encarnación del nodo
Causalidad: orden causal
Operación: tracing y diagnóstico de rendimiento
```

## Transición al laboratorio

El laboratorio instrumenta procesos con wall time intencionadamente sesgado, Lamport y vectores. Reconstruirás causalidad mediante aristas de mensaje, identificarás eventos concurrentes y mostrarás un caso donde ordenar por reloj de pared cuenta una historia imposible.

Debes producir:

```text
vista de tiempo físico
```

y:

```text
grafo causal / vista de tiempo lógico
```

y explicar por qué responden preguntas distintas.

## Resumen del capítulo

1. **Los nodos no comparten un reloj físico perfecto.**
2. **Sincronizar reduce error sin eliminar incertidumbre de red.**
3. **Wall time y duración monotónica resuelven problemas diferentes.**
4. **Happened-before define causalidad por orden local, mensajes y transitividad.**
5. **Eventos concurrentes no tienen un camino causal aunque sus tiempos físicos difieran.**
6. **Lamport asigna tiempo lógico escalar compatible con happened-before.**
7. **El orden de valores Lamport no prueba causalidad.**
8. **Los vectores conservan suficiente conocimiento por proceso para distinguir muchas historias causales y concurrentes.**
9. **Los relojes lógicos no miden duración ni imponen orden de entrega.**
10. **Una buena traza combina identidades, aristas de mensaje, tiempo físico apropiado y evidencia lógica.**
11. **Distintos mecanismos necesitan distintos conceptos de tiempo: duración, wall time, causalidad y epochs.**
12. **Podemos razonar sobre qué ocurrió antes aunque las máquinas no estén de acuerdo sobre la hora.**

<div class="ds-next-action">
  <span>Lectura esencial completada</span>
  <strong>Siguiente paso obligatorio · Práctica guiada</strong>
  <a href="../guided-practice/">Comenzar práctica guiada →</a>
</div>
