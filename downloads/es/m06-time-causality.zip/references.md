> **Vista de referencia.** Esta página ofrece contexto opcional; vuelve a la [Lección](../lesson/) para la ruta obligatoria.

## Esencial

- **●● Time, Clocks, and the Ordering of Events in a Distributed System** — Leslie Lamport. [paper](https://lamport.azurewebsites.net/pubs/time-clocks.pdf)

## Recomendado

- **●●● Virtual Time and Global States of Distributed Systems** — Friedemann Mattern. [paper](https://www.vs.inf.ethz.ch/publ/papers/VirtTimeGlobStates.pdf)

## Avanzado

Todavía no hay un recurso adicional asignado.

## Herramientas y práctica

- **●● OpenTelemetry Documentation** — OpenTelemetry project. [tool documentation](https://opentelemetry.io/docs/)

## Explora

- **●●● Concurrent and Distributed Systems** — University of Cambridge. [course](https://www.cl.cam.ac.uk/teaching/)
