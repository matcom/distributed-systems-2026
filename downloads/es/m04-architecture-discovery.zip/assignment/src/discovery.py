"""Deterministic service-discovery model for M04.

The registry uses an injected clock so lease behavior is testable without sleeps.
"""

from dataclasses import dataclass
from typing import Callable, List


@dataclass(frozen=True)
class Member:
    service: str
    node_id: str
    incarnation: int
    endpoint: str
    expires_at: float


class Registry:
    def __init__(self, now: Callable[[], float]):
        self._now = now
        self._members = {}

    def register(self, service: str, node_id: str, incarnation: int, endpoint: str, lease_seconds: float) -> None:
        """Register/refresh a member.

        A higher incarnation replaces an older one for the same (service,node_id).
        A stale lower incarnation must not overwrite the current record.
        """
        raise NotImplementedError("TODO: implement registration and incarnation rules")

    def resolve(self, service: str) -> List[Member]:
        """Return only currently valid members for service."""
        raise NotImplementedError("TODO: implement lease expiry and resolution")


class RoundRobin:
    def __init__(self):
        self._next = 0

    def choose(self, members: List[Member]) -> Member:
        """Choose members round-robin; empty input must raise LookupError."""
        raise NotImplementedError("TODO: implement endpoint selection")
