# M04 Laboratory Report — Architectures, Naming, and Service Discovery

## 1. Environment and topology

Record process layout, ports, configuration, and exact commands required to reproduce the registry, workers, and client.

## 2. Identity model

Define:

- logical service name;
- node ID;
- incarnation;
- endpoint/address;
- lease/expiry state.

Explain which values survive restart and which change.

## 3. Normal registration and resolution

### Prediction

### Registry evidence

### Client evidence

### Worker evidence

## 4. Endpoint-selection comparison

| Worker | Pick-first requests | Round-robin requests |
|---|---:|---:|
| W1 | | |
| W2 | | |
| W3 | | |

Explain why equal request counts do or do not represent equal load.

## 5. Worker-failure timeline

| Event | Time | Evidence |
|---|---:|---|
| worker actually stops | | |
| registry expires/removes worker | | |
| client refreshes membership | | |
| client successfully reroutes | | |

Explain why these events are distinct.

## 6. Lease comparison

Compare at least two lease settings.

| Property | Setting A | Setting B |
|---|---:|---:|
| lease duration | | |
| heartbeat interval | | |
| stale-entry interval observed | | |
| control traffic / qualitative cost | | |
| false-removal sensitivity | | |

## 7. Registry state versus client cache

Show one interval where the registry has already removed a worker but the client still holds the stale endpoint.

Explain the client's recovery/reselection policy.

## 8. Worker alive but discovery path broken

State what the registry believes, what the client can reach, and why those facts differ.

## 9. Process replacement and incarnation

Show the old and new incarnation/endpoint and explain how stale messages from the old process should be handled.

## 10. Registry unavailable

Compare behavior for:

- a client with cached endpoints;
- a new client with no cached discovery state.

State the control-plane dependency explicitly.

## 11. Registry restart

Which state survives? Which state is reconstructed? What guarantee is temporarily unavailable?

## 12. Scale-out

Record:

| Event | Time |
|---|---:|
| W4 starts | |
| registry sees W4 | |
| existing client sees W4 | |
| first request reaches W4 | |

Explain how discovery freshness affects use of new capacity.

## 13. Architecture table

| Question | Decision | Trade-off |
|---|---|---|
| service naming | | |
| registration owner | | |
| lease policy | | |
| cache policy | | |
| refresh trigger | | |
| balancing policy | | |
| registry failure behavior | | |
| persisted control state | | |

## 14. Ray-removal analysis

Identify which membership, scheduling, naming, and placement capabilities were previously hidden by Ray and where they now appear in the native design.

## 15. AI-use disclosure

List AI tools used, activities delegated, and how important output was independently verified.

## 16. Final answer

Answer in your own words:

> At each moment after a worker failure, who knows what—and how does that knowledge eventually change?
