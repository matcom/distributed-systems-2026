# Planned transparent official tests — M04

Executable public tests are provided in this directory together with the starter discovery adapter under `starter/src/`. They encode deterministic registration, lease, incarnation, resolution, and endpoint-selection behavior; broader process/network behavior remains evidence-based. No hidden correctness cases are planned.

## Registration model

- a worker can register a logical service, node ID, incarnation, endpoint, and lease;
- duplicate refreshes of the same current incarnation do not create duplicate members;
- malformed registrations are rejected;
- a higher incarnation can replace older endpoint state for the same logical node;
- stale lower-incarnation updates do not overwrite the newer process record.

## Lease and expiry

- successful refresh extends membership validity;
- a member whose lease expires is removed or marked unavailable according to the declared contract;
- the expiry policy is deterministic under the test clock/configuration.

## Resolution

- resolving an existing service returns currently valid candidates;
- resolving an unknown/empty service returns a defined result;
- logical service names are independent from one concrete worker address.

## Endpoint selection

- pick-first follows its documented policy;
- round-robin rotates across the current candidate set;
- membership changes do not cause invalid index/state behavior;
- an empty candidate set is handled explicitly.

## Failure/recovery

- killing a worker without deregistration leaves a temporary stale record until the declared expiry/health mechanism acts;
- a replacement process can register with a new endpoint/incarnation;
- registry restart behavior matches the persistence/re-registration contract.

## Client cache behavior

- cached membership may remain stale until the configured refresh condition;
- endpoint failure can trigger the documented refresh/reselection policy;
- a client with cached endpoints and a fresh client may behave differently while the registry is unavailable.

Students may inspect, run, and extend all executable cases without limit. Student-added cases belong in `tests/student/`.