import unittest

from discovery import Registry, RoundRobin


class FakeClock:
    def __init__(self):
        self.t = 0.0

    def now(self):
        return self.t

    def advance(self, seconds):
        self.t += seconds


class DiscoveryTests(unittest.TestCase):
    def setUp(self):
        self.clock = FakeClock()
        self.registry = Registry(self.clock.now)

    def test_register_and_resolve(self):
        self.registry.register("kv", "n1", 1, "127.0.0.1:9001", 10)
        members = self.registry.resolve("kv")
        self.assertEqual(len(members), 1)
        self.assertEqual(members[0].node_id, "n1")

    def test_refresh_does_not_duplicate_member(self):
        self.registry.register("kv", "n1", 1, "a", 10)
        self.clock.advance(3)
        self.registry.register("kv", "n1", 1, "a", 10)
        self.assertEqual(len(self.registry.resolve("kv")), 1)

    def test_expired_member_is_not_resolved(self):
        self.registry.register("kv", "n1", 1, "a", 5)
        self.clock.advance(6)
        self.assertEqual(self.registry.resolve("kv"), [])

    def test_higher_incarnation_replaces_endpoint(self):
        self.registry.register("kv", "n1", 1, "old", 10)
        self.registry.register("kv", "n1", 2, "new", 10)
        members = self.registry.resolve("kv")
        self.assertEqual([(m.incarnation, m.endpoint) for m in members], [(2, "new")])

    def test_stale_incarnation_does_not_overwrite_newer(self):
        self.registry.register("kv", "n1", 2, "new", 10)
        self.registry.register("kv", "n1", 1, "old", 10)
        self.assertEqual(self.registry.resolve("kv")[0].endpoint, "new")

    def test_service_names_are_independent(self):
        self.registry.register("kv", "n1", 1, "a", 10)
        self.registry.register("search", "n1", 1, "b", 10)
        self.assertEqual([m.endpoint for m in self.registry.resolve("kv")], ["a"])
        self.assertEqual([m.endpoint for m in self.registry.resolve("search")], ["b"])

    def test_round_robin_rotates_and_handles_empty(self):
        self.registry.register("kv", "n1", 1, "a", 10)
        self.registry.register("kv", "n2", 1, "b", 10)
        members = sorted(self.registry.resolve("kv"), key=lambda m: m.node_id)
        picker = RoundRobin()
        self.assertEqual(picker.choose(members).endpoint, "a")
        self.assertEqual(picker.choose(members).endpoint, "b")
        self.assertEqual(picker.choose(members).endpoint, "a")
        with self.assertRaises(LookupError):
            picker.choose([])


if __name__ == "__main__":
    unittest.main()
