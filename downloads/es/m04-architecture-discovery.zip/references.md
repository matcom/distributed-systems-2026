> **Vista de referencia.** Esta página ofrece contexto opcional; vuelve a la [Lección](../lesson/) para la ruta obligatoria.

## Esencial

- **●● RFC 1034 — Domain Names: Concepts and Facilities** — Paul Mockapetris. [standard](https://www.rfc-editor.org/rfc/rfc1034.html)
- **● Distributed Systems, 4th ed.** — Maarten van Steen and Andrew S. Tanenbaum. [book](https://www.distributed-systems.net/index.php/books/ds4/)

## Recomendado

- **●● gRPC Custom Name Resolution** — gRPC Authors. [documentation](https://grpc.io/docs/guides/custom-name-resolution/)
- **●● gRPC Service Config** — gRPC Authors. [documentation](https://grpc.io/docs/guides/service-config/)
- **●● Designing Data-Intensive Applications** — Martin Kleppmann. [book](https://dataintensive.net/)

## Avanzado

- **●● DNS for Services and Pods** — Kubernetes Authors. [system documentation](https://kubernetes.io/docs/concepts/services-networking/dns-pod-service/)

## Herramientas y práctica

- **● The Go Documentation** — The Go Project. [tool documentation](https://go.dev/doc/)

## Explora

- **●●● 6.5840 Distributed Systems** — MIT PDOS. [course](https://pdos.csail.mit.edu/6.824/)
