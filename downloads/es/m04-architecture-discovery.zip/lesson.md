<p class="ds-book-part">Parte III — Nombres y estado replicado</p>
<div class="ds-lesson-banner">
  <div><span>Paso del curso</span><strong>Capítulo 8</strong></div>
  <div><span>Lectura esencial</span><strong>35 min–50 min</strong></div>
  <div><span>Ruta obligatoria</span><strong>Leer → Objetivo de práctica → Comprobar → Laboratorio</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 8 de 12</span>
    <span>67% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 67%"></span></div>
</div>

> **Pregunta guía:** ¿Cómo encuentras el servicio lógico correcto cuando los nombres permanecen estables pero cambian las ubicaciones y la membresía?

## Antes de leer

> Un servicio llamado payments reinicia en una nueva dirección. ¿Qué identificador debería permanecer estable, qué valor debería cambiar y quién puede almacenar en caché el mapeo anterior?

Escribe primero una respuesta breve. No necesitas acertar todavía: necesitas una predicción que puedas revisar a medida que el capítulo te dé mejores modelos y evidencia.

**Usa lo que ya sabes:** Arquitectura, comunicación y límites de fallo de los Capítulos 2–7.

## Mapa de carga de trabajo

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>35 min–50 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>45 min–1 h 10 min</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>2 h–2 h 30 min · 7 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../../downloads/es/m04-architecture-discovery.zip" download>Descargar lección + práctica + laboratorio para estudio sin conexión (.zip)</a></p>

## Por qué importa este capítulo

Ya has trabajado con arquitectura y comunicación. Ahora centra la atención en una pregunta más estrecha: ¿cómo se refiere un componente a otro cuando la identidad lógica debe sobrevivir a cambios de procesos, direcciones, réplicas y ubicación?

Las primeras secciones de arquitectura son un repaso breve, porque los nombres solo tienen sentido cuando sabes **quién debe descubrir a quién**. La progresión principal es: nombres → identificadores → direcciones → nombres estructurados → DNS/caché → descubrimiento dinámico → búsqueda descentralizada.

El Capítulo 4 hizo explícita una operación remota. Ya sabemos que un cliente necesita un protocolo, un identificador de solicitud, un plazo, una semántica de reintento y evidencia sobre lo ocurrido.

Pero seguía oculto un supuesto conveniente:

> **¿Cómo sabe el cliente dónde está el servicio?**

Codificar `10.0.0.7:50051` parece resolver la pregunta hasta que el proceso se reinicia en otra ubicación, se añade una segunda réplica, el nodo deja de estar saludable o un despliegue sustituye la máquina.

Las aplicaciones distribuidas necesitan separar al menos tres conceptos:

```text
identidad lógica      dirección/ubicación      instancia actual
"payments"            10.0.0.7:50051           proceso P42
```

Pueden cambiar a ritmos distintos.

Un buen nombre de servicio debe sobrevivir normalmente a la sustitución de un proceso. Una dirección indica dónde puede contactarse algo en este momento. Una instancia concreta puede vivir muy poco tiempo.

Este capítulo estudia arquitectura y nombres conjuntamente porque la arquitectura determina **quién debe descubrir a quién**, **qué estado debe permanecer estable** y **qué ocurre cuando la información de descubrimiento queda obsoleta**.

> **Detente y predice.** Un registro dice que el servicio `worker` tiene tres endpoints. Uno cayó hace cinco segundos pero continúa en el registro. ¿Está «equivocado» el registro? ¿Cambiaría tu respuesta si los registros caducan a los 30 segundos? ¿Qué comportamiento necesita el cliente durante ese intervalo?

## 1. La arquitectura es la asignación de responsabilidades

Una arquitectura distribuida no es simplemente un dibujo de cajas. Asigna responsabilidad y estado.

Para cada componente pregunta:

- ¿qué sabe?
- ¿qué estado posee?
- ¿en quién confía?
- ¿a quién contacta?
- ¿puede sustituirlo otro componente?
- ¿qué ocurre si desaparece?
- ¿qué debe permanecer consistente con él?

Un diagrama útil incluye **canales y estado**, no solo nombres de servicios.

Diagrama débil:

```text
frontend → backend → base de datos
```

Diagrama más útil:

```text
cliente
  |
  | RPC
  v
réplicas API ----> registro
  |                    |
  |                    | membresía + leases
  v                    |
servicio de estado <---+
  |
  v
estado durable replicado
```

Ahora aparecen preguntas que se pueden estudiar.

<aside class="ds-book-note ds-history">
  <span class="ds-book-note-label">Historia</span>
  <strong>Los sistemas peer-to-peer preguntaron qué ocurre cuando los participantes aportan la infraestructura en vez de limitarse a consumirla</strong>
  <p>Overlays estructurados como Chord y Kademlia, junto a sistemas de intercambio distribuido, exploraron lookup escalable, churn, membresía descentralizada y uso directo del almacenamiento y ancho de banda de los participantes.</p>
  <a class="ds-book-note-source" href="../../../history/peer-to-peer-dhts/">Lee la historia del diseño →</a>
</aside>

## 2. Cliente/servidor centraliza un rol, no necesariamente una sola máquina

El modelo cliente/servidor distingue a quienes inician solicitudes de quienes ofrecen el servicio.

Una forma simple es:

```text
cliente → servidor
```

No es necesario interpretar esto como «un único proceso servidor».

Un servicio lógico puede contener varias réplicas:

```text
             ┌→ servidor A
cliente → LB ─┼→ servidor B
             └→ servidor C
```

La arquitectura sigue siendo cliente/servidor porque los clientes consumen un rol de servicio en lugar de actuar como peers equivalentes.

Esta distinción importa porque un nombre lógico como:

```text
api.course.local
```

puede representar un conjunto cambiante de endpoints físicos.

## 3. Los sistemas multinivel separan estados y necesidades de escalado distintas

Las aplicaciones suelen separar roles como:

```text
cliente
  ↓
API / presentación
  ↓
servicio de aplicación
  ↓
almacenamiento
```

¿Por qué introducir más componentes?

Los niveles pueden tener diferentes:

- patrones de escalado;
- límites de seguridad;
- necesidades de persistencia;
- ritmos de despliegue;
- consecuencias de fallo;
- requisitos de hardware.

Por ejemplo, las réplicas API sin estado son fáciles de sustituir porque el estado durable del usuario vive en otro lugar. Un nodo de almacenamiento no puede tratarse igual si contiene la única copia de datos ya reconocidos.

La lección arquitectónica es:

> **La capacidad de sustituir un componente depende de dónde reside el estado.**

Un proceso resulta más fácil de escalar y recuperar cuando su identidad no es el único lugar que conserva estado durable importante.

## 4. Los microservicios intercambian simplicidad local por coordinación distribuida

Una aplicación monolítica puede hacer una llamada ordinaria dentro del proceso:

```text
orders.create()
```

Separar ese componente como servicio cambia la operación:

```text
order-api → red → inventory-service
```

Ahora heredamos:

- serialización;
- nombres de servicios;
- descubrimiento;
- autenticación;
- plazos;
- reintentos;
- fallos parciales;
- versionado;
- tracing distribuido.

Los microservicios pueden aportar límites útiles de organización y escalado, pero también **fabrican problemas de sistemas distribuidos** donde antes existían llamadas locales.

Por eso el curso no presenta «microservicios» como una opción automáticamente moderna o superior. Un límite de servicio debe justificar su coste operacional.

> **Detente y predice.** Si dos funciones escalan juntas, se despliegan juntas, tienen el mismo responsable, comparten el mismo límite de durabilidad y necesitan llamadas síncronas de baja latencia, ¿qué ventaja distribuida obtienes al poner una red entre ellas?

## 5. Los sistemas peer-to-peer distribuyen tanto el servicio como el descubrimiento

En arquitecturas peer-to-peer, los participantes pueden consumir y ofrecer recursos.

Todavía puede existir un directorio central:

```text
      directorio
      /   |   \
     /    |    \
   P1 ↔ P2 ↔ P3
```

o el descubrimiento también puede descentralizarse:

```text
P1 ↔ P2
|     |
P4 ↔ P3
```

Eso cambia el modelo de fallo y escalado.

Un registro central ofrece coordinación simple, pero crea un servicio cuya disponibilidad y consistencia deben protegerse.

Un overlay descentralizado elimina ese centro concreto, pero introduce:

- estado de encaminamiento;
- churn;
- vistas parciales de membresía;
- diseminación probabilística;
- reparación de la estructura del overlay.

El Capítulo 5 estudia DHT y gossip con profundidad. Aquí peer-to-peer se introduce como decisión arquitectónica sobre **quién puede conocer y servir qué**.

## 6. Nombres, identificadores y direcciones responden preguntas diferentes

Esta distinción es fundamental.

### Nombre

Etiqueta significativa para personas o aplicaciones que identifica un recurso o servicio.

Ejemplos:

```text
orders.service
student-42
object/photos/logo
```

### Identificador

Token cuyo propósito es distinguir una entidad, normalmente con independencia de su ubicación actual.

Ejemplos:

```text
job_id = J731
node_id = 9b2f...
content_hash = sha256:...
```

### Dirección

Información usada para contactar o encaminar hacia una ubicación actual.

Ejemplos:

```text
192.0.2.8:50051
[2001:db8::7]:443
unix:///run/service.sock
```

Un error arquitectónico habitual consiste en hacer que una identidad supuestamente estable sea igual a una dirección inestable.

Si `worker-7` significa solamente `10.0.0.7:9000`, ¿qué ocurre cuando el proceso se mueve?

Un modelo mejor es:

```text
ID lógico worker-7
       ↓ resolución
endpoint actual 10.0.0.31:9000
```

La resolución es en sí misma una operación distribuida.

## 7. Los sistemas de nombres proyectan preguntas estables sobre información cambiante

Un sistema de nombres permite a los clientes solicitar información asociada a un nombre.

La relación no tiene que ser uno a uno.

Un nombre de servicio puede resolver a:

- una dirección;
- varias réplicas;
- un alias;
- metadatos;
- una delegación hacia otra autoridad de nombres.

Una abstracción útil es:

```text
nombre + tipo de registro/contexto
              ↓
           resolver
              ↓
       información actual
```

El resolver puede consultar cachés, configuración local, servicios recursivos, registros o varias fuentes autoritativas.

La idea clave es que **la resolución tiene estado y semántica de frescura**.

## 8. DNS es un sistema distribuido, no una simple agenda telefónica

DNS es un excelente caso histórico porque sustituyó un modelo que dejó de escalar: distribuir globalmente un único archivo de hosts a medida que crecía Internet.

Su diseño separa un espacio de nombres jerárquico, información autoritativa, resolvers, delegación y caché.

La jerarquía permite distribuir responsabilidad:

```text
.
└── example
    └── course
        └── api
```

Un resolver no necesita mantener para siempre una base de datos global completa. Puede seguir la autoridad delegada y almacenar respuestas en caché.

### La caché crea un compromiso controlado de obsolescencia

Supón que un registro de dirección tiene TTL de 60 segundos.

Un resolver cliente puede seguir utilizando esa respuesta hasta que expire la entrada, aunque el mapeo autoritativo haya cambiado diez segundos después.

No es necesariamente un bug. Es consecuencia de una decisión explícita entre frescura y rendimiento.

La caché reduce:

- latencia;
- carga sobre servidores autoritativos;
- tráfico de red repetido.

Pero crea un periodo durante el cual distintos clientes pueden mantener legítimamente vistas distintas.

Es un patrón recurrente:

```text
caché más agresiva
       ↓
menor coste de búsqueda
       ↓
información potencialmente más antigua
```

### La disponibilidad de DNS depende de más de un servidor

DNS utiliza replicación, delegación, caché y varios servidores para evitar un único punto central global.

Aun así, una aplicación puede usar DNS mal, por ejemplo si asume que una dirección obtenida al iniciar el proceso seguirá siendo válida para siempre.

La resiliencia del sistema de nombres no hace automáticamente resiliente la política de descubrimiento del cliente.

## 9. El descubrimiento de servicios añade membresía dinámica a los nombres

Los nombres de hosts tradicionales suelen cambiar lentamente. Las instancias de servicios en un clúster pueden cambiar mucho más rápido.

Un despliegue podría evolucionar así:

```text
09:00  servicio A = [node1, node2]
09:10  falla node2
09:11  inicia node3
09:12  servicio A = [node1, node3]
```

Los clientes necesitan algún mecanismo para conocer el conjunto actual.

Un registro de servicios suele almacenar entradas como:

```text
service: image-worker
instance: worker-17
endpoint: 10.0.0.31:7000
metadata:
  zone: lab-a
  capacity: 4
expires_at: ...
```

El registro no es un simple diccionario. Debe definir:

- quién puede registrar;
- cómo caducan las entradas;
- cómo se representa la salud;
- si los clientes observan cambios o hacen polling;
- cómo se replican las actualizaciones;
- qué deben hacer clientes con datos obsoletos.

## 10. El registro puede ser push, pull, estático o derivado

No existe un mecanismo universal de descubrimiento.

### Configuración estática

Los clientes reciben una lista fija de endpoints.

Ventajas:

- mecanismo mínimo y sencillo;
- fácil de razonar;
- sin dependencia de un registro.

Desventajas:

- los cambios de membresía exigen actualizar configuración;
- el estado obsoleto puede persistir indefinidamente;
- el trabajo operacional crece con el dinamismo del despliegue.

La configuración estática no es «incorrecta». En un clúster educativo de tres nodos que cambia poco, puede ser totalmente apropiada.

### Autorregistro

Una instancia inicia y se registra a sí misma.

```text
worker → registry: register(worker-17, endpoint)
```

Es flexible, pero exige que el trabajador renueve o retire correctamente su entrada.

### Registro por terceros

Un orquestador o plano de control observa el proceso y publica la membresía.

Así se evita confiar en que cada aplicación mantenga por sí sola el estado del registro.

### Descubrimiento derivado

El sistema puede derivar endpoints a partir de otra fuente de verdad, por ejemplo el estado deseado/observado de un orquestador.

La arquitectura debe identificar qué componente es autoritativo.

## 11. Los leases convierten el silencio en eliminación eventual

Supón que un trabajador se registra una vez y después cae.

Si el registro conserva la entrada para siempre, los clientes pueden seleccionar repetidamente un endpoint muerto.

Una entrada basada en lease o TTL expresa:

> «Esta entrada solo es válida si se renueva antes de expirar».

Ejemplo:

```text
duración del lease = 15 s
heartbeat cada       = 5 s
```

Si cesan los heartbeats, el registro termina eliminando la instancia o marcándola como no saludable.

Pero un lease introduce supuestos temporales.

Preguntas relevantes:

- ¿cuánto debe durar antes de expirar?
- ¿qué ocurre si la red está lenta pero el trabajador sigue sano?
- ¿qué ocurre si el trabajador alcanza a los clientes, pero no al registro?
- ¿qué pasa si los relojes de registro y trabajador difieren?

La detección de fallos nunca es gratuita. El Capítulo 10 profundiza en ella.

## 12. «Salud» puede significar varias cosas

Un proceso puede estar:

- vivo;
- aceptando conexiones TCP;
- respondiendo un endpoint de salud;
- capaz de acceder a su base de datos;
- capaz de completar solicitudes útiles;
- suficientemente actualizado como para servir lecturas consistentes.

No son la misma propiedad.

Una comprobación de salud simplista puede producir información de descubrimiento engañosa.

Por ejemplo:

```text
GET /health -> 200
```

quizá solo demuestra que el proceso HTTP está vivo. No necesariamente demuestra que puede completar su operación principal.

Por otro lado, una comprobación que valida síncronamente cada dependencia puede provocar un fallo en cascada: si una base de datos se ralentiza, todas las réplicas API podrían declararse no saludables y eliminar de golpe toda la capacidad.

Las comprobaciones de salud codifican arquitectura.

## 13. La información de descubrimiento puede estar obsoleta aunque el registro esté correcto

Supón:

1. el registro devuelve `[A, B, C]`;
2. el cliente guarda el resultado en caché;
3. `B` cae;
4. el registro elimina `B`;
5. el cliente todavía no ha refrescado.

En el paso 4 el registro es correcto. El cliente aún tiene estado obsoleto.

Esto es normal en un sistema distribuido.

Un cliente resistente combina descubrimiento con manejo de fallos durante la ejecución:

```text
resolver servicio
    ↓
elegir endpoint
    ↓
intentar RPC
    ↓
observar éxito/fallo
    ↓
refrescar o reseleccionar según la política
```

El descubrimiento no sustituye los plazos, reintentos ni observaciones de salud del Capítulo 4.

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosidad</span>
  <strong>Un servicio sano puede ser inalcanzable por discovery obsoleto, y uno fallado puede seguir anunciado</strong>
  <p>Registros, leases y cachés publican creencias sobre ubicación. Esas creencias cambian en momentos distintos al estado físico real.</p>
  <p><strong>Pruébalo:</strong> Dibuja el timeline desde crash del worker hasta lease expiry y refresh del cliente.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">Más curiosidades del capítulo →</a>
</aside>

## 14. El balanceo de carga consume información de descubrimiento

Una vez que un servicio lógico resuelve a varios endpoints, alguien debe elegir uno.

Políticas frecuentes:

- elegir el primero;
- round robin;
- aleatoria;
- menor número de solicitudes pendientes;
- selección ponderada;
- selección consciente de localidad;
- consistent hashing por clave.

Cada política necesita estado diferente.

### Round robin

Es simple y determinista sobre un conjunto saludable, pero ignora el coste de las solicitudes y la capacidad de cada backend.

### Menor carga

Puede ser mejor cuando las solicitudes varían, pero «carga» debe medirse y comunicarse. Esas mediciones pueden estar obsoletas.

### Consistent hashing

Resulta útil cuando las solicitudes de una misma clave deberían tender a alcanzar el mismo backend o caché, pero los cambios de membresía deben manejarse con cuidado.

### Balanceo del lado del cliente frente a proxy

Del lado del cliente:

```text
registro → cliente → servidor elegido
```

Mediante proxy:

```text
cliente → balanceador/proxy → servidor
```

El balanceo del lado del cliente distribuye la lógica entre clientes y puede evitar un salto extra por proxy, pero obliga a implementar descubrimiento y selección en los clientes.

El balanceo mediante proxy centraliza la política y simplifica clientes, pero la capa de proxy pasa a ser infraestructura que también debe escalar y tolerar fallos.

No existe una arquitectura gratuita.

## 15. gRPC hace suficientemente explícitos los nombres y el balanceo como para estudiarlos

Un cliente gRPC suele crear un canal hacia un **target**, en lugar de abrir manualmente un socket por cada llamada.

El target se resuelve a una o varias direcciones. Después, una política de balanceo elige entre conexiones utilizables hacia backends.

Es un ejemplo moderno de esta separación:

```text
target lógico
    ↓
resolver de nombres
    ↓
conjunto de direcciones
    ↓
política de balanceo
    ↓
subchannel/backend
```

DNS es el resolver por defecto en muchos usos de gRPC, pero gRPC permite mecanismos de resolución configurables en los lenguajes que lo soportan. La configuración de servicio puede influir en balanceo y comportamiento de las llamadas.

La lección importante no es la API concreta: un sistema RPC maduro reconoce **resolución de nombres y selección de endpoints como responsabilidades distribuidas diferentes**.

## 16. Los nombres de servicio al estilo Kubernetes ilustran la indirección

La orquestación de contenedores proporciona otra comparación moderna.

Las instancias de workload de corta duración pueden recibir direcciones cambiantes. Las aplicaciones no deberían codificar normalmente esas direcciones de pod o instancia.

Un Service lógico puede recibir un nombre DNS estable mientras el sistema mantiene el conjunto actual de endpoints que lo respaldan.

Conceptualmente:

```text
cliente pregunta por servicio lógico
            ↓
DNS / descubrimiento
            ↓
abstracción de servicio
            ↓
instancias actuales
```

Esto ilustra un principio recurrente:

> **Coloca la ubicación volátil detrás de un nombre o identidad más estable.**

No necesitas Kubernetes para implementar localmente este principio.

## 17. Los registros crean su propio problema de sistemas distribuidos

Un registro central parece simple:

```text
clientes + trabajadores → registro
```

Pero ahora pregunta:

- ¿qué ocurre si cae el registro?
- ¿qué ocurre si pierde el estado de registro?
- ¿qué ocurre si dos réplicas discrepan?
- ¿qué ocurre si una partición divide las réplicas?
- ¿qué réplica puede aceptar escrituras?
- ¿cómo se entregan las notificaciones o watches?

Hemos desplazado el problema distribuido, no lo hemos eliminado.

No es un argumento contra los registros. Es un argumento a favor de describir honestamente sus garantías.

Un proyecto final pequeño puede aceptar razonablemente un único registro como punto único de fallo documentado si la especificación no exige tolerancia a fallos del registro.

Un proyecto más fuerte puede replicarlo mediante mecanismos introducidos más adelante.

La arquitectura consiste en elegir qué complejidad está justificada.

## 18. Membresía no es lo mismo que detección de fallos

La membresía responde:

> ¿Qué nodos se consideran actualmente parte del sistema?

La detección de fallos responde:

> ¿Qué nodos sospecho actualmente que no están disponibles?

Esos conjuntos pueden diferir temporalmente.

Un nodo puede ser miembro válido pero estar momentáneamente inaccesible.

Un nodo puede ser alcanzable, pero haber dejado de estar autorizado como miembro.

Un proceso puede reiniciarse en la misma dirección con una encarnación diferente.

Por eso un registro robusto de membresía suele necesitar información de identidad o versión más allá de host y puerto.

Por ejemplo:

```text
node_id = worker-7
incarnation = 43
endpoint = 10.0.0.7:9000
```

Si llega retrasado un heartbeat de la encarnación 42, el registro no debería necesariamente resucitar estado obsoleto.

Este patrón será importante en protocolos de membresía por gossip.

## 19. La membresía obsoleta puede causar problemas de corrección, no solo solicitudes fallidas

Seleccionar un backend caído suele producir tiempo de espera y reintento.

Pero el descubrimiento obsoleto puede ser más peligroso cuando los endpoints tienen autoridad.

Supón que un cliente guarda en caché que el nodo A es el líder actual. Cambia el liderazgo, pero el cliente sigue enviando escrituras a A.

Un protocolo de consenso correcto exige que A rechace o redirija solicitudes cuando sepa que ya no es líder. La caché del cliente no puede ser la fuente de verdad sobre la autoridad.

Regla útil:

> **El descubrimiento puede localizar un endpoint candidato; el protocolo debe validar todavía la autoridad cuando la corrección lo requiera.**

Nombres y consenso resuelven problemas distintos.

## 20. Ejemplo trabajado — registro de trabajadores

Considera tres trabajadores:

```text
W1 capacity=2
W2 capacity=4
W3 capacity=1
```

Cada uno registra:

```text
POST /register
{
  "node_id": "W2",
  "incarnation": 5,
  "endpoint": "127.0.0.1:7202",
  "capacity": 4,
  "lease_seconds": 15
}
```

El registro almacena el plazo del lease.

Un cliente solicita:

```text
GET /services/worker
```

y recibe los candidatos actuales.

Inyecta ahora un fallo:

```text
kill W2
```

Justo después, algunos clientes todavía pueden seleccionar W2.

El comportamiento esperado no es una omnisciencia instantánea. El diseño debe definir:

1. con qué rapidez se sospecha de W2;
2. con qué rapidez expira su registro;
3. qué ocurre mientras tanto con un RPC dirigido a W2;
4. si el cliente refresca descubrimiento tras el fallo;
5. cuándo puede seleccionarse el sustituto W4.

El laboratorio debe medir estos intervalos, no explicarlos de manera vaga.

## 21. Ejemplo trabajado — caché obsoleta después de escalar

Estado inicial:

```text
service = [A]
```

El cliente C resuelve el servicio y guarda A durante 60 segundos.

Diez segundos después:

```text
service = [A, B, C]
```

Las nuevas réplicas existen, pero C continúa usando solo A hasta refrescar.

Añadir capacidad no garantiza que todos los clientes existentes la utilicen inmediatamente.

La frescura del descubrimiento afecta a la elasticidad.

Un sistema que escala rápidamente puede necesitar:

- TTL más cortos;
- actualizaciones push/watch;
- refresco de conexión o canal;
- balanceo mediante proxy;
- otro mecanismo dinámico de control.

La elección depende de la carga y los objetivos operacionales.

## 22. Ejemplo trabajado — partición del registro

Supón un registro replicado:

```text
R1 ----- R2 ----- R3
```

Una partición aísla R1.

Los trabajadores cercanos a R1 continúan renovando allí sus entradas. Los clientes cerca de R2/R3 ven una membresía diferente.

¿Qué debe ocurrir?

No hay una respuesta universal. Algunas posibilidades:

- solo el lado con quórum acepta cambios de membresía;
- ambos lados aceptan cambios y reconcilian después;
- el estado del registro se considera eventualmente consistente y los clientes toleran candidatos obsoletos;
- los cambios autoritativos de membresía requieren consenso, mientras las observaciones de salud permanecen locales.

El diseño debe distinguir **estado de membresía crítico para la seguridad** de **información de descubrimiento orientativa**.

Los capítulos posteriores proporcionan mecanismos para implementar opciones más fuertes.

## 23. Los patrones arquitectónicos deben elegirse por sus consecuencias de fallo

Considera tres diseños para un servicio de trabajos.

### Diseño A — coordinador único

```text
clientes → coordinador → trabajadores
```

Ventajas:

- modelo de estado sencillo;
- decisiones de scheduling simples;
- depuración fácil.

Riesgo:

- el fallo del coordinador puede detener el progreso.

### Diseño B — coordinador replicado

```text
clientes → grupo de coordinadores → trabajadores
```

Ventajas:

- mayor disponibilidad del plano de control.

Coste:

- coordinación de estado replicado;
- elección de líder/consenso;
- recuperación más compleja.

### Diseño C — trabajadores descentralizados

```text
trabajadores ↔ trabajadores
```

Ventajas:

- no existe un único rol de scheduler.

Coste:

- membresía distribuida;
- propiedad del trabajo;
- prevención de asignaciones duplicadas;
- convergencia.

No se obtiene más mérito por escoger el diagrama más complicado. El mejor diseño es el más pequeño que satisface las garantías declaradas y puede defenderse experimentalmente.

## 24. Camino histórico — de archivos globales de hosts al descubrimiento dinámico

La historia de los nombres muestra por qué los sistemas distribuidos evolucionan a menudo desde configuración estática hacia mecanismos delegados y dinámicos.

Los primeros mapas nombre-host podían distribuirse como un archivo compartido mientras la red era pequeña. El crecimiento hizo costosos y frágiles el mantenimiento central y la redistribución global repetida.

DNS introdujo una base de datos jerárquica distribuida con autoridad delegada y caché.

Los centros de datos y nubes introdujeron después membresía mucho más dinámica: procesos y contenedores se sustituyen con frecuencia, las réplicas escalan, y los servicios abarcan zonas o regiones. Registros, Services administrados por orquestadores, sidecars/proxies y resolvers del cliente aparecieron para conectar una identidad de aplicación relativamente estable con una ubicación volátil.

A pesar de los cambios de software, la pregunta sigue siendo:

> **¿Qué nombre permanece estable mientras se mueve aquello que lo sirve?**

## 25. Errores comunes

### Error 1 — codificar direcciones y llamar a eso descubrimiento

Las direcciones estáticas pueden ser una configuración de bootstrap válida, pero la arquitectura debe reconocer sus consecuencias de actualización y fallo.

### Error 2 — equiparar DNS con estado siempre actualizado

DNS utiliza caché de forma intencionada. Distintos resolvers pueden conservar temporalmente respuestas diferentes.

### Error 3 — asumir que la salud es binaria y objetiva

Vivo, alcanzable, listo, actualizado y semánticamente saludable son propiedades distintas.

### Error 4 — retirar endpoints de inmediato tras un único tiempo de espera

Un tiempo de espera puede reflejar retraso de red, sobrecarga, problemas del cliente o pérdida transitoria, no necesariamente un servidor muerto.

### Error 5 — permitir que el descubrimiento obsoleto conceda autoridad

Una dirección de líder guardada en caché no convierte a ese nodo en el líder actual.

### Error 6 — construir un registro sin explicar su propio fallo

El registro forma parte del sistema distribuido y necesita su propio modelo de fallos.

### Error 7 — elegir microservicios porque distribuir suena moderno

Cada límite remoto introduce fallos, versionado, observabilidad y coste operacional.

### Error 8 — confundir identidad lógica con encarnación del proceso

Un proceso reiniciado puede representar el mismo rol lógico, pero debe distinguirse de mensajes retrasados enviados por su predecesor.

## 26. La conexión con la retirada de Ray

Ray resolvía indirectamente buena parte de esto.

Cuando escribías:

```text
@ray.remote
class Worker:
    ...
```

y obtenías handles a trabajadores, el runtime proporcionaba mecanismos para ubicar y planificar trabajo en procesos distribuidos.

Después de retirar Ray, la arquitectura debe responder explícitamente:

```text
¿Cómo entra un trabajador?
¿Cuál es su identidad estable?
¿Dónde se almacena su endpoint actual?
¿Cómo aprende un cliente ese endpoint?
¿Cuánto tiempo puede almacenarse en caché?
¿Cómo se sospecha un fallo?
¿Cómo se elimina una entrada muerta?
¿Quién selecciona entre réplicas?
¿Qué ocurre si la información del registro está obsoleta?
¿Qué ocurre si falla el propio registro?
```

Estas preguntas amplían el **mapa de dependencias del middleware** iniciado en el Capítulo 2.

## Transición al laboratorio

El laboratorio del Capítulo 8 construye un pequeño registro y un pool de trabajadores sin Ray. Los trabajadores registran identidad lógica, endpoint, metadatos e información de lease. Los clientes resuelven un nombre lógico de servicio, seleccionan un backend, observan membresía obsoleta después de una caída y comparan al menos dos estrategias de balanceo.

El experimento final particiona o desconecta deliberadamente parte del camino de descubrimiento para obligarte a distinguir:

```text
el servicio existe
el registro lo conoce
el cliente lo conoce
el cliente puede alcanzarlo
el servicio puede completar realmente la operación
```

Son hechos distintos.

## Resumen del capítulo

La arquitectura determina dónde viven el estado distribuido y la responsabilidad.

1. **Un servicio lógico no es lo mismo que un proceso o una dirección.**
2. **Cliente/servidor, multinivel, microservicios y peer-to-peer crean responsabilidades de fallo y descubrimiento diferentes.**
3. **Nombres, identificadores, direcciones e instancias concretas deben separarse deliberadamente.**
4. **DNS demuestra nombres delegados, caché y obsolescencia controlada.**
5. **El descubrimiento dinámico añade membresía y salud que cambian rápidamente.**
6. **Los leases permiten expirar registros obsoletos, pero dependen de supuestos temporales y de detección de fallos.**
7. **Los clientes pueden seguir obsoletos incluso cuando el registro ya es correcto.**
8. **El balanceo consume información de endpoints y hereda sus limitaciones de frescura.**
9. **Un registro es un componente del sistema distribuido cuyo fallo debe contabilizarse.**
10. **El descubrimiento localiza endpoints candidatos; por sí solo no establece autoridad ni corrección.**
11. **Una arquitectura estática puede ser correcta si sus supuestos encajan con el problema; la complejidad no es un objetivo de aprendizaje por sí misma.**
12. **Retirar Ray expone decisiones de membresía, placement, nombres y selección de endpoints que antes tomaba el middleware.**

El siguiente capítulo pregunta qué ocurre cuando ya has localizado a los participantes adecuados, pero varios mantienen copias del mismo estado lógico: ¿qué historias pueden observar los clientes y qué significa que esas copias estén de acuerdo?

<div class="ds-next-action">
  <span>Lectura esencial completada</span>
  <strong>Siguiente paso obligatorio · Práctica guiada</strong>
  <a href="../guided-practice/">Comenzar práctica guiada →</a>
</div>
