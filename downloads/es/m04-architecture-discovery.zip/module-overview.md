<p class="ds-book-part">Parte III — Nombres y estado replicado</p>
<p class="ds-module-kicker">Capítulo 8</p>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 8 de 12</span>
    <span>67% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 67%"></span></div>
</div>
<p class="ds-guiding-question">¿Cómo encuentras el servicio lógico correcto cuando los nombres permanecen estables pero cambian las ubicaciones y la membresía?</p>

Separa aquello que quieres nombrar de dónde se ejecuta en este momento. Comienza con nombres, identificadores y direcciones; sigue con indirection y caché al estilo DNS; después pasa a registros dinámicos, leases, membresía obsoleta, selección de endpoints y búsqueda descentralizada.

## Ideas clave

- nombres, identificadores y direcciones;
- nombres planos, estructurados y por atributos/servicio;
- DNS y caché;
- registros de servicio;
- leases y membresía;
- descubrimiento y selección de carga;
- mapeos obsoletos;
- hashing consistente;
- búsqueda tipo Chord/Kademlia;
- identidad lógica frente a incarnación de proceso.

## Transición al laboratorio

Construye un registro con leases y selección del lado del cliente. Mata/reemplaza workers, observa entradas y cachés obsoletas y compara la ruta centralizada con una alternativa estructurada.

## Empieza aquí

> **Antes de leer:** Un servicio llamado payments reinicia en una nueva dirección. ¿Qué identificador debería permanecer estable, qué valor debería cambiar y quién puede almacenar en caché el mapeo anterior?

**Trae contigo:** Arquitectura, comunicación y límites de fallo de los Capítulos 2–7.

**Este capítulo te prepara para:** Diseños de nombres y descubrimiento que sigan siendo comprensibles cuando cambian las ubicaciones, la membresía y las cachés.

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>35 min–50 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>45 min–1 h 10 min</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>2 h–2 h 30 min · 7 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Leer lección →</a>
  <a class="ds-secondary-action" href="lab/">Abrir laboratorio</a>
</div>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../downloads/es/m04-architecture-discovery.zip" download>Descargar capítulo + laboratorio para estudio sin conexión (.zip)</a></p>

## Qué aprenderás

- Distingue nombre, identificador, dirección, endpoint e incarnación de proceso.
- Explica nombres planos, estructurados y orientados a servicios usando DNS y registros de servicio como ejemplos concretos.
- Diseña registro, leases, caché y selección de endpoints para membresía cambiante.
- Razona sobre descubrimiento obsoleto y la diferencia entre autoridad de nombres y sospecha de fallo.
- Compara directorios centrales/replicados con hashing consistente y búsqueda descentralizada estructurada.

## Aprende trabajando la pregunta

1. Escribe tu respuesta a **Empieza aquí** antes de abrir la lección completa.
2. Lee hasta la siguiente predicción o traza; detente y resuélvela antes de revelar la explicación.
3. Trata la práctica guiada como un **banco de práctica**, no como una hoja para completar deprisa. Trabaja las trazas centrales hasta alcanzar el objetivo de práctica y vuelve después a los casos restantes.
4. Usa la comprobación para detectar vacíos y entra al laboratorio con una predicción falsable y con la evidencia que podría contradecirla.
5. Termina explicando qué estableció el experimento, qué no estableció y cómo cambia tu explicación del servicio acumulativo.

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../m09-consensus/">← Coordinación II — Exclusión mutua, elecciones y acuerdo</a>
<a class="ds-sequence-link next" href="../m08-replication-consistency/">Replicación y consistencia →</a>
</nav>
