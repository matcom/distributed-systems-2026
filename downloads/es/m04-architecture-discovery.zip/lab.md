<div class="ds-lesson-banner">
  <div><span>Laboratorio obligatorio</span><strong>Capítulo 8</strong></div>
  <div><span>Modelo de evidencia</span><strong>predecir → ejecutar → observar → explicar</strong></div>
  <div><span>Verificación</span><strong>7 pruebas públicas transparentes + evidencia</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 8 de 12</span>
    <span>67% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 67%"></span></div>
</div>
<p class="ds-back-link"><a href="../quick-check/">← Volver a la comprobación</a></p>

> **Antes de comenzar:** Completa los pasos de práctica guiada y comprobación de conocimientos. Ya deberías poder formular una predicción y nombrar la evidencia que la apoyaría o contradeciría. Si no, [vuelve a la comprobación](../quick-check/) y revisa la lección donde haga falta.

## Objetivo

Construye un pequeño registro de trabajadores y un sistema de descubrimiento del lado del cliente **sin Ray**. Demuestra que el fallo de un trabajador, el estado del registro, el estado de la caché del cliente y la alcanzabilidad real pueden discrepar temporalmente. Después compara estrategias de selección de endpoints y define el comportamiento cuando el propio servicio de descubrimiento no está disponible.

La cronología experimental central es:

```text
falla el trabajador
        ↓
el registro acaba expirando/eliminando al trabajador
        ↓
el cliente acaba refrescando la membresía
        ↓
el cliente redirige correctamente
```

Son cuatro eventos distintos.

## Resultados de aprendizaje

Al finalizar el laboratorio debes poder:

- separar nombre de servicio, identidad de nodo, encarnación de proceso y dirección;
- implementar registro y descubrimiento de trabajadores sin Ray;
- implementar una entrada de membresía basada en TTL/lease;
- demostrar vistas obsoletas del registro y del cliente;
- comparar al menos dos políticas de selección de endpoints;
- combinar descubrimiento con los plazos y la reselección/reintento del Capítulo 4;
- explicar el propio modelo de fallo del registro;
- identificar qué estado necesitaría después replicación o consenso para obtener garantías más fuertes.

## Límite de implementación

Ray está prohibido.

Implementación recomendada:

- servicios en Go;
- HTTP o gRPC para las operaciones del registro;
- gRPC o HTTP para las operaciones de los trabajadores;
- logs JSON estructurados;
- procesos locales o contenedores.

Kubernetes, Consul, etcd, ZooKeeper, balanceadores de nube y service meshes de producción pueden estudiarse como referencias, pero no pueden sustituir el mecanismo que debes implementar en este laboratorio.

## Arquitectura lógica

Empieza con:

```text
                    registro
                   /   |   \
                  /    |    \
                W1    W2    W3
                  \     |    /
                   \    |   /
                      cliente
```

El cliente debe dirigirse a un nombre lógico de servicio, por ejemplo:

```text
image-worker
```

y no a una dirección concreta codificada.

## Modelo requerido del registro

Cada registro debe incluir al menos:

```text
service_name
node_id
incarnation
endpoint
lease_duration o expires_at
```

Metadatos opcionales útiles:

```text
capacity
zone
version
labels
```

No añadas metadatos solo porque los registros de producción los tengan. Cada campo debe apoyar una decisión de diseño o un experimento.

## Comportamiento requerido del trabajador

Un trabajador debe exponer una operación determinista como:

```text
Work(request_id, value) -> result
```

y una señal básica de salud/readiness.

La respuesta debe identificar al trabajador que atendió la solicitud para poder observar la distribución de carga.

Ejemplo:

```text
request_id=R7
node_id=W2
incarnation=3
result=84
```

## Comportamiento requerido del cliente

El cliente debe:

1. resolver el servicio lógico mediante el registro;
2. almacenar el conjunto devuelto de endpoints durante un periodo configurable;
3. seleccionar un endpoint según una política configurable;
4. ejecutar un RPC con plazo;
5. reaccionar ante un endpoint fallido según una política documentada de refresco/reselección.

Implementa como mínimo:

- `pick-first` o primer endpoint utilizable;
- `round-robin`.

Una política ponderada o de menor número de solicitudes pendientes es una extensión opcional.

## Experimento 0 — registro y resolución normales

Inicia el registro y tres trabajadores.

Despliegue conceptual:

```text
registro :7100
W1       :7201
W2       :7202
W3       :7203
```

Cada trabajador se registra y comienza a renovar su lease.

Recoge el estado del registro:

```text
service=image-worker
members=[W1,W2,W3]
```

Después emite una solicitud del cliente.

Evidencia requerida:

- evento de registro;
- evento de resolución del cliente;
- endpoint seleccionado;
- evento de recepción/respuesta del trabajador;
- separación visible entre nombre lógico y endpoint físico.

## Experimento 1 — compara políticas de selección

Envía al menos 30 solicitudes deterministas mientras todos los trabajadores están saludables.

### Política A — pick first

Registra la distribución por trabajador.

### Política B — round robin

Registra la distribución por trabajador.

Presenta una tabla:

| Trabajador | Solicitudes pick-first | Solicitudes round-robin |
|---|---:|---:|
| W1 | | |
| W2 | | |
| W3 | | |

Explica por qué el mismo número de solicitudes no implica necesariamente la misma carga si los costes de las operaciones o las capacidades de los trabajadores son diferentes.

## Experimento 2 — muerte abrupta de un trabajador

Mata W2 **sin** desregistrarlo limpiamente.

Registra inmediatamente cuatro instantes/eventos:

```text
t_fail       el proceso realmente se detiene
t_registry   el registro expira/elimina W2
t_refresh    el cliente obtiene una membresía sin W2
t_recover    el cliente completa correctamente usando otro trabajador
```

No asumas que coinciden.

Si un cliente selecciona W2 mientras su lease sigue válido, debe aplicarse el comportamiento del Capítulo 4: la solicitud puede fallar o agotar su plazo y la política puede entonces reseleccionar o refrescar.

## Experimento 3 — ajuste de leases

Repite el experimento de fallo con al menos dos configuraciones de lease:

```text
lease A = corto
lease B = más largo
```

Compara:

- duración de la entrada obsoleta;
- riesgo de eliminación falsa ante retraso temporal;
- tráfico de heartbeat/control;
- tiempo de recuperación.

No se busca un número universalmente correcto. Explica el compromiso.

## Experimento 4 — trabajador vivo, camino al registro roto

Crea una situación en la que W3 siga siendo alcanzable por el cliente pero no pueda renovar su lease con el registro.

Puedes aproximarlo localmente con controles de procesos o red disponibles en tu entorno.

Observa:

```text
el trabajador está vivo
el cliente todavía puede alcanzarlo
el registro termina eliminándolo
```

Responde:

- ¿ha fallado W3?
- ¿está equivocado el registro?
- ¿deben los clientes nuevos seleccionar W3?
- ¿qué supuesto realiza tu política de lease?

Este experimento distingue **membresía** de **alcanzabilidad**.

## Experimento 5 — caché obsoleta del cliente

Configura el TTL de caché del cliente para que sea mayor que el intervalo de eliminación del registro.

1. El cliente resuelve `[W1,W2,W3]`.
2. Mata W2.
3. El registro elimina W2.
4. El cliente continúa deliberadamente usando el conjunto almacenado.

Muestra un intervalo en el que:

```text
estado del registro = [W1,W3]
estado del cliente  = [W1,W2,W3]
```

Este es un resultado requerido, no un bug que debas ocultar.

Después demuestra la política de recuperación del cliente.

Opciones posibles:

- refrescar descubrimiento inmediatamente después de un fallo de conexión;
- marcar localmente un endpoint como no saludable durante un tiempo acotado;
- seleccionar otro endpoint almacenado antes de refrescar;
- combinar ambas.

Justifica la elección.

## Experimento 6 — proceso sustituto y encarnación

Reinicia el trabajador lógico `W2` en otro endpoint e incrementa su encarnación.

Ejemplo:

```text
antiguo: node_id=W2 incarnation=7 endpoint=:7202
nuevo:   node_id=W2 incarnation=8 endpoint=:7292
```

Demuestra que el registro distingue el nuevo proceso de metadatos obsoletos asociados a la encarnación anterior.

Si tu implementación no transmite heartbeats antiguos retrasados, explica mediante traza o tabla cómo se usaría el campo de encarnación para rechazarlos.

## Experimento 7 — registro no disponible

Detén el registro mientras todos los trabajadores siguen saludables.

Prueba dos clientes.

### Cliente A — ya tiene endpoints en caché

¿Puede seguir haciendo solicitudes durante algún intervalo acotado?

### Cliente B — inicia sin estado de descubrimiento

¿Puede encontrar el servicio?

La respuesta depende de tu arquitectura y debe quedar documentada.

Este experimento identifica cuánto depende el camino de datos del camino de control/descubrimiento.

## Experimento 8 — reinicio del registro

Reinicia el registro.

Observa cómo se reconstruye la membresía.

Diseños posibles:

- los trabajadores vuelven a registrarse cuando detectan fallo/recuperación del heartbeat;
- el registro persiste las entradas, pero sigue exigiendo renovar leases;
- los clientes no participan en el registro.

Explica qué estado sobrevive al reinicio y cuál se reconstruye.

No afirmes que el registro es tolerante a fallos solo porque puede reiniciarse. La tolerancia depende de qué garantías siguen disponibles y de si se pierde estado importante.

## Experimento 9 — scale out

Inicia un nuevo trabajador W4 después de que un cliente ya haya guardado la membresía.

Mide:

```text
t_start_W4
t_registry_sees_W4
t_existing_client_sees_W4
t_first_request_to_W4
```

Esto revela que añadir capacidad y **usar** capacidad son eventos diferentes.

Discute cómo cambiaría el retraso con otro TTL o con actualizaciones push/watch.

## Experimento 10 — semántica de salud

Introduce un trabajador que está vivo y escucha conexiones, pero devuelve deliberadamente un resultado de aplicación «not ready».

Decide si el registro debe:

- conservarlo y marcarlo no listo;
- eliminarlo;
- dejar que el cliente decida;
- usar un campo de readiness separado.

No necesitas reproducir un sistema de health checks de producción, pero el informe debe distinguir vivacidad del proceso de readiness del servicio.

## Análisis arquitectónico requerido

Completa esta tabla:

| Pregunta | Tu diseño |
|---|---|
| ¿Cuál es el nombre lógico estable del servicio? | |
| ¿Cuál es el ID estable del nodo? | |
| ¿Qué cambia al reiniciar un proceso? | |
| ¿Dónde se almacena el estado de endpoints actual? | |
| ¿Quién crea/renueva el registro? | |
| ¿Cómo expira una entrada obsoleta? | |
| ¿Cuánto puede el cliente guardar la membresía? | |
| ¿Qué provoca un refresco del cliente? | |
| ¿Qué política de balanceo se usa? | |
| ¿Qué ocurre cuando el registro no está disponible? | |
| ¿Qué estado sobrevive al reinicio del registro? | |
| ¿Está replicado el estado del registro? | |

Si el registro es intencionadamente un punto único de fallo en el Capítulo 8, indícalo claramente. Los capítulos posteriores proporcionan mecanismos más fuertes.

## Objetivo de las pruebas públicas

Las pruebas públicas ejecutables viven en `tests/official/`, con el adaptador determinista de registro/lease/selección en `starter/src/`. Verifican los invariantes portables de descubrimiento; la muerte de procesos, el reinicio del registro y los tiempos de caché del cliente siguen requiriendo evidencia experimental.

Los casos visibles están documentados en `tests/official/README.md`. No se planean pruebas ocultas.

Añade casos para:

- registro duplicado;
- renovación de lease;
- eliminación de miembro expirado;
- nuevo registro con encarnación mayor;
- selección sobre un conjunto vacío;
- cambios de membresía durante round robin;
- endpoints malformados;
- comportamiento tras reinicio del registro.

## Requisitos de evidencia

El informe debe incluir:

1. traza normal de registro/resolución;
2. distribución de selección para dos políticas;
3. cronología de fallo de trabajador con cuatro eventos distintos;
4. evidencia de estado obsoleto entre registro y cliente;
5. comparación de configuraciones de lease;
6. comportamiento con registro no disponible;
7. evidencia de encarnación de sustitución;
8. tabla de arquitectura y limitaciones.

## Uso de IA

Se permiten asistentes y agentes de programación con IA.

Un ejercicio útil de auditoría consiste en preguntar a un asistente si un diseño con un único registro al inicio y una caché infinita del cliente es «tolerante a fallos». Clasifica sus afirmaciones y usa tus experimentos de fallo para demostrar dónde su razonamiento es correcto o incompleto.

Incluye la declaración estándar de uso de IA en el trabajo evaluado.

## Informe

Usa `REPORT.md` como estructura de entrega.

El resultado conceptual más importante debe responder:

> **En cada instante posterior al fallo de un trabajador, ¿quién sabe qué y cómo cambia finalmente ese conocimiento?**

## Termina el capítulo

Reproduce el resultado importante desde un inicio limpio. Después vuelve a tu predicción inicial: explica qué cambió, qué evidencia provocó el cambio y qué incertidumbre queda. Un comando exitoso o una captura no bastan cuando la afirmación trata de retries, orden, durabilidad, consistencia, recovery, seguridad o rendimiento.

<div class="ds-next-action">
  <span>Capítulo completo</span>
  <strong>Continuar el curso</strong>
  <a href="../../m08-replication-consistency/">Replicación y consistencia →</a>
</div>

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../../m09-consensus/">← Coordinación II — Exclusión mutua, elecciones y acuerdo</a>
<a class="ds-sequence-link next" href="../../m08-replication-consistency/">Replicación y consistencia →</a>
</nav>
