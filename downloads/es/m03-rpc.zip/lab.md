<div class="ds-lesson-banner">
  <div><span>Laboratorio obligatorio</span><strong>Capítulo 4</strong></div>
  <div><span>Modelo de evidencia</span><strong>predecir → ejecutar → observar → explicar</strong></div>
  <div><span>Verificación</span><strong>6 pruebas públicas transparentes + evidencia</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 4 de 12</span>
    <span>33% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 33%"></span></div>
</div>
<p class="ds-back-link"><a href="../quick-check/">← Volver a la comprobación</a></p>

> **Antes de comenzar:** Completa los pasos de práctica guiada y comprobación de conocimientos. Ya deberías poder formular una predicción y nombrar la evidencia que la apoyaría o contradeciría. Si no, [vuelve a la comprobación](../quick-check/) y revisa la lección donde haga falta.

## Objetivo

Construye un pequeño servicio RPC **sin Ray**, reproduce un tiempo de espera ambiguo, demuestra cómo un reintento ingenuo puede duplicar un efecto no idempotente y después rediseña el protocolo usando un identificador de solicitud estable y supresión de duplicados.

El laboratorio solo se considera correcto cuando la evidencia muestra tanto el fallo como la reparación.

## Resultados de aprendizaje

Al finalizar el laboratorio debes poder:

- definir un contrato versionado de solicitud/respuesta;
- implementar una operación remota sin Ray;
- configurar y observar un plazo del cliente;
- distinguir la observación del cliente de la ejecución del servidor;
- reproducir ejecución duplicada causada por reintentos;
- usar un único ID lógico de solicitud a través de varios intentos de transporte;
- implementar y explicar un mecanismo básico de supresión de duplicados;
- indicar con precisión qué garantiza y qué no garantiza tu implementación.

## Límite de implementación

Ray está prohibido en este laboratorio.

Stack nativo recomendado:

- Go;
- gRPC;
- Protocol Buffers;
- archivos locales u otro mecanismo durable sencillo cuando se necesite persistencia.

Puede usarse una implementación pequeña HTTP/JSON como alternativa aprobada por el profesor, siempre que conserve los mismos experimentos semánticos.

El objetivo no es la sintaxis del framework. El objetivo es el modelo de fallo de una operación remota.

## Problema del servicio

Implementa un servicio mínimo de contador con dos operaciones:

```text
GetCounter(name) -> value
Increment(request_id, name, delta) -> value
```

`Increment` es intencionadamente no idempotente cuando se ejecuta repetidamente.

El servicio debe exponer evidencia estructurada que contenga al menos:

```text
node_id
request_id
attempt_id o attempt_number cuando el cliente lo conozca
operation
counter_name
old_value
new_value
event
local_timestamp
```

El cliente debe generar un `request_id` estable para cada incremento lógico y puede usar números de intento distintos para los reintentos.

## Contrato sugerido con Protocol Buffers

El esquema exacto forma parte de tu diseño, pero debe ser equivalente en significado a:

```proto
service CounterService {
  rpc GetCounter(GetCounterRequest) returns (GetCounterReply);
  rpc Increment(IncrementRequest) returns (IncrementReply);
}

message IncrementRequest {
  string request_id = 1;
  string name = 2;
  int64 delta = 3;
}
```

Evita campos innecesarios. Cada campo debe tener una razón de existir.

## Superficie de comandos requerida

Los binarios concretos pueden variar, pero la entrega debe proporcionar comandos equivalentes a:

```text
iniciar servidor
consultar contador
incrementar contador con un ID de solicitud explícito
incrementar con un plazo del cliente
configurar retraso/punto de fallo determinista en el servidor
reiniciar servidor
inspeccionar estado/logs durables
```

El repositorio final debe exponer comandos reproducibles mediante su `Makefile` o un equivalente documentado.

## Experimento 0 — ejecución normal

Empieza sin retrasos artificiales.

Predicción:

> Un `Increment(R1, x, 1)` debe cambiar el contador `x` exactamente una vez y devolver el valor resultante.

Recoge:

- evento de envío del cliente;
- evento de recepción en el servidor;
- evento de aplicación en el servidor;
- evento de respuesta del servidor;
- valor final del contador.

Dibuja la secuencia normal.

No continúes hasta que puedas correlacionar los IDs de solicitud entre la evidencia del cliente y del servidor.

## Experimento 1 — el plazo vence antes de la ejecución

Configura el servidor para retrasarse **antes** de aplicar el efecto.

Cronología conceptual:

```text
cliente envía R2
servidor recibe R2
servidor espera 500 ms
vence el plazo del cliente a los 200 ms
el servidor todavía no ha aplicado el efecto
```

Registra:

- resultado observado por el cliente;
- si el servidor acaba aplicando o no;
- valor final del contador.

Según la implementación y el manejo de cancelación, el servidor puede detenerse o continuar. El informe debe describir el comportamiento observado, no asumir de antemano un resultado.

## Experimento 2 — efecto antes de una respuesta retrasada

Crea ahora la ambigüedad importante.

Configura el servicio para que haga:

```text
recibe solicitud
aplica incremento
registra estado
espera antes de responder
responde
```

Elige un plazo del cliente más corto que el retraso de la respuesta, pero suficientemente largo para que el efecto ya se haya aplicado.

Forma esperada:

```text
cliente                   servidor
   |                         |
   |------ R3 -------------> |
   |                         | aplica +1
   |                         | registra estado
   |                         | espera
   | vence plazo             |
   |<------- X --------------|
```

Después de que el cliente informe un fallo, inspecciona el estado del servidor.

La evidencia requerida debe demostrar:

> El cliente no recibió a tiempo una respuesta satisfactoria, pero el efecto de aplicación ocurrió.

Este es el experimento central del Capítulo 4.

## Experimento 3 — reintento ingenuo con un nuevo ID lógico

Partiendo de un valor conocido del contador:

1. ejecuta el escenario de respuesta retrasada;
2. deja que el cliente agote su plazo después de que el servidor haya aplicado el efecto;
3. reintenta la misma acción pretendida por el usuario usando un **nuevo** ID de solicitud;
4. inspecciona el valor final.

Por ejemplo:

```text
x inicial = 10
R4 aplica +1, la respuesta no se observa
R5 reintenta el +1 pretendido
x final = 12
```

El usuario pretendía un incremento. El servicio produjo dos efectos.

Explica por qué la fiabilidad de TCP, gRPC y el mecanismo de plazos no evitan este duplicado a nivel de aplicación.

## Experimento 4 — ID estable sin deduplicación

Repite el experimento usando el mismo ID de solicitud en ambos intentos.

Si el servidor simplemente ejecuta cada solicitud recibida, el efecto duplicado sigue ocurriendo.

Esto establece una distinción importante:

> Un ID de solicitud es metadato útil, pero no impone idempotencia por sí mismo.

## Experimento 5 — supresión de duplicados

Añade estado en el servidor que recuerde IDs lógicos completados y sus resultados.

Conceptualmente:

```text
si request_id ya está completado:
    devuelve resultado registrado
si no:
    aplica efecto
    recuerda request_id -> resultado
    devuelve resultado
```

Repite el tiempo de espera ambiguo y el reintento usando un único ID estable.

Resultado requerido:

- puede haber más de un intento de transporte;
- el incremento lógico cambia el contador una sola vez;
- el segundo intento devuelve o reconstruye el resultado lógico anterior.

Recoge logs que muestren:

```text
req=R6 event=apply
req=R6 event=duplicate-detected
```

## Experimento 6 — reinicio y durabilidad de la deduplicación

Reinicia el servidor entre el primer intento incierto y el reintento.

Si el estado de supresión de duplicados existe solo en memoria, un reinicio puede borrar el conocimiento de que R6 ya terminó.

Elige e implementa uno de estos contratos explícitos:

### Contrato A — deduplicación solo durante la vida de un proceso servidor

Documenta claramente esta limitación. Demuestra el duplicado después del reinicio.

### Contrato B — supresión durable de duplicados

Persiste suficiente estado de solicitud/resultado para que el reintento posterior al reinicio siga siendo suprimido.

Para obtener crédito completo en la implementación, se prefiere el Contrato B porque hace explícita la relación entre reconocimiento, durabilidad del estado y reintentos.

Todavía **no** necesitas resolver la replicación de este estado entre varios servidores. Los Capítulos 9 y 10 abordan ese problema.

## Experimento 7 — incrementos concurrentes

Ejecuta varios clientes concurrentemente contra un mismo contador.

Por ejemplo:

```text
20 solicitudes lógicas × delta 1
```

Cada solicitud debe tener un ID lógico distinto. Algunos intentos pueden repetirse de forma intencionada.

Compara:

- total lógico esperado;
- número de intentos de transporte;
- número de IDs de solicitud únicos;
- valor final del contador.

Este experimento conecta la semántica RPC con la concurrencia local de Sistemas Operativos y prepara el Capítulo 3.

## Experimento 8 — política de reintentos

Implementa una política acotada de reintentos del cliente.

La política debe especificar:

- número máximo de intentos;
- plazo global o presupuesto temporal;
- comportamiento de backoff;
- qué errores/estados son reintentables;
- conservación del ID lógico de solicitud.

No reintentes simplemente todos los errores.

El informe debe incluir al menos un error permanente que **no** se reintente.

## Análisis requerido — límite semántico

Completa esta tabla para tu implementación:

| Afirmación | ¿Soportada? | Evidencia / limitación |
|---|---|---|
| gRPC/HTTP enmarca los bytes de solicitud | | |
| la espera del cliente está acotada | | |
| los fallos transitorios pueden reintentarse | | |
| un mismo ID lógico se conserva entre reintentos | | |
| pueden ocurrir ejecuciones duplicadas del handler | | |
| se suprimen efectos duplicados sobre el contador | | |
| la supresión sobrevive al reinicio del servidor | | |
| la supresión sobrevive a la pérdida del único servidor | | |
| se garantizan efectos externos exactamente una vez | | |

No marques las dos últimas como verdaderas salvo que tu arquitectura realmente lo soporte.

## Objetivo de las pruebas públicas

Las pruebas públicas ejecutables viven en `tests/official/`, con un pequeño adaptador semántico en `starter/src/`. Verifican invariantes deterministas de identidad de solicitud y supresión de duplicados; plazos, transporte, reinicio y comportamiento multiproceso siguen requiriendo la evidencia descrita arriba.

Los casos públicos que debes implementar están documentados en `tests/official/README.md`. No se planean casos ocultos.

Añade tus propias pruebas en `tests/student/`, especialmente para:

- IDs de solicitud duplicados;
- IDs malformados;
- deltas cero o negativos, si la API los permite;
- reintento después de tiempo de espera;
- comportamiento tras reinicio;
- solicitudes concurrentes.

## Requisitos de evidencia

Tu informe debe incluir evidencia legible por máquinas cuando sea posible.

Como mínimo proporciona:

1. una traza de ejecución normal;
2. una traza donde el cliente agota su tiempo de espera **después** de que ocurra el efecto del servidor;
3. un reintento ingenuo que muestre el efecto duplicado;
4. un reintento reparado que muestre supresión de duplicados;
5. estado final antes/después del experimento de reinicio;
6. explicación de tu política de reintentos.

Las capturas de pantalla pueden ilustrar el experimento, pero no sustituyen los logs ni la evidencia de estado.

## Uso de IA

Se permiten asistentes y agentes de programación con IA.

Un flujo útil es:

1. pide al agente que prediga historias posibles de un tiempo de espera;
2. diseña de forma independiente un experimento que las distinga;
3. pide al agente que revise el código de reintento/idempotencia;
4. clasifica sus observaciones como válidas, inválidas o incompletas;
5. verifica el comportamiento final con tu propio experimento.

Incluye la declaración estándar de uso de IA en el trabajo evaluado.

## Informe

Usa `REPORT.md` como estructura de entrega.

La frase más importante del informe debe responder:

> **Después de un tiempo de espera agotado, ¿qué evidencia permite a este cliente determinar si la operación lógica ya produjo su efecto?**

## Termina el capítulo

Reproduce el resultado importante desde un inicio limpio. Después vuelve a tu predicción inicial: explica qué cambió, qué evidencia provocó el cambio y qué incertidumbre queda. Un comando exitoso o una captura no bastan cuando la afirmación trata de retries, orden, durabilidad, consistencia, recovery, seguridad o rendimiento.

<div class="ds-next-action">
  <span>Capítulo completo</span>
  <strong>Continuar el curso</strong>
  <a href="../../m12-dht-gossip/">Comunicación II — Mensajería, diseminación y overlays →</a>
</div>

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../../m05-processes-concurrency/">← Procesos, virtualización y ejecución distribuida</a>
<a class="ds-sequence-link next" href="../../m12-dht-gossip/">Comunicación II — Mensajería, diseminación y overlays →</a>
</nav>
