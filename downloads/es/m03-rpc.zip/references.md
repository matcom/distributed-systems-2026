> **Vista de referencia.** Esta página ofrece contexto opcional; vuelve a la [Lección](../lesson/) para la ruta obligatoria.

## Esencial

- **● gRPC Core Concepts, Architecture and Lifecycle** — gRPC Authors. [documentation](https://grpc.io/docs/what-is-grpc/core-concepts/)
- **● Protocol Buffers Documentation** — Google. [documentation](https://protobuf.dev/)

## Recomendado

- **●● gRPC Deadlines Guide** — gRPC Authors. [documentation](https://grpc.io/docs/guides/deadlines/)
- **●● gRPC Retry Guide** — gRPC Authors. [documentation](https://grpc.io/docs/guides/retry/)

## Avanzado

- **●●● Implementing Remote Procedure Calls** — Andrew D. Birrell and Bruce Jay Nelson. [paper](https://www.cs.cmu.edu/~dga/15-712/F07/papers/birrell842.pdf)
- **●●● End-to-End Arguments in System Design** — Saltzer, Reed, Clark. [paper](https://web.mit.edu/Saltzer/www/publications/endtoend/endtoend.pdf)

## Herramientas y práctica

- **● gRPC Documentation** — gRPC Authors. [documentation](https://grpc.io/docs/)

## Explora

- **●●● 6.5840 Distributed Systems** — MIT PDOS. [course](https://pdos.csail.mit.edu/6.824/)
