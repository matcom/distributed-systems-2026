# Planned transparent official tests — M03

Executable public tests are provided in this directory together with the starter semantic adapter under `starter/src/`. They encode deterministic portions of the categories below; broader network/failure behavior remains evidence-based. No hidden correctness cases are planned.

## Protocol and normal behavior

- service starts from documented local configuration;
- `GetCounter` returns the current value;
- `Increment` applies the requested delta;
- request IDs are accepted and observable;
- malformed requests receive a defined application error.

## Deadline and delay controls

- deterministic pre-effect delay can exceed the client deadline;
- deterministic post-effect/pre-response delay can create the required ambiguous timeout;
- the client returns within the configured wait budget.

## Duplicate semantics

- repeated attempts with no suppression can demonstrate duplicate effects in the intentionally naive stage;
- the completed implementation recognizes repeated logical request IDs;
- repeated attempts using the same request ID do not apply the counter effect twice;
- different request IDs remain different logical operations.

## Persistence/restart

- if durable duplicate suppression is claimed, a server restart preserves the relevant request/result record;
- if only process-lifetime suppression is implemented, the limitation must be declared and the corresponding expected behavior remains public.

## Concurrency

- distinct concurrent logical requests are all represented in final state;
- retry attempts do not increase the logical result beyond the unique operation set when suppression is enabled.

Students may inspect, run, and extend every executable case without limit. Student-added cases belong in `tests/student/`.