import unittest

from rpc_semantics import CounterService


class RpcSemanticsTests(unittest.TestCase):
    def test_get_counter_starts_at_initial_value(self):
        service = CounterService(initial=7)
        self.assertEqual(service.get_counter(), 7)

    def test_increment_applies_delta_once(self):
        service = CounterService()
        self.assertEqual(service.increment("r1", 3), 3)
        self.assertEqual(service.get_counter(), 3)

    def test_duplicate_request_id_does_not_repeat_effect(self):
        service = CounterService()
        first = service.increment("r1", 5)
        second = service.increment("r1", 5)
        self.assertEqual(first, second)
        self.assertEqual(service.get_counter(), 5)

    def test_duplicate_uses_original_result_even_if_delta_changes(self):
        service = CounterService()
        self.assertEqual(service.increment("r1", 2), 2)
        self.assertEqual(service.increment("r1", 999), 2)
        self.assertEqual(service.get_counter(), 2)

    def test_distinct_request_ids_are_distinct_operations(self):
        service = CounterService()
        service.increment("r1", 2)
        service.increment("r2", 2)
        self.assertEqual(service.get_counter(), 4)

    def test_completed_result_exposes_deduplication_record(self):
        service = CounterService()
        self.assertIsNone(service.completed_result("missing"))
        result = service.increment("r1", 4)
        self.assertEqual(service.completed_result("r1"), result)


if __name__ == "__main__":
    unittest.main()
