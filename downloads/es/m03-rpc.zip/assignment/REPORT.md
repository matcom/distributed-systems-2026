# M03 Laboratory Report — Communication, RPC, and Failure Semantics

## 1. Environment

Record OS/runtime versions, language/tool versions, process layout, and exact commands needed to reproduce the service.

## 2. Protocol contract

Describe the RPC methods, request/response fields, versioning decisions, and the role of `request_id`.

## 3. Normal execution

### Prediction

### Evidence

### Explanation

Include one correlated client/server trace.

## 4. Ambiguous timeout

Construct the required execution in which the server applies the effect before the client deadline is observed.

### Prediction

### Timeline

| Event | Local time / relative time | Evidence |
|---|---:|---|
| client sends | | |
| server receives | | |
| server applies | | |
| client deadline expires | | |
| server attempts reply | | |

### What did the client know at timeout?

### What had actually happened at the server?

## 5. Naive retry

Show the duplicate effect caused by retrying the intended operation without effective duplicate suppression.

## 6. Stable request ID and duplicate suppression

### Design

### State retained by the server

### Repeated-attempt trace

### Final state

Explain why a stable request ID alone was insufficient and what server state was required.

## 7. Restart experiment

Does duplicate suppression survive restart? Provide evidence and state the exact guarantee your implementation offers.

## 8. Concurrent workload

Report logical requests, transport attempts, duplicate attempts, and final counter state.

## 9. Retry policy

Document retryable conditions, non-retryable conditions, attempt limit, deadline/budget, and backoff strategy.

## 10. Semantic guarantee table

| Claim | Supported? | Evidence / limitation |
|---|---|---|
| bounded waiting | | |
| stable logical request IDs | | |
| duplicate effects suppressed | | |
| suppression survives restart | | |
| suppression survives loss of only server | | |
| exactly-once external side effects | | |

## 11. What the abstraction hid

Relate the native implementation back to the Ray Phase 1 / M02 middleware dependency map.

## 12. AI-use disclosure

List AI tools used, activities delegated, and how important output was independently verified.

## 13. Final answer

Answer in your own words:

> After a timeout, what evidence lets this client determine whether the logical operation has already taken effect?
