"""Small application-level contract for M03 RPC semantics.

The network/RPC transport is intentionally outside this file. These functions model
state-changing request identity and duplicate suppression so public tests can verify
the semantic boundary independently from the student's chosen transport.
"""


class CounterService:
    def __init__(self, initial: int = 0):
        self.value = initial
        self._results = {}

    def get_counter(self) -> int:
        return self.value

    def increment(self, request_id: str, delta: int) -> int:
        """Apply one logical increment and return the resulting counter value.

        Repeating the same request_id must return the original result without
        applying the effect again. Distinct request IDs are distinct operations.
        """
        raise NotImplementedError("TODO: implement retry-safe increment semantics")

    def completed_result(self, request_id: str):
        """Return the stored result for request_id, or None when unknown."""
        raise NotImplementedError("TODO: expose duplicate-suppression state")
