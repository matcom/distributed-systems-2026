<p class="ds-book-part">Parte II — Comunicación y coordinación</p>
<div class="ds-lesson-banner">
  <div><span>Paso del curso</span><strong>Capítulo 4</strong></div>
  <div><span>Lectura esencial</span><strong>30 min–45 min</strong></div>
  <div><span>Ruta obligatoria</span><strong>Leer → Objetivo de práctica → Comprobar → Laboratorio</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 4 de 12</span>
    <span>33% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 33%"></span></div>
</div>

> **Pregunta guía:** Cuando una operación remota no responde, ¿qué sabes exactamente que ocurrió?

## Antes de leer

> El servidor confirma una operación y su respuesta se pierde. ¿Debe el cliente reintentar? Escribe tu respuesta antes de elegir un mecanismo de idempotencia.

Escribe primero una respuesta breve. No necesitas acertar todavía: necesitas una predicción que puedas revisar a medida que el capítulo te dé mejores modelos y evidencia.

**Usa lo que ya sabes:** Los límites entre procesos del Capítulo 3 y el comportamiento básico de transporte/sockets visto en Redes de Computadoras.

## Mapa de carga de trabajo

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>30 min–45 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>45 min–1 h</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>2 h–2 h 30 min · 6 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../../downloads/es/m03-rpc.zip" download>Descargar lección + práctica + laboratorio para estudio sin conexión (.zip)</a></p>

## Por qué importa este capítulo

En el Capítulo 2, Ray hizo que la ejecución remota pareciera deliberadamente ordinaria. Una función podía convertirse en una tarea, un actor podía conservar estado y una referencia similar a un futuro podía representar un resultado. Esa productividad es útil, pero oculta la pregunta que este capítulo debe volver inevitable:

> **Cuando una llamada remota falla, ¿qué sabemos exactamente que ocurrió?**

En una llamada a una función local, quien llama y quien ejecuta suelen compartir un mismo límite de fallo. Si el proceso continúa y la función retorna, quien llama tiene una evidencia fuerte de que la función terminó. Si el proceso cae, ambos lados de la llamada desaparecen juntos.

Una llamada remota es distinta. El cliente, la red, el proceso servidor, el subsistema de almacenamiento y el camino de respuesta pueden fallar de forma independiente. Por eso, un tiempo de espera agotado no responde con un simple sí o no a la pregunta de si la operación se ejecutó. Introduce incertidumbre.

Imagina que un cliente pide a un servicio incrementar el saldo de una cuenta:

```text
cliente                 servidor
   |                        |
   |---- increment(10) ---> |
   |                        | aplica +10
   |                        | persiste
   | <----- X respuesta --- |
   |                        |
   | tiempo de espera       |
```

¿Qué debe hacer el cliente?

Reintentar puede ser correcto si la primera solicitud nunca llegó. Puede ser incorrecto si la primera solicitud terminó y solo se perdió la respuesta. Este único diagrama concentra gran parte de la ingeniería de sistemas distribuidos: enmarcado de mensajes, serialización, plazos, reintentos, supresión de duplicados, estado durable, observabilidad y semántica de aplicación.

> **Detente y predice.** Un cliente recibe `DEADLINE_EXCEEDED`. Enumera al menos cuatro ejecuciones diferentes que podrían haber producido esa observación.

Este capítulo avanza desde la comunicación básica de solicitud/respuesta hacia RPC, pero su tema real no es la sintaxis de gRPC. Es la distancia semántica entre **un intento de llamada** y **un efecto de aplicación**.

## 1. La comunicación comienza con un protocolo, no con una llamada a una biblioteca

Dos procesos no pueden compartir una pila de llamadas normal a través de la red. Intercambian bytes de acuerdo con un protocolo.

Un protocolo mínimo de solicitud/respuesta debe responder preguntas como estas:

- cómo empieza y termina un mensaje;
- qué operación se solicita;
- cómo se representan los parámetros;
- cómo se representan el éxito y el fallo;
- cómo evolucionan las versiones;
- cómo se distingue una solicitud de otra;
- si varias solicitudes pueden compartir una conexión;
- si las respuestas pueden llegar fuera de orden.

Incluso un diseño pequeño necesita estructura:

```text
Solicitud
+----------------------+-------------------------+
| cabecera             | carga útil              |
+----------------------+-------------------------+
| versión              | datos de la operación   |
| request_id           |                         |
| operación            |                         |
| longitud_payload     |                         |
+----------------------+-------------------------+
```

La representación exacta puede ser JSON, Protocol Buffers, CBOR, una codificación binaria propia u otra alternativa. La pregunta de sistemas viene primero: **¿qué información debe cruzar el límite de fallo?**

### Los flujos de bytes necesitan enmarcado

TCP ofrece un flujo de bytes ordenado. No conserva los límites de los mensajes de la aplicación.

Si un emisor ejecuta:

```text
send("ABC")
send("DEF")
```

el receptor no tiene garantizadas dos lecturas que devuelvan exactamente `ABC` y `DEF`. Puede observar los seis bytes juntos o fragmentos parciales, según el buffering y la planificación.

Por tanto, un protocolo de aplicación necesita enmarcar sus mensajes. Algunas opciones habituales son:

- mensajes de tamaño fijo;
- delimitadores;
- prefijos de longitud;
- codificaciones estructuradas autodescriptivas;
- un protocolo de nivel superior, como HTTP/2, que ya proporciona enmarcado.

Un parser robusto debe tratar la red como un flujo de bytes, no como una cola mágica de objetos de aplicación.

> **Ejemplo trabajado.** Un protocolo usa un prefijo de longitud sin signo de 4 bytes seguido de la carga útil. El receptor lee primero suficientes bytes para reconstruir la longitud `N` y continúa hasta recibir exactamente `N` bytes de carga útil. Que una sola llamada a `read()` devuelva menos de `N` bytes no es automáticamente un error; puede ser el comportamiento normal de un flujo.

<aside class="ds-book-note ds-history">
  <span class="ds-book-note-label">Historia</span>
  <strong>RPC facilitó escribir programas distribuidos al ocultar la red, y también hizo más fácil olvidar la semántica de los fallos</strong>
  <p>Remote Procedure Call convirtió mensajes en llamadas con apariencia familiar, pero timeouts, ejecución duplicada, reintentos y fallos parciales impiden que una llamada remota sea semánticamente igual a una local.</p>
  <a class="ds-book-note-source" href="../../../history/rpc-transparency-and-failure/">Lee la historia del diseño →</a>
</aside>

## 2. La serialización define la representación en el cable

Los objetos en memoria contienen detalles propios del lenguaje y del proceso: punteros, padding, metadatos del runtime, identidades de objetos y representaciones dependientes de la arquitectura. Enviar esos bytes directamente suele ser inútil o inseguro.

La serialización crea una representación compartida.

Supón que un proceso mantiene:

```text
Job {
    id: 41
    operation: "resize"
    width: 640
}
```

El receptor necesita una representación cuyos campos y tipos entiendan ambos lados.

Por ello, la serialización introduce preguntas de compatibilidad:

- ¿puede un cliente antiguo hablar con un servidor nuevo?
- ¿qué ocurre con los campos desconocidos?
- ¿pueden añadirse campos sin romper peers antiguos?
- ¿los enteros tienen signo?
- ¿el orden es significativo?
- ¿qué tamaño máximo puede tener un mensaje?
- ¿una entrada hostil puede provocar una asignación de memoria sin límite?

No son detalles cosméticos. Un sistema distribuido suele actualizar nodos de manera gradual, por lo que pueden coexistir varias versiones del software.

### Versiona el contrato, no solo el despliegue

Un protocolo debe hacer explícita su evolución.

Un diseño débil dice:

> «Todos los nodos ejecutarán siempre exactamente el mismo código».

Ese supuesto se rompe durante actualizaciones progresivas, despliegues parciales, reinicios fallidos, clientes con caché o procesos de larga duración.

Un diseño más sólido especifica qué cambios son compatibles y cómo se informa un comportamiento no soportado.

## 3. RPC convierte el intercambio de mensajes en una abstracción de interfaz

Remote Procedure Call intenta permitir que un programa invoque funcionalidad en otro proceso mediante una interfaz parecida a una llamada a procedimiento.

Históricamente, RPC fue un paso importante en la programación distribuida porque separó el código de aplicación de muchos detalles repetitivos de serialización de solicitudes, transporte, despacho y deserialización de respuestas.

Conceptualmente:

```text
aplicación cliente
        |
        v
    stub cliente
        |
 serializa solicitud
        |
        v
      red
        |
        v
  runtime servidor
        |
     despacho
        |
        v
implementación servidor
```

La abstracción es valiosa porque permite razonar con operaciones como:

```text
Get(key)
Put(key, value)
Submit(job)
GetStatus(job_id)
```

en lugar de definir manualmente cada lectura y escritura de socket.

Sin embargo, la abstracción se vuelve peligrosa cuando sugiere que una llamada remota tiene la misma semántica que una llamada local.

### Las llamadas locales y remotas son fundamentalmente distintas

Una llamada local suele ser:

- rápida en comparación con una operación de red;
- interna a un único límite de fallo de proceso;
- basada en argumentos en memoria;
- controlada directamente por un único runtime;
- ajena a pérdidas de paquetes o particiones.

Una llamada remota puede:

- retrasarse de forma impredecible;
- duplicarse por la lógica de reintentos;
- cancelarse solo del lado local mientras los efectos remotos continúan;
- rechazarse por una incompatibilidad de versión;
- ejecutarse en un nodo que cae inmediatamente después;
- completarse aunque el cliente informe un fallo.

Por eso este curso trata RPC como una abstracción valiosa, pero nunca como «una llamada local que ocurre en otra máquina».

## 4. HTTP y gRPC ofrecen tipos diferentes de contrato de aplicación

HTTP es un protocolo de aplicación ampliamente desplegado, con métodos, códigos de estado, cabeceras, cuerpos de solicitud y respuesta, semántica de caché, intermediarios y un gran ecosistema de herramientas.

Con frecuencia es suficiente para APIs de servicios distribuidos. Un servicio JSON sobre HTTP resulta fácil de inspeccionar con `curl`, proxies, logs y herramientas del navegador.

gRPC ofrece un modelo más explícitamente orientado a RPC. Los servicios y métodos se declaran mediante una definición de interfaz, normalmente con Protocol Buffers. El código generado de cliente y servidor representa después esos métodos mediante APIs propias de cada lenguaje.

Una definición de servicio puede parecerse conceptualmente a:

```proto
service Counter {
  rpc Add(AddRequest) returns (AddReply);
  rpc Get(GetRequest) returns (GetReply);
}
```

Esto convierte el contrato en una descripción legible por máquinas y facilita stubs generados, mensajes tipados, distintos modos de streaming, metadatos, plazos y manejo de estados.

La razón de usar gRPC en el curso no es que sea universalmente superior. Nos proporciona un entorno RPC realista y cómodo donde **el límite de red sigue siendo suficientemente visible como para estudiarlo**.

### El streaming cambia la forma de la interacción

RPC no se limita a una solicitud y una respuesta. Los frameworks actuales pueden soportar:

- solicitud unaria → respuesta unaria;
- una solicitud → flujo de respuestas;
- flujo de solicitudes → una respuesta;
- flujos bidireccionales.

El streaming no elimina la semántica de fallos. Introduce nuevas preguntas:

- ¿cuánto del flujo se procesó antes del fallo?
- ¿puede reanudarse el procesamiento?
- ¿dónde se registra el progreso?
- ¿qué ocurre si el cliente vuelve a conectarse?

Vuelve el mismo principio: el progreso del transporte y el progreso de la aplicación no son el mismo estado.

## 5. Protocol Buffers separa la estructura de la interfaz de la representación en memoria

Protocol Buffers es útil en el curso porque obliga a escribir explícitamente el contrato que cruza la red.

Por ejemplo:

```proto
message PutRequest {
  string request_id = 1;
  string key = 2;
  bytes value = 3;
}

message PutReply {
  bool applied = 1;
  string detail = 2;
}
```

Observa que `request_id` pertenece al protocolo de aplicación. No es simple decoración de trazado. Más adelante permite distinguir una operación lógica de varios intentos de transporte.

### La identidad de los campos importa entre versiones

En un formato binario etiquetado, los identificadores numéricos de los campos se convierten en parte del contrato durable del protocolo. Reutilizar el número de un campo eliminado para un significado distinto puede crear ambigüedad cuando conviven software antiguo y nuevo.

La lección general va más allá de Protocol Buffers:

> **Los formatos de red sobreviven a versiones individuales del código fuente.**

Debes poder señalar la definición de interfaz y explicar cómo se interpreta una solicitud independientemente de la implementación concreta del cliente que la produjo.

## 6. Los plazos limitan la espera, no la incertidumbre

Sin un plazo, un cliente puede esperar indefinidamente una respuesta de un servicio lento, particionado, sobrecargado, caído o simplemente inaccesible.

Un plazo dice aproximadamente:

> «Después de este punto, el cliente ya no está dispuesto a esperar este intento RPC».

Es principalmente una decisión de recursos y vivacidad.

No dice:

> «Después de este punto, sé que el servidor no ejecutó la operación».

gRPC modela explícitamente plazos y tiempos de espera, y el servidor suele poder observar cuánto tiempo útil queda. Aun así, cada lado solo puede concluir a partir de la evidencia que observa localmente.

### Cuatro historias compatibles con un tiempo de espera

Supón que un cliente envía `Put(k, v)` y se agota su tiempo de espera.

#### Historia A — la solicitud nunca llega al servidor

```text
cliente ----X----> servidor
```

Reintentar es necesario para progresar.

#### Historia B — el servidor comienza, pero falla antes del efecto

```text
cliente ----> servidor
              comienza
              falla
```

Puede ser necesario reintentar.

#### Historia C — el efecto termina, pero la respuesta se pierde

```text
cliente ----> servidor
              persiste efecto
cliente <----X respuesta
```

Un reintento ciego puede duplicar un efecto no idempotente.

#### Historia D — la operación sigue ejecutándose cuando el cliente deja de esperar

```text
cliente ----> servidor
              cómputo largo ...
cliente agota el plazo
              ... termina después
```

La cancelación o el tiempo de espera del cliente no deshacen automáticamente efectos de aplicación que ya se realizaron.

Por tanto, un tiempo de espera convierte una llamada con «resultado desconocido» en una **operación distribuida incierta**, salvo que la semántica de la aplicación proporcione una forma de resolver esa incertidumbre.

## 7. Cancelar no significa revertir

Un cliente puede cancelar un RPC porque:

- el usuario cerró la solicitud;
- venció el plazo de una operación padre;
- otra réplica respondió antes;
- la operación ya no resulta útil.

La cancelación puede ayudar al servidor a detener trabajo innecesario. Sin embargo, los efectos que ya terminaron pueden permanecer.

Imagina:

```text
1. servidor escribe una fila
2. servidor publica un evento
3. vence el plazo del cliente
4. llega la cancelación
```

El sistema no puede fingir que la escritura y la publicación nunca ocurrieron.

Por eso cancelación, transacciones, compensación e idempotencia son conceptos distintos.

## 8. Los reintentos intercambian fallos transitorios por riesgo de duplicados y carga

Los reintentos son uno de los mecanismos más útiles y también más peligrosos de los sistemas distribuidos.

Ayudan cuando el fallo es temporal:

- una conexión se reinicia;
- un proceso servidor se reinicia;
- un balanceador elige un backend no saludable;
- se pierde un paquete;
- termina un breve periodo de sobrecarga.

Pero cada reintento añade trabajo. Durante un fallo extendido, muchos clientes reintentando a la vez pueden incrementar la carga precisamente cuando el sistema dispone de menos capacidad libre.

Así aparece una tormenta de reintentos:

```text
el servicio se ralentiza
          ↓
aumentan los tiempos de espera
          ↓
los clientes reintentan
          ↓
aumenta la carga
          ↓
el servicio se ralentiza todavía más
```

### Una política de reintentos necesita semántica

Una política útil debe preguntar:

1. **¿Qué operaciones son seguras de reintentar?**
2. **¿Qué fallos parecen razonablemente transitorios?**
3. **¿Cuántos intentos se permiten?**
4. **¿Cuánto debe esperar el cliente entre intentos?**
5. **¿Existe un plazo o presupuesto global?**
6. **¿Cómo se observarán los reintentos en métricas y trazas?**

El backoff exponencial y el jitter ayudan a evitar que clientes sincronizados saturen un servicio que se recupera, pero no resuelven los efectos duplicados.

### Reintento de transporte y reintento de aplicación no son lo mismo

Un framework puede reintentar automáticamente cuando sabe que un intento nunca llegó a código de aplicación. Eso es mucho más seguro que repetir una solicitud después de que el servidor quizá ejecutó un efecto secundario.

Debes distinguir:

```text
reintentar un intento que se sabe que no se ejecutó
```

de:

```text
reintentar una operación cuyo resultado es incierto
```

El segundo caso requiere diseño a nivel de aplicación.

## 9. La idempotencia hace que ejecuciones repetidas converjan a un único efecto

Una operación es idempotente cuando aplicarla varias veces produce el mismo efecto intencionado que aplicarla una sola vez.

Ejemplos habituales:

```text
SetStatus(job, "cancelled")
Delete(object X)   [según la definición de la API]
SetConfiguration(version, value)
```

Ejemplos no idempotentes:

```text
Increment(counter, 1)
Transfer($10 from A to B)
Append(new unique item without duplicate control)
SendEmail(message)
```

Pero la idempotencia depende de la **operación semántica**, no solo del nombre de un método HTTP o de la firma de una función.

### Las claves de idempotencia convierten intentos en una operación lógica

Supón que el cliente asigna un identificador estable a la operación:

```text
request_id = 8f31...
operation = Transfer(A, B, 10)
```

Todos los reintentos usan el mismo ID.

El servidor conserva suficiente estado durable para reconocer ese ID:

```text
request 8f31 primera vez
    ↓
ejecuta transferencia
    ↓
registra resultado de 8f31

request 8f31 otra vez
    ↓
devuelve resultado registrado
    ↓
no ejecuta de nuevo la transferencia
```

Parece sencillo, pero introduce un requisito importante de atomicidad:

> Registrar «solicitud completada» por separado de aplicar el efecto secundario también puede fallar entre ambas acciones.

Los capítulos posteriores sobre transacciones y máquinas de estado replicadas retoman este problema.

## 10. «Como máximo una vez» y «al menos una vez» describen efectos solo bajo ciertos supuestos

En conversaciones informales sobre sistemas aparecen expresiones como:

- como máximo una vez;
- al menos una vez;
- exactamente una vez.

Solo son útiles cuando definimos **qué se está contando** y **dónde termina la garantía**.

### Efecto como máximo una vez

Una operación afecta el estado de aplicación cero o una vez.

Una implementación simple puede evitar por completo los reintentos. Eso puede conservar como máximo un intento, pero sacrifica vivacidad: una pérdida transitoria puede provocar que una operación válida nunca suceda.

La deduplicación mediante IDs estables puede ofrecer efectos de «como máximo una vez» más fuertes y permitir reintentos, siempre que el estado de deduplicación sea correcto y durable.

### Efecto al menos una vez

El cliente continúa reintentando hasta disponer de evidencia suficiente de que la operación terminó.

Esto favorece el progreso ante fallos transitorios, pero puede duplicar efectos salvo que la operación sea idempotente o se deduplique.

### «Exactamente una vez» necesita un límite

No existe un modo mágico de red que elimine todos los posibles efectos secundarios duplicados entre sistemas externos arbitrarios.

Un servicio puede proporcionar una semántica similar a «exactamente una vez» dentro de un límite transaccional cuidadosamente definido mediante IDs de solicitud durables, cambios de estado atómicos y deduplicación. Pero si la operación también envía correo, cobra mediante un servicio externo y actualiza otra base de datos independiente, la garantía depende también de esos sistemas.

La pregunta correcta es:

> **¿Exactamente una vez respecto a qué transición de estado?**

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosidad</span>
  <strong>Un retry puede hacer a un cliente más confiable y menos correcto</strong>
  <p>Si la primera operación sí produjo efecto pero se perdió su respuesta, reintentar puede duplicar pagos, emails o transiciones de estado.</p>
  <p><strong>Pruébalo:</strong> Rediseña una operación no idempotente con request ID estable y supresión durable de duplicados.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">Más curiosidades del capítulo →</a>
</aside>

## 11. Los identificadores de solicitud sirven tanto a la corrección como a la observabilidad

Cada solicitud significativa del curso debe transportar un identificador lógico estable.

Esto sirve para dos tareas diferentes.

### Corrección

El servidor puede reconocer reintentos de la misma operación lógica.

### Observabilidad

Los logs de distintos procesos pueden correlacionarse:

```text
cliente req=R7 intento=1 enviar
proxy   req=R7 route=node2
node2   req=R7 apply
node2   req=R7 reply
cliente req=R7 timeout
cliente req=R7 intento=2 enviar
node3   req=R7 duplicate lookup
node3   req=R7 return prior-result
```

Sin el ID de solicitud, el segundo intento podría parecer una operación independiente.

Un ID de solicitud no sustituye relojes lógicos, tracing o IDs de transacción. Responde una pregunta más estrecha, pero fundamental: **¿qué eventos pertenecen a una misma operación intencionada?**

## 12. Los errores deben conservar distinciones útiles

Una API distribuida no debe reducir cada problema a:

```text
ERROR
```

El cliente puede necesitar distinguir:

- entrada inválida;
- fallo de autenticación o autorización;
- recurso inexistente;
- conflicto o incompatibilidad de versión;
- servicio sobrecargado o no disponible;
- plazo excedido;
- operación rechazada de manera permanente;
- fallo interno del servidor.

Sin embargo, la clasificación del error no debe afirmar más certeza de la que tiene el servidor.

Un fallo de transporte, como una pérdida de conexión, puede significar que el cliente no recibió ninguna respuesta de aplicación. La ausencia de respuesta no equivale a un rechazo de aplicación.

## 13. Reutilizar conexiones cambia el rendimiento, no la verdad de la aplicación

Crear una conexión nueva para cada llamada puede añadir costes de handshake y recursos. Los canales de larga duración amortizan ese coste y pueden mantener conexiones hacia varios backends.

Por eso las bibliotecas RPC modernas representan un **canal** u objeto de conexión de cliente, en lugar de tratar cada llamada como la creación aislada de un socket.

Pero reutilizar conexiones introduce estado:

- salud de la conexión;
- resultados del resolver;
- selección de backends;
- estado de control de flujo;
- estado de reintentos.

La biblioteca de red puede optimizar estos mecanismos sin cambiar la regla de aplicación: después de un fallo, los efectos remotos pueden seguir siendo inciertos.

## 14. El control de presión comienza en la capa de comunicación

Supón que un cliente puede crear 100 000 solicitudes por segundo, mientras el servidor solo completa 10 000.

Si el sistema acepta trabajo sin límite, las colas crecen:

```text
tasa de llegada > tasa de servicio
          ↓
crece la cola
          ↓
crece la latencia
          ↓
vencen los plazos
          ↓
los reintentos pueden añadir más trabajo
```

Un buen diseño de comunicación incluye concurrencia acotada, control de admisión, control de flujo o mecanismos de control de presión.

El Capítulo 12 estudia estos mecanismos con mayor profundidad. El Capítulo 4 establece la conexión: reintentos y tiempos de espera no son solo cuestiones de corrección; participan directamente en el comportamiento de carga.

## 15. Ejemplo trabajado — una API segura para `SubmitJob`

Supón que necesitamos una operación:

```text
SubmitJob(parámetros de procesamiento de imagen)
```

Una API ingenua solo retorna cuando termina todo el trabajo. Eso crea un RPC largo con estado incierto si la conexión desaparece después de varios minutos.

Un contrato más resistente separa el envío del trabajo de su ejecución:

```text
SubmitJob(request_id, parameters) -> job_id
GetJob(job_id) -> state/result
```

La primera llamada crea metadatos durables del trabajo. Si la respuesta se pierde, el cliente reintenta con el mismo `request_id`.

El servicio puede responder con el mismo `job_id` en lugar de crear un segundo trabajo.

La ejecución puede continuar independientemente de una conexión concreta del cliente.

Este diseño no resuelve todos los problemas, pero reduce el límite de incertidumbre.

### Transición de estado

```text
request_id R9 no visto
    ↓
crea job J42
    ↓
registra R9 -> J42
    ↓
responde J42
```

Una implementación correcta debe definir si la creación de `J42` y el registro del mapeo de deduplicación son atómicos.

Esa pregunta anticipa los Capítulos 10 y 11.

## 16. Ejemplo trabajado — reintentar una lectura

Las lecturas suelen ser más fáciles de reintentar, pero incluso ellas tienen semántica sutil.

Supón:

```text
GetBalance(A)
```

se queda sin respuesta y se reintenta contra otra réplica.

Si las réplicas no son fuertemente consistentes, el segundo intento puede devolver un valor más antiguo que una lectura anterior que sí tuvo éxito.

Así, «seguro para reintentar» puede significar:

- no produce un efecto secundario duplicado;

sin garantizar:

- el mismo valor devuelto;
- lecturas monótonas;
- linealizabilidad.

La semántica de comunicación y la semántica de consistencia interactúan.

El Capítulo 9 desarrolla esa relación.

## 17. Ejemplo trabajado — la respuesta llega después del plazo

Imagina:

```text
0 ms   cliente envía solicitud
40 ms  servidor recibe
80 ms  servidor confirma estado
95 ms  servidor envía respuesta
100 ms vence plazo del cliente
120 ms respuesta llega al cliente
```

El servidor puede registrar correctamente un éxito local.

El cliente puede registrar correctamente que su plazo expiró.

No existe contradicción. Ambos responden preguntas diferentes desde puntos de observación distintos.

El cliente sigue necesitando un mecanismo de aplicación para averiguar si la operación tuvo efecto.

Por eso las APIs de producción suelen exponer IDs de operación, consultas de estado o claves de idempotencia.

## 18. Camino histórico — de la transparencia de RPC a la semántica explícita de fallos

Los primeros trabajos sobre RPC perseguían un objetivo poderoso: permitir una estructura de llamada a procedimiento entre máquinas sin escribir a mano toda la maquinaria de transporte.

Esa abstracción influyó en sistemas de objetos distribuidos, plataformas de middleware, RPC empresarial, servicios web y sistemas modernos como gRPC.

La historia es útil porque muestra un patrón recurrente:

```text
una nueva abstracción oculta mecanismos
          ↓
programar se vuelve más sencillo
          ↓
los fallos revelan un desajuste semántico
          ↓
las APIs vuelven a exponer algunos aspectos distribuidos
```

Por eso los sistemas RPC modernos incluyen plazos, códigos de estado, cancelación, metadatos, streaming, configuración de servicios, resolución de nombres, reintentos y hooks de observabilidad.

No es evidencia de que RPC haya fracasado como idea. Es evidencia de que las abstracciones útiles terminan exponiendo las propiedades distribuidas que las aplicaciones necesitan controlar.

## 19. Errores comunes

### Error 1 — «Un tiempo de espera significa que el servidor no hizo nada»

Incorrecto. Significa que el cliente dejó de esperar sin obtener a tiempo una respuesta satisfactoria.

### Error 2 — reintentar todos los errores

Algunos errores son permanentes. Algunas operaciones no son seguras de duplicar. Los reintentos ilimitados pueden sobrecargar un servicio que ya falla.

### Error 3 — usar un ID de solicitud nuevo en cada reintento

Eso impide al servidor reconocer varios intentos de la misma operación lógica.

### Error 4 — declarar una operación idempotente porque usa `PUT`

El nombre del método de protocolo no demuestra la semántica de la aplicación.

### Error 5 — asumir un `read()` por mensaje

TCP es un flujo de bytes. El enmarcado de la aplicación debe manejar lecturas parciales y agrupamiento.

### Error 6 — confundir cancelación con rollback

Una solicitud cancelada puede haber producido ya efectos durables.

### Error 7 — tratar el código RPC generado como prueba de compatibilidad

La IDL ayuda a definir el contrato, pero la evolución del esquema y el significado de la aplicación siguen requiriendo diseño.

### Error 8 — ocultar todos los errores de comunicación tras una excepción genérica

Una política útil del cliente necesita distinguir solicitudes inválidas, indisponibilidad, plazos, conflictos y fallos de transporte inciertos.

## 20. La conexión con la retirada de Ray

Vuelve al Capítulo 2.

Una llamada Ray como:

```text
worker.process.remote(job)
```

ocultaba muchas decisiones.

En el sistema nativo debemos expresarlas:

```text
¿Quién es el trabajador?
¿Cómo se direcciona?
¿Qué bytes representan la solicitud?
¿Cuál es el ID de solicitud?
¿Cuál es el plazo?
¿Qué errores pueden reintentarse?
¿Puede ejecutarse dos veces?
¿Dónde se almacena el estado de deduplicación?
¿Cómo se correlaciona la respuesta?
¿Qué evidencia demuestra el efecto?
```

Ese es precisamente el propósito pedagógico de retirar Ray.

La implementación nativa no es «más real» solo porque tenga más código. Es pedagógicamente útil porque las decisiones semánticas son ahora visibles y atribuibles a ti.

## Transición al laboratorio

El laboratorio del Capítulo 4 construye un pequeño servicio RPC sin Ray. Defines la interfaz, envías solicitudes concurrentes, impones plazos, introduces pérdida o retraso de respuestas y reparas los efectos duplicados mediante IDs de solicitud estables y deduplicación en el servidor.

El entregable importante no es solo código que funcione. El informe debe incluir una ejecución en la que el cliente inicialmente no pueda saber si el efecto remoto ocurrió, seguida de evidencia que muestre cómo el protocolo rediseñado resuelve esa incertidumbre.

## Resumen del capítulo

La comunicación en un sistema distribuido no consiste solamente en mover bytes.

1. **Un protocolo define la estructura y la semántica de los mensajes entre procesos independientes.**
2. **TCP conserva bytes y orden, no los límites de los mensajes de aplicación.**
3. **La serialización crea un contrato durable de red que debe evolucionar con cuidado.**
4. **RPC es útil precisamente porque oculta maquinaria repetitiva de comunicación.**
5. **Las llamadas remotas no son semánticamente equivalentes a las llamadas locales.**
6. **Un plazo limita la espera, pero no demuestra que el efecto remoto no ocurrió.**
7. **Cancelar no deshace automáticamente efectos ya completados.**
8. **Los reintentos mejoran el progreso, pero pueden duplicar efectos y amplificar la sobrecarga.**
9. **IDs de solicitud estables y mecanismos de idempotencia convierten varios intentos en una única operación lógica.**
10. **Las garantías de entrega solo son significativas cuando se declara con precisión su límite de aplicación.**
11. **La observabilidad debe correlacionar intentos con operaciones lógicas.**
12. **Retirar Ray obliga a hacer explícitas en la arquitectura decisiones que antes permanecían ocultas.**

El siguiente capítulo plantea otra pregunta de comunicación. Incluso con un contrato RPC preciso, no toda interacción debe requerir un receptor conocido y una respuesta síncrona: trabajo en cola, publicación/suscripción, gossip y diseminación mediante overlays cambian el acoplamiento y la semántica de entrega.

<div class="ds-next-action">
  <span>Lectura esencial completada</span>
  <strong>Siguiente paso obligatorio · Práctica guiada</strong>
  <a href="../guided-practice/">Comenzar práctica guiada →</a>
</div>
