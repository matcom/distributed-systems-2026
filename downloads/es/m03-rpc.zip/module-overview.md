<p class="ds-book-part">Parte II — Comunicación y coordinación</p>
<p class="ds-module-kicker">Capítulo 4</p>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 4 de 12</span>
    <span>33% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 33%"></span></div>
</div>
<p class="ds-guiding-question">Cuando una operación remota no responde, ¿qué sabes exactamente que ocurrió?</p>

Haz explícita la comunicación. Serializa una solicitud, cruza un límite de proceso/red, impón un deadline, pierde una respuesta y decide si reintentar es seguro. Trata una respuesta ausente como incertidumbre, no como prueba de que el servidor no hizo nada.

## Ideas clave

- mensajes y solicitud/respuesta;
- serialización y framing;
- HTTP/gRPC y Protocol Buffers;
- deadlines y timeouts;
- identidad estable de solicitud;
- reintentos y backoff;
- idempotencia;
- efectos at-most-once y at-least-once;
- supresión de duplicados.

## Transición al laboratorio

Construye un servicio pequeño, simula una respuesta que no llega al cliente, observa un efecto repetido y repara después el protocolo usando identidad explícita de solicitud.

## Empieza aquí

> **Antes de leer:** El servidor confirma una operación y su respuesta se pierde. ¿Debe el cliente reintentar? Escribe tu respuesta antes de elegir un mecanismo de idempotencia.

**Trae contigo:** Los límites entre procesos del Capítulo 3 y el comportamiento básico de transporte/sockets visto en Redes de Computadoras.

**Este capítulo te prepara para:** Un protocolo de solicitudes explícito cuyos tiempos de espera, reintentos y semántica de duplicados puedas defender.

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>30 min–45 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>45 min–1 h</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>2 h–2 h 30 min · 6 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Leer lección →</a>
  <a class="ds-secondary-action" href="lab/">Abrir laboratorio</a>
</div>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../downloads/es/m03-rpc.zip" download>Descargar capítulo + laboratorio para estudio sin conexión (.zip)</a></p>

## Qué aprenderás

- Diseña un protocolo de solicitud/respuesta versionado.
- Implementa un servicio RPC sin Ray.
- Explica por qué un timeout no equivale a un fallo remoto.
- Usa identificadores de solicitud para razonar sobre ejecuciones duplicadas.
- Selecciona estrategias de reintento e idempotencia apropiadas para cada operación.

## Aprende trabajando la pregunta

1. Escribe tu respuesta a **Empieza aquí** antes de abrir la lección completa.
2. Lee hasta la siguiente predicción o traza; detente y resuélvela antes de revelar la explicación.
3. Trata la práctica guiada como un **banco de práctica**, no como una hoja para completar deprisa. Trabaja las trazas centrales hasta alcanzar el objetivo de práctica y vuelve después a los casos restantes.
4. Usa la comprobación para detectar vacíos y entra al laboratorio con una predicción falsable y con la evidencia que podría contradecirla.
5. Termina explicando qué estableció el experimento, qué no estableció y cómo cambia tu explicación del servicio acumulativo.

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../m05-processes-concurrency/">← Procesos, virtualización y ejecución distribuida</a>
<a class="ds-sequence-link next" href="../m12-dht-gossip/">Comunicación II — Mensajería, diseminación y overlays →</a>
</nav>
