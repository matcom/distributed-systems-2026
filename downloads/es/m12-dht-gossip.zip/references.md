> **Vista de referencia.** Esta página ofrece contexto opcional; vuelve a la [Lección](../lesson/) para la ruta obligatoria.

## Esencial

- **●● Chord: A Scalable Peer-to-peer Lookup Service for Internet Applications** — Stoica et al.. [paper](https://pdos.csail.mit.edu/papers/chord:sigcomm01/chord_sigcomm.pdf)

## Recomendado

- **●●● Dynamo: Amazon's Highly Available Key-value Store** — DeCandia et al.. [paper](https://www.allthingsdistributed.com/files/amazon-dynamo-sosp2007.pdf)

## Avanzado

- **●●● Kademlia: A Peer-to-peer Information System Based on the XOR Metric** — Maymounkov and Mazières. [paper](https://pdos.csail.mit.edu/~petar/papers/maymounkov-kademlia-lncs.pdf)

## Herramientas y práctica

- **● The Go Documentation** — The Go Project. [tool documentation](https://go.dev/doc/)

## Explora

- **●●● SWIM: Scalable Weakly-consistent Infection-style Process Group Membership Protocol** — Das, Gupta, Motivala. [paper](https://www.cs.cornell.edu/projects/Quicksilver/public_pdfs/SWIM.pdf)
