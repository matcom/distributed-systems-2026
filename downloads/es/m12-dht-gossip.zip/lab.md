<div class="ds-lesson-banner">
  <div><span>Laboratorio obligatorio</span><strong>Capítulo 5</strong></div>
  <div><span>Modelo de evidencia</span><strong>predecir → ejecutar → observar → explicar</strong></div>
  <div><span>Verificación</span><strong>9 pruebas públicas transparentes + evidencia</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 5 de 12</span>
    <span>42% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 42%"></span></div>
</div>
<p class="ds-back-link"><a href="../quick-check/">← Volver a la comprobación</a></p>

> **Antes de comenzar:** Completa los pasos de práctica guiada y comprobación de conocimientos. Ya deberías poder formular una predicción y nombrar la evidencia que la apoyaría o contradeciría. Si no, [vuelve a la comprobación](../quick-check/) y revisa la lección donde haga falta.

## Objetivo

Compara descubrimiento centralizado con conocimiento parcial descentralizado y después implementa y evalúa **uno** de dos tracks:

- **Track A — lookup/placement con DHT estructurada**, o
- **Track B — gossip de membership/diseminación**.

Este laboratorio no usa Ray.

## Pregunta principal

> ¿Qué información puede conocer localmente cada nodo, cómo se vuelve obsoleta y qué trabajo de mantenimiento se necesita para que el sistema siga entregando información, localizando peers/datos o haciendo converger membership bajo churn?

## Parte 0 obligatoria — compara semántica de comunicación

Antes de elegir un track descentralizado, traza la misma actualización lógica en dos modelos de comunicación.

### Request/response directo

Usa un camino local pequeño:

```text
productor → receptor → respuesta
```

Registra qué conoce el productor tras una respuesta exitosa y qué se vuelve ambiguo tras un timeout.

### Entrega asíncrona

Modela o implementa una cola/mailbox local mínima:

```text
productor → mensaje durable/pendiente → consumidor → acknowledgement
```

No necesitas RabbitMQ, Kafka ni un broker alojado. Un proceso local pequeño o la abstracción starter incluida es suficiente.

Crea esta ejecución:

1. el productor envía el mensaje 81;
2. el consumidor lo recibe y aplica;
3. el consumidor se detiene antes del acknowledgement;
4. el mensaje 81 vuelve a entregarse.

Antes de ejecutar, predice si el efecto de aplicación ocurrirá una o dos veces.

Registra:

- message ID;
- intentos de entrega;
- estado de acknowledgement;
- transiciones del estado de aplicación.

Haz después segura la entrega repetida mediante una operación idempotente o supresión explícita de duplicados.

Termina la Parte 0 comparando:

| Pregunta | Request/response | Entrega asíncrona |
|---|---|---|
| el emisor espera por | | |
| destino conocido al enviar | | |
| trabajo pendiente almacenado por | | |
| ambigüedad ante timeout | | |
| riesgo de duplicado/redelivery | | |
| fan-out natural | | |

El resto del laboratorio pregunta cómo funciona la comunicación cuando el conocimiento de membership o del destino también está distribuido.

## Baseline común — modelo de registro

Antes de cualquier track, modela el mismo problema de descubrimiento usando un registro estilo Capítulo 8.

Por ejemplo:

```text
REGISTER(node, endpoint, metadata)
LOOKUP(key/capability/node)
HEARTBEAT/lease
```

No necesitas reconstruir todo el laboratorio del Capítulo 8. Úsalo como arquitectura de comparación.

Registra:

- quién conserva membership completo;
- camino de mensajes del lookup;
- dependencia ante fallo;
- política de entradas obsoletas;
- comunicación por cada cambio de membership.

Después explica qué elimina tu track descentralizado y qué mantenimiento nuevo introduce.

---

# Track A — DHT estructurada

## A1. Espacio de identificadores

Elige un espacio de identificadores pequeño y determinista para pruebas locales.

Ejemplo:

```text
0..255
```

Asigna IDs lógicos estables a los nodos y mapea claves al mismo espacio.

Mantén campos separados para:

```text
node_id
network endpoint
incarnation
```

## A2. Regla de ownership

Define exactamente qué nodo posee una clave `k`.

Una regla estilo Chord suficiente es:

> el primer sucesor vivo en sentido horario desde `k`.

Escribe pruebas para límites, incluidas claves iguales a IDs de nodos y wrap-around cerca de cero.

## A3. Baseline de lookup estático

Comienza con al menos 8 nodos.

Implementa primero lookup correcto con conocimiento mínimo de sucesores si resulta útil.

Mide:

```text
tasa de éxito del lookup
media/mediana de hops de overlay
p95 de hops de overlay
```

sobre un conjunto fijo de lookups.

## A4. Atajos de routing

Añade fingers/atajos estilo Chord u otra tabla de routing estructurada y documentada.

Repite los mismos lookups.

Compara número de hops, no solo latencia de reloj.

Explica por qué menos hops de overlay pueden seguir correspondiendo a caminos físicos arbitrarios en un despliegue real.

## A5. Join de un nodo

Añade un nodo entre dos identificadores existentes.

Demuestra:

- actualización de predecessor/successor;
- cambio del rango de ownership;
- movimiento de claves/metadatos si lo implementaste;
- rutas temporalmente obsoletas;
- estabilización/convergencia.

Registra cuántos mensajes de mantenimiento fueron necesarios.

## A6. Leave ordenado

Retira un nodo notificando y transfiriendo estado.

Verifica que las claves afectadas siguen siendo localizables según la política declarada.

## A7. Salida por crash

Mata un nodo sin handoff ordenado.

Usa timeout/sospecha y redundancia de sucesores/routing cuando corresponda.

Evidencia obligatoria:

```text
ocurre el fallo
primer peer sospecha
comienza reparación de routing/ownership
los lookups se recuperan
```

No afirmes detección perfecta de crashes.

## A8. Experimento con ruta obsoleta

Congela la tabla de routing de un nodo mientras cambia la topología en otros lugares.

Ejecuta lookups a través de él.

Clasifica los resultados:

- éxito mediante forwarding obsoleto pero aún correcto;
- redirección/reparación;
- fallo temporal;
- propietario incorrecto.

La última categoría es un defecto de corrección salvo que la semántica transitoria del protocolo la permita explícitamente y la repare sin violar garantías de estado almacenado.

## A9. Experimento de churn

Ejecuta una secuencia determinista de joins, leaves y crashes mientras sigues emitiendo lookups.

Mide:

```text
tasa de éxito durante churn
distribución del número de hops
mensajes de mantenimiento
tiempo de recuperación/estabilización
```

Usa seed fija si aleatorizas eventos de membership.

## A10. Extensión opcional de replicación

Replica cada registro de clave/valor/localización en uno o más propietarios adicionales.

Si lo haces, declara el modelo de consistencia. No escribas «replicado, por tanto consistente».

---

# Track B — Gossip membership

## B1. Membership inicial

Inicia al menos 10 procesos peer locales o nodos simulados desde una lista pequeña de seeds de bootstrap.

Cada nodo mantiene una vista local, por ejemplo:

```text
node_id
incarnation
status
endpoint
last evidence
```

## B2. Diseminación gossip

Implementa configuración de:

```text
round interval
fanout
random seed
```

Usa push, pull o push-pull y documenta la elección.

Introduce una actualización conocida inicialmente por un solo nodo.

Sigue el número o porcentaje de nodos informados por ronda.

## B3. Baseline de convergencia

Ejecuta el mismo experimento con varias seeds aleatorias.

Reporta al menos:

```text
mediana de rondas hasta 50%
mediana de rondas hasta 90%
p95 de rondas hasta 90% o equivalente
mensajes totales
```

No evalúes diseminación probabilística con una única ejecución.

## B4. Pérdida de mensajes

Inyecta pérdida configurable en los intercambios gossip.

Repite el experimento de convergencia.

Explica cómo la diseminación repetida proporciona caminos alternativos y qué coste extra de mensajes paga esa resiliencia.

## B5. Fallo de miembro

Detén un miembro.

Implementa un camino de detector de fallos apropiado al laboratorio reducido, por ejemplo:

```text
ALIVE → SUSPECT → DEAD
```

Un timeout directo debe crear sospecha, no una verdad incuestionable.

## B6. Evidencia indirecta

Cuando sea práctico, pide a uno o más peers que prueben al target sospechoso antes de escalar.

Compara sospechas falsas con probing solo directo.

## B7. Refutación por incarnation

Crea:

```text
node A incarnation 7 = SUSPECT
```

y deja que A se reafirme o reinicie como:

```text
node A incarnation 8 = ALIVE
```

Verifica que rumores obsoletos de incarnation 7 no pueden sobrescribir incarnation 8.

## B8. Partición y reparación

Divide membership en dos grupos alcanzables.

Permite que las vistas locales evolucionen.

Repara la partición y observa la convergencia.

El informe debe mostrar que nodos distintos pueden mantener legítimamente vistas diferentes durante la partición.

## B9. Experimento de churn

Une, reinicia y detén nodos repetidamente mientras gossip continúa.

Mide:

```text
lag de convergencia de membership
mensajes por nodo/unidad de tiempo
sospechas falsas
tiempo de recuperación/refutación
```

## B10. Extensión opcional de payload

Propaga por gossip un dato adicional pequeño, como:

- estimación de carga;
- capacidad;
- versión de software;
- presencia de cache.

Declara si esos metadatos son autoritativos o aproximados.

---

# Paso común C1 — Compara registro, DHT y gossip

Toda entrega debe completar esta tabla con evidencia y razonamiento arquitectónico:

| Propiedad | Registro | DHT | Gossip |
|---|---|---|---|
| lookup exacto por clave | | | |
| consulta rica de metadatos | | | |
| membership completo en un nodo | | | |
| dependencia central en runtime | | | |
| mantenimiento ante churn | | | |
| comportamiento de estado obsoleto | | | |
| modelo de detección de fallos | | | |
| estado por nodo | | | |

Discute tu track implementado con más detalle que los dos diseños usados solo para comparación.

---

# Paso común C2 — Modelo de confianza

Declara si supones nodos:

```text
correctos salvo crash/omisión
```

o si incluyes comportamiento malicioso.

El laboratorio obligatorio supone peers no bizantinos.

Explica un ataque posible si un peer pudiera mentir sobre:

- identidad;
- ownership/routing;
- estado de membership.

El Capítulo 12 estudia ese modelo de fallos más fuerte.

---

# Paso común C3 — Auditoría con IA

Si contribuyó un asistente de IA, pídele identificar una debilidad bajo cambios de membership.

Para Track DHT, inspecciona:

- routing solo estático;
- reutilización de endpoints obsoletos;
- ownership incorrecto en wrap-around;
- join que no mueve datos/metadatos;
- crash tratado como leave ordenado.

Para Track gossip, inspecciona:

- un timeout marca directamente DEAD;
- rumores obsoletos sobrescriben incarnations nuevas;
- fanout de mensajes sin límites;
- una ejecución se trata como prueba de convergencia;
- se supone que todas las vistas locales son idénticas en todo instante.

Verifica experimentalmente un hallazgo.

---

# Objetivo de pruebas transparentes

Las pruebas públicas previstas están documentadas en:

```text
tests/official/README.md
```

Las pruebas ejecutables viven en `tests/official/`, con un adapter seleccionable DHT/gossip en `starter/src/`. Seleccionas explícitamente un track; se prueban invariantes deterministas de ownership/merge mientras churn multiproceso, pérdida y convergencia siguen siendo basados en evidencia.

No se planifican casos ocultos.

Añade casos deterministas en `tests/student/` y scripts estadísticos separados si los necesitas.

---

# Entrega

Entrega:

- código fuente;
- declaración del track;
- configuración de topología/bootstrap;
- comandos reproducibles;
- `REPORT.md`;
- trazas machine-readable de lookup/gossip;
- datos de medición;
- descripción/casos de pruebas públicas y del estudiante;
- declaración de uso de IA.

# Criterio de éxito

Una entrega sólida puede decir:

> «Este overlay estructurado encuentra el propietario correcto usando estado parcial y acotado de routing, repara membership/ownership bajo los eventos de churn probados y presenta este coste medido de lookup/mantenimiento».

o:

> «Este protocolo de gossip membership converge probabilísticamente bajo el modelo de pérdida/churn probado, distingue sospecha de verdad, rechaza incarnations obsoletas y presenta este coste medido de convergencia/mensajes».

En ambos casos debes explicar por qué un registro más simple sería o no preferible para el mismo problema.

## Termina el capítulo

Reproduce el resultado importante desde un inicio limpio. Después vuelve a tu predicción inicial: explica qué cambió, qué evidencia provocó el cambio y qué incertidumbre queda. Un comando exitoso o una captura no bastan cuando la afirmación trata de retries, orden, durabilidad, consistencia, recovery, seguridad o rendimiento.

<div class="ds-next-action">
  <span>Capítulo completo</span>
  <strong>Continuar el curso</strong>
  <a href="../../m06-time-causality/">Coordinación I — Tiempo, eventos y causalidad →</a>
</div>

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../../m03-rpc/">← Comunicación I — Mensajes, RPC y fallos remotos</a>
<a class="ds-sequence-link next" href="../../m06-time-causality/">Coordinación I — Tiempo, eventos y causalidad →</a>
</nav>
