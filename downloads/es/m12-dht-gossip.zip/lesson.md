<p class="ds-book-part">Parte II — Comunicación y coordinación</p>
<div class="ds-lesson-banner">
  <div><span>Paso del curso</span><strong>Capítulo 5</strong></div>
  <div><span>Lectura esencial</span><strong>30 min–40 min</strong></div>
  <div><span>Ruta obligatoria</span><strong>Leer → Objetivo de práctica → Comprobar → Laboratorio</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 5 de 12</span>
    <span>42% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 42%"></span></div>
</div>

> **Pregunta guía:** ¿Cómo debe moverse la información cuando una única ruta directa de solicitud/respuesta no basta?

## Antes de leer

> Un productor crea un evento mientras todos los consumidores están desconectados. ¿Qué modelos de comunicación pueden entregarlo después y qué estado debe existir para hacerlo posible?

Escribe primero una respuesta breve. No necesitas acertar todavía: necesitas una predicción que puedas revisar a medida que el capítulo te dé mejores modelos y evidencia.

**Usa lo que ya sabes:** La semántica de solicitud/respuesta del Capítulo 4 y la diferencia entre rutas lógicas y físicas de comunicación.

## Mapa de carga de trabajo

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>30 min–40 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>45 min–1 h</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>2 h–2 h 30 min · 9 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../../downloads/es/m12-dht-gossip.zip" download>Descargar lección + práctica + laboratorio para estudio sin conexión (.zip)</a></p>

## Por qué importa este capítulo

RPC proporciona una conversación clara de request/response con un destino conocido. Muchos sistemas necesitan formas diferentes de comunicación:

- poner trabajo en cola para un consumidor que quizá se ejecute más tarde;
- publicar un evento para varios componentes interesados;
- diseminar membership o estado dentro de un grupo cambiante;
- alcanzar muchos participantes sin que un emisor mantenga un canal directo con todos;
- enrutar a través de un overlay lógico cuando no existe un directorio permanente.

Antes de elegir un mecanismo, pregunta:

1. ¿conoces ahora el destino?
2. ¿debe el emisor esperar al receptor?
3. ¿la entrega se dirige a un participante o a un grupo?
4. ¿necesitas conocimiento exacto y actual o basta una diseminación eventual/probabilística?

Una comparación útil es:

```text
RPC directo            → peer conocido, request/response síncrono
cola / stream eventos  → desacopla tiempos de productor y consumidor
publish / subscribe    → un evento, receptores interesados
intuición multicast    → un envío lógico hacia un grupo
gossip                 → intercambios repetidos entre peers, difusión probabilística
overlay estructurado   → enruta hacia una clave/participante mediante vecinos lógicos
```

Este capítulo se concentra en las dos últimas opciones porque son fáciles de reproducir localmente sin depender de un broker alojado. La semántica de colas y publish/subscribe sigue formando parte del modelo de comunicación: entrega, duplicación, orden, acknowledgement e identidad del consumidor deben permanecer explícitos.

---

## 1. Descentralización no es una única propiedad

Un sistema puede estar descentralizado en una dimensión y centralizado en otra.

Pregunta por separado:

- ¿quién asigna identidades?
- ¿quién conoce membership?
- ¿quién decide placement?
- ¿quién enruta solicitudes?
- ¿quién almacena datos?
- ¿quién resuelve conflictos?
- ¿quién controla la admisión?

Por ejemplo, una red de almacenamiento peer-to-peer puede descentralizar el placement de datos y seguir dependiendo de un conjunto pequeño de nodos de bootstrap.

Del mismo modo, un servicio de membership basado en gossip puede distribuir conocimiento sobre liveness y depender a la vez de una autoridad central de autenticación.

Evita etiquetas binarias como:

```text
centralizado / descentralizado
```

sin identificar qué mecanismo estás describiendo.

---

<aside class="ds-book-note ds-history">
  <span class="ds-book-note-label">Historia</span>
  <strong>Los sistemas peer-to-peer preguntaron qué ocurre cuando los participantes aportan la infraestructura en vez de limitarse a consumirla</strong>
  <p>Overlays estructurados como Chord y Kademlia, junto a sistemas de intercambio distribuido, exploraron lookup escalable, churn, membresía descentralizada y uso directo del almacenamiento y ancho de banda de los participantes.</p>
  <a class="ds-book-note-source" href="../../../history/peer-to-peer-dhts/">Lee la historia del diseño →</a>
</aside>

## 2. Las redes overlay crean una topología lógica

La conectividad física/IP proporciona una topología:

```text
routers, subredes, caminos
```

Una aplicación descentralizada puede construir encima otra topología lógica:

```text
peer A conoce a peer F y peer K
peer F conoce a peer B y peer M
...
```

Eso es una **red overlay**.

Una arista del overlay significa:

> este nodo de aplicación sabe cómo contactar a aquel peer

y no:

> estos hosts son físicamente adyacentes.

Un hop de overlay puede atravesar muchos routers IP.

La diferencia importa al razonar sobre latencia: menos hops de overlay no implica automáticamente caminos físicos más cortos.

---

## 3. Una DHT convierte un diccionario distribuido en un problema de routing

Una distributed hash table ofrece conceptualmente:

```text
PUT(key, value/location)
GET(key)
```

pero ningún nodo almacena el mapa completo.

En su lugar:

1. las claves se mapean a un espacio de identificadores;
2. los nodos ocupan posiciones o IDs en ese espacio;
3. la responsabilidad por rangos de claves se distribuye;
4. cada nodo conserva una tabla de routing acotada;
5. las consultas se reenvían hacia el nodo responsable.

El desafío central es:

> localizar de forma eficiente al propietario de un identificador arbitrario cuando cada nodo solo conoce una fracción del membership.

---

## 4. El hashing consistente proporciona la intuición de placement

El Capítulo 11 introdujo hashing consistente para reducir el remapeo cuando cambian los nodos.

Imagina un anillo de identificadores:

```text
0 -------------------------------- 2^m-1
```

Nodos y claves reciben identificadores dentro de ese espacio circular.

Una regla sencilla podría ser:

> la clave `k` pertenece al primer nodo en sentido horario cuyo identificador sea al menos `k`.

Ejemplo:

```text
nodos: 10, 40, 70
```

Los rangos se mapean aproximadamente así:

```text
(70,10] → nodo 10
(10,40] → nodo 40
(40,70] → nodo 70
```

El anillo es una abstracción. No implica una red física circular.

---

## 5. Un anillo con solo punteros al sucesor enruta correctamente pero despacio

Supón que cada nodo conoce únicamente su sucesor inmediato.

Para encontrar la clave 65 desde el nodo 10:

```text
10 → 40 → 70
```

En un anillo grande, el lookup puede necesitar atravesar muchos nodos.

La tabla de routing necesita por tanto **atajos de larga distancia**.

La idea de finger tables de Chord es una solución elegante.

---

## 6. Chord construye atajos de routing espaciados exponencialmente

En un espacio de identificadores de `m` bits, un nodo estilo Chord `n` mantiene entradas asociadas aproximadamente a:

```text
n + 2^0
n + 2^1
n + 2^2
...
```

mapeadas a los sucesores responsables.

La construcción exacta de la tabla importa menos que la idea geométrica:

> conocer peers a distancias crecientes dentro del espacio de identificadores.

Así, un lookup puede avanzar mucho al principio y hacer pasos cada vez más finos cerca del objetivo.

Bajo los supuestos idealizados de Chord, la longitud del lookup es logarítmica respecto al número de nodos participantes.

Interprétalo como una propiedad arquitectónica de escalabilidad, no como una garantía de baja latencia de Internet.

---

## 7. Ejemplo trabajado — lookup estilo Chord

Supón estos IDs:

```text
4, 12, 20, 35, 52, 60
```

y queremos encontrar al propietario de la clave 50.

El nodo 4 puede conocer atajos como 12, 20 y 35.

Reenvía hacia el predecesor conocido más cercano de 50:

```text
4 → 35 → 52
```

El nodo 52 es el primer sucesor de 50 y, con la regla elegida, es el propietario.

Otra tabla de routing válida puede tomar otro camino y conservar el mismo propietario.

Las preguntas comprobables son:

- ¿terminó el lookup?
- ¿encontró al propietario correcto?
- ¿cuántos hops de overlay ocurrieron?
- ¿cómo cambia el número de hops al crecer la red?

---

## 8. Los IDs de nodo de una DHT y las direcciones físicas son identidades distintas

Un nodo DHT puede tener:

```text
logical node ID = 0x9f31...
network address = 192.0.2.18:7400
incarnation = 12
```

La posición lógica no debe confundirse con la IP/puerto actual.

Esto reutiliza la separación del Capítulo 8:

```text
identidad lógica ≠ dirección física
```

y la idea de incarnation del Capítulo 10:

```text
un mismo participante lógico puede reiniciarse como una instancia de proceso nueva
```

Por eso una entrada de routing suele necesitar metadatos suficientes para rechazar endpoints obsoletos.

---

## 9. Un join cambia los límites de responsabilidad

Supón que el nodo 30 entra entre los nodos 20 y 40.

Antes:

```text
(20,40] → nodo 40
```

Después:

```text
(20,30] → nodo 30
(30,40] → nodo 40
```

Parte de las claves o el estado debe moverse o pasar a estar replicado también en el nuevo nodo.

El protocolo de join debe actualizar gradualmente la información de vecinos y routing sin hacer que los lookups se vuelvan catastróficamente incorrectos.

Los overlays estructurados necesitan por ello **estabilización y mantenimiento**, no solo una fórmula estática de routing.

---

## 10. Una salida ordenada y un crash son problemas diferentes

Un nodo que se retira de forma ordenada puede avisar:

```text
me retiro; transfiere estas claves; sustituye estos punteros
```

Un nodo que sufre un crash no dice nada.

Los peers necesitan entonces detección de fallos y redundancia.

Aquí vuelve el Capítulo 10:

- un timeout es sospecha, no prueba;
- una sospecha falsa puede eliminar un peer lento pero correcto;
- pueden persistir entradas de routing obsoletas;
- varios sucesores o réplicas pueden aumentar la resiliencia.

---

## 11. Churn es cambio continuo de membership

Una red peer-to-peer puede experimentar con frecuencia:

```text
join
leave
crash
restart
address change
```

En conjunto, esto es **churn**.

Una DHT gasta comunicación no solo en lookups útiles, sino también en mantener estado de routing y placement.

Por tanto, el coste incluye:

```text
coste de lookup
+
coste de mantenimiento
+
coste de rebalanceo/replicación
```

Un benchmark con anillo estático mide solo una parte del sistema.

---

## 12. Normalmente se necesita replicación porque un único propietario es frágil

Si una clave tiene exactamente un propietario y ese propietario desaparece, el mapping o dato deja de estar disponible.

Los sistemas basados en DHT suelen replicar valores o metadatos en varios peers cercanos o seleccionados.

Una política posible:

```text
propietario primario + siguientes r sucesores
```

u otra regla de placement.

Esto reconecta con el Capítulo 9:

- ¿cuántas copias?
- ¿replicación síncrona o asíncrona?
- ¿qué consistencia?
- ¿cómo se reconcilian versiones en conflicto?

Una DHT responde **dónde** debe encontrarse un dato. No resuelve automáticamente todo el problema de consistencia.

---

## 13. Kademlia usa distancia XOR en vez de una relación sucesor-en-anillo

Kademlia mapea IDs de nodos y claves al mismo espacio, pero define distancia con XOR bit a bit:

```text
d(a,b) = a XOR b
```

Esto crea una estructura útil de prefijos y buckets.

Un nodo mantiene contactos agrupados por rangos de distancia y realiza búsquedas iterativas o paralelas hacia IDs cada vez más cercanos al objetivo.

Los detalles difieren de Chord, pero el objetivo de alto nivel es similar:

> enrutar hacia un identificador usando solo conocimiento parcial del membership.

Kademlia ha influido especialmente en sistemas reales de descubrimiento y contenido peer-to-peer.

El curso no exige implementar Chord y Kademlia.

Debes entender el contraste entre:

```text
anillo/rangos de propiedad estilo Chord
```

y:

```text
métrica XOR/buckets estilo Kademlia
```

---

## 14. El routing de una DHT no es routing IP ordinario

El routing IP decide cómo se mueven paquetes hacia una dirección de red.

El routing DHT decide qué peer de aplicación es responsable de una clave lógica y qué peer conocido debe recibir la siguiente consulta de aplicación.

Un lookup DHT como:

```text
peer 10 → peer 35 → peer 52
```

puede corresponder físicamente a:

```text
host A → muchos routers de Internet → host B
host B → muchos routers de Internet → host C
```

Aquí el curso conecta de forma deliberada Redes de Computadoras con Sistemas Distribuidos.

---

## 15. Corrección y eficiencia del routing son propiedades diferentes

Un algoritmo de lookup puede encontrar siempre al propietario correcto y requerir O(N) hops.

Otro puede usar normalmente O(log N) hops y fallar temporalmente cuando el estado de routing está obsoleto.

Por eso evalúa por separado:

```text
tasa de propietario correcto
tasa de éxito del lookup
número de hops
latencia
tráfico de mantenimiento
```

No reduzcas la evaluación a un único promedio de tiempo de lookup.

---

## 16. Gossip resuelve diseminación, no lookup exacto

Cambia ahora el problema.

Supón que cada nodo quiere información aproximada o actual sobre membership:

```text
¿quién está vivo?
¿qué versión/configuración conocen los peers?
¿qué nodos se unieron recientemente?
```

Una estructura de lookup DHT puede ser innecesaria.

Un protocolo gossip usa intercambios repetidos peer-to-peer.

Modelo push sencillo:

```text
cada intervalo:
    elegir peer aleatorio
    enviar información nueva
```

A lo largo de varias rondas, la información se propaga por la población de forma parecida a una epidemia.

---

## 17. Gossip push, pull y push-pull

### Push

Un nodo envía a otro peer la información que conoce.

### Pull

Un nodo pide a un peer información que le falta.

### Push-pull

Ambos intercambian resúmenes o actualizaciones.

Las variantes intercambian ancho de banda, velocidad de convergencia y tráfico duplicado.

La propiedad central es la diseminación probabilística, no un único camino de routing exacto.

---

## 18. La convergencia de gossip es probabilística y medible

Supón que un nodo aprende el evento `E` en la ronda 0.

Sigue:

```text
ronda 0: 1 nodo informado
ronda 1: 2
ronda 2: 4
...
```

Las colisiones y contactos repetidos impiden que el número simplemente se duplique para siempre.

Mide:

- rondas hasta informar al 50%;
- rondas hasta el 90%;
- rondas hasta todos los nodos alcanzables;
- mensajes enviados;
- efecto del fanout;
- efecto de la pérdida.

Es un laboratorio especialmente útil porque el resultado es estadístico/probabilístico y no una única traza determinista.

---

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosidad</span>
  <strong>Gossip escala en parte porque nadie necesita una vista idéntica en el mismo instante</strong>
  <p>La diseminación epidémica acepta desacuerdo temporal y propaga información mediante intercambios repetidos.</p>
  <p><strong>Pruébalo:</strong> Simula una actualización propagándose entre ocho nodos cuando cada nodo informado contacta un peer por ronda.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">Más curiosidades del capítulo →</a>
</aside>

## 19. Gossip tolera de forma natural cierta pérdida de mensajes

Si la actualización E se envía una sola vez por un camino único, una pérdida puede eliminarla para siempre.

Gossip crea repetidamente caminos alternativos de diseminación.

Perder un mensaje retrasa la convergencia, pero no necesariamente la destruye.

Esta resiliencia tiene redundancia como coste:

```text
muchos intercambios duplicados o solapados
```

El sistema intercambia ancho de banda por robustez y propagación descentralizada.

---

## 20. Gossip también puede propagar información obsoleta o incorrecta

La diseminación descentralizada no convierte la información en verdadera.

Si un peer anuncia:

```text
nodo X está DEAD
```

los demás necesitan una regla para decidir si aceptan esa afirmación y cómo.

Los protocolos de membership suelen adjuntar:

- números de incarnation;
- transiciones de estado;
- timestamps o contadores lógicos;
- fases de sospecha;
- probes indirectos.

Esto reconecta con los detectores de fallos del Capítulo 10.

---

## 21. SWIM combina detección de fallos con diseminación de membership estilo gossip

SWIM es un diseño clásico de membership escalable.

Su separación arquitectónica resulta útil pedagógicamente:

```text
detección de fallos
+
diseminación de membership
```

Un nodo sondea a otro miembro. Si falla la comunicación directa, puede pedir a otros peers que realicen probes indirectos antes de elevar la sospecha.

Los cambios de membership se diseminan después mediante tráfico del protocolo y mecanismos estilo gossip.

El objetivo es membership escalable con overhead acotado por nodo en vez de que cada nodo haga ping constantemente a todos los demás.

No necesitas reproducir SWIM completo, pero es una comparación excelente para la opción de gossip membership del laboratorio.

---

## 22. El estado SUSPECT mejora el compromiso entre rapidez y falsos positivos

En lugar de pasar directamente:

```text
ALIVE → DEAD
```

tras un timeout, un protocolo de membership puede usar:

```text
ALIVE → SUSPECT → DEAD
```

Durante SUSPECT, evidencia contraria o una incarnation mayor puede refutar la sospecha.

Esto no crea detección perfecta de fallos.

Da al protocolo tiempo y oportunidad para corregir incertidumbre antes de eliminar al miembro.

---

## 23. Los números de incarnation distinguen rumores antiguos del estado actual del proceso

Supón que gossip contiene:

```text
node A incarnation 7 = SUSPECT
```

pero A se reinició o reafirmó como:

```text
node A incarnation 8 = ALIVE
```

Los peers necesitan una regla de orden para impedir que la sospecha antigua sobrescriba la incarnation más reciente.

Es el mismo problema de procesos obsoletos introducido en los Capítulos 8 y 10, ahora a escala descentralizada.

---

## 24. Registro central, DHT y gossip responden bien a preguntas distintas

### Registro central o replicado

Adecuado cuando:

- membership autoritativo es importante;
- el control operacional central es aceptable;
- las consultas necesitan metadatos o filtros ricos;
- la escala del clúster es moderada.

### DHT

Adecuada cuando:

- placement y lookup por clave son centrales;
- no quieres exigir una tabla de membership completa en todos los nodos;
- deseas routing descentralizado;
- churn debe manejarse estructuralmente.

### Gossip membership

Adecuado cuando:

- basta una diseminación aproximada o eventualmente convergente de membership/estado;
- cada cambio no necesita atravesar una única autoridad;
- la información escalable sobre miembros y fallos es importante.

Un sistema puede combinarlos.

Por ejemplo:

```text
gossip descubre nodos vivos
+
DHT enruta claves
+
replicación almacena valores
```

---

## 25. Descentralizado no significa libre de coordinación

Incluso los sistemas descentralizados necesitan reglas para:

- identidad;
- conflictos de membership;
- propiedad de claves;
- reconciliación de réplicas;
- peers maliciosos;
- versiones de software.

Eliminar un servidor central distribuye esas responsabilidades; no las elimina.

Por eso los diseños descentralizados pueden ser operacionalmente más difíciles aunque eviten un cuello de botella central.

---

## 26. Bootstrap es una pregunta práctica inevitable

¿Cómo descubre un peer nuevo a su primer peer?

Respuestas posibles:

- lista de seeds configurada;
- seeds DNS;
- multicast local;
- peers cacheados anteriormente;
- invitación manual;
- servicio de bootstrap bien conocido.

Un servicio de bootstrap puede ser centralizado sin permanecer en el camino crítico después del join.

Distingue:

```text
dependencia de bootstrap
```

de:

```text
dependencia central en cada operación
```

---

## 27. Ejemplo trabajado — join en una DHT

Anillo inicial:

```text
10 → 40 → 70 → 10
```

Entra el nodo 25.

Antes:

```text
(10,40] propiedad de 40
```

Después:

```text
(10,25] propiedad de 25
(25,40] propiedad de 40
```

Las acciones pueden incluir:

1. 25 descubre un peer existente;
2. 25 encuentra a su sucesor 40;
3. se actualizan las relaciones predecessor/successor;
4. el rango de claves relevante se transfiere o queda disponible en 25;
5. las tablas de routing convergen mediante rondas de estabilización.

Durante la transición algunos peers pueden seguir enrutando según la topología antigua.

Un diseño correcto debe definir cómo trata esas rutas obsoletas.

---

## 28. Ejemplo trabajado — gossip membership bajo pérdida

Diez nodos comienzan con una actualización `E` conocida solo por A.

Fanout = 1 por ronda.

Introduce ahora 20% de pérdida de mensajes.

Un árbol de broadcast único podría perder E en una rama esencial.

Gossip aleatorio repetido crea oportunidades nuevas cada ronda.

El experimento no debe esperar una secuencia idéntica en cada ejecución.

Reporta una distribución:

```text
mediana de rondas hasta 90%
p95 de rondas hasta 90%
mensajes totales
```

y ofrece una seed fija para depuración determinista.

---

## 29. Ejemplo trabajado — sospecha falsa y refutación

Nodos A, B y C.

B no puede contactar directamente a A debido a pérdida transitoria.

B marca A como SUSPECT y disemina:

```text
A incarnation 5 SUSPECT
```

A recibe o refuta la sospecha anunciando:

```text
A incarnation 6 ALIVE
```

Los peers comparan la información de incarnation y conservan el estado más reciente.

Este ejemplo conecta:

- incertidumbre por timeout;
- orden lógico de incarnations;
- propagación mediante gossip;
- recuperación ante sospechas falsas.

---

## 30. La seguridad se vuelve más difícil cuando membership está descentralizado

Un registro central puede imponer admisión en una única frontera.

Un overlay peer-to-peer debe considerar:

- IDs de nodo falsificados;
- identidades Sybil;
- respuestas maliciosas de routing;
- rumores envenenados de membership;
- corrupción de contenido;
- ataques eclipse.

El Capítulo 12 estudia con mayor profundidad comportamiento adversario o bizantino.

En el Capítulo 5 basta declarar el supuesto de confianza:

> ¿todos los peers son no maliciosos pero pueden sufrir crashes, o pueden mentir?

El laboratorio base supone fallos por crash u omisión, no adversarios bizantinos.

---

## 31. El énfasis histórico del curso en DHT pasa a ser una opción dentro de un espacio más amplio

El material anterior del curso dedicaba mucha atención a estructuras DHT tipo Chord, Pastry y Kademlia.

Estas ideas siguen siendo valiosas porque enseñan:

- overlays estructurados;
- tablas parciales de routing;
- razonamiento de lookup logarítmico;
- churn;
- propiedad descentralizada.

El curso rediseñado reduce taxonomía de algoritmos y conecta DHT con un espacio mayor de diseño:

```text
registro central
DHT
mapa de propiedad por hashing consistente
gossip membership
directorio replicado
```

El objetivo es elegir arquitectura, no memorizar cada overlay histórico.

---

## 32. Ejemplos de proyectos finales

### P05 — Distribución P2P de archivos por bloques

Una DHT puede localizar metadatos de archivos o chunks sin un tracker central permanente. Gossip puede difundir disponibilidad de peers o información del swarm.

### P06 — Plataforma distribuida de agentes y capacidades

Una DHT podría localizar agentes o capacidades por clave y gossip podría diseminar membership aproximado. Un registro central sigue siendo válido cuando se desea mayor autoridad o filtrado.

### P08 — Mensajería segura descentralizada

Descubrimiento de peers y routing store-and-forward pueden beneficiarse de membership o lookup descentralizado, aunque identidad y autenticación complican el modelo de confianza.

### P16 — Almacenamiento distribuido de objetos

Placement estilo hashing consistente o DHT puede determinar propiedad de objetos y rebalanceo.

### P20 — Caché de contenido en el edge

Gossip puede diseminar estado de caches o miembros, mientras hashing consistente puede asignar responsabilidad de cache.

---

## 33. Implementación asistida por IA — qué debes verificar

Un agente puede generar con facilidad un anillo o loop de gossip que funciona en una demo estática.

Las pruebas importantes tratan el cambio.

Para una DHT, verifica:

- propietario correcto después de join;
- propietario correcto después de leave ordenado;
- lookup con entradas de routing obsoletas;
- fallo de un peer intermedio;
- comportamiento de hops cuando crece N;
- movimiento de datos o metadatos tras cambios de propiedad.

Para gossip, verifica:

- propagación eventual con seed fija;
- convergencia estadística en muchas ejecuciones;
- efecto de pérdidas;
- sospecha falsa y refutación;
- orden de incarnations;
- tasa de mensajes acotada por nodo.

Una implementación generada que solo pasa un happy path estático de cinco nodos no ha demostrado los objetivos del capítulo.

---

## 34. Errores comunes

### Error 1 — confundir hops del overlay con hops físicos

Son capas diferentes.

### Error 2 — asumir que el hashing consistente realiza por sí mismo routing

Placement y routing son mecanismos relacionados pero distintos.

### Error 3 — implementar solo lookup DHT estático

Join, leave, rutas obsoletas y churn son donde aparece el comportamiento distribuido.

### Error 4 — llamar «consistente» a la replicación de una DHT sin definir un modelo

La propiedad de claves de una DHT no resuelve consistencia entre réplicas.

### Error 5 — usar gossip cuando se necesita membership exacto y actual de inmediato

Gossip expone naturalmente conocimiento eventual o probabilístico.

### Error 6 — declarar DEAD a un peer tras un único timeout

Retrasos o pérdida transitoria producen sospechas falsas.

### Error 7 — ignorar incarnation del proceso

Rumores antiguos de fallo pueden matar incorrectamente un peer reiniciado.

### Error 8 — medir una sola ejecución determinista de gossip

La diseminación aleatoria debe evaluarse estadísticamente y también con seeds reproducibles.

### Error 9 — afirmar «descentralizado significa que no existe ningún componente central»

Bootstrap, identidad, administración o raíces de confianza pueden seguir centralizados.

### Error 10 — elegir DHT/gossip porque suenan avanzados

Un registro replicado puede ser más simple y más correcto para un clúster pequeño y controlado.

---

## Conexiones de sistemas

### [NET]

El routing del overlay funciona sobre transporte IP; latencia y caminos físicos siguen afectando los hops de aplicación.

### [DIST]

Las DHT distribuyen lookup y placement; gossip distribuye conocimiento. Ambos deben tolerar estado obsoleto y churn.

### [DB]

Placement de particiones, hashing consistente, replicación y reparación conectan con arquitectura de bases de datos y almacenamiento distribuidos.

### [SEC]

Admisión y routing descentralizados amplían la superficie de ataque e introducen preguntas de identidad y confianza.

### [PERF]

Evalúa por separado hops de lookup, latencia, tráfico de mantenimiento, fanout de gossip, rondas de convergencia y overhead de rebalanceo.

---

## Transición al laboratorio

El laboratorio tiene una comparación común y dos tracks de implementación.

Todo estudiante debe:

1. modelar un registro central como baseline;
2. comparar sus supuestos con alternativas descentralizadas;
3. implementar una DHT estructurada pequeña **o** gossip membership;
4. introducir joins, departures, pérdida y churn;
5. medir coste de lookup o de convergencia;
6. explicar comportamiento bajo estado obsoleto;
7. declarar el modelo de confianza.

### Track A — DHT

Construye un pequeño anillo u overlay estructurado con:

- IDs de nodo estables;
- lookup;
- join;
- manejo de leave/fallo;
- estabilización básica;
- replicación opcional.

### Track B — Gossip membership

Construye:

- muestreo de peers;
- estados estilo ALIVE/SUSPECT/DEAD;
- orden de incarnation o versión;
- diseminación repetida;
- fanout y pérdida configurables;
- métricas de convergencia.

El objetivo no es una red P2P de producción.

El objetivo es entender el intercambio:

```text
autoridad central y lookup directo
        frente a
conocimiento parcial descentralizado y mantenimiento continuo
```

---

## Resumen del capítulo

Los sistemas descentralizados sustituyen un directorio completo por conocimiento parcial distribuido.

Las DHT estructuran ese conocimiento parcial para que el lookup de una clave avance eficientemente hacia su propietario.

Gossip propaga membership o estado probabilísticamente mediante intercambios repetidos entre peers.

Ambos introducen costes nuevos:

```text
estado obsoleto
tráfico de mantenimiento
manejo de churn
bootstrap
sospecha de fallos
complejidad de seguridad/confianza
```

No son automáticamente mejores que un registro.

El diseño correcto depende de la propiedad que realmente necesite la aplicación:

> **lookup autoritativo exacto, routing descentralizado y estructurado por clave, o diseminación eventual escalable.**

El Capítulo 9 plantea una pregunta relacionada pero diferente: si las réplicas se actualizan independientemente mientras están desconectadas, ¿pueden diseñarse los *datos mismos* para converger sin coordinar cada escritura?

<div class="ds-next-action">
  <span>Lectura esencial completada</span>
  <strong>Siguiente paso obligatorio · Práctica guiada</strong>
  <a href="../guided-practice/">Comenzar práctica guiada →</a>
</div>
