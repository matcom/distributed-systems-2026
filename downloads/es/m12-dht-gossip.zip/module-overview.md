<p class="ds-book-part">Parte II — Comunicación y coordinación</p>
<p class="ds-module-kicker">Capítulo 5</p>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 5 de 12</span>
    <span>42% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 42%"></span></div>
</div>
<p class="ds-guiding-question">¿Cómo debe moverse la información cuando una única ruta directa de solicitud/respuesta no basta?</p>

Amplía el modelo del Capítulo 4. Compara RPC con entrega asíncrona, colas, pub/sub, comunicación de grupo, gossip y overlays estructurados. Pregunta quién conoce el destino, quién espera, dónde queda el trabajo pendiente y qué significa una confirmación.

## Ideas clave

- solicitud/respuesta frente a mensajería asíncrona;
- colas, redelivery y acknowledgement;
- publish/subscribe y fan-out;
- multicast y comunicación de grupo;
- gossip push, pull y push-pull;
- overlays lógicos frente a red física;
- hashing consistente;
- Chord y la intuición de Kademlia;
- churn y mantenimiento de membresía.

## Transición al laboratorio

Traza primero el mismo efecto mediante RPC y mediante una cola local con redelivery. Después experimenta con gossip o con un overlay y mide qué cambia cuando se pierden mensajes o cambia la membresía.

## Empieza aquí

> **Antes de leer:** Un productor crea un evento mientras todos los consumidores están desconectados. ¿Qué modelos de comunicación pueden entregarlo después y qué estado debe existir para hacerlo posible?

**Trae contigo:** La semántica de solicitud/respuesta del Capítulo 4 y la diferencia entre rutas lógicas y físicas de comunicación.

**Este capítulo te prepara para:** Un vocabulario para llamadas síncronas, eventos en cola, diseminación en grupo, gossip y encaminamiento sobre overlays.

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>30 min–40 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>45 min–1 h</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>2 h–2 h 30 min · 9 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Leer lección →</a>
  <a class="ds-secondary-action" href="lab/">Abrir laboratorio</a>
</div>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../downloads/es/m12-dht-gossip.zip" download>Descargar capítulo + laboratorio para estudio sin conexión (.zip)</a></p>

## Qué aprenderás

- Compara RPC síncrono con comunicación asíncrona, de grupo, gossip y mediante overlays.
- Explicita los supuestos de entrega, orden, duplicación, confirmación y destino de un patrón de comunicación.
- Explica gossip push, pull y push-pull, y traza una búsqueda en un overlay estructurado.
- Implementa un mecanismo pequeño de diseminación u overlay y mide su comportamiento ante pérdidas o churn.
- Explica qué garantías de comunicación son deterministas y cuáles son probabilísticas o eventuales.

## Aprende trabajando la pregunta

1. Escribe tu respuesta a **Empieza aquí** antes de abrir la lección completa.
2. Lee hasta la siguiente predicción o traza; detente y resuélvela antes de revelar la explicación.
3. Trata la práctica guiada como un **banco de práctica**, no como una hoja para completar deprisa. Trabaja las trazas centrales hasta alcanzar el objetivo de práctica y vuelve después a los casos restantes.
4. Usa la comprobación para detectar vacíos y entra al laboratorio con una predicción falsable y con la evidencia que podría contradecirla.
5. Termina explicando qué estableció el experimento, qué no estableció y cómo cambia tu explicación del servicio acumulativo.

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../m03-rpc/">← Comunicación I — Mensajes, RPC y fallos remotos</a>
<a class="ds-sequence-link next" href="../m06-time-causality/">Coordinación I — Tiempo, eventos y causalidad →</a>
</nav>
