<p class="ds-book-part">Parte IV — Tolerancia a fallos</p>
<div class="ds-lesson-banner">
  <div><span>Paso del curso</span><strong>Capítulo 10</strong></div>
  <div><span>Lectura esencial</span><strong>40 min–55 min</strong></div>
  <div><span>Ruta obligatoria</span><strong>Leer → Objetivo de práctica → Comprobar → Laboratorio</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 10 de 12</span>
    <span>83% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 83%"></span></div>
</div>

> **Pregunta guía:** ¿Cómo sigues tomando decisiones seguras cuando un fallo y una lentitud pueden parecer lo mismo?

## Antes de leer

> Un nodo permanece en silencio durante cinco segundos. ¿Qué puedes concluir de forma segura? Ahora supón que reinicia: ¿qué estado debe sobrevivir antes de que pueda reincorporarse con seguridad?

Escribe primero una respuesta breve. No necesitas acertar todavía: necesitas una predicción que puedas revisar a medida que el capítulo te dé mejores modelos y evidencia.

**Usa lo que ya sabes:** Ambigüedad de los tiempos de espera, replicación, consenso e historiales observables de los capítulos anteriores.

## Mapa de carga de trabajo

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>40 min–55 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>50 min–1 h 15 min</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>2 h 30 min–3 h · 8 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<p class="ds-workload-note"><strong>Alcance esencial:</strong> El núcleo del laboratorio es Pasos 1–6, Paso 8, checkpoint durable 8b y Pasos 10–13. El fallo unidireccional y la comparación de políticas adicionales del detector siguen como extensiones.</p>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../../downloads/es/m07-failures.zip" download>Descargar lección + práctica + laboratorio para estudio sin conexión (.zip)</a></p>

## Por qué importa este capítulo

Los sistemas distribuidos se vuelven interesantes cuando el entorno deja de comportarse de forma amable.

Un proceso puede desaparecer. Una máquina puede seguir viva mientras uno de sus servicios queda bloqueado. Un paquete puede retrasarse, duplicarse, reordenarse o perderse. Dos grupos de máquinas saludables pueden dejar de comunicarse. Una dependencia puede responder tan lentamente que quien la llama abandone aunque la dependencia termine el trabajo más tarde.

Lo difícil es que estas observaciones suelen ser ambiguas.

Supón que el nodo A recibe un heartbeat del nodo B cada 500 ms. De pronto faltan tres heartbeats.

¿Qué sabe A?

Muy poco.

Posibilidades:

```text
B cayó
B está pausado
B está sobrecargado
A está sobrecargado
se pierden paquetes desde B
se pierden paquetes hacia B
cambió el routing
una partición separa A de B
el hilo de heartbeat de B está bloqueado
los supuestos de reloj/temporizador de A son incorrectos
```

Aun así, un sistema real debe tomar decisiones.

Este capítulo introduce una de las disciplinas centrales de la ingeniería de sistemas distribuidos:

> **Convierte la incertidumbre en un modelo de fallos explícito y diseña el sistema alrededor de lo que puede y no puede saberse.**

La pregunta guía es:

> **¿Cómo puede un proceso distinguir un peer caído de uno lento o particionado?**

En un sistema completamente asíncrono, en general no puede hacerlo perfectamente solo a partir del silencio.

Ese hecho impulsa detectores de fallos, tiempos de espera, quórums, leases de líder, consenso, estrategias de reintento y buena parte de la arquitectura que estudiaremos después.

---

## 1. «Fallo» no es una sola cosa

La palabra *fallo* es demasiado amplia para razonar con precisión.

Considera una solicitud de servicio que no termina. Pueden haber ocurrido fallos distintos:

- el cliente falla antes de enviar;
- la solicitud se pierde;
- el servidor cae antes de procesarla;
- el servidor procesa y cae antes de responder;
- la respuesta se pierde;
- la respuesta llega después del plazo del cliente;
- el servicio está saludable, pero una partición lo vuelve inaccesible.

Todas esas historias pueden producir la misma observación del cliente:

```text
timeout
```

Un modelo de fallos útil pone nombre a clases diferentes de comportamiento y declara cuáles asume el diseño.

---

<aside class="ds-book-note ds-history">
  <span class="ds-book-note-label">Historia</span>
  <strong>La investigación sobre consenso separó seguridad de progreso y precisó qué puede significar acuerdo bajo incertidumbre</strong>
  <p>Paxos, FLP y trabajos relacionados establecieron el lenguaje moderno para razonar sobre acuerdo, supuestos de fallo, intersección de quórums y la diferencia entre lo que nunca debe ocurrir y lo que puede dejar de progresar temporalmente.</p>
  <a class="ds-book-note-source" href="../../../history/paxos-consensus/">Lee la historia del diseño →</a>
</aside>

## 2. Crash-stop es una abstracción útil, no una descripción completa de la realidad

Un modelo introductorio frecuente es **crash-stop**:

> Un proceso se comporta correctamente hasta que cae y, una vez caído, no vuelve.

Este modelo simplifica el razonamiento.

Si el proceso P se detiene para siempre, no necesitamos modelar mensajes arbitrariamente corruptos enviados por P después de la caída.

Pero los servicios reales suelen reiniciarse.

Eso produce un modelo **crash-recovery**:

```text
ejecutando
   ↓
caído
   ↓
reinicia
   ↓
ejecutando de nuevo
```

Crash-recovery introduce nuevas preguntas inmediatamente:

- ¿qué estado sobrevivió?
- ¿el proceso reiniciado es el mismo nodo lógico o una encarnación nueva?
- ¿pueden llegar todavía mensajes retrasados de la encarnación anterior?
- ¿puede el proceso repetir trabajo que ya había completado antes de caer?

Por eso el Capítulo 8 introdujo identificadores de encarnación y por eso la recuperación exige tratar explícitamente el estado persistente.

> **Detente y predice.** Un trabajador llamado `worker-3` cae y reinicia con memoria vacía, pero en la misma dirección de red. ¿Debe otro nodo asumir que recuerda las tareas asignadas antes del fallo?

No. El nombre estable o la dirección no demuestran continuidad del estado volátil.

---

## 3. Los fallos por omisión significan que no ocurre una acción esperada

Un **fallo por omisión** ocurre cuando un mensaje o una acción que debería observarse no ocurre desde el punto de vista del observador.

Ejemplos:

```text
envío omitido
recepción omitida
respuesta omitida
heartbeat omitido
```

La idea importante es que la omisión no identifica al componente que falló.

Si A no recibe el heartbeat de B, el problema podría estar en B, en A o en cualquier punto del camino de comunicación.

Principio recurrente:

> **La ausencia de evidencia desde un único punto de observación rara vez identifica la causa raíz.**

El Calentamiento introdujo esto como disciplina de evidencia; el Capítulo 10 lo convierte en una restricción de diseño de protocolos.

---

## 4. Los fallos temporales dependen de supuestos sobre retrasos aceptables

Un **fallo de temporización** ocurre cuando una acción sucede fuera de los límites temporales exigidos por el modelo.

Por ejemplo, supón que un servicio de control en tiempo real requiere una respuesta en 20 ms.

Una respuesta después de 2 segundos es funcionalmente un fallo para esa aplicación, aunque el servidor termine devolviendo el valor correcto.

Esta distinción importa porque los algoritmos distribuidos asumen modelos temporales diferentes.

### Modelo síncrono

Existen límites conocidos para cantidades relevantes como:

- retraso de mensajes;
- tiempo de ejecución de procesos;
- deriva de relojes.

### Modelo asíncrono

No se asume un límite superior fijo útil para retrasos de mensajes o ejecución.

Un proceso correcto puede parecer silencioso durante un tiempo arbitrariamente largo.

### Modelo parcialmente síncrono

La temporización puede permanecer sin límite durante un periodo, pero finalmente el sistema se comporta dentro de límites útiles, o bien existen límites que inicialmente son desconocidos.

Muchos sistemas prácticos se parecen conceptualmente más a la sincronía parcial que a una red perfectamente síncrona.

Esto será importante para consenso: la vivacidad suele depender de que la temporización acabe siendo favorable, aunque la seguridad no dependa de ello.

---

## 5. Un tiempo de espera es una decisión local, no un hecho remoto

Supón que A envía una solicitud a B y espera 500 ms.

A los 500 ms vence el temporizador de A.

¿Qué ocurrió remotamente?

El tiempo de espera solo establece algo parecido a:

> A no observó la finalización esperada antes de su plazo local.

No demuestra:

```text
B está muerto
la solicitud se perdió
la solicitud no se ejecutó
la respuesta nunca llegará
la red está rota
```

Esto conecta directamente con el Capítulo 4.

Un plazo es valioso porque el cliente no puede esperar indefinidamente, pero cada tiempo de espera convierte incertidumbre en una decisión de política.

La política puede ser:

- reintentar;
- fallar la solicitud del usuario;
- elegir otra réplica;
- marcar al peer como sospechoso;
- iniciar una elección de líder;
- degradar el servicio;
- encolar el trabajo para más tarde.

La pregunta de ingeniería no es solo:

> ¿Qué valor debe tener el timeout?

Es:

> **¿Qué acción se vuelve segura o útil cuando vence, sabiendo que el estado remoto sigue siendo incierto?**

---

## 6. Detectar fallos significa, en esencia, producir sospechas

Un detector práctico suele convertir evidencia ausente en una transición de estado.

Por ejemplo:

```text
ALIVE
  |
  | no heartbeat durante T
  v
SUSPECT
  |
  | evidencia adicional / expiración
  v
DEAD o REMOVED
```

Llamar **sospechoso** al primer estado, en lugar de **muerto**, es conceptualmente útil.

Un detector de fallos es un servicio de información cuya salida puede ser temporalmente incorrecta.

Esto conduce a dos propiedades clásicas.

### Completitud

¿El detector termina sospechando de procesos que realmente fallaron?

### Exactitud

¿Evita sospechar de procesos correctos?

En un entorno asíncrono con retraso no acotado, un detector perfecto no puede saber simultáneamente que el silencio significa fallo permanente y no un retraso extremo.

No es un defecto de implementación. Se deriva de la información disponible para el proceso.

---

## 7. Por qué la detección perfecta falla bajo asincronía

Compara dos ejecuciones desde el punto de vista de A.

### Ejecución 1 — B cae

```text
A               B
| heartbeat <---|
|               X caída
| ...silencio...|
```

### Ejecución 2 — B solo está retrasado

```text
A               B
| heartbeat <---|
|               |
| ...silencio...|  retraso de scheduler/red
|               |
| heartbeat <---|
```

Hasta que en la segunda ejecución llegue finalmente otro heartbeat, las observaciones de A pueden ser idénticas.

Si A declara muerto a B después de un silencio finito, arriesga una falsa sospecha en la segunda ejecución.

Si A espera para siempre para evitar sospechas falsas, nunca detecta a B en la primera.

Es uno de los patrones más profundos de los sistemas distribuidos:

> **Cuando dos mundos distintos producen las mismas observaciones locales, ningún algoritmo que use solo esas observaciones puede distinguir siempre ambos mundos de inmediato.**

---

## 8. Los heartbeats aportan evidencia de alcanzabilidad reciente

Un detector sencillo usa heartbeats periódicos.

Supón que B envía uno cada segundo.

A registra el instante del heartbeat más reciente usando un reloj monotónico local.

```text
last_seen[B] = monotonic_now()
```

A puede sospechar de B cuando:

```text
monotonic_now() - last_seen[B] > timeout
```

El diseño es deliberadamente local.

No compares el reloj de pared de A con una marca generada por el reloj de pared de B salvo que el protocolo disponga de un modelo explícito de sincronización y error.

Para detección básica de vivacidad, el receptor suele necesitar únicamente:

> ¿Cuánto tiempo ha transcurrido según **mi temporizador local** desde la última vez que recibí algo de B?

El Capítulo 6 preparó esta distinción.

---

## 9. El intervalo de heartbeat y el tiempo de sospecha son parámetros diferentes

Si el heartbeat se envía cada segundo, el detector no tiene que sospechar necesariamente tras exactamente un segundo.

Un diseño simple podría usar:

```text
intervalo heartbeat = 1 s
tiempo de sospecha  = 4 s
```

Así tolera varios mensajes perdidos antes de cambiar el estado de membresía.

El compromiso es directo.

Tiempo corto:

```text
detección más rápida
más falsas sospechas
más churn
```

Tiempo largo:

```text
failover más lento
menos falsas sospechas
```

No existe un valor universalmente correcto.

Importan la carga, la red, el scheduler, la distribución de latencias y el coste de sospechar incorrectamente.

---

## 10. Los detectores adaptativos responden a las condiciones observadas

Un tiempo fijo es sencillo, pero puede comportarse mal cuando cambia la latencia.

Un detector adaptativo puede seguir los retrasos recientes de heartbeats y ajustar su umbral.

Conceptualmente:

```text
distribución de retrasos observados
             ↓
estimación de confianza/sospecha
             ↓
umbral de decisión
```

El curso no exige implementar un detector probabilístico sofisticado en el Capítulo 10, pero sí comprender por qué existe.

Un detector debe evaluarse experimentalmente, no mediante un número que «parezca razonable».

Mediciones útiles:

- latencia de detección después de una caída real;
- tasa de falsas sospechas bajo retraso;
- tiempo de recuperación cuando se repara la comunicación;
- sensibilidad a la carga;
- overhead de mensajes.

---

## 11. La salida del detector no es lo mismo que la autoridad de membresía

Supón que A sospecha de B.

¿Puede A eliminar a B permanentemente del clúster?

Depende de la arquitectura.

Un detector local quizá solo produce:

```text
A cree que B no es alcanzable ahora
```

Convertir esa creencia en membresía global autoritativa puede necesitar:

- un registro central;
- un servicio de membresía replicado;
- acuerdo por quórum;
- convergencia por gossip;
- consenso.

El Capítulo 8 introdujo leases de registro. Este capítulo aclara que el mecanismo de expiración y el mecanismo de autoridad son cuestiones distintas.

---

## 12. Las particiones producen desacuerdo entre nodos saludables

Una **partición de red** divide el sistema en grupos que no pueden intercambiar los mensajes necesarios.

Por ejemplo:

```text
A <-> B     X     C <-> D
```

Los cuatro procesos pueden estar saludables.

Desde A, C y D pueden parecer caídos.

Desde C, A y B pueden parecer caídos.

Esta simetría es peligrosa.

Si ambos lados concluyen independientemente:

> «El otro lado está muerto; por tanto yo soy autoritativo»,

el sistema puede crear estado conflictivo.

Esto motiva intersección de quórums y consenso.

---

## 13. Una partición no es solo un cable de Internet cortado

Una partición puede surgir por:

- fallo de routing;
- reglas de firewall;
- configuración errónea de una red virtual;
- fallo de switch;
- política de service mesh;
- una cola sobrecargada que se comporta como pérdida efectiva;
- conectividad unidireccional;
- DNS o descubrimiento que apunta a nodos inalcanzables.

Por tanto, matar un proceso no basta para afirmar tolerancia a particiones.

El laboratorio debe provocar **fallo de comunicación mientras los procesos siguen vivos**.

---

## 14. Las particiones unidireccionales son especialmente reveladoras

Supón que A puede enviar a B, pero las respuestas de B no llegan a A.

```text
A ----solicitud----> B
A <---X respuesta--- B
```

B puede seguir cambiando estado mientras A experimenta tiempos de espera.

Esto reproduce la ambigüedad RPC del Capítulo 4.

La dirección de los heartbeats también importa.

Si B envía heartbeats a A pero A no puede enviar solicitudes a B, el detector puede declarar B saludable aunque el camino de aplicación sea inutilizable.

Regla práctica:

> **La salud depende del camino y de la función concreta.**

Un heartbeat satisfactorio demuestra menos de lo que muchos sistemas asumen.

---

## 15. Pérdida y duplicación de mensajes interactúan con la semántica de aplicación

Transporte y middleware pueden retransmitir. Clientes y proxies pueden reintentar. Las colas pueden volver a entregar.

Así, una aplicación puede recibir solicitudes lógicas duplicadas incluso si ningún componente está «roto».

Considera:

```text
cliente envía R7
servidor aplica R7
se pierde la respuesta
cliente reintenta R7
servidor vuelve a ver R7
```

El modelo de fallo de red y el modelo de idempotencia de la operación están acoplados.

El Capítulo 4 introdujo IDs de solicitud y deduplicación. Aquí se integran dentro de una campaña de fallos más amplia.

Un sistema que tolera pérdida de paquetes reintentando, pero no tolera efectos duplicados, no es realmente robusto.

---

## 16. Reordenamiento significa que el orden de llegada no es una garantía semántica

Los mensajes pueden llegar en un orden distinto al esperado conceptualmente por la aplicación.

Por ejemplo:

```text
M1: set mode = ACTIVE
M2: set mode = STOPPED
```

Si M2 se observa antes que un M1 retrasado, procesar ingenuamente según último arribo puede terminar en un estado incorrecto.

Las soluciones dependen de la semántica:

- números de secuencia;
- versiones;
- metadatos causales;
- orden del log de consenso;
- actualizaciones idempotentes y monótonas;
- reglas explícitas de máquina de estados.

La lección no es «la red siempre reordena».

Es:

> **Si la corrección depende del orden, el protocolo debe definir cómo se establece ese orden.**

---

## 17. La recuperación forma parte de la tolerancia a fallos

Un sistema no es resiliente solo porque sobreviva al instante del fallo.

También debe definir qué ocurre después.

Supón que la réplica C permanece desconectada diez minutos mientras A y B procesan escrituras.

Cuando C vuelve:

```text
el estado de C está obsoleto
```

Estrategias posibles:

- reproducir entradas de log faltantes;
- copiar una instantánea;
- comparar versiones;
- intercambio anti-entropy;
- reconstruir desde otra réplica;
- descartar C y provisionar un nodo nuevo.

Los capítulos posteriores implementan distintas versiones de estas ideas.

Requisito general:

> **Todo escenario de fallo necesita una historia de recuperación.**

### Recuperar una máquina de estados replicada exige más que reiniciar el proceso

La coordinación anterior proporcionó una secuencia acordada de comandos. Convertirla en un servicio recuperable añade otro límite:

```text
solicitud del cliente
       ↓
comando confirmado
       ↓
log durable / registro de recuperación
       ↓
aplicación determinista
       ↓
estado del servicio
```

Un proceso reiniciado debe responder antes de servir tráfico:

- ¿qué comandos fueron confirmados?
- ¿qué comandos confirmados ya se aplicaron?
- ¿reaplicar uno puede duplicar un efecto secundario?
- ¿puede reconstruirse el estado en memoria desde información durable?
- ¿la instantánea es suficientemente reciente y qué sufijo de log debe reproducirse?
- si el nodo está muy atrasado, ¿es más barato reproducir el log o transferir estado desde otra réplica?

Por eso muchos sistemas distinguen:

```text
commit index
last applied
snapshot index
estado durable de solicitud/deduplicación
```

Esos valores no avanzan necesariamente al mismo tiempo.

### La identidad estable de solicitudes debe sobrevivir también a la recuperación

Supón que la solicitud 81 se confirmó y aplicó antes de una caída, pero la respuesta nunca llegó al cliente.

Tras reiniciar, el cliente reintenta la solicitud 81.

Si la supresión de duplicados existía solo en memoria, el servicio recuperado puede aplicar el efecto dos veces. La seguridad de reintento y la recuperación tras caída se encuentran en el mismo límite de estado durable.

Un diseño educativo simple puede persistir:

```text
última instantánea
sufijo del log confirmado
request_id → registro de resultado/efecto
```

y reconstruir estado determinista tras reiniciar.

### Las instantáneas acortan la recuperación, pero crean otro límite de corrección

Reproducir diez comandos es sencillo. Reproducir diez millones puede ser impráctico.

Una instantánea captura el estado de aplicación en una posición conocida del log:

```text
snapshot hasta índice 5000
sufijo de log 5001..actual
```

La recuperación carga la instantánea y reproduce el sufijo.

Solo es útil si puedes indicar:

- exactamente qué comandos confirmados contiene;
- cómo se escribe de forma suficientemente atómica para el modelo de fallo;
- qué estado de deduplicación/sesión debe incluir;
- cómo verifica o sustituye el nodo una instantánea corrupta o incompleta.

> **Detente y predice.** Un nodo reinicia correctamente, pero restaura una instantánea del índice 5000 mientras el clúster ha confirmado hasta 5400. ¿Está «recuperado»? Está vivo, pero todavía no es seguro para cualquier rol de servicio.

---

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosidad</span>
  <strong>Un detector perfecto tendría que saber si un nodo silencioso murió o solo está lento</strong>
  <p>En un modelo asíncrono, un proceso sano suficientemente retrasado puede parecer idéntico a uno que hizo crash desde la perspectiva local de otro nodo.</p>
  <p><strong>Pruébalo:</strong> Ejecuta el mismo heartbeat timeout una vez con crash real y otra con delay; compara la evidencia local.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">Más curiosidades del capítulo →</a>
</aside>

## 18. Reintegrarse con seguridad puede requerir información de encarnación

Imagina que un proceso reinicia con el mismo ID de nodo.

Un heartbeat antiguo retrasado de antes de la caída llega después del reinicio.

Sin información de encarnación o versión, otro componente puede confundir evidencia antigua con vivacidad actual.

Metadatos útiles:

```text
node_id = worker-3
incarnation = 91384
sequence = 22
```

Después del reinicio:

```text
node_id = worker-3
incarnation = 77102
sequence = 1
```

Ahora los mensajes antiguos de la encarnación `91384` pueden reconocerse como obsoletos.

Principio general:

> **La identidad suele necesitar un nombre lógico estable y un epoch/encarnación cambiante.**

---

## 19. Las tormentas de reintentos pueden convertir un fallo parcial en un fallo total

Supón que 10 000 clientes llaman a un servicio.

El servicio se ralentiza.

Los clientes agotan sus tiempos de espera y reintentan inmediatamente.

El tráfico aumenta.

El servicio se ralentiza más.

Más clientes reintentan.

```text
servicio lento
   ↓
timeouts
   ↓
reintentos
   ↓
más carga
   ↓
servicio aún más lento
```

Este ciclo de realimentación positiva puede producir una **tormenta de reintentos**.

El mecanismo pensado para aumentar disponibilidad se convierte en amplificador del fallo.

---

## 20. El backoff exponencial reduce la presión sincronizada de reintentos

Una estrategia común incrementa el retraso entre reintentos.

Conceptualmente:

```text
intento 1 -> espera ~100 ms
intento 2 -> espera ~200 ms
intento 3 -> espera ~400 ms
intento 4 -> espera ~800 ms
```

Esto reduce carga repetida sobre una dependencia que quizá todavía se recupera.

Pero si todos los clientes usan exactamente el mismo calendario, pueden sincronizarse:

```text
todos reintentan a 100 ms
todos reintentan a 200 ms
todos reintentan a 400 ms
```

Por eso suele añadirse **jitter**, variación aleatoria del tiempo de reintento.

El objetivo no es introducir azar por sí mismo.

Es evitar comportamiento correlacionado entre muchos clientes.

---

## 21. Los presupuestos de reintentos acotan cuánto trabajo extra puede crear un fallo

Un sistema robusto debe definir cuánto tráfico de reintento puede generar una operación lógica.

Límites posibles:

- número máximo de intentos;
- plazo absoluto;
- tiempo total de reintentos;
- presupuesto por cliente;
- política global de circuit breaking o load shedding.

Sin límites, el manejo del fallo puede convertirse en trabajo ilimitado.

Esto conecta con el control de presión del Capítulo 3.

---

## 22. Los circuit breakers son política, no prueba de fallo

Un circuit breaker puede dejar de enviar tráfico a una dependencia después de varios fallos.

Conceptualmente:

```text
CLOSED -> OPEN -> HALF-OPEN -> CLOSED
```

Puede proteger una dependencia sobrecargada y reducir trabajo inútil.

Pero un circuito abierto no demuestra que la dependencia esté muerta.

Significa:

> La política local del cliente considera que enviar más solicitudes no es deseable ahora.

De nuevo, el estado operacional local no debe confundirse con verdad global.

---

## 23. Los fallos correlacionados invalidan supuestos ingenuos sobre replicación

Supón que tenemos tres réplicas:

```text
R1 R2 R3
```

¿Toleramos un fallo de hardware?

Quizá no si las tres son contenedores en el mismo portátil.

¿Toleramos un fallo eléctrico?

No si todas las máquinas comparten el mismo circuito.

¿Toleramos un bug de software?

No si cada réplica ejecuta el mismo código defectuoso.

Dominios de fallo posibles:

- proceso;
- contenedor;
- VM;
- host;
- rack;
- switch;
- dominio eléctrico;
- zona de disponibilidad;
- región;
- versión de software;
- credenciales/configuración.

La replicación mejora resiliencia solo cuando las copias no fallan juntas bajo los fallos que afirmamos tolerar.

---

## 24. Fail-stop, crash, omisión, temporización y comportamiento bizantino son afirmaciones diferentes

Conviene distinguir varias abstracciones.

### Crash

El proceso deja de ejecutarse.

### Fail-stop

Otros procesos pueden detectar de manera fiable la parada según el modelo.

### Omisión

Faltan mensajes o acciones esperadas.

### Temporización

Las acciones suceden demasiado pronto o demasiado tarde respecto a límites exigidos.

### Bizantino

Un componente puede comportarse arbitrariamente, incluso enviar mensajes inconsistentes o maliciosos.

El Capítulo 12 estudia los fallos bizantinos.

La mayor parte del curso asume fallos de crash, omisión, temporización o red salvo que se indique otra cosa.

No debes afirmar tolerancia a comportamiento malicioso arbitrario solo porque el sistema sobreviva a matar un proceso.

---

## 25. Seguridad y vivacidad reaccionan de manera distinta a los fallos

Recuerda:

### Seguridad (*safety*)

Algo malo nunca ocurre.

Ejemplos:

- dos valores conflictivos no se confirman en la misma posición del log;
- un ID de solicitud no aplica un pago dos veces;
- una lectura no observa un estado imposible bajo el modelo declarado.

### Vivacidad (*liveness*)

Algo bueno termina ocurriendo.

Ejemplos:

- una solicitud válida termina;
- se elige finalmente un nuevo líder;
- una réplica recuperada termina poniéndose al día.

Ante un fallo, un sistema suele preservar seguridad sacrificando temporalmente vivacidad.

Por ejemplo, durante una partición el grupo minoritario puede rechazar escrituras para evitar confirmar estados conflictivos.

Esta distinción es central en los capítulos de replicación y consenso.

---

## 26. La disponibilidad depende del contexto

Un servicio puede estar:

- vivo como proceso, pero sin aceptar solicitudes;
- aceptando lecturas, pero no escrituras;
- disponible en una partición, pero no en otra;
- alcanzable, pero demasiado lento para cumplir el plazo del usuario;
- devolviendo datos obsoletos en un modo degradado.

Por tanto, evita afirmaciones vagas como:

> «El sistema permanece disponible».

Prefiere:

> «Durante la pérdida de un trabajador, las lecturas continúan desde las réplicas restantes; las escrituras se bloquean hasta recuperar un quórum».

Eso sí puede probarse.

---

## 27. Un inyector de fallos cambia el entorno; un oráculo evalúa el resultado

Herramientas como `tc netem`, señales de proceso, reglas de firewall/namespaces o controles de contenedores pueden inyectar fallos.

No deciden si el sistema se comportó correctamente.

Por ejemplo:

```bash
tc qdisc add ... netem delay 300ms loss 10%
```

puede introducir retraso y pérdida.

Pero todavía necesitas un **oráculo**:

- invariante esperado;
- degradación de disponibilidad permitida;
- comportamiento esperado de recuperación;
- comprobación de integridad;
- interpretación de trazas.

Por eso cada laboratorio empieza con una predicción.

---

## 28. La inyección de fallos debe ser reproducible y acotada

Un buen experimento registra:

```text
tipo de fallo
objetivo del fallo
instante de inicio
instante de fin
parámetros
carga
comportamiento esperado
comportamiento observado
criterio de recuperación
```

Una afirmación como:

> «Desconecté algo y siguió funcionando».

no es evidencia útil.

Prefiere:

> «A t=12,0 s bloqueé durante 8 s el tráfico saliente de B hacia A mientras continuaban 20 solicitudes/s. A sospechó de B tras 3,1 s. Ninguna solicitud fue reconocida dos veces. B volvió a considerarse saludable 1,0 s después de restablecer la conectividad».

Ahora otra persona puede razonar sobre el experimento.

---

## 29. Ejemplo trabajado — falsa sospecha mediante heartbeat

Supón:

```text
heartbeat cada     = 1 s
tiempo de sospecha = 3 s
```

Llegadas normales a A:

```text
t=0
t=1
t=2
t=3
```

Ahora la red retrasa cuatro segundos el tráfico de heartbeat de B.

A no observa nuevos heartbeats entre t=3 y t=6.

Aproximadamente en t=6:

```text
A marca B como SUSPECT
```

Sin embargo, B nunca cayó.

Cuando llegan mensajes retrasados o heartbeats nuevos, A puede devolver B a ALIVE.

Esto demuestra:

```text
falsa sospecha != necesariamente bug del detector
```

El detector opera bajo un supuesto temporal que el entorno violó temporalmente.

La pregunta de diseño pasa a ser:

- ¿qué acciones incorrectas están permitidas mientras B está falsamente sospechado?

Si la respuesta es «A puede borrar datos durables de B», la arquitectura es peligrosa.

Si la respuesta es «A envía temporalmente nuevo trabajo a otros nodos pero conserva seguridad», la consecuencia puede ser aceptable.

---

## 30. Ejemplo trabajado — crash frente a partición

Tres nodos:

```text
A B C
```

A monitoriza B.

### Escenario 1

Se mata el proceso B.

A deja de recibir heartbeats.

### Escenario 2

B sigue ejecutándose, pero se bloquea el tráfico entre A y B.

A también deja de recibir heartbeats.

Desde el detector de A, ambas observaciones pueden ser iguales.

La evidencia de C puede diferir:

```text
Escenario 1: C tampoco puede hablar con B
Escenario 2: C puede seguir comunicándose con B
```

Esto muestra cómo la información de varios observadores o de un quórum puede mejorar decisiones, aunque siempre debe interpretarse bajo un modelo de red.

---

## 31. Ejemplo trabajado — amplificación insegura de reintentos

Un servicio puede manejar 100 solicitudes/s.

Normalmente recibe 90 solicitudes/s.

Una pausa temporal hace que la latencia supere los plazos de los clientes.

Supón que cada solicitud que expira se reintenta tres veces inmediatamente.

La carga ofrecida efectiva puede acercarse a:

```text
90 originales + hasta 270 reintentos
```

El servicio queda muy por encima de su capacidad incluso después de terminar la pausa original.

Añadir reintentos sin backoff, jitter y presupuestos puede reducir disponibilidad.

Por eso el manejo de fallos debe evaluarse bajo carga, no solo con un cliente.

---

## 32. Ejemplo trabajado — criterio de recuperación

Un nodo vuelve después de una partición de 20 segundos.

¿Cuándo está el sistema «recuperado»?

Posibles respuestas:

- volvió la conectividad TCP;
- se observó un heartbeat;
- el nodo reaparece en el registro;
- se copió el estado faltante;
- el nodo comienza a servir lecturas;
- el nodo vuelve a ser elegible para escrituras;
- convergen todas las réplicas.

Son hitos distintos.

Un buen experimento define el que corresponde a la afirmación medida.

Para replicación puede resultar útil:

```text
tiempo de reparación =
tiempo desde que vuelve la conectividad hasta que la réplica queda sincronizada
```

Para descubrimiento:

```text
recuperación de redirección =
tiempo desde la reparación hasta una solicitud satisfactoria
```

---

## 33. Perspectiva histórica — los detectores de fallos hicieron explícita la incertidumbre

La teoría de computación distribuida no resolvió la comunicación no fiable fingiendo que los tiempos de espera eran exactos.

En su lugar, la investigación sobre detectores formalizó la idea de que los algoritmos pueden recibir **pistas o sospechas** sobre fallos de procesos con determinadas propiedades de completitud y exactitud.

Es un cambio conceptual poderoso.

En lugar de preguntar:

> «¿Cómo detecto caídas perfectamente?»

preguntamos:

> «¿Qué calidad de sospecha necesita este algoritmo para progresar sin romper seguridad?»

Ese enfoque será importante en consenso.

---

## 36. Errores comunes

### Error 1 — timeout significa que el servidor cayó

Significa que venció el plazo del cliente sin obtener la observación esperada.

### Error 2 — un heartbeat significa que todo el servicio está saludable

El éxito del heartbeat solo demuestra el camino/función comprobado en ese instante.

### Error 3 — matar un proceso demuestra tolerancia a particiones

Un crash y un fallo de comunicación crean condiciones globales diferentes.

### Error 4 — los reintentos inmediatos siempre mejoran fiabilidad

Pueden duplicar efectos y amplificar sobrecarga.

### Error 5 — replicar implica automáticamente tolerar fallos

Réplicas dentro del mismo dominio de fallo pueden caer juntas.

### Error 6 — la recuperación empieza y termina cuando reinicia el proceso

Puede seguir siendo necesario reparar estado y reintegrar el nodo.

### Error 7 — usar relojes de pared entre máquinas para medir frescura de heartbeats

Usa tiempo transcurrido local salvo que un modelo de sincronización justifique la comparación remota.

### Error 8 — sospechoso equivale a eliminado

Sospecha y cambio autoritativo de membresía son mecanismos distintos.

### Error 9 — la pérdida de paquetes es el único fallo de red relevante

Retraso, asimetría, partición, duplicación y recuperación pueden revelar bugs diferentes.

### Error 10 — probar fallos significa introducir caos destructivo

Una buena campaña es acotada, repetible, medible y ligada a invariantes explícitos.

---

## Transición al laboratorio

El laboratorio del Capítulo 10 convierte estas ideas en mediciones.

Construirás un detector basado en heartbeat y después inyectarás por separado:

- caída de proceso;
- retraso;
- pérdida;
- partición;
- conectividad restaurada;
- reintentos repetidos de clientes.

El resultado importante no es simplemente si el sistema «funcionó».

Debes medir:

```text
latencia de detección de fallo real
comportamiento de falsas sospechas
tiempo de recuperación
comportamiento de duplicados/reintentos
amplificación de carga
```

y conectar cada resultado con los supuestos del detector y del modelo de fallos.

---

## Resumen del capítulo

1. **El fallo es un modelo, no un único tipo de evento.** Crash, omisión, temporización, partición, recuperación y comportamiento bizantino implican supuestos diferentes.
2. **Un tiempo de espera es una observación local.** No revela exactamente qué ocurrió remotamente.
3. **La detección perfecta a partir del silencio es imposible en un sistema totalmente asíncrono.** Una ejecución lenta y una caída pueden ser localmente indistinguibles.
4. **Los detectores prácticos producen sospechas.** Su calidad puede describirse mediante completitud, exactitud, latencia de detección y falsos positivos.
5. **Los heartbeats aportan evidencia de comunicación reciente, no salud universal.**
6. **Las particiones separan nodos saludables y pueden producir vistas locales contradictorias.**
7. **Los reintentos forman parte del modelo de fallos.** Pueden duplicar efectos y amplificar sobrecarga.
8. **Backoff, jitter y presupuestos limitan presión correlacionada de reintentos.**
9. **Los dominios de fallo determinan si la replicación realmente añade resiliencia.**
10. **La recuperación forma parte de la corrección.** Un nodo reiniciado o reconectado puede necesitar reparar estado antes de servir tráfico con seguridad.
11. **Seguridad, vivacidad y disponibilidad deben declararse por separado.** Un fallo puede exigir sacrificar progreso temporalmente para conservar corrección.
12. **La inyección de fallos solo se convierte en evidencia cuando se combina con un oráculo, carga, mediciones y comportamiento esperado explícito.**

El siguiente capítulo cruza otro límite: una operación lógica puede necesitar cambiar estado perteneciente a varias autoridades independientes. La recuperación deberá preservar una decisión entre participantes, no solo reconstruir una réplica.

<div class="ds-next-action">
  <span>Lectura esencial completada</span>
  <strong>Siguiente paso obligatorio · Práctica guiada</strong>
  <a href="../guided-practice/">Comenzar práctica guiada →</a>
</div>
