<div class="ds-lesson-banner">
  <div><span>Laboratorio obligatorio</span><strong>Capítulo 10</strong></div>
  <div><span>Modelo de evidencia</span><strong>predecir → ejecutar → observar → explicar</strong></div>
  <div><span>Verificación</span><strong>8 pruebas públicas transparentes + evidencia</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 10 de 12</span>
    <span>83% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 83%"></span></div>
</div>
<p class="ds-back-link"><a href="../quick-check/">← Volver a la comprobación</a></p>

> **Antes de comenzar:** Completa los pasos de práctica guiada y comprobación de conocimientos. Ya deberías poder formular una predicción y nombrar la evidencia que la apoyaría o contradeciría. Si no, [vuelve a la comprobación](../quick-check/) y revisa la lección donde haga falta.

## Objetivo

Construye un detector de fallos basado en heartbeats y haz que el mismo estado local del detector aparezca a partir de realidades distintas: un crash verdadero, retraso de red, pérdida de paquetes y partición. Mide detección, falsas sospechas y recuperación en lugar de limitarte a afirmar que el sistema «falló».

El laboratorio añade además un experimento de amplificación de reintentos para observar cómo la propia lógica de manejo de fallos puede convertirse en parte de una caída.

## Ruta esencial de realización

Completa los Pasos 1–6, el Paso 8, el checkpoint de recuperación durable del Paso 8b y los Pasos 10–13.

El Paso 7 (fallo unidireccional) y el Paso 9 (comparar políticas adicionales de detección) son **extensiones**. Son útiles cuando el entorno las permite, pero el núcleo del capítulo no exige todas las formas de fallo ni todas las variantes de detector.

## Topología requerida

Usa al menos tres procesos:

```text
observador A
observador C
trabajador B
```

A y C reciben independientemente evidencia de heartbeat de B.

Cada proceso debe exponer o registrar:

```text
node_id
incarnation_id
secuencia de heartbeat
hora monotónica local de recepción
estado del peer: ALIVE/SUSPECT
razón de la transición de estado
```

El detector debe medir la frescura con tiempo transcurrido local.

## Parámetros configurables

Como mínimo:

```text
intervalo heartbeat
tiempo de sospecha
umbral o regla de recuperación
```

No los codifiques directamente dentro de la lógica del protocolo.

## Paso 1 — línea base saludable

Ejecuta los tres procesos sin fallos inyectados durante al menos diez intervalos de heartbeat.

Mide:

- intervalo configurado;
- tiempos observados entre llegadas en A y C;
- número de heartbeats perdidos;
- transiciones de estado.

La línea base debe establecer la variabilidad normal del entorno antes de extraer conclusiones sobre fallos.

## Paso 2 — predice la detección de crash

Antes de matar B, calcula un rango esperado de latencia de sospecha a partir de las reglas del detector.

Después mata B de forma abrupta.

Registra:

```text
instante real del crash
último heartbeat observado por A
último heartbeat observado por C
instante de sospecha en A
instante de sospecha en C
```

Calcula la latencia de detección por separado para A y C.

Explica por qué no tienen que cambiar de estado exactamente al mismo tiempo.

## Paso 3 — reinicio y encarnación

Reinicia B con el mismo ID estable de nodo, pero con un ID de encarnación diferente.

Verifica que los observadores distinguen el proceso reiniciado de la encarnación antigua.

Si usas números de secuencia de heartbeat, explica por qué la secuencia por sí sola puede ser insuficiente después de un reinicio si no se combina con información de epoch/encarnación.

## Paso 4 — falsa sospecha mediante retraso

Mantén B vivo.

Introduce en el camino de heartbeat un retraso mayor que el tiempo configurado de sospecha.

Cuando el entorno lo permita, usa un mecanismo acotado como `tc/netem`, reglas de contenedor/network namespace o un wrapper de fallos proporcionado por el profesor.

Antes de aplicar el fallo, predice:

- si A debería sospechar de B;
- si C también debería sospechar;
- cuánto debería tardar la sospecha.

Recoge evidencia independiente de que B sigue vivo mientras A cambia su estado a `SUSPECT`.

Este es el experimento central del laboratorio.

## Paso 5 — pérdida de paquetes

Restaura el retraso normal e inyecta una tasa repetible de pérdida, por ejemplo 10–30 %.

Ejecuta durante suficientes intervalos de heartbeat.

Compara al menos dos tiempos de sospecha.

Para cada configuración informa:

- estado real del proceso;
- número de heartbeats recibidos/perdidos;
- número de falsas sospechas;
- sensibilidad aproximada de detección.

No afirmes que un valor es universalmente mejor. Explica el compromiso.

## Paso 6 — partición con procesos vivos

Crea una partición de comunicación entre A y B manteniendo ambos procesos ejecutándose.

Cuando sea posible, deja a C comunicarse con B:

```text
A  X  B <-> C
```

Recoge evidencia que muestre:

```text
A cree que B es inalcanzable/sospechoso
C sigue recibiendo heartbeats de B
el proceso B continúa vivo
```

Explica por qué el detector local de A no puede inferir la topología global de red solo a partir del silencio.

## Extensión 7 — fallo unidireccional

Si el entorno soporta reglas por dirección, bloquea o retrasa solo una dirección.

Por ejemplo:

```text
A ----solicitud----> B
A <---X respuesta--- B
```

o bloquea el heartbeat únicamente en una dirección.

Documenta por qué «salud» depende del camino y de la operación comprobada.

Si no puedes inyectar fallos direccionales localmente, analiza una traza proporcionada o crea una simulación determinista a nivel de aplicación.

## Paso 8 — repara la partición

Restaura la comunicación normal.

Mide al menos dos hitos:

```text
primer heartbeat fresco observado
peer marcado ALIVE de nuevo
```

Si además debe repararse estado de aplicación, identifícalo como otro hito de recuperación.

Calcula:

```text
latencia de recuperación =
instante de transición a ALIVE - instante de reparación del fallo
```

## Paso 8b — checkpoint de recuperación de estado durable

Reutiliza el servicio con estado más pequeño que ya tengas de los trabajos de comunicación, consenso o replicación. No necesitas construir un segundo servicio de calidad de producción.

Persiste suficiente información para reconstruir un estado clave/valor después de un crash:

- una pequeña instantánea o estado durable inicial;
- un log ordenado de comandos/actualizaciones posteriores;
- IDs de solicitud estables para operaciones con efectos.

Ejecuta:

1. parte de una instantánea/estado conocido;
2. aplica varias actualizaciones;
3. garantiza que al menos una actualización reconocida está representada de forma durable;
4. detén el proceso abruptamente;
5. reinicia con memoria vacía;
6. restaura la instantánea/estado y reproduce el sufijo necesario;
7. reintenta un ID de solicitud previamente completado.

Antes de reiniciar, predice el valor recuperado y si el reintento debería producir otro efecto.

Registra:

```text
punto de snapshot/recuperación
comandos durables
orden de replay
estado recuperado
decisión de deduplicación
tiempo hasta poder servir de forma segura la operación declarada
```

Si ya tienes un log replicado del Capítulo 7, usa sus entradas confirmadas como entrada ordenada. Si no, basta un log durable de comandos de un solo nodo para demostrar el límite de recuperación.

La conclusión requerida es más estrecha que «el sistema es tolerante a fallos». Declara exactamente qué historia de crash/reinicio recuperaste y qué estado sobrevivió.

## Extensión 9 — compara políticas de detector

Evalúa dos configuraciones, por ejemplo:

```text
Política A: heartbeat 500 ms, sospecha tras 1.5 s
Política B: heartbeat 500 ms, sospecha tras 4 s
```

Ejecuta ambas bajo:

- crash real;
- retraso/pérdida artificial.

Compara:

| Política | Detección de crash | Falsas sospechas | Retraso de recuperación | Tasa de mensajes |
|---|---:|---:|---:|---:|
| A | | | | |
| B | | | | |

Explica el compromiso operacional.

## Paso 10 — servicio de amplificación de reintentos

Usa un pequeño servicio cuya capacidad pueda limitarse o retrasarse artificialmente.

Genera una carga estable por debajo de su capacidad.

Introduce después suficiente latencia para que expiren los plazos de los clientes.

Compara:

### Estrategia 1 — reintentos inmediatos

Reintenta las operaciones expiradas inmediatamente hasta un número máximo de intentos.

### Estrategia 2 — backoff acotado

Usa:

- máximo de intentos o plazo total;
- backoff exponencial o creciente;
- jitter cuando sea posible.

Mide:

- solicitudes lógicas enviadas;
- intentos reales enviados;
- número de timeouts;
- rendimiento;
- latencia de cola o crecimiento de colas;
- tiempo para volver a la normalidad al terminar el fallo.

La razón clave es:

```text
amplificación = intentos reales / solicitudes lógicas
```

## Paso 11 — auditoría de efectos duplicados

Si la carga de reintento incluye una operación que modifica estado, usa IDs de solicitud estables y determina si se producen efectos duplicados.

Conecta el resultado con el Capítulo 4:

```text
manejo de fallos
    +
semántica de reintento
    +
idempotencia/deduplicación
```

deben diseñarse conjuntamente.

## Paso 12 — inventario de dominios de fallo

Dibuja el despliegue físico/lógico real usado en el laboratorio.

Para cada proceso identifica qué comparte con otros:

- host OS/kernel;
- presión de CPU/memoria;
- almacenamiento;
- interfaz de red;
- runtime de contenedores;
- dominio eléctrico.

Después escribe una afirmación de tolerancia a fallos que el laboratorio **sí** pueda apoyar y otra que no.

Por ejemplo:

> El experimento apoya tolerancia a la caída de un proceso, pero no a la pérdida de un host físico porque todos los nodos se ejecutaron en el mismo portátil.

## Paso 13 — tabla de campaña de fallos

Resume todos los experimentos:

| Fallo | Mundo real | Observación local | Decisión del detector | Efecto de aplicación | Criterio de recuperación |
|---|---|---|---|---|---|
| crash | | | | | |
| retraso | | | | | |
| pérdida | | | | | |
| partición | | | | | |

La distinción entre **mundo real** y **observación local** es obligatoria.

## Objetivo de pruebas transparentes

Las pruebas públicas ejecutables viven en `tests/official/`, con helpers deterministas de detector y política de reintentos en `starter/src/`. Verifican sospecha, frescura de encarnación/secuencia y reintentos acotados; los experimentos reales de crash, retraso, partición, falsa sospecha y recuperación siguen requiriendo evidencia de procesos/red.

Los casos públicos están documentados en `tests/official/README.md`. `make test` ejecuta únicamente pruebas oficiales visibles y las añadidas por el estudiante en `tests/student/`.

No se planean pruebas ocultas.

## Uso de IA

Se permiten asistentes y agentes de programación con IA.

Incluye un diagnóstico de fallo auditado:

1. proporciona al asistente una traza de timeout o heartbeat;
2. pídele una causa;
3. identifica qué afirmaciones son observaciones, hipótesis plausibles o certezas no justificadas;
4. verifica experimentalmente al menos una hipótesis.

La habilidad evaluada es el diagnóstico basado en evidencia, no si el modelo adivinó correctamente.

## Informe

Completa `REPORT.md` con predicciones, configuración, definición de fallos, mediciones del detector, amplificación de reintentos, criterios de recuperación y el inventario final de dominios de fallo.

Prefiere logs y tablas estructuradas frente a capturas cuando sea posible.

## Termina el capítulo

Reproduce el resultado importante desde un inicio limpio. Después vuelve a tu predicción inicial: explica qué cambió, qué evidencia provocó el cambio y qué incertidumbre queda. Un comando exitoso o una captura no bastan cuando la afirmación trata de retries, orden, durabilidad, consistencia, recovery, seguridad o rendimiento.

<div class="ds-next-action">
  <span>Capítulo completo</span>
  <strong>Continuar el curso</strong>
  <a href="../../m11-transactions-sharding/">Tolerancia a fallos II — Transacciones, recuperación y estado distribuido →</a>
</div>

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../../m08-replication-consistency/">← Replicación y consistencia</a>
<a class="ds-sequence-link next" href="../../m11-transactions-sharding/">Tolerancia a fallos II — Transacciones, recuperación y estado distribuido →</a>
</nav>
