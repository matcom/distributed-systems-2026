<p class="ds-book-part">Parte IV — Tolerancia a fallos</p>
<p class="ds-module-kicker">Capítulo 10</p>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 10 de 12</span>
    <span>83% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 83%"></span></div>
</div>
<p class="ds-guiding-question">¿Cómo sigues tomando decisiones seguras cuando un fallo y una lentitud pueden parecer lo mismo?</p>

Trata los fallos como parte normal de la ejecución. Distingue crashes, omisiones, fallos temporales, particiones, sobrecarga y fallos correlacionados. Un timeout aporta evidencia local; no revela por sí solo la verdad remota. Recuperar significa restaurar invariantes, no simplemente reiniciar un proceso.

## Ideas clave

- crash, omisión, tiempo y partición;
- sincronía, asincronía y sincronía parcial;
- detección como sospecha;
- heartbeats y timeouts adaptativos;
- pérdida, duplicación y reordenamiento;
- amplificación por reintentos y backoff;
- dominios de fallo correlacionados;
- safety y liveness;
- recuperación e incarnación;
- inyección reproducible de fallos.

## Transición al laboratorio

Construye un detector por heartbeat y crea escenarios de crash, retardo, pérdida, partición y recuperación. Para cada uno separa lo que el detector sospecha de lo que tu evidencia realmente demuestra.

## Empieza aquí

> **Antes de leer:** Un nodo permanece en silencio durante cinco segundos. ¿Qué puedes concluir de forma segura? Ahora supón que reinicia: ¿qué estado debe sobrevivir antes de que pueda reincorporarse con seguridad?

**Trae contigo:** Ambigüedad de los tiempos de espera, replicación, consenso e historiales observables de los capítulos anteriores.

**Este capítulo te prepara para:** Un manejo de fallos que incluya detección, reintentos acotados, recuperación durable, reproducción y reincorporación segura.

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>40 min–55 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>50 min–1 h 15 min</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>2 h 30 min–3 h · 8 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<p class="ds-workload-note"><strong>Alcance esencial:</strong> El núcleo del laboratorio es Pasos 1–6, Paso 8, checkpoint durable 8b y Pasos 10–13. El fallo unidireccional y la comparación de políticas adicionales del detector siguen como extensiones.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Leer lección →</a>
  <a class="ds-secondary-action" href="lab/">Abrir laboratorio</a>
</div>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../downloads/es/m07-failures.zip" download>Descargar capítulo + laboratorio para estudio sin conexión (.zip)</a></p>

## Qué aprenderás

- Define un modelo de fallos explícito que cubra crashes, omisiones, fallos temporales, particiones y fallos correlacionados.
- Explica por qué el silencio produce sospecha y no conocimiento perfecto de un fallo remoto.
- Construye y ajusta un detector de fallos basado en heartbeats e identifica el compromiso asociado a las falsas sospechas.
- Diseña experimentos reproducibles de crash, retardo, pérdida, partición, reintento y recuperación.
- Explica cómo recuperación, reincarnación, backoff y dominios de fallo afectan safety y liveness.

## Aprende trabajando la pregunta

1. Escribe tu respuesta a **Empieza aquí** antes de abrir la lección completa.
2. Lee hasta la siguiente predicción o traza; detente y resuélvela antes de revelar la explicación.
3. Trata la práctica guiada como un **banco de práctica**, no como una hoja para completar deprisa. Trabaja las trazas centrales hasta alcanzar el objetivo de práctica y vuelve después a los casos restantes.
4. Usa la comprobación para detectar vacíos y entra al laboratorio con una predicción falsable y con la evidencia que podría contradecirla.
5. Termina explicando qué estableció el experimento, qué no estableció y cómo cambia tu explicación del servicio acumulativo.

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../m08-replication-consistency/">← Replicación y consistencia</a>
<a class="ds-sequence-link next" href="../m11-transactions-sharding/">Tolerancia a fallos II — Transacciones, recuperación y estado distribuido →</a>
</nav>
