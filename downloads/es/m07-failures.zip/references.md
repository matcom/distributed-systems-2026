> **Vista de referencia.** Esta página ofrece contexto opcional; vuelve a la [Lección](../lesson/) para la ruta obligatoria.

## Esencial

- **●●● Unreliable Failure Detectors for Reliable Distributed Systems** — Chandra and Toueg. [paper](https://dl.acm.org/doi/10.1145/226643.226647)

## Recomendado

- **●●● End-to-End Arguments in System Design** — Saltzer, Reed, Clark. [paper](https://web.mit.edu/Saltzer/www/publications/endtoend/endtoend.pdf)

## Avanzado

Todavía no hay un recurso adicional asignado.

## Herramientas y práctica

- **●● tc-netem manual** — Linux man-pages project. [tool documentation](https://man7.org/linux/man-pages/man8/tc-netem.8.html)

## Explora

- **●●● Jepsen** — Kyle Kingsbury et al.. [testing resource](https://jepsen.io/)
