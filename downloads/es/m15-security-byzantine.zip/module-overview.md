<p class="ds-book-part">Parte V — Seguridad y operación</p>
<p class="ds-module-kicker">Capítulo 12</p>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 12 de 12</span>
    <span>100% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 100%"></span></div>
</div>
<p class="ds-guiding-question">¿Qué cambia cuando un participante puede no estar autorizado, estar comprometido, actuar maliciosamente, estar sobrecargado o ser simplemente difícil de diagnosticar?</p>

Cierra el libro ampliando los supuestos usados hasta ahora. Identifica a quién confías, autentica identidades de servicio, autoriza acciones, prueba replay y pregunta qué argumentos basados en crash dejan de ser válidos si un nodo miente. Al mismo tiempo, usa logs, métricas, trazas, distribuciones de latencia y señales de backpressure para saber qué está haciendo realmente el sistema.

## Ideas clave

- threat models y trust boundaries;
- autenticación y autorización;
- TLS e identidad de servicio;
- replay y validación de mensajes;
- mínimo privilegio;
- comportamiento bizantino y equivocación;
- consenso crash-fault frente a Byzantine;
- logs estructurados e IDs de correlación;
- métricas, trazas, latencia y backpressure;
- evidencia de auditoría y manejo de secretos.

## Transición al laboratorio

Threat-modela un servicio de capítulos anteriores, añade una frontera autenticada/autorizada, reproduce una solicitud no autorizada o reejecutada y diagnostica el resultado con evidencia operacional compacta.

## Empieza aquí

> **Antes de leer:** Una solicitud es lenta y finalmente tiene éxito, pero quien la envió no estaba autorizado. ¿Qué evidencia pertenece al diagnóstico de rendimiento, cuál a seguridad y cuál a ambos?

**Trae contigo:** El servicio completo construido a lo largo del curso: comunicación, nombres, coordinación, replicación, recuperación y evidencia.

**Este capítulo te prepara para:** Un sistema que puedas operar y defender: observable bajo carga, explícito respecto a la confianza y honesto sobre su modelo de fallos.

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>40 min–55 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>45 min–1 h 10 min</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>2 h–3 h · 8 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Leer lección →</a>
  <a class="ds-secondary-action" href="lab/">Abrir laboratorio</a>
</div>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../downloads/es/m15-security-byzantine.zip" download>Descargar capítulo + laboratorio para estudio sin conexión (.zip)</a></p>

## Qué aprenderás

- Dibuja límites de confianza explícitos y distingue autenticación, autorización y protección del transporte.
- Prueba replay, acciones no autorizadas y validación de mensajes en el límite de un servicio.
- Distingue consenso bajo fallos por crash de comportamiento bizantino como la equivocación.
- Usa logs estructurados, métricas, trazas, distribuciones de latencia y evidencia de backpressure para diagnosticar una ejecución distribuida.
- Indica qué afirmaciones operativas y de seguridad respaldan tus evidencias y qué supuestos permanecen fuera del diseño.

## Aprende trabajando la pregunta

1. Escribe tu respuesta a **Empieza aquí** antes de abrir la lección completa.
2. Lee hasta la siguiente predicción o traza; detente y resuélvela antes de revelar la explicación.
3. Trata la práctica guiada como un **banco de práctica**, no como una hoja para completar deprisa. Trabaja las trazas centrales hasta alcanzar el objetivo de práctica y vuelve después a los casos restantes.
4. Usa la comprobación para detectar vacíos y entra al laboratorio con una predicción falsable y con la evidencia que podría contradecirla.
5. Termina explicando qué estableció el experimento, qué no estableció y cómo cambia tu explicación del servicio acumulativo.

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../m11-transactions-sharding/">← Tolerancia a fallos II — Transacciones, recuperación y estado distribuido</a>
</nav>
