El contenido del curso es local-first, pero un ZIP de capítulo no puede contener todo el toolchain de un sistema operativo. Usa esta página como **contrato de entorno**: instala las herramientas que esperas utilizar antes de un período largo sin conexión y después descarga el paquete del capítulo correspondiente.

No necesitas todas las herramientas en todos los capítulos. La ruta obligatoria prefiere la herramienta más pequeña que haga visible el mecanismo y la evidencia.

## Entorno base

Ten disponibles estas herramientas desde el comienzo del curso.

| Herramienta | Para qué se usa | Preparación sin conexión |
|---|---|---|
| **Entorno capaz de ejecutar Linux** | procesos, archivos, señales, sockets, red local, namespaces y experimentos de fallo | Ten una instalación Linux, VM o entorno equivalente funcionando antes de desconectarte. |
| **Shell + herramientas estándar de procesos** | iniciar/detener servicios, inspeccionar archivos/procesos y automatizar experimentos reproducibles | Comprueba que los comandos normales de shell y control de procesos funcionan localmente. |
| **Git** | historial reproducible del código y procedencia de los experimentos | Clona/descarga los repositorios necesarios antes de desconectarte. |
| **Python 3** | herramientas del curso, laboratorios introductorios y scripts pequeños de análisis/apoyo | Instala Python con `venv` y `pip`; conserva el repositorio del curso localmente. |
| **Toolchain de Go** | servicios nativos, concurrencia, red, pruebas, race detector y profiling | Instala Go y verifica `go version` antes de los capítulos con servicios nativos. |
| **make** | comandos locales consistentes de laboratorio/pruebas cuando una tarea exporta un Makefile | Instálalo o usa el comando subyacente documentado cuando no esté disponible. |
| **curl** | sonda independiente HTTP/de aplicación | Instálalo localmente; al probar servicios locales no necesita Internet. |
| **Herramientas iproute2** (`ss`, `ip`, `tc`) | inspección de sockets, namespaces, configuración de red local y fallos con `tc netem` | Instala el paquete del sistema operativo que contiene estos comandos. Algunos experimentos con `tc`/namespaces requieren privilegios administrativos locales. |

El Calentamiento comprueba deliberadamente este entorno antes de que los capítulos posteriores dependan de él.

## Herramientas específicas de capítulos

Instálalas antes del capítulo o fase de proyecto que las utiliza.

| Herramienta | Uso principal | Estado en el curso |
|---|---|---|
| **Ray Core 2.58.0** | experimento de middleware del Capítulo 2 y Fase 1 del proyecto | Obligatorio solo para la fase con Ray. Después se elimina del runtime nativo. |
| **Bibliotecas gRPC** | implementación explícita de RPC | Ruta nativa recomendada en el capítulo de RPC. |
| **Protocol Buffers + `protoc`** | mensajes RPC tipados/versionados y bindings generados | Se usa con la ruta gRPC. |
| **grpcurl** | inspección independiente de un servicio gRPC local | Herramienta de diagnóstico recomendada para el capítulo de RPC. |
| **netcat / `nc`** | experimentos sencillos con endpoints locales y streams de bytes | Herramienta útil de inspección; no sustituye la evidencia de aplicación. |
| **OpenSSL** | inspección de certificados/claves y pequeños experimentos TLS locales | Se usa en el capítulo de seguridad/confianza; no hace falta una CA pública. |

Para Ray, el capítulo fija su dependencia en `modules/M02-ray-middleware/lab/starter/requirements.txt`. Si esperas estar sin conexión durante ese capítulo, descarga los paquetes Python mientras tengas conectividad:

```bash
python3 -m pip download -r modules/M02-ray-middleware/lab/starter/requirements.txt -d offline-wheels
```

Después, desde el directorio que contiene esos wheels:

```bash
python3 -m pip install --no-index --find-links offline-wheels -r modules/M02-ray-middleware/lab/starter/requirements.txt
```

Haz una preparación equivalente para cualquier dependencia Python adicional que el profesor asigne explícitamente.

## Inspección y evidencia de paquetes

Estas herramientas ayudan a responder preguntas concretas. No recopiles salida solo porque la herramienta esté disponible.

| Herramienta | Uso |
|---|---|
| **`ss`** | sockets en escucha/conectados y estado de endpoints |
| **`tcpdump`** | evidencia de paquetes en una interfaz/namespace seleccionado |
| **Wireshark** | inspección interactiva de paquetes cuando una GUI resulta útil |
| **`curl` / `grpcurl` / `nc`** | sondas independientes en diferentes capas de protocolo |

La captura de paquetes normalmente es opcional. Los logs de aplicación y el estado explícito suelen ser mejor evidencia para efectos de aplicación.

## Aislamiento e inyección de fallos

| Herramienta/mecanismo | Uso | Requisito |
|---|---|---|
| kill/restart de procesos | experimentos de crash y crash-recovery | Técnica esencial |
| delay/punto de fallo configurable en la aplicación | inyección determinista y reversible | Preferido cuando responde la pregunta |
| **`tc netem`** | delay, pérdida, duplicación y reordenamiento de red | Úsalo solo sobre una interfaz/namespace desechable que sepas restaurar |
| namespaces de red/proceso de Linux | aislamiento local y experimentos de partición | Úsalos cuando se necesite una frontera más fuerte que procesos ordinarios |
| **Docker o Podman** | fronteras reproducibles de procesos/contenedores | Opcional; se prefieren fallbacks con procesos locales cuando sean suficientes |

No conviertas Docker/Podman en un prerrequisito oculto para un laboratorio cuyo objetivo pueda demostrarse con procesos locales ordinarios.

## Corrección, concurrencia y rendimiento

| Herramienta | Uso |
|---|---|
| **`go test`** | comprobaciones deterministas en Go |
| **`go test -race`** | evidencia de accesos inseguros a memoria compartida en las ejecuciones probadas |
| **Go `pprof` / perfiles del runtime** | evidencia de CPU, memoria, goroutines y bloqueos |
| logs estructurados | IDs de solicitud/nodo, transiciones de estado, retries e historias de recuperación |
| pequeño generador de carga local | experimentos reproducibles de latencia/throughput/backpressure |

Una ejecución limpia de tests o del race detector solo establece lo que ejercitó. Las garantías distribuidas siguen necesitando invariantes explícitos, historias, escenarios de fallo y evidencia de recuperación.

## Herramientas de observabilidad

El curso enseña observabilidad sin exigir una plataforma hospedada.

- **OpenTelemetry** puede usarse para instrumentación de trazas/métricas y propagación de contexto.
- **Métricas estilo Prometheus** o un endpoint local ligero pueden usarse para tasas, colas, errores y uso de recursos.
- Un backend dedicado de trazas es opcional; trazas/logs locales compactos son suficientes para la ruta obligatoria.

No se requiere ningún servicio de monitorización de pago.

## Herramientas que no son prerrequisitos

La ruta obligatoria no depende de:

- infraestructura cloud de pago;
- productos SaaS de pago;
- APIs de IA de pago;
- Kubernetes;
- una cuenta en una autoridad certificadora pública;
- un backend de observabilidad hospedado;
- conexión permanente a Internet durante los laboratorios.

Los proyectos pueden justificar bibliotecas o infraestructura adicionales, pero no deben ocultar el mecanismo distribuido que se evalúa.

## Antes de desconectarte

Para los capítulos que planeas estudiar sin conexión:

1. descarga el ZIP del capítulo;
2. clona o actualiza tu repositorio de trabajo;
3. instala el toolchain base;
4. instala o descarga previamente las dependencias específicas del capítulo;
5. ejecuta una vez los checks de setup/versión del capítulo;
6. comprueba que las pruebas transparentes pueden iniciar localmente;
7. conserva en la máquina cualquier caché de lenguajes/módulos/paquetes necesaria.

Después de eso, la lectura obligatoria, el starter code, las pruebas públicas, los logs, las historias y los experimentos locales normales no deberían requerir Internet.

El **contrato sin conexión tiene por tanto dos partes**:

- el curso entrega en el paquete offline el material de aprendizaje, starter code, reportes y pruebas públicas;
- tú preparas en la máquina los compiladores, runtimes, paquetes de terceros y herramientas del sistema antes de desconectarte.
