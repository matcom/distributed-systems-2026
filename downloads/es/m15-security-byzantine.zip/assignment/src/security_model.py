"""Deterministic security-boundary helpers for M15 public tests.

The full laboratory still uses real service/TLS evidence. These helpers expose
portable authorization, replay, redaction, and BFT-quorum invariants.
"""

from __future__ import annotations

from typing import Iterable, Mapping


class Authorizer:
    def __init__(self, permissions: Mapping[str, Iterable[str]]):
        self.permissions = {principal: set(actions) for principal, actions in permissions.items()}

    def allowed(self, principal: str | None, action: str) -> bool:
        """Unauthenticated/unknown principals are denied; known principals need action permission."""
        raise NotImplementedError("TODO: separate identity from authorization")


class ReplayGuard:
    def __init__(self):
        self._results = {}

    def record_or_replay(self, principal: str, request_id: str, result):
        """Return (is_new, result).

        Replaying the same (principal, request_id) must return the original result
        without replacing it with a later proposed value.
        """
        raise NotImplementedError("TODO: implement stable replay/deduplication identity")


def bft_replica_count(faults: int) -> int:
    """Return the classic n = 3f + 1 replica requirement."""
    raise NotImplementedError("TODO: compute BFT replica requirement")


def validate_transition(current: str, requested: str, allowed: Mapping[str, Iterable[str]]) -> bool:
    """Return whether requested is an allowed semantic state transition."""
    raise NotImplementedError("TODO: implement application-level validation")


def redact_security_fields(fields: Mapping[str, object]) -> dict:
    """Redact common secret fields while preserving audit-relevant metadata."""
    raise NotImplementedError("TODO: redact password/token/private-key material")
