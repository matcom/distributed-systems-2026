# Laboratory — Security, Byzantine Failure, and Modern Distributed Systems

## Target

Threat-model one previously implemented distributed service, make one trust boundary explicit with authenticated communication, enforce one authorization or validation rule at the service boundary, reproduce an unauthorized or replayed request, and analyze how the system's guarantees change if one previously trusted replica becomes Byzantine.

This laboratory is not a full penetration test and does not require implementing PBFT. Its purpose is to make **operational evidence, security assumptions, and failure-model boundaries experimentally visible**.

## Core completion path

Complete Part 0, workflow Steps 1–12, Step 14, the required evidence, and the transparent tests.

Step 13 (agentic delegation analysis) is an **extension**. It connects the course to modern agent workloads without making another application domain part of the core security assessment.

## Required Part 0 — diagnose the service before threat-modeling it

Reuse the same service you will secure.

Create a repeatable local workload with a stable request rate. Record:

- throughput;
- p50/p95/p99 or an equivalent latency distribution;
- error/timeout count;
- queue depth or in-flight work;
- retry attempts;
- one correlation identifier that crosses the important service boundary.

Then introduce **one** controlled degradation:

- downstream delay;
- bounded worker capacity;
- one slow replica;
- artificial storage delay;
- another reproducible local bottleneck.

Before applying it, write two competing hypotheses about what the evidence will show.

After the run:

1. identify the slow path from logs/traces/metrics;
2. state which hypothesis the evidence supports;
3. identify one observation that remains ambiguous;
4. apply one bounded response such as backpressure, admission control, or a retry limit;
5. rerun the same workload and compare the distribution, not just the average.

No hosted telemetry service is required. Text logs, a small metrics endpoint, and locally generated timing data are sufficient.

Keep this evidence. Later in the lab you will check that the observability data needed for diagnosis does not expose secrets.

## Choose the base system

Reuse one Ray-free service from Chapter 4–Chapter 12. Suitable examples include:

- RPC key/value service;
- discovery registry;
- replicated store;
- Raft-backed key/value service;
- sharded transfer service;
- DHT/gossip service;
- build/task executor.

Do not add unrelated features merely to make the system appear more security-oriented.

## Required workflow

### 1. Draw the trust architecture

Create an architecture diagram showing:

- clients;
- public/internal services;
- storage/replicas;
- credentials;
- trust boundaries;
- untrusted inputs.

Mark which components share one administrative trust domain and which do not.

### 2. Write the threat model

At minimum identify:

- three assets;
- three principals/roles;
- three attacker capabilities;
- trusted components;
- one explicit out-of-scope threat.

Claims must be concrete enough to test or review.

### 3. Establish a baseline protected operation

Choose one operation with meaningful authority, such as:

```text
PUT protected-key
DELETE object
submit job
change membership
transfer value
```

Record normal successful behavior with structured evidence.

### 4. Test unauthenticated access

Invoke the protected operation without acceptable identity material.

Expected result:

- operation rejected;
- no protected state change;
- useful audit/log evidence without leaking secrets.

### 5. Test authenticated but unauthorized access

Use a valid principal that lacks permission for the selected resource/action.

Expected result:

- identity verification succeeds;
- authorization fails;
- protected state remains unchanged.

This step is mandatory because it demonstrates that authentication and authorization are separate mechanisms.

### 6. Add or inspect authenticated service communication

Protect at least one service-to-service or client-to-service boundary with TLS or mTLS, depending on the chosen trust model.

Inspect enough connection/certificate information to explain:

- which peer is authenticated;
- which authority or trust root is accepted;
- whether only server identity or both identities are checked.

Instructor-generated local certificates are sufficient. Public certificates are not required.

### 7. Test message/application validation

Send one syntactically valid but semantically invalid request, for example:

- invalid resource ownership;
- impossible state transition;
- value outside permitted range;
- malformed logical identifier;
- unauthorized membership change.

Show that transport security does not replace application validation.

### 8. Replay a valid mutation

Execute one legitimate side-effecting request with a stable request identifier.

Then replay it exactly.

Record whether the system:

- applies a second effect;
- returns the stored prior result;
- rejects the replay;
- cannot determine what happened.

Connect the result to Chapter 4/Chapter 10 deduplication semantics.

### 9. Secret/logging audit

Inspect logs and traces generated during the previous steps.

Verify that they do not expose prohibited secret material such as:

- private keys;
- passwords;
- bearer tokens;
- raw secret credentials.

Identify what security-relevant evidence *is* recorded, such as authenticated principal, operation, outcome, and request ID.

### 10. Change the failure model

Take one trusted replica/component and assume it can now behave Byzantine.

Construct at least one behavior such as:

```text
send state X to peer A
send state Y to peer B
```

or:

```text
claim write persisted without persisting it
```

or:

```text
forge/fabricate a job result within its existing authority
```

Do not necessarily implement the malicious behavior if it would require unsafe changes. A trace/state-machine analysis is sufficient.

State exactly which prior correctness argument breaks.

### 11. Compare crash and Byzantine tolerance

For the selected service, write a table:

| Property | Crash/partition fault | Byzantine component |
|---|---|---|
| Failure detection | | |
| Agreement/consistency | | |
| Data integrity | | |
| Required replicas/evidence | | |
| Existing design sufficient? | | |

The objective is to show that “fault tolerant” is incomplete without a failure model.

### 12. BFT quorum exercise

For a classic BFT setting, compute required replica count for at least:

```text
f = 1
f = 2
```

using the course relation `n >= 3f + 1`.

Explain why the existing three-node Raft cluster cannot simply be relabeled Byzantine tolerant.

### Extension 13. Agentic delegation analysis

Even if the chosen service is not an AI system, add a short architecture thought experiment:

```text
User → Agent → Your service
```

State:

- what identity reaches the service;
- what authority the agent receives;
- where authorization must be enforced;
- which side-effect operation requires retry-safe semantics;
- what should be audited.

This keeps agentic AI connected to ordinary distributed security rather than creating a separate AI-security curriculum.

### 14. Final-project security contract

Produce a compact contract for the final project containing:

- trust model;
- identity mechanism;
- authorization boundary;
- input-validation rule;
- secret-handling rule;
- replay/idempotency policy;
- assumed replica failure model;
- one explicitly unsupported adversary.

## Required evidence

Submit:

- trust-boundary diagram;
- threat-model table;
- logs for successful, unauthenticated, and unauthorized requests;
- certificate/peer-verification evidence where used;
- replay experiment evidence;
- state evidence proving rejected operations did not modify protected state;
- crash-vs-Byzantine comparison;
- final-project security contract.

Screenshots alone are insufficient when machine-readable logs/configuration can be provided.

## Testing policy

All official tests remain visible. Security tests should check observable properties such as rejection, state preservation, request deduplication, and configured identity expectations rather than depend on hidden credentials.

You may run the tests without limit and may add adversarial tests under `tests/student/`.

Executable public tests now live under `tests/official/`, with portable authorization/replay/BFT helpers in `starter/src/`. They verify deterministic boundary behavior without hidden credentials; TLS evidence, trust-boundary analysis, and Byzantine reasoning still require the experiments and review described above.

## AI use

AI assistants and coding agents are permitted. They may assist with threat-model brainstorming, configuration review, or protocol analysis.

You must not treat an AI security review as proof. At least one AI-generated security claim must be classified and checked against the architecture, implementation, specification, or an experiment.

The course AI disclosure remains mandatory for assessed work.