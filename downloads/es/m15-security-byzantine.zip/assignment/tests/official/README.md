# Planned Public Tests — M15 Security, Byzantine Failure, and Modern Distributed Systems

These cases define the intended transparent test surface. No hidden credentials or hidden cases are planned.

Executable public tests are provided in this directory together with portable authorization/replay/BFT helpers under `starter/src/`. They check deterministic boundary invariants without introducing hidden credentials or claiming a complete security audit.

Broader TLS, trust-boundary, and Byzantine analyses remain evidence-based.

## T1 — protected operation accepts authorized principal

A valid authorized principal can execute the selected protected operation and the expected state transition occurs.

## T2 — unauthenticated request is rejected

The same protected operation without acceptable identity material is rejected and protected state remains unchanged.

## T3 — authenticated but unauthorized request is rejected

A valid principal without the required permission is authenticated but denied authorization. Protected state remains unchanged.

## T4 — authorization decision is auditable

The result of a protected request produces machine-readable evidence containing at least:

```text
principal identity
operation/resource
allow/deny outcome
request identity
```

without emitting prohibited secret material.

## T5 — semantic validation rejects invalid transition

A syntactically valid but semantically invalid request is rejected and does not modify protected state.

## T6 — replay fixture preserves declared semantics

Replay the same authenticated side-effecting request with the same logical request identifier.

The result must match the service's declared policy, for example:

- one logical effect with prior result returned;
- explicit replay rejection;
- another documented safe behavior.

A duplicate silent effect fails this fixture when the operation is declared retry-safe.

## T7 — secret redaction fixture

Given instructor-provided synthetic credential values, logs/traces must not include fields explicitly classified as prohibited secrets.

This narrow check does not prove absence of every accidental disclosure.

## T8 — TLS identity expectation

For the protected TLS/mTLS boundary, connection configuration exposes enough deterministic local state to verify the expected peer identity/trust root.

The test should use instructor-generated local certificates rather than public infrastructure.

## T9 — wrong peer/trust fixture fails

A client or peer configured with an untrusted certificate/authority must not successfully establish the protected authenticated relationship.

## T10 — rejected operations preserve state

For unauthenticated, unauthorized, and semantically invalid fixtures, compare canonical protected state before and after and verify no prohibited mutation occurred.

## T11 — BFT quorum calculation fixture

A small pure-function or analysis test verifies the course relation:

```text
n = 3f + 1
```

for at least `f=1` and `f=2`.

This checks reasoning support code only; it does not make the service Byzantine tolerant.

## T12 — failure-model declaration exists

The implementation/report metadata identifies the assumed node failure model and does not claim Byzantine tolerance solely because crash/partition tests pass.

## Student extensions

Useful additions include:

- resource-level authorization matrices;
- stale/revoked credential cases;
- certificate rotation fixtures;
- request nonce/timestamp replay policies;
- membership-change authorization;
- audit-log completeness checks;
- fuzz/property tests for semantic validation;
- principal propagation through an agent/proxy hop.

Students should avoid adding destructive exploit code merely to make the laboratory appear more security-oriented. The target is boundary reasoning and observable guarantees.