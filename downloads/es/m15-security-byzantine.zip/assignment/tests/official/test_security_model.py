import unittest

from security_model import (
    Authorizer,
    ReplayGuard,
    bft_replica_count,
    redact_security_fields,
    validate_transition,
)


class SecurityBoundaryTests(unittest.TestCase):
    def test_authorized_principal_is_allowed(self):
        auth = Authorizer({"alice": {"read", "write"}, "bob": {"read"}})
        self.assertTrue(auth.allowed("alice", "write"))

    def test_unauthenticated_principal_is_denied(self):
        auth = Authorizer({"alice": {"write"}})
        self.assertFalse(auth.allowed(None, "write"))

    def test_authenticated_but_unauthorized_is_denied(self):
        auth = Authorizer({"bob": {"read"}})
        self.assertFalse(auth.allowed("bob", "write"))

    def test_replay_returns_original_result(self):
        guard = ReplayGuard()
        self.assertEqual(guard.record_or_replay("alice", "r1", {"value": 1}), (True, {"value": 1}))
        self.assertEqual(guard.record_or_replay("alice", "r1", {"value": 999}), (False, {"value": 1}))

    def test_request_identity_is_scoped_by_principal(self):
        guard = ReplayGuard()
        self.assertEqual(guard.record_or_replay("alice", "r1", "A"), (True, "A"))
        self.assertEqual(guard.record_or_replay("bob", "r1", "B"), (True, "B"))

    def test_semantic_transition_validation(self):
        allowed = {"queued": {"running", "cancelled"}, "running": {"complete", "failed"}}
        self.assertTrue(validate_transition("queued", "running", allowed))
        self.assertFalse(validate_transition("complete", "running", allowed))

    def test_bft_replica_relation(self):
        self.assertEqual(bft_replica_count(0), 1)
        self.assertEqual(bft_replica_count(1), 4)
        self.assertEqual(bft_replica_count(2), 7)
        with self.assertRaises(ValueError):
            bft_replica_count(-1)

    def test_secret_fields_are_redacted_but_audit_fields_remain(self):
        event = {
            "principal": "alice",
            "operation": "write",
            "request_id": "r1",
            "password": "pw",
            "token": "tok",
            "private_key": "key",
        }
        safe = redact_security_fields(event)
        self.assertEqual(safe["principal"], "alice")
        self.assertEqual(safe["operation"], "write")
        self.assertEqual(safe["request_id"], "r1")
        self.assertEqual(safe["password"], "<redacted>")
        self.assertEqual(safe["token"], "<redacted>")
        self.assertEqual(safe["private_key"], "<redacted>")


if __name__ == "__main__":
    unittest.main()
