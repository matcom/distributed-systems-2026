Add your own transparent tests here.
