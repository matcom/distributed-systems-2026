# Laboratory Report — Security, Byzantine Failure, and Modern Distributed Systems

## 1. Base system

Identify the Ray-free service reused for this laboratory.

Document:

- service topology;
- node/process count;
- relevant API operations;
- identity mechanism;
- trust-domain assumptions;
- exact startup/teardown commands.

## 2. Trust architecture

Include an architecture diagram showing:

- clients;
- public/internal services;
- replicas/storage;
- credentials;
- trust boundaries;
- untrusted input paths.

State which components share one administrative trust domain.

## 3. Threat model

Complete a table containing at least:

| Category | Entries |
|---|---|
| Assets | |
| Principals/roles | |
| Attacker capabilities | |
| Trusted components | |
| Explicitly out of scope | |

Use concrete, testable statements.

## 4. Protected operation

Identify one operation requiring meaningful authority, such as:

```text
PUT protected-key
DELETE object
submit job
change membership
transfer value
```

Record the expected authorized behavior and the state that should change.

## 5. Unauthenticated request

Record:

- request shape;
- authentication material omitted;
- returned status/error;
- relevant audit log;
- protected state before/after.

Explain why rejection is attributable to missing/invalid identity rather than authorization.

## 6. Authenticated but unauthorized request

Use a valid identity lacking the selected permission.

Record evidence that:

- authentication succeeded;
- authorization failed;
- protected state did not change.

Explain why this distinction matters.

## 7. TLS or mTLS boundary

Document the protected communication boundary.

State:

- which endpoint authenticates which peer;
- accepted trust root/authority;
- whether authentication is one-way TLS or mutual TLS;
- certificate identity checked;
- relevant local configuration.

Include machine-readable verification evidence where practical.

## 8. Application validation

Describe one request that is syntactically valid but semantically invalid.

Record:

- request;
- validation rule;
- response;
- state before/after;
- audit/log evidence.

Explain why transport security cannot replace this application-level check.

## 9. Replay experiment

Execute one valid side-effecting request using a stable logical request identifier, then replay it.

Record whether the implementation:

- applies a second effect;
- returns the stored prior result;
- rejects the replay;
- remains ambiguous.

Connect the result to the retry/deduplication semantics studied in M03 and M10.

## 10. Secret/telemetry audit

Inspect logs and traces from the previous experiments.

List prohibited values that must not appear, for example:

- private keys;
- passwords;
- bearer tokens;
- raw secret credentials.

List the security-relevant fields that should remain observable, such as:

- principal identity;
- operation;
- resource;
- outcome;
- request ID;
- authorization decision.

## 11. Byzantine thought experiment

Choose one previously trusted replica/component and allow it to behave Byzantine.

Describe one concrete behavior, for example:

```text
send X to peer A and incompatible Y to peer B
```

or:

```text
claim durable success without persisting the mutation
```

State exactly which prior correctness argument or invariant no longer holds.

Implementation of unsafe malicious behavior is not required when analysis is sufficient.

## 12. Crash versus Byzantine comparison

Complete:

| Property | Crash/partition fault | Byzantine component |
|---|---|---|
| Detection | | |
| Agreement/consistency | | |
| Data integrity | | |
| Required replicas/evidence | | |
| Existing design sufficient? | | |

Explain why the phrase “fault tolerant” is incomplete without a failure model.

## 13. BFT quorum reasoning

For the classic relation:

```text
n >= 3f + 1
```

compute the minimum replica count for:

- `f = 1`;
- `f = 2`.

Explain why the three-node Raft configuration used earlier cannot simply be called Byzantine tolerant.

## 14. Agentic delegation analysis

Analyze:

```text
User → Agent → Service
```

State:

- which identity reaches the service;
- what authority the agent receives;
- where authorization is enforced;
- which operation requires retry-safe semantics;
- what should be audited;
- one capability the agent must not inherit implicitly.

## 15. Final-project security contract

Provide:

- trust model;
- identity mechanism;
- authorization boundary;
- input-validation rule;
- secret-handling rule;
- replay/idempotency policy;
- assumed replica failure model;
- one explicitly unsupported adversary.

## 16. AI-use disclosure

Record:

- tools used;
- tasks delegated;
- security configuration/code affected;
- verification performed;
- at least one AI-generated security claim that was checked, refined, or rejected.

AI-generated threat lists or security reviews are hypotheses, not proof.

## 17. Limits

State what the exercise does not prove, for example:

- resistance to all implementation vulnerabilities;
- production PKI correctness;
- cryptographic protocol soundness beyond libraries used;
- Byzantine tolerance if no BFT protocol was implemented;
- protection against compromised administrators;
- side-channel resistance.

## 18. Final technical claim

Write one paragraph answering:

> Which trust boundary did you make explicit, what evidence shows authentication/authorization/replay behavior, how does the guarantee change when a trusted component becomes Byzantine, and what security contract should the final project defend?