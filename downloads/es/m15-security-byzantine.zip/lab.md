<div class="ds-lesson-banner">
  <div><span>Laboratorio obligatorio</span><strong>Capítulo 12</strong></div>
  <div><span>Modelo de evidencia</span><strong>predecir → ejecutar → observar → explicar</strong></div>
  <div><span>Verificación</span><strong>8 pruebas públicas transparentes + evidencia</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 12 de 12</span>
    <span>100% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 100%"></span></div>
</div>
<p class="ds-back-link"><a href="../quick-check/">← Volver a la comprobación</a></p>

> **Antes de comenzar:** Completa los pasos de práctica guiada y comprobación de conocimientos. Ya deberías poder formular una predicción y nombrar la evidencia que la apoyaría o contradeciría. Si no, [vuelve a la comprobación](../quick-check/) y revisa la lección donde haga falta.

## Objetivo

Construye el threat model de un servicio distribuido que ya implementaste, vuelve explícito un límite de confianza mediante comunicación autenticada, aplica una regla de autorización o validación en el servicio, reproduce una solicitud no autorizada o repetida y analiza cómo cambian las garantías si una réplica antes confiable pasa a comportarse de forma bizantina.

No es un pentest completo y no exige implementar PBFT. El propósito es volver **visibles mediante evidencia los supuestos de seguridad, los límites del modelo de fallos y el comportamiento operacional**.

## Ruta esencial

Completa la Parte 0, los Pasos 1–12, el Paso 14, la evidencia requerida y las pruebas transparentes.

El Paso 13 sobre agentes es una **extensión**.

## Parte 0 — diagnostica antes de construir el threat model

Reutiliza el servicio que vas a proteger.

Crea una carga local repetible y registra:

- rendimiento;
- p50/p95/p99 o distribución equivalente;
- errores/timeouts;
- profundidad de cola o trabajo en vuelo;
- intentos de reintento;
- un ID de correlación que cruce el límite importante.

Introduce **una** degradación controlada:

- retraso aguas abajo;
- capacidad acotada de workers;
- una réplica lenta;
- retraso artificial de almacenamiento;
- otro cuello de botella reproducible.

Antes escribe dos hipótesis competidoras.

Después:

1. identifica el camino lento con logs/trazas/métricas;
2. indica qué hipótesis apoya la evidencia;
3. identifica una observación que siga siendo ambigua;
4. aplica una respuesta acotada como backpressure, control de admisión o límite de reintentos;
5. repite la misma carga y compara la distribución, no solo el promedio.

No se necesita telemetría alojada. Logs de texto, un endpoint pequeño de métricas y tiempos generados localmente bastan.

Conserva esta evidencia y comprueba después que no expone secretos.

## Elige el sistema base

Reutiliza un servicio sin Ray de los capítulos anteriores:

- clave/valor por RPC;
- registro de descubrimiento;
- almacenamiento replicado;
- servicio con Raft;
- transferencia shardeada;
- DHT/gossip;
- ejecutor de builds/tareas.

No añadas funcionalidades sin relación solo para hacerlo parecer «de seguridad».

## Workflow requerido

### 1. Dibuja la arquitectura de confianza

Muestra:

- clientes;
- servicios públicos/internos;
- almacenamiento/réplicas;
- credenciales;
- límites de confianza;
- entradas no confiables.

Marca qué componentes comparten dominio administrativo y cuáles no.

### 2. Escribe el threat model

Identifica al menos:

- tres activos;
- tres principales/roles;
- tres capacidades de atacante;
- componentes confiables;
- una amenaza explícitamente fuera de alcance.

Las afirmaciones deben ser concretas y revisables.

### 3. Establece una operación protegida

Elige una operación con autoridad significativa:

```text
PUT protected-key
DELETE object
submit job
change membership
transfer value
```

Registra el comportamiento normal satisfactorio.

### 4. Prueba acceso no autenticado

Invoca la operación sin identidad aceptable.

Resultado esperado:

- rechazo;
- ningún cambio de estado protegido;
- evidencia de auditoría útil sin filtrar secretos.

### 5. Prueba autenticado pero no autorizado

Usa un principal válido que no tenga permiso para ese recurso/acción.

Resultado esperado:

- autenticación satisfactoria;
- autorización fallida;
- estado protegido sin cambios.

Este paso demuestra que ambos mecanismos son distintos.

### 6. Añade o inspecciona comunicación autenticada

Protege al menos un límite servicio-servicio o cliente-servicio con TLS o mTLS según el modelo.

Inspecciona suficiente información para explicar:

- qué peer se autentica;
- qué autoridad/raíz se acepta;
- si se valida solo el servidor o ambas identidades.

Certificados locales generados por el profesor son suficientes.

### 7. Prueba validación de aplicación

Envía una solicitud sintácticamente válida pero semánticamente inválida:

- propiedad de recurso incorrecta;
- transición imposible;
- valor fuera de rango;
- ID lógico malformado;
- cambio de membresía no autorizado.

Demuestra que TLS no sustituye la validación de aplicación.

### 8. Reproduce una mutación válida

Ejecuta una solicitud con efecto y un ID estable.

Reprodúcela exactamente.

Registra si el sistema:

- aplica un segundo efecto;
- devuelve el resultado anterior;
- rechaza el replay;
- no puede determinar qué ocurrió.

Conecta el resultado con deduplicación de RPC/fallos.

### 9. Auditoría de logs y secretos

Inspecciona logs/trazas.

Verifica que no exponen:

- claves privadas;
- contraseñas;
- bearer tokens;
- credenciales secretas crudas.

Indica qué evidencia relevante sí se registra: principal autenticado, operación, resultado, ID de solicitud, etc.

### 10. Cambia el modelo de fallos

Supón que un componente antes confiable puede comportarse de forma bizantina.

Construye al menos una conducta:

```text
envía estado X al peer A
envía estado Y al peer B
```

o:

```text
afirma que una escritura fue persistida sin hacerlo
```

o:

```text
fabrica un resultado de trabajo dentro de su autoridad actual
```

No necesitas implementar comportamiento malicioso si implicaría cambios inseguros. Basta análisis de traza/máquina de estados.

Indica qué argumento previo de corrección deja de ser válido.

### 11. Compara tolerancia crash y bizantina

| Propiedad | Fallo crash/partición | Componente bizantino |
|---|---|---|
| detección de fallo | | |
| acuerdo/consistencia | | |
| integridad de datos | | |
| réplicas/evidencia necesarias | | |
| ¿basta el diseño actual? | | |

El objetivo es mostrar que «tolerante a fallos» no está completo sin el modelo.

### 12. Ejercicio de quórum BFT

Calcula el número de réplicas para:

```text
f = 1
f = 2
```

con `n >= 3f + 1`.

Explica por qué un clúster Raft de tres nodos no puede simplemente renombrarse «Byzantine tolerant».

### Extensión 13. Análisis de delegación con agente

Añade un experimento mental:

```text
Usuario → Agente → Tu servicio
```

Indica:

- qué identidad llega al servicio;
- qué autoridad recibe el agente;
- dónde se aplica autorización;
- qué operación con efectos exige semántica segura de reintento;
- qué debe auditarse.

### 14. Contrato de seguridad del proyecto final

Produce un contrato compacto que incluya:

- modelo de confianza;
- mecanismo de identidad;
- límite de autorización;
- regla de validación de entrada;
- regla de manejo de secretos;
- política de replay/idempotencia;
- modelo de fallo asumido para las réplicas;
- un adversario explícitamente no soportado.

## Evidencia requerida

Entrega:

- diagrama de límites de confianza;
- tabla de threat model;
- logs de solicitudes satisfactoria, no autenticada y no autorizada;
- evidencia de verificación de peer/certificado;
- experimento de replay;
- evidencia de estado que demuestre que operaciones rechazadas no modificaron estado protegido;
- comparación crash frente a Byzantine;
- contrato de seguridad del proyecto final.

Las capturas solas no bastan cuando pueden proporcionarse logs/configuración legibles por máquinas.

## Política de pruebas

Todas las pruebas oficiales son visibles. Las pruebas de seguridad verifican propiedades observables como rechazo, preservación de estado, deduplicación y expectativas de identidad configuradas; no dependen de credenciales ocultas.

Puedes ejecutarlas sin límite y añadir pruebas adversariales en `tests/student/`.

Las pruebas públicas están en `tests/official/`, con helpers portables de autorización/replay/BFT en `starter/src/`. TLS, límites de confianza y razonamiento Byzantine requieren además los experimentos/revisión descritos.

## Uso de IA

Se permiten asistentes y agentes para lluvia de ideas del threat model, revisión de configuración o análisis de protocolos.

Una revisión de IA no es prueba. Al menos una afirmación de seguridad producida por IA debe clasificarse y comprobarse frente a arquitectura, implementación, especificación o experimento.

La declaración de uso de IA sigue siendo obligatoria.

## Termina el capítulo

Reproduce el resultado importante desde un inicio limpio. Después vuelve a tu predicción inicial: explica qué cambió, qué evidencia provocó el cambio y qué incertidumbre queda. Un comando exitoso o una captura no bastan cuando la afirmación trata de retries, orden, durabilidad, consistencia, recovery, seguridad o rendimiento.

<div class="ds-next-action">
  <span>Capítulo completo</span>
  <strong>Continuar el curso</strong>
  <a href="../../../modules/">Volver al contenido del curso →</a>
</div>

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../../m11-transactions-sharding/">← Tolerancia a fallos II — Transacciones, recuperación y estado distribuido</a>
</nav>
