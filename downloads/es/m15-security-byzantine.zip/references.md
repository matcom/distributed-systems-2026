> **Vista de referencia.** Esta página ofrece contexto opcional; vuelve a la [Lección](../lesson/) para la ruta obligatoria.

## Esencial

- **●●● Practical Byzantine Fault Tolerance** — Miguel Castro and Barbara Liskov. [paper](https://pmg.csail.mit.edu/papers/osdi99.pdf)

## Recomendado

- **●●● RFC 8446 — The Transport Layer Security (TLS) Protocol Version 1.3** — IETF. [standard](https://www.rfc-editor.org/rfc/rfc8446)

## Avanzado

Todavía no hay un recurso adicional asignado.

## Herramientas y práctica

- **●● OpenSSL Documentation** — OpenSSL Project. [tool documentation](https://docs.openssl.org/)

## Explora

- **●●● A2A Protocol Specification** — A2A Project. [protocol reference](https://a2a-protocol.org/)
