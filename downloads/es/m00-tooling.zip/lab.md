<div class="ds-lesson-banner">
  <div><span>Laboratorio obligatorio</span><strong>Calentamiento</strong></div>
  <div><span>Modelo de evidencia</span><strong>predecir → ejecutar → observar → explicar</strong></div>
  <div><span>Verificación</span><strong>7 pruebas públicas transparentes + evidencia</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Calentamiento</span>
    <span>0% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 0%"></span></div>
</div>
<p class="ds-back-link"><a href="../quick-check/">← Volver a la comprobación</a></p>

> **Antes de comenzar:** Completa los pasos de práctica guiada y comprobación de conocimientos. Ya deberías poder formular una predicción y nombrar la evidencia que la apoyaría o contradeciría. Si no, [vuelve a la comprobación](../quick-check/) y revisa la lección donde haga falta.

## Propósito

Antes de construir un algoritmo distribuido, demuestra que puedes crear, observar, perturbar y restaurar una pequeña ejecución distribuida en tu propia máquina.

Ejecutarás tres procesos de servicio independientes, identificarás su estado de procesos y sockets, enviarás solicitudes con identificadores estables, terminarás un nodo, introducirás un retardo controlado y producirás un informe basado en evidencia.

La aplicación es deliberadamente sencilla. La habilidad evaluada es el **control experimental y la observación**.

## Objetivo de aprendizaje

Al terminar debes poder responder:

> ¿Qué nodo atendió la solicitud `R`, qué proceso/endpoint representaba ese nodo, qué cambió al terminar o ralentizar un nodo y qué evidencia demuestra cada afirmación?

## Entorno

Obligatorio:

- Python 3
- Git

Muy recomendado:

- `ss`
- `curl`

Opcional para una observación más profunda:

- `tcpdump` o Wireshark
- Docker/Podman
- `tc netem`

El recorrido obligatorio no requiere privilegios de root.

## Contrato mínimo del servicio

Implementa un nodo HTTP y un cliente deliberadamente pequeños. Mantén la lógica de aplicación tan simple que el foco siga estando en la evidencia del sistema.

Estructura sugerida:

```text
src/node.py
src/client.py
src/protocol.py
```

Cada nodo debe exponer:

```text
GET /health
GET /work?value=<integer>
```

`/work` devuelve el doble del entero recibido después de un retardo configurable opcional. El nodo debe aceptar una cabecera estable `X-Request-ID` e incluir el mismo identificador en los eventos estructurados del servidor.

La forma de línea de comandos usada en el resto del laboratorio es:

```text
node.py --node-id <id> --port <port> [--delay-ms <ms>]
client.py --port <port> --value <integer> --request-id <id> [--timeout-ms <ms>]
```

Puedes implementar este contrato con la biblioteca estándar de Python o con otra implementación local pequeña aprobada por el profesor. No se pretende construir una aplicación distribuida interesante; necesitamos un objetivo estable que podamos observar.

## Paso 1 — Establece el estado del repositorio

Registra:

```bash
git status --short
git rev-parse --short HEAD
```

Si el laboratorio exportado todavía no está committeado, indícalo claramente en el informe en lugar de inventar un identificador de revisión.

## Paso 2 — Inicia tres nodos

Usa tres terminales:

```bash
python3 src/node.py --node-id a --port 8101
python3 src/node.py --node-id b --port 8102
python3 src/node.py --node-id c --port 8103
```

Predice antes de inspeccionar: ¿cuántos procesos de servidor Python y cuántos sockets TCP en escucha deberían existir?

Recoge evidencia:

```bash
pgrep -af 'src/node.py'
ss -lntp | grep -E '8101|8102|8103'
```

Si tu plataforma no muestra la propiedad del proceso mediante `ss`, registra la evidencia de sockets disponible y usa evidencia de procesos por separado.

## Paso 3 — Envía una solicitud correlacionada

```bash
python3 src/client.py --port 8102 --value 21 --request-id m00-r1
```

El resultado debe ser `42`.

Busca en la salida estructurada el evento del servidor con `request_id=m00-r1`.

Tu informe debe conectar:

```text
solicitud del cliente
    ↓
endpoint de red
    ↓
proceso / ID lógico del servidor
    ↓
evento de la solicitud en el servidor
    ↓
respuesta
```

## Paso 4 — Confirma con un cliente independiente

Usa `curl`:

```bash
curl -s 'http://127.0.0.1:8102/work?value=7' -H 'X-Request-ID: m00-curl-1'
```

Explica qué establece esta observación que no establece por sí solo el cliente proporcionado.

## Paso 5 — Observa el tráfico

Si la captura de paquetes está disponible y permitida, captura loopback en otra terminal:

```bash
sudo tcpdump -i lo -nn tcp port 8102
```

Genera una solicitud y detén la captura.

Registra:

- interfaz de captura;
- direcciones y puertos cliente/servidor;
- si puedes identificar tráfico de conexión/solicitud;
- una limitación de lo que demuestra la captura.

Si no puedes capturar paquetes, usa la ruta de evidencia basada en procesos, sockets y logs. No tener root no impide completar el laboratorio.

## Paso 6 — Termina un nodo

Antes de terminar B, predice el resultado de:

```bash
python3 src/client.py --port 8102 --value 5 --request-id m00-dead
```

Termina el proceso B y vuelve a recoger:

```bash
pgrep -af 'src/node.py'
ss -lntp | grep -E '8101|8102|8103'
```

Ejecuta el cliente.

Explica por qué el fallo de B no implica el fallo de A o C.

Indica también el dominio de fallo físico que comparten los tres procesos.

## Paso 7 — Reinicia con retardo artificial

Reinicia B con 700 ms de retardo de aplicación:

```bash
python3 src/node.py --node-id b --port 8102 --delay-ms 700
```

Ejecuta:

```bash
python3 src/client.py --port 8102 --value 8 --request-id m00-slow --timeout-ms 1500
```

Después usa deliberadamente un timeout menor:

```bash
python3 src/client.py --port 8102 --value 8 --request-id m00-timeout --timeout-ms 200
```

El segundo comando debe fallar localmente aunque el servidor todavía pueda terminar la operación.

Explica con precisión qué demuestra el timeout y qué **no** demuestra.

## Paso 8 — Retardo de red opcional

Si dispones de una interfaz o namespace desechable y sabes restaurarlo, repite el experimento con `tc netem` en lugar de `--delay-ms`.

**No** apliques una alteración sobre una interfaz de producción o de administración remota.

Documenta la interfaz exacta y el comando de limpieza.

## Paso 9 — Pruebas transparentes

El servicio y cliente iniciales están en:

```text
starter/src/
```

Los casos públicos ejecutables están en:

```text
tests/official/
```

Ejecuta el runner transparente del curso. La suite pública comprueba únicamente comportamiento que puedes inspeccionar: parseo de solicitudes, validación de configuración, campos de eventos estructurados, respuesta de salud, trabajo determinista, propagación del identificador y manejo de solicitudes malformadas.

Añade al menos un caso en:

```text
tests/student/
```

Buenas extensiones:

- otro entero negativo;
- solicitud sin request ID;
- una ruta desconocida;
- otra aserción sobre eventos estructurados.

La terminación de procesos, los retardos, la inspección de sockets y la captura de paquetes permanecen como experimentos basados en informe: allí lo importante es interpretar un sistema en ejecución.

No existen casos ocultos.

## Paso 10 — Limpieza

Detén todos los procesos restantes.

Confirma que los puertos del laboratorio ya no están en escucha.

Un experimento reproducible incluye su limpieza.

## Informe obligatorio

Completa `REPORT.md` con:

1. entorno y herramientas disponibles;
2. topología lógica y dominio de fallo físico;
3. predicción y evidencia de la línea base;
4. una traza correlacionada de solicitud;
5. predicción/evidencia/explicación al terminar un nodo;
6. predicción/evidencia/explicación al ralentizarlo y agotar timeout;
7. evidencia opcional de paquetes/red;
8. una prueba escrita por ti;
9. declaración del uso de IA;
10. una explicación corta de qué puedes demostrar antes de afirmar «el sistema distribuido está roto».

## Énfasis de evaluación

Una buena entrega **no** necesita código de aplicación elaborado.

Sí debe demostrar que distingues:

- estado de procesos;
- estado de sockets;
- comportamiento de aplicación;
- comportamiento temporal;
- evidencia de red;
- sospecha local frente a hecho remoto.

## Uso de IA

Se permiten asistentes de IA y agentes de programación.

Si un asistente propone la causa de un fallo, incluye la evidencia local con la que confirmaste o descartaste esa hipótesis. Una explicación generada por IA no sustituye una observación de tu experimento.

## Termina el capítulo

Reproduce el resultado importante desde un inicio limpio. Después vuelve a tu predicción inicial: explica qué cambió, qué evidencia provocó el cambio y qué incertidumbre queda. Un comando exitoso o una captura no bastan cuando la afirmación trata de retries, orden, durabilidad, consistencia, recovery, seguridad o rendimiento.

<div class="ds-next-action">
  <span>Capítulo completo</span>
  <strong>Continuar el curso</strong>
  <a href="../../m01-distributed-systems/">Pensar en sistemas distribuidos →</a>
</div>

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link next" href="../../m01-distributed-systems/">Pensar en sistemas distribuidos →</a>
</nav>
