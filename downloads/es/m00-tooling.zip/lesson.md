<p class="ds-book-part">Calentamiento</p>
<div class="ds-lesson-banner">
  <div><span>Paso del curso</span><strong>Calentamiento</strong></div>
  <div><span>Lectura esencial</span><strong>25 min–35 min</strong></div>
  <div><span>Ruta obligatoria</span><strong>Leer → Objetivo de práctica → Comprobar → Laboratorio</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Calentamiento</span>
    <span>0% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 0%"></span></div>
</div>

> **Pregunta guía:** ¿Cómo observas, controlas y sometes a fallos de forma segura un sistema distribuido en una sola máquina?

## Antes de leer

> Tres procesos de servicio se ejecutan en una misma computadora. Si un proceso termina, ¿qué falló de forma independiente? Si la computadora pierde la alimentación, ¿qué falló al mismo tiempo?

Escribe primero una respuesta breve. No necesitas acertar todavía: necesitas una predicción que puedas revisar a medida que el capítulo te dé mejores modelos y evidencia.

**Usa lo que ya sabes:** Uso básico de la línea de comandos de Linux, procesos, archivos y Git.

## Mapa de carga de trabajo

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>25 min–35 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>25 min–40 min</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>1 h–1 h 30 min · 7 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../../downloads/es/m00-tooling.zip" download>Descargar lección + práctica + laboratorio para estudio sin conexión (.zip)</a></p>

## Por qué importa este capítulo

Los experimentos con sistemas distribuidos pueden fallar por razones que no tienen nada que ver con el algoritmo que quieres estudiar. Un proceso quizá nunca inició. Dos servicios pueden intentar usar el mismo puerto. Un contenedor puede estar en otra red. Un timeout puede ser demasiado pequeño. Un cliente puede estar hablando con un proceso viejo. Una captura puede observar la interfaz equivocada. Una prueba puede depender de estado dejado por una ejecución anterior.

Antes de estudiar RPC, relojes lógicos, replicación, Raft, DHT, CRDT o transacciones necesitamos responder de manera reproducible una pregunta más básica:

> **¿Qué está ejecutándose, dónde, cómo se comunica y qué evidencia respalda esa afirmación?**

El Calentamiento establece la disciplina experimental que usarás durante todo el curso. No necesitas memorizar comandos; necesitas saber qué observación responde qué pregunta, cómo levantar un pequeño clúster local y cómo cambiar una sola condición sin perder la capacidad de explicar el resultado.

> **Detente y predice.** Un cliente imprime `timeout`. ¿Demuestra eso que el servidor murió? No. El servidor puede estar lento; la solicitud o la respuesta pueden estar retrasadas; la dirección puede ser incorrecta; el proceso puede estar vivo pero sobrecargado; incluso puede haber terminado la operación antes de que desapareciera la respuesta. El timeout es evidencia sobre cuánto esperó el cliente, no un diagnóstico completo.

## 1. Una computadora basta para estudiar muchos fallos distribuidos

Un sistema de producción puede ocupar muchas máquinas, racks, zonas y redes. Para aprender los mecanismos fundamentales no necesitas reproducir el datacenter completo.

En una sola máquina Linux puedes ejecutar varios procesos independientes:

```text
terminal/proceso A          terminal/proceso B          terminal/proceso C
      :8101                       :8102                       :8103
        │                           │                           │
        └──────────── localhost / red virtual ─────────────────┘
```

Cada proceso tiene su propio:

- contador de programa y pila;
- heap y variables locales;
- descriptores de archivo y sockets;
- logs;
- ciclo de vida;
- visión del tiempo;
- archivos durables si escribe alguno.

Todos comparten kernel y hardware, por lo que el experimento no equivale a un datacenter. Aun así conserva propiedades importantes:

- un proceso puede fallar mientras otro continúa;
- los mensajes cruzan un límite de socket;
- la serialización es explícita;
- los timeouts tienen sentido;
- las solicitudes pueden retrasarse o duplicarse;
- el estado no puede compartirse accidentalmente mediante variables locales ordinarias;
- cada nodo puede producir evidencia independiente.

Más adelante usarás contenedores o namespaces cuando necesites aislamiento de red más fuerte.

### Regla local-first

El laboratorio autoritativo debe funcionar localmente antes de añadir CI, nube o servicios remotos.

```text
código fuente
   ↓
proceso local
   ↓
clúster multiproceso local
   ↓
contenedor/namespace cuando haga falta
   ↓
CI o despliegue remoto opcional
```

Si la versión simple no funciona, añadir infraestructura suele añadir incertidumbre, no comprensión.

## 2. Un nodo es un rol, no necesariamente una computadora física

En este curso, **nodo** significa un participante que ejecuta de forma independiente una parte del protocolo distribuido.

Puede ser:

- un proceso del sistema operativo;
- un contenedor;
- una VM;
- un host físico;
- un worker o actor de Ray en el Capítulo 2;
- una réplica de almacenamiento;
- un peer de una DHT;
- un servidor de consenso.

No confundas el rol lógico con el hardware.

Tres servidores Raft en una sola laptop siguen siendo tres nodos lógicos en cuanto a estado y mensajes del protocolo. Pero un corte de alimentación elimina los tres a la vez. Eso es una limitación del dominio físico de fallo.

> **Hábito de sistemas:** declara siempre la **topología lógica** y el **dominio de fallo físico** del experimento.

## 3. Los procesos proporcionan ejecución y fallo independientes

Herramientas útiles:

```bash
ps -ef
ps -o pid,ppid,state,etime,cmd -p <PID>
pgrep -af python
pgrep -af go
```

Preguntas importantes:

1. ¿Existe el proceso?
2. ¿Qué ejecutable y argumentos lo iniciaron?
3. ¿Cuánto tiempo lleva activo?
4. ¿Cuál es su proceso padre?
5. ¿El PID coincide con el proceso cuyos logs estás leyendo?

Un PID es solo una identidad local y temporal. Puede reutilizarse.

Más adelante separaremos explícitamente:

```text
ID lógico de nodo ≠ PID del sistema operativo ≠ dirección de red
```

Esta diferencia es esencial durante reinicios.

## 4. Direcciones y puertos localizan endpoints actuales

Un servicio en:

```text
127.0.0.1:8101
```

tiene un endpoint compuesto por dirección y puerto de transporte.

Inspecciona sockets con:

```bash
ss -lntp
ss -tnp
```

Un socket en escucha demuestra que, en ese instante y punto de observación, un proceso logró enlazar el endpoint.

No demuestra que:

- el protocolo de aplicación sea correcto;
- el handler responda;
- otro namespace pueda alcanzarlo;
- el servicio tenga el estado esperado;
- el proceso siga existiendo un segundo después.

Una dirección dice dónde intentar ahora. El Capítulo 8 separará identidades más estables de ubicaciones cambiantes.

## 5. Establece una línea base antes de introducir fallos

Para un servicio HTTP sencillo:

```bash
curl -v http://127.0.0.1:8101/health
```

Registra al menos:

- comando/carga;
- inicio y fin del cliente;
- endpoint destino;
- respuesta o error;
- evento relevante del servidor;
- estado de proceso/socket cuando sea pertinente.

Después introduce **un solo cambio controlado**:

```text
predicción
   ↓
línea base
   ↓
un cambio controlado
   ↓
observación
   ↓
explicación
   ↓
recuperación / limpieza
```

Cambiar cinco cosas a la vez produce una demostración, no un experimento.

## 6. Los logs estructurados convierten historias en evidencia reconstruible

Salida débil:

```text
handling request
finished
error
```

Salida útil:

```json
{
  "event": "request_start",
  "node": "worker-a",
  "request_id": "req-1042",
  "operation": "double",
  "value": 21
}
```

y luego:

```json
{
  "event": "request_finish",
  "node": "worker-a",
  "request_id": "req-1042",
  "result": 42
}
```

Un identificador estable permite correlacionar componentes sin asumir relojes perfectamente sincronizados.

Campos frecuentes:

- `event`;
- `node`;
- `request_id` o `job_id`;
- timestamp local;
- peer/destino;
- operación;
- término/versión/secuencia si existe;
- resultado o categoría de fallo.

No registres secretos solo porque estructurar logs sea cómodo. Observabilidad y seguridad comparten un límite que debe ser explícito.

## 7. El reloj de pared ayuda, pero no prueba causalidad

Los logs usan timestamps porque son útiles para humanos. Sin embargo, los relojes pueden diferir y la planificación de procesos puede producir órdenes aparentemente extraños.

En el Capítulo 6 estudiarás relojes lógicos. Por ahora usa esta regla:

> **Usa el tiempo de pared para localizar eventos y las relaciones entre mensajes/solicitudes para explicar el orden.**

Para medir duraciones dentro de un proceso, usa una fuente monotónica cuando el lenguaje la ofrezca.

## 8. `curl` y clientes pequeños son sondas de aplicación

`curl` permite crear una solicitud independientemente de tu cliente.

Si tu cliente falla y `curl` funciona contra el mismo endpoint, la investigación se estrecha hacia la lógica de protocolo del cliente.

Si ambos fallan, baja de nivel:

```text
solicitud de aplicación
      ↓
¿socket en escucha?
      ↓
¿dirección/ruta/namespace correctos?
      ↓
¿tráfico visible?
      ↓
¿handler/estado del servidor?
```

Cada observación tiene un **límite de autoridad**.

## 9. Una captura de paquetes responde otra pregunta

Herramientas:

- `tcpdump`;
- TShark;
- Wireshark.

Ejemplo en localhost:

```bash
sudo tcpdump -i lo -nn tcp port 8101
```

La captura puede demostrar que tráfico cruzó esa interfaz y qué direcciones/puertos participaron.

No puede demostrar por sí sola que una transacción de aplicación sea correcta. Además, el cifrado puede ocultar el contenido.

Registra siempre el punto de captura:

```text
¿namespace del cliente?
¿namespace del servidor?
¿loopback?
¿bridge de contenedores?
¿interfaz física?
```

La ausencia de un paquete en un punto no implica que no exista en otro tramo.

## 10. Los contenedores añaden aislamiento, no corrección automática

Compara:

```text
tres funciones en un proceso        no distribuido
tres procesos en un contenedor      procesos distribuidos, dominio de fallo del contenedor compartido
tres contenedores en un host        mayor aislamiento, dominio de fallo del host compartido
tres hosts físicos                  fallos de host independientes, quizá rack/red compartidos
```

El entorno correcto depende de lo que quieras probar.

En los laboratorios iniciales, procesos sobre loopback suelen bastar. Para particiones selectivas, namespaces o contenedores facilitan alterar conectividad sin afectar toda la máquina.

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosidad</span>
  <strong>Tres procesos en una laptop siguen formando un experimento distribuido, pero no tres dominios físicos de fallo</strong>
  <p>Los procesos tienen memoria y ciclo de vida independientes, suficiente para estudiar muchas semánticas distribuidas, pero comparten kernel, disco, alimentación y normalmente una sola red física.</p>
  <p><strong>Pruébalo:</strong> Ejecuta tres servicios, mata solo uno y enumera qué fallos todavía derribarían a los tres.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">Más curiosidades del capítulo →</a>
</aside>

## 11. La reproducibilidad empieza con configuración explícita

Evita esconder direcciones, puertos, timeouts o rutas de datos en constantes del código.

Prefiere:

```bash
python3 src/node.py --node-id a --listen 127.0.0.1:8101 --delay-ms 0
```

Parámetros habituales:

- identidad del nodo;
- dirección de escucha;
- direcciones de peers;
- timeout;
- número de reintentos;
- directorio de datos;
- semilla aleatoria;
- factor de replicación;
- tamaño de carga.

El proyecto final usa el mismo principio.

## 12. Git forma parte del registro experimental

Un resultado reproducible debe identificar el código que lo produjo.

```bash
git status --short
git rev-parse --short HEAD
```

No afirmes que un experimento corresponde a un commit si cambios sin commit alteraban de forma material el comportamiento. Registra el estado dirty cuando importe.

GitHub no es obligatorio para ejecutar laboratorios; Git funciona localmente.

## 13. Go y Python cumplen roles distintos, no conceptos distintos

Las implementaciones nativas usan principalmente **Go** por su networking explícito, goroutines, canales, biblioteca estándar, pruebas, detector de carreras y binarios sencillos.

Python se usa para:

- Ray en el Capítulo 2 y la Fase 1 del proyecto;
- helpers compactos;
- generación determinista de cargas;
- análisis cuando convenga.

Proceso, mensaje, timeout, reintento o estado replicado siguen siendo conceptos distribuidos independientemente del lenguaje.

## 14. La inyección de fallos debe cambiar el entorno, no la especificación

Queremos preguntar:

- ¿qué pasa si desaparece este proceso?
- ¿qué pasa si los mensajes tardan 300 ms más?
- ¿qué pasa si se pierde el 10 % de los paquetes?
- ¿qué pasa si dos grupos dejan de comunicarse?
- ¿qué pasa si el cliente repite una solicitud?

Fallo más simple:

```bash
kill <PID>
```

Una parada ordenada y un crash abrupto son experimentos distintos.

Para red, `tc netem` permite introducir retardo, pérdida, duplicación y reordenamiento:

```bash
sudo tc qdisc add dev <lab-interface> root netem delay 300ms
# experimento
sudo tc qdisc del dev <lab-interface> root
```

No apliques reglas destructivas a interfaces de producción o administración remota.

### El retardo de aplicación sigue siendo útil

Muchos laboratorios exponen `--delay-ms`. No simula todas las propiedades de red, pero muestra de forma segura que **lento** y **fallido** no son lo mismo antes de que expire un timeout elegido.

Usa el mecanismo más sencillo que pruebe la propiedad que te interesa.

## 15. Una partición es un fallo selectivo de comunicación

Partición no significa «toda la red cayó».

```text
A <──> B      X      C <──> D
```

A y B pueden seguir comunicándose; C y D también; incluso clientes diferentes pueden alcanzar ambos grupos.

Los capítulos de replicación y consenso dependerán de **qué enlaces** siguen disponibles. Documenta la matriz de conectividad prevista, no solo «desconectamos la red».

## 16. Las pruebas transparentes son parte ejecutable de la especificación

Cuando un laboratorio tiene comportamiento determinista, sus pruebas oficiales son visibles.

Puedes:

- leerlas;
- ejecutarlas tantas veces como quieras;
- añadir casos en `tests/student/`;
- usar IA para proponer casos adicionales;
- modificar tu copia durante la investigación.

No existen casos de corrección ocultos.

Eso no elimina la exigencia: cambia la evaluación desde adivinar al grader hacia explicar **por qué** el comportamiento es correcto.

Hay propiedades distribuidas que una prueba unitaria aislada no demuestra. Para ellas necesitas experimento y explicación.

## 17. La evidencia tiene una jerarquía

Supón que afirmas:

> «El servidor definitivamente nunca recibió la solicitud».

¿Qué lo respalda?

Posibles observaciones:

1. el cliente imprimió timeout;
2. el log del servidor no contiene el request ID;
3. `tcpdump` en la interfaz del servidor no vio paquetes;
4. estadísticas de sockets no muestran conexión;
5. el proceso del servidor no estaba ejecutándose.

Ninguna observación es universalmente suficiente. Combina fuentes independientes hasta reducir explicaciones alternativas.

| Pregunta | Evidencia útil |
|---|---|
| ¿Está vivo el proceso? | `ps`, `pgrep`, estado del contenedor |
| ¿Está escuchando? | `ss -lntp` |
| ¿Puedo alcanzar el endpoint? | `curl`, cliente específico |
| ¿Cruzó tráfico esta interfaz? | `tcpdump`, Wireshark |
| ¿A qué solicitud pertenece este log? | request/job ID |
| ¿Cambió latencia o throughput? | duraciones, métricas, resultados |
| ¿Sobrevivió estado al reinicio? | archivos persistentes, consulta de estado |

## 18. El formato del informe forma parte del método

Todo experimento importante debe poder explicarse con cuatro elementos.

### Predicción

Escribe qué esperas **antes** de introducir el fallo.

### Procedimiento

Registra comandos, configuración, carga y topología.

### Evidencia

Incluye fragmentos legibles por máquina cuando sea posible: logs, trazas, salida de pruebas, métricas, estado persistente o resúmenes de paquetes.

### Explicación

Conecta la observación con el modelo del sistema. Nombra el mecanismo y el supuesto que cambió.

Informe débil:

> «Dejó de funcionar después de matar el servidor».

Informe mejor:

> «El cliente agotó 500 ms porque el único proceso enlazado a `127.0.0.1:8102` fue terminado. `ss` mostró que ya no existía listener y el cliente no recibió respuesta de aplicación. Al reiniciar el proceso reapareció el endpoint porque este servicio de juguete no requería estado durable».

## 19. La IA puede acelerar la investigación; la evidencia sigue siendo tuya

Puedes usar asistentes y agentes.

Buenos usos:

- explicar un comando;
- proponer hipótesis para un timeout;
- generar otra prueba;
- revisar un script;
- sugerir qué logs distinguirían dos explicaciones.

Pero una afirmación generada no es una observación de tu máquina.

```text
sugerencia de IA
    ↓
hipótesis técnica
    ↓
experimento local
    ↓
evidencia
    ↓
tu conclusión
```

Este patrón se mantiene durante todo el curso.

## 22. Errores comunes del Calentamiento

### Empezar con packet capture antes de comprobar que el proceso existe

Recoge primero evidencia de la dependencia más sencilla. Un proceso muerto no puede responder aunque todos los paquetes del mundo lleguen correctamente.

### Codificar puertos y olvidar procesos antiguos

Un proceso de ayer puede seguir ocupando el puerto. Comprueba el listener y su PID en vez de suponer qué binario lo posee.

### Tratar un timeout como detector perfecto de crash

Un timeout convierte incertidumbre en una decisión local; no revela la verdad remota.

### Ejecutar todo el laboratorio con privilegios elevados

Usa privilegios solo para operaciones que realmente los requieran, como determinadas capturas o inyección de fallos de red. El resto debe funcionar con mínimo privilegio.

### Aplicar `tc` a la interfaz equivocada

Un fallo experimental mal aislado puede afectar tráfico ajeno al escenario. Prefiere namespaces/contenedores dedicados o una demora de aplicación cuando el objetivo pedagógico no exige manipular la red real.

### Entregar capturas sin comandos reproducibles

Una captura puede apoyar una explicación, pero configuración, comandos, logs y pruebas permiten repetir y auditar el experimento.

### Tratar unit tests como prueba completa de tolerancia a fallos

Una función determinista y una campaña de crash/partición establecen hechos diferentes. Usa la evidencia adecuada a la propiedad que afirmas.

## Resumen del Calentamiento

El banco establece el método que reutilizarás durante todo el curso:

1. **Una máquina local puede alojar varios nodos lógicos útiles.**
2. **ID lógico, PID y endpoint son identidades distintas.**
3. **Primero establece una línea base conocida; después inyecta fallos.**
4. **Logs estructurados e IDs de solicitud convierten ejecuciones en evidencia correlacionable.**
5. **Toda observación tiene un límite de autoridad.**
6. **Contenedores y namespaces añaden aislamiento, no corrección automática.**
7. **Configuración explícita, estado Git y comandos exactos hacen reproducible un experimento.**
8. **La inyección de fallos debe ser controlada, selectiva y reversible.**
9. **Las pruebas transparentes son parte de la especificación pública, no sustituto de toda evidencia experimental.**
10. **Una hipótesis producida por IA sigue necesitando evidencia local.**

Antes del Capítulo 1 debes poder iniciar varios nodos locales, identificar sus PIDs y endpoints, emitir una solicitud con ID estable, detener uno de los procesos y explicar el comportamiento del cliente usando al menos dos fuentes de evidencia independientes.

## Conexiones de sistemas

### [OS]

Procesos, señales, descriptores, planificación, namespaces, permisos y archivos durables son mecanismos del sistema operativo que usamos para construir y observar nodos.

### [ARCH]

Una computadora es un dominio físico de fallo compartido aunque ejecute varios nodos lógicos. Planificación de CPU, presión de memoria y almacenamiento pueden influir en el rendimiento observado.

### [NET]

Todo mensaje entre nodos termina usando abstracciones de red. Direcciones, puertos, TCP, pérdida y retardo se convierten en entradas semánticas para protocolos posteriores.

### [SEC]

Mínimo privilegio, identidad de servicio, secretos en logs y aislamiento determinan qué experimentos son seguros y qué evidencia puede exponerse.

### [AI]

Los agentes pueden acelerar preparación y diagnóstico, pero debes convertir sus sugerencias en hipótesis comprobables y evidencia.

<div class="ds-next-action">
  <span>Lectura esencial completada</span>
  <strong>Siguiente paso obligatorio · Práctica guiada</strong>
  <a href="../guided-practice/">Comenzar práctica guiada →</a>
</div>
