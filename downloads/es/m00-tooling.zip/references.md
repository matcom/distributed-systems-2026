> **Vista de referencia.** Esta página ofrece contexto opcional; vuelve a la [Lección](../lesson/) para la ruta obligatoria.

## Esencial

- **● The Go Documentation** — The Go Project. [tool documentation](https://go.dev/doc/)
- **● Docker Documentation** — Docker. [tool documentation](https://docs.docker.com/)

## Recomendado

- **● Wireshark User's Guide** — Wireshark Foundation. [tool documentation](https://www.wireshark.org/docs/wsug_html_chunked/)

## Avanzado

Todavía no hay un recurso adicional asignado.

## Herramientas y práctica

- **●● tc-netem manual** — Linux man-pages project. [tool documentation](https://man7.org/linux/man-pages/man8/tc-netem.8.html)

## Explora

- **●●● 6.5840 Distributed Systems** — MIT PDOS. [course](https://pdos.csail.mit.edu/6.824/)
