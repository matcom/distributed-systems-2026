<p class="ds-book-part">Calentamiento</p>
<p class="ds-module-kicker">Calentamiento</p>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Calentamiento</span>
    <span>0% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 0%"></span></div>
</div>
<p class="ds-guiding-question">¿Cómo observas, controlas y sometes a fallos de forma segura un sistema distribuido en una sola máquina?</p>

Antes de estudiar algoritmos distribuidos, prepara un entorno de calentamiento donde puedas iniciar varios procesos independientes, observarlos, introducir retardos, desconectar rutas, terminar/reiniciar nodos y recoger evidencia que puedas reproducir después.

## Ideas clave

- procesos y puertos en Linux;
- Git y repositorios reproducibles;
- entornos de Go y Python;
- contenedores y espacios de nombres de red cuando sean útiles;
- `curl`, `ss`, `tcpdump` y Wireshark;
- inyección controlada de fallos;
- logs estructurados e identificadores estables de solicitud;
- evidencia compacta que siga siendo útil sin conexión.

## Transición al laboratorio

Ejecuta un servicio sencillo con tres procesos, captura una solicitud, termina uno de los procesos, añade latencia a otro y explica exactamente qué demuestra tu evidencia.

## Empieza aquí

> **Antes de leer:** Tres procesos de servicio se ejecutan en una misma computadora. Si un proceso termina, ¿qué falló de forma independiente? Si la computadora pierde la alimentación, ¿qué falló al mismo tiempo?

**Trae contigo:** Uso básico de la línea de comandos de Linux, procesos, archivos y Git.

**Este capítulo te prepara para:** Un entorno de calentamiento donde puedas comprobar cada afirmación posterior con evidencia local reproducible.

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>25 min–35 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>25 min–40 min</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>1 h–1 h 30 min · 7 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Leer lección →</a>
  <a class="ds-secondary-action" href="lab/">Abrir laboratorio</a>
</div>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../downloads/es/m00-tooling.zip" download>Descargar capítulo + laboratorio para estudio sin conexión (.zip)</a></p>

## Qué aprenderás

- Prepara un entorno local reproducible para todos los laboratorios posteriores.
- Ejecuta varios procesos de servicio independientes e identifica sus endpoints de red.
- Captura e interpreta un intercambio sencillo de solicitud/respuesta.
- Inyecta latencia o fallos de proceso sin modificar el código de la aplicación.
- Empaqueta tus observaciones para que otra persona pueda reproducirlas.

## Aprende trabajando la pregunta

1. Escribe tu respuesta a **Empieza aquí** antes de abrir la lección completa.
2. Lee hasta la siguiente predicción o traza; detente y resuélvela antes de revelar la explicación.
3. Trata la práctica guiada como un **banco de práctica**, no como una hoja para completar deprisa. Trabaja las trazas centrales hasta alcanzar el objetivo de práctica y vuelve después a los casos restantes.
4. Usa la comprobación para detectar vacíos y entra al laboratorio con una predicción falsable y con la evidencia que podría contradecirla.
5. Termina explicando qué estableció el experimento, qué no estableció y cómo cambia tu explicación del servicio acumulativo.

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link next" href="../m01-distributed-systems/">Pensar en sistemas distribuidos →</a>
</nav>
