# M05 Laboratory Report — Processes, Concurrency, and Isolation

## 1. Environment

Record Go version, OS, CPU count, container availability, and the exact command used to start the service.

## 2. Invariant

State the local correctness invariant for request IDs and the counter in one sentence.

## 3. Baseline

Document one sequential execution and its expected/observed state.

## 4. Raw data race

- workload:
- prediction:
- observed race evidence:
- conflicting accesses:
- explanation:

## 5. Memory-safety repair

Describe the synchronization strategy. Include before/after race-detector evidence and explain the authority boundary of a clean run.

## 6. Semantic race

Provide the interleaving that violates the check-then-act invariant even after a naive synchronization repair.

State the complete transition that must be atomic.

## 7. Deadlock, starvation, or leak

- scenario:
- evidence:
- wait/progress explanation:
- repair:

## 8. Bounded concurrency experiment

| Workload | Strategy | Throughput | Typical latency | Tail latency | Resource/queue evidence |
|---|---|---:|---:|---:|---|
| | unbounded | | | | |
| | bounded | | | | |

Explain the backpressure policy when capacity is exhausted.

## 9. Isolation experiment

Compare two processes and, if available, two containers. State which failures are independent and which remain shared at the host level.

## 10. Graceful versus abrupt stop

Describe the observable difference and identify which cleanup guarantees disappear under abrupt death.

## 11. Local mutex versus distributed coordination

Show how two independent replicas can each accept the same logical request despite correct local locking.

State precisely what remains unsolved without introducing a later consensus solution prematurely.

## 12. AI audit

- tool, if any:
- suggestion examined:
- classification: valid / invalid / incomplete
- evidence used to verify:

## 13. Conclusion

Answer the guiding question: **What can go wrong inside one node before the network is even involved?**
