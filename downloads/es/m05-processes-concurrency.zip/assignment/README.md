# Laboratory — Processes, Concurrency, and Isolation

## Target

Expose a local concurrency defect inside one service node, repair the memory-safety problem, identify a remaining semantic race, observe deadlock/overload behavior, and then compare process/container isolation boundaries.

This lab deliberately keeps the network simple. The point is to prove that a distributed service can fail **inside one node** even when every packet arrives correctly.

## Learning evidence

By the end of the lab, your report must contain evidence for all of the following:

- one reproducible concurrent interleaving that violates an invariant;
- one race-detector run or equivalent memory-access diagnostic;
- one repair that removes the raw data race;
- one higher-level race that survives a naive repair;
- one deadlock, starvation, or goroutine-leak diagnosis;
- one bounded-concurrency experiment;
- one comparison between graceful shutdown and abrupt process death;
- one explanation of why a local mutex cannot coordinate two independent replicas.

## Required service shape

Use a small Go service with at least:

```text
POST /apply?id=<request-id>&delta=<integer>
GET  /state
GET  /health
```

The service maintains:

```text
counter
completed request IDs
basic request metrics
```

The important invariant is:

> A logical request ID may affect the counter at most once inside one service instance.

Keep the application intentionally small. This lab is about interleavings and isolation, not framework design.

## Step 1 — Baseline sequential behavior

Run one service instance and send requests one at a time.

Record:

- process ID;
- listening port;
- initial counter;
- request ID;
- resulting counter;
- structured log event.

Confirm the simple sequential invariant before adding concurrency.

## Step 2 — Introduce concurrent handlers

Run at least 20 concurrent requests. Include multiple copies of the same logical request ID.

Before running, predict:

- expected final counter under correct deduplication;
- whether request completion order is deterministic;
- which shared structures are accessed concurrently.

Do not repair anything yet.

## Step 3 — Expose a raw data race

Use the Go race detector where possible:

```bash
go test -race ./...
```

or run an equivalent race-enabled workload against the service.

The submission must identify the conflicting accesses reported by the tool. Merely attaching the warning text is insufficient.

Explain:

1. which memory location is involved;
2. which goroutines access it;
3. which access is a write;
4. why the interleaving is unsafe.

## Step 4 — Repair memory safety

Apply one explicit strategy:

- mutex-protected state;
- one owner goroutine plus channels;
- another justified local synchronization mechanism.

Rerun the same workload.

A clean race-detector run is evidence that the exercised accesses no longer contain that data race. It is **not** proof that the service's higher-level invariant is correct.

## Step 5 — Preserve or construct a semantic race

Create or identify a check-then-act sequence such as:

```text
check whether request R exists
release synchronization / perform other work
apply effect
record R
```

Construct an interleaving in which two handlers both conclude that R has not yet been processed.

Your explanation must identify the complete state transition that needs to be atomic.

Then repair the semantic invariant.

## Step 6 — Deadlock or starvation evidence

Choose one controlled scenario.

### Option A — deadlock

Use two locks acquired in opposite order by two goroutines, or another deterministic wait cycle.

Collect goroutine-stack or waiting-state evidence.

Explain the wait-for cycle.

### Option B — starvation

Create a workload where one class of operation repeatedly fails to make progress while the process continues serving other work.

Explain why the system is not globally deadlocked.

Do not leave the intentionally broken version as the final implementation.

## Step 7 — Unbounded versus bounded concurrency

Create a handler that takes a configurable amount of time, for example 50 ms.

Run increasing concurrent load against:

1. an effectively unbounded request/goroutine strategy;
2. a bounded worker/semaphore strategy.

Record at minimum:

- request concurrency;
- completed requests/s;
- median or approximate typical latency;
- p95 or another tail-latency observation;
- goroutine count or process-resource indicator;
- rejection/queue behavior when capacity is exhausted.

The goal is not to prove that fewer goroutines are always faster. The goal is to show that concurrency is a **resource policy**.

## Step 8 — Backpressure policy

When the bounded queue is full, choose and implement one explicit behavior:

- reject immediately;
- block the caller up to a deadline;
- shed a lower-priority request;
- another justified strategy.

Document why the chosen policy is preferable for this toy service.

## Step 9 — Lock across a remote call thought experiment

You do not need a second production service for this step.

Take one critical section and redesign it under the assumption that it calls a remote dependency that may take 10 ms, 10 s, or never respond.

Produce two diagrams:

```text
lock -> RPC -> unlock
```

and your safer alternative.

Explain which local state must be copied or reserved before releasing the lock.

## Step 10 — Process isolation

Run two independent service processes on different ports.

Kill one abruptly.

Verify that the other process remains alive and report which resources were truly isolated and which remain shared through the host kernel, filesystem, CPU, memory pressure, or disk.

## Step 11 — Container boundary

If Docker or Podman is available, run the two services in separate containers.

Classify the following failures:

- service panic;
- container kill;
- host network-interface failure;
- host kernel failure;
- host disk full;
- host power loss.

State which failures containerization isolates and which it does not.

If containers are unavailable, perform this step as an architecture analysis and document the missing local capability.

## Step 12 — Graceful versus abrupt termination

Test both:

```text
gracious stop / SIGTERM
```

and:

```text
abrupt kill / crash-like stop
```

For graceful termination, observe whether the service:

- stops accepting new work;
- drains in-flight work;
- flushes required state/logs;
- exits.

Then explain which of those steps cannot be assumed after abrupt death.

## Step 13 — Two replicas and the mutex boundary

Run two independent instances, each with a perfectly correct local mutex.

Show that the same request ID can still be accepted independently by both replicas if no distributed authority exists between them.

This is the key transition to later modules:

```text
local mutual exclusion
        !=
distributed agreement
```

Do not solve this with Raft yet. State the unsolved problem precisely.

## Transparent-test target

Executable public tests now live under `tests/official/`, with a deterministic concurrency adapter in `starter/src/`. They verify local at-most-once and bounded-admission invariants; race-detector output, deadlock behavior, process isolation, and lifecycle experiments still require the evidence described above.

The visible official cases are documented under `tests/official/README.md`. `make test` runs only public official tests plus student tests under `tests/student/`.

No hidden tests are planned.

## AI use

AI assistants and coding agents are permitted.

For this lab, include one short AI-audit entry:

- one concurrency issue suggested by AI;
- whether it was valid, invalid, or incomplete;
- the experiment or reasoning used to decide.

An AI claim is not evidence by itself.

## Report

Complete `REPORT.md` with:

- predictions;
- invariant definitions;
- commands/workloads;
- race/deadlock/resource evidence;
- before/after behavior;
- explanation of the local-versus-distributed synchronization boundary.

Screenshots may support the report, but machine-readable logs, test output, stack traces, or measurements should be preferred whenever available.
