# Planned Public Tests — M05

Executable public tests are provided in this directory together with the starter concurrency adapter under `starter/src/`. They cover deterministic local invariants from the categories below; lifecycle and multi-process observations remain evidence-based. No hidden cases are planned.

## Functional cases

1. Sequential `apply` changes the counter exactly once.
2. Repeating the same request ID within one instance does not apply the effect twice.
3. Distinct request IDs may execute concurrently.
4. `/state` reports counter and completed-request metadata consistently.

## Concurrency cases

5. A concurrent duplicate-request workload preserves the at-most-once local invariant.
6. The race-enabled test workload produces no data-race report in the final implementation.
7. The final implementation terminates the controlled deadlock fixture or rejects the invalid lock-order path rather than hanging indefinitely.
8. Bounded concurrency never exceeds the configured active-work limit.
9. Capacity exhaustion follows the documented backpressure policy.

## Lifecycle cases

10. Graceful shutdown stops new work and terminates within the documented bound.
11. One service process can be killed without terminating an independent service process.
12. Restarting one process does not magically recover transient in-memory deduplication state unless persistence is explicitly implemented.

## Boundary case

13. Two independent replicas may both accept the same logical request when no cross-node coordination mechanism exists. This case is **observational**, not a required repair in M05; the lab must explain why local mutexes are insufficient.

Students should add at least one additional case under `tests/student/` for a semantic concurrency edge case discovered during experimentation.
