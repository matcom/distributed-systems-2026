import threading
import unittest

from concurrency_model import DeduplicatingCounter


class ConcurrencyModelTests(unittest.TestCase):
    def test_sequential_apply(self):
        counter = DeduplicatingCounter()
        self.assertEqual(counter.apply("r1", 2), 2)
        self.assertEqual(counter.value, 2)

    def test_duplicate_is_applied_once(self):
        counter = DeduplicatingCounter()
        first = counter.apply("r1", 3)
        second = counter.apply("r1", 3)
        self.assertEqual(first, second)
        self.assertEqual(counter.value, 3)

    def test_concurrent_duplicate_requests_preserve_at_most_once(self):
        counter = DeduplicatingCounter()
        results = []
        errors = []

        def run():
            try:
                results.append(counter.apply("same", 1))
            except Exception as exc:  # make thread failures visible
                errors.append(exc)

        threads = [threading.Thread(target=run) for _ in range(20)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(timeout=2)

        self.assertFalse(errors)
        self.assertTrue(all(not thread.is_alive() for thread in threads))
        self.assertEqual(counter.value, 1)
        self.assertTrue(all(result == 1 for result in results))

    def test_distinct_request_ids_all_contribute(self):
        counter = DeduplicatingCounter()
        threads = [threading.Thread(target=counter.apply, args=(f"r{i}", 1)) for i in range(20)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(timeout=2)
        self.assertEqual(counter.value, 20)

    def test_bounded_admission_never_exceeds_limit(self):
        counter = DeduplicatingCounter(limit=2)
        self.assertTrue(counter.begin_work())
        self.assertTrue(counter.begin_work())
        self.assertFalse(counter.begin_work())
        self.assertLessEqual(counter.max_active_observed, 2)
        counter.end_work()
        self.assertTrue(counter.begin_work())
        self.assertLessEqual(counter.max_active_observed, 2)


if __name__ == "__main__":
    unittest.main()
