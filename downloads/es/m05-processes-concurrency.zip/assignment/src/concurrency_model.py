"""Deterministic local-concurrency contract for M05."""

import threading


class DeduplicatingCounter:
    def __init__(self, limit: int = 4):
        if limit <= 0:
            raise ValueError("limit must be positive")
        self.value = 0
        self.limit = limit
        self._completed = {}
        self._lock = threading.Lock()
        self._active = 0
        self.max_active_observed = 0

    def apply(self, request_id: str, delta: int) -> int:
        """Apply one logical request at most once, safely under concurrency."""
        raise NotImplementedError("TODO: implement thread-safe deduplication and update")

    def begin_work(self) -> bool:
        """Admit work only while active count is below limit."""
        raise NotImplementedError("TODO: implement bounded admission")

    def end_work(self) -> None:
        """Release one active-work slot."""
        raise NotImplementedError("TODO: release bounded admission slot")

    def state(self):
        return {"counter": self.value, "completed": dict(self._completed), "active": self._active}
