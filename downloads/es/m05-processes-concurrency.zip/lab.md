<div class="ds-lesson-banner">
  <div><span>Laboratorio obligatorio</span><strong>Capítulo 3</strong></div>
  <div><span>Modelo de evidencia</span><strong>predecir → ejecutar → observar → explicar</strong></div>
  <div><span>Verificación</span><strong>5 pruebas públicas transparentes + evidencia</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 3 de 12</span>
    <span>25% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 25%"></span></div>
</div>
<p class="ds-back-link"><a href="../quick-check/">← Volver a la comprobación</a></p>

> **Antes de comenzar:** Completa los pasos de práctica guiada y comprobación de conocimientos. Ya deberías poder formular una predicción y nombrar la evidencia que la apoyaría o contradeciría. Si no, [vuelve a la comprobación](../quick-check/) y revisa la lección donde haga falta.

## Objetivo

Expón un defecto de concurrencia local dentro de un nodo de servicio, repara el problema de seguridad de memoria, identifica una carrera semántica que permanezca, observa deadlock/sobrecarga y compara límites de aislamiento de proceso/contenedor.

La red se mantiene deliberadamente simple. El objetivo es demostrar que un servicio distribuido puede fallar **dentro de un nodo** aunque todos los paquetes lleguen correctamente.

## Evidencia de aprendizaje

El informe debe incluir:

- una intercalación concurrente reproducible que viole un invariante;
- una ejecución del race detector o diagnóstico equivalente;
- una reparación de la data race;
- una carrera de alto nivel que sobreviva a una reparación ingenua;
- un diagnóstico de deadlock, starvation o fuga de goroutine;
- un experimento de concurrencia acotada;
- comparación entre graceful shutdown y muerte abrupta;
- explicación de por qué un mutex local no coordina dos réplicas independientes.

## Forma requerida del servicio

Usa un servicio Go pequeño con al menos:

```text
POST /apply?id=<request-id>&delta=<integer>
GET  /state
GET  /health
```

Mantiene:

```text
counter
IDs completados
métricas básicas
```

Invariante:

> Un ID lógico de solicitud puede afectar al contador como máximo una vez dentro de una instancia.

Mantén la aplicación pequeña.

## Paso 1 — comportamiento secuencial base

Ejecuta una instancia y envía solicitudes de una en una.

Registra:

- PID;
- puerto;
- contador inicial;
- request ID;
- contador resultante;
- evento estructurado.

Confirma primero el invariante secuencial.

## Paso 2 — handlers concurrentes

Ejecuta al menos 20 solicitudes concurrentes e incluye duplicados del mismo ID lógico.

Antes predice:

- contador final correcto;
- si el orden de finalización es determinista;
- qué estructuras se comparten.

No repares todavía.

## Paso 3 — expón una data race

Usa:

```bash
go test -race ./...
```

o carga equivalente instrumentada.

No basta adjuntar el warning. Explica:

1. qué memoria está implicada;
2. qué goroutines acceden;
3. qué acceso escribe;
4. qué intercalación es insegura.

## Paso 4 — repara seguridad de memoria

Aplica una estrategia:

- mutex;
- goroutine propietaria + channels;
- otro mecanismo local justificado.

Repite la misma carga.

Una ejecución limpia es evidencia sobre las rutas ejercitadas, no prueba del invariante de alto nivel.

## Paso 5 — conserva o construye una carrera semántica

Usa un check-then-act como:

```text
comprobar si R existe
liberar sincronización / hacer otro trabajo
aplicar efecto
registrar R
```

Construye una intercalación donde dos handlers concluyen que R no fue procesada.

Identifica **toda** la transición que debe ser atómica y después repárala.

## Paso 6 — evidencia de deadlock o starvation

### Opción A — deadlock

Dos locks en orden opuesto u otro ciclo determinista.

Recoge stack/waiting state y explica el ciclo wait-for.

### Opción B — starvation

Crea una carga donde una clase de operación no progresa mientras otras sí.

Explica por qué no es deadlock global.

No dejes la versión rota como implementación final.

## Paso 7 — concurrencia ilimitada frente a acotada

Crea un handler con duración configurable, por ejemplo 50 ms.

Compara:

1. estrategia prácticamente ilimitada;
2. worker pool/semaphore acotado.

Registra:

- concurrencia;
- completadas/s;
- latencia típica;
- p95 o cola;
- goroutine count/recurso;
- rechazo/cola cuando se agota capacidad.

No se pretende probar que «menos goroutines es más rápido». Se pretende demostrar que concurrencia es una **política de recursos**.

## Paso 8 — política de backpressure

Cuando la cola esté llena, implementa una conducta explícita:

- rechazar;
- bloquear hasta un plazo;
- descartar prioridad inferior;
- otra política justificada.

Explica por qué encaja en este servicio.

## Paso 9 — lock durante RPC, experimento mental

No necesitas un segundo servicio real.

Rediseña una sección crítica suponiendo que llama una dependencia que tarda 10 ms, 10 s o nunca responde.

Dibuja:

```text
lock -> RPC -> unlock
```

y una alternativa más segura.

Indica qué estado debe copiarse/reservarse antes de liberar el lock.

## Paso 10 — aislamiento de procesos

Ejecuta dos procesos independientes en puertos diferentes.

Mata uno abruptamente.

Comprueba que el otro sigue vivo e indica qué recursos están realmente aislados y cuáles comparten mediante kernel, filesystem, CPU, memoria o disco.

## Paso 11 — límite de contenedor

Si Docker/Podman está disponible, ejecuta ambos en contenedores.

Clasifica:

- panic del servicio;
- kill del contenedor;
- fallo de interfaz de red del host;
- fallo del kernel;
- disco lleno;
- pérdida de alimentación.

Indica cuáles aísla el contenedor y cuáles no.

Si no hay contenedores, haz análisis arquitectónico y documenta la capacidad ausente.

## Paso 12 — graceful frente a abrupto

Prueba:

```text
SIGTERM / stop limpio
```

y:

```text
kill abrupto / estilo crash
```

En graceful observa si:

- deja de aceptar;
- drena trabajo;
- hace flush;
- sale.

Explica qué pasos no pueden asumirse después de muerte abrupta.

## Paso 13 — dos réplicas y límite del mutex

Ejecuta dos instancias independientes, cada una con mutex local correcto.

Demuestra que el mismo request ID puede aceptarse en ambas si no hay autoridad distribuida.

```text
exclusión mutua local
        !=
acuerdo distribuido
```

No lo resuelvas todavía con Raft. Formula el problema pendiente.

### Checklist de interpretación

Al terminar los pasos anteriores debes poder separar cuatro tipos de evidencia:

- **race detector:** acceso de memoria inseguro observado;
- **traza de invariante:** transición lógica incorrecta aunque la memoria esté sincronizada;
- **métrica de recursos:** cola, goroutines, utilización o rechazo bajo carga;
- **experimento de aislamiento:** qué fallo afectó a un proceso y cuáles siguieron vivos.

Ninguna sustituye a las demás.

Para el paso de dos réplicas, conserva el mismo `request_id` en ambas ejecuciones y muestra los dos logs. El objetivo es observar que dos mutex correctos pueden aceptar el mismo efecto porque no comparten autoridad. Esa evidencia prepara la necesidad posterior de coordinación distribuida.

## Pruebas transparentes

Las pruebas públicas están en `tests/official/`, con adaptador determinista en `starter/src/`. Verifican at-most-once local y admisión acotada. Race detector, deadlock, aislamiento y lifecycle necesitan la evidencia experimental.

Los casos visibles están en `tests/official/README.md`; `make test` ejecuta solo pruebas públicas y las del estudiante.

No se planean pruebas ocultas.

## Uso de IA

Se permiten asistentes/agentes.

Incluye una entrada breve:

- problema de concurrencia sugerido;
- válido, inválido o incompleto;
- experimento o razonamiento usado para decidir.

La afirmación del modelo no es evidencia.

## Informe

Completa `REPORT.md` con predicciones, invariantes, comandos, evidencia de carreras/deadlock/recursos, antes/después y explicación del límite entre sincronización local y distribuida.

Prefiere logs, test output, stacks y mediciones a capturas.

## Termina el capítulo

Reproduce el resultado importante desde un inicio limpio. Después vuelve a tu predicción inicial: explica qué cambió, qué evidencia provocó el cambio y qué incertidumbre queda. Un comando exitoso o una captura no bastan cuando la afirmación trata de retries, orden, durabilidad, consistencia, recovery, seguridad o rendimiento.

<div class="ds-next-action">
  <span>Capítulo completo</span>
  <strong>Continuar el curso</strong>
  <a href="../../m03-rpc/">Comunicación I — Mensajes, RPC y fallos remotos →</a>
</div>

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../../m02-ray-middleware/">← Arquitecturas y middleware</a>
<a class="ds-sequence-link next" href="../../m03-rpc/">Comunicación I — Mensajes, RPC y fallos remotos →</a>
</nav>
