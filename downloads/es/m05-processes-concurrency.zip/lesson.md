<p class="ds-book-part">Parte I — Fundamentos y arquitectura</p>
<div class="ds-lesson-banner">
  <div><span>Paso del curso</span><strong>Capítulo 3</strong></div>
  <div><span>Lectura esencial</span><strong>25 min–35 min</strong></div>
  <div><span>Ruta obligatoria</span><strong>Leer → Objetivo de práctica → Comprobar → Laboratorio</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 3 de 12</span>
    <span>25% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 25%"></span></div>
</div>

> **Pregunta guía:** ¿Qué límites de ejecución aíslan estado, planificación, recursos y fallos?

## Antes de leer

> Cuatro contenedores se ejecutan en una misma computadora. ¿Cuántos dominios independientes de fallo de proceso existen? ¿Cuántos dominios independientes de fallo de máquina?

Escribe primero una respuesta breve. No necesitas acertar todavía: necesitas una predicción que puedas revisar a medida que el capítulo te dé mejores modelos y evidencia.

**Usa lo que ya sabes:** Procesos, hilos o goroutines, sincronización y memoria virtual vistos en Sistemas Operativos.

## Mapa de carga de trabajo

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>25 min–35 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>35 min–50 min</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>1 h 30 min–2 h · 5 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../../downloads/es/m05-processes-concurrency.zip" download>Descargar lección + práctica + laboratorio para estudio sin conexión (.zip)</a></p>

## Por qué importa este capítulo

Con frecuencia se culpa a la red de un fallo cuyo primer origen está dentro de un solo nodo.

Un proceso de servicio puede contener muchos handlers concurrentes, temporizadores, bucles de fondo, colas, cachés, pools de conexiones, workers de reintento y caminos de apagado. Todas esas actividades comparten memoria y recursos antes de que empiece cualquier coordinación distribuida.

Pregunta guía:

> **¿Qué puede salir mal dentro de un nodo antes incluso de que intervenga la red?**

Este capítulo conecta Sistemas Operativos con ingeniería de servicios distribuidos. La reparación de una carrera local no es la reparación de una carrera distribuida.

Un mutex puede coordinar goroutines de un proceso. No puede hacer que dos máquinas que fallan independientemente estén de acuerdo.

## 1. Un nodo distribuido sigue siendo un programa concurrente normal

Piensa en un servidor RPC:

```text
listener
  ↓
accept/request loop
  ├── handler R1
  ├── handler R2
  ├── handler R3
  ├── heartbeat loop
  ├── cleanup de caché
  └── shutdown/recovery
```

Aunque la red sea perfecta, las intercalaciones pueden ser incorrectas:

- dos handlers modifican el mismo mapa;
- una goroutine cierra un canal mientras otra envía;
- shutdown compite con una escritura;
- un worker de reintento duplica una transición;
- una cola crece sin límite;
- un ciclo de locks produce deadlock.

La corrección distribuida depende también de la corrección concurrente local de cada nodo.

## 2. Concurrencia y paralelismo son distintos

**Concurrencia**: varias actividades progresan en intervalos solapados.

**Paralelismo**: varias actividades ejecutan literalmente al mismo tiempo en CPU/cores distintos.

Un único core puede ser concurrente:

```text
tiempo CPU →
R1  ####      ####
R2      ####       ###
```

Un multicore puede ejecutarlas simultáneamente.

Para corrección importan ambos casos: el programa no debe depender de un orden afortunado del scheduler salvo que la sincronización lo establezca.

## 3. El estado mutable compartido crea obligaciones de orden local

Dos handlers ejecutan:

```text
counter = counter + 1
```

Conceptualmente:

```text
read counter
compute +1
write counter
```

Si ambos leen 10 antes de escribir, ambos pueden escribir 11. El resultado esperado era 12.

Pregunta útil:

> **¿Qué posiciones de memoria pueden leer o modificar varias actividades concurrentes?**

En revisión de código conviene inventariar:

```text
estado                 propietarios/usuarios
------------------------------------------------
request map            handlers + cleanup
worker registry        registro + expiración
connection pool        todos los RPC salientes
shutdown flag          main + signal handler
métricas               muchas goroutines
```

Después se decide cómo sincronizar.

<figure class="ds-book-figure">
  <img src="../../../../assets/book/m05-failure-boundaries-es.svg" alt="Hilos, procesos, contenedores y hosts forman distintos límites de estado y fallo." loading="lazy" decoding="async" />
  <figcaption><span>Figura</span>El aislamiento tiene capas. Un fallo de proceso, contenedor o host elimina conjuntos diferentes de estado y ejecución.</figcaption>
</figure>

## 4. Data race y carrera lógica no son lo mismo

Una **data race** en Go ocurre cuando accesos concurrentes conflictivos a una variable carecen de la sincronización exigida y al menos uno escribe.

El race detector instrumenta el programa y reporta carreras que realmente aparecieron en las rutas ejecutadas.

Es valioso, pero un programa libre de data races puede seguir teniendo una carrera lógica.

Ejemplo:

```text
if balance >= 10:
    withdraw 10
```

Cada lectura/escritura puede estar protegida por mutex y, aun así, el **check** y el **update** ocurrir en secciones críticas separadas:

```text
lock
read balance = 10
unlock

... otro handler hace lo mismo ...

lock
write balance = 0
unlock
```

No hay necesariamente data race, pero el invariante puede romperse.

> **El race detector encuentra accesos de memoria inseguros importantes; no prueba el invariante de aplicación.**

## 5. Los mutex protegen invariantes locales

Para un mapa local:

```text
lock
lookup/update
unlock
```

puede establecer:

> no hay dos goroutines modificando el mapa simultáneamente.

Es apropiado cuando:

- el estado vive en un proceso;
- todos los accesos siguen la misma disciplina;
- bloquear mientras otra goroutine mantiene el lock es aceptable.

La granularidad importa.

Un único lock global simplifica razonamiento, pero puede destruir concurrencia.

Muchos locks finos pueden aumentar throughput y complejidad de orden.

La regla del curso es preferir la estrategia más simple que cumpla corrección y rendimiento medido.

## 6. Los canales trasladan sincronización a la estructura de comunicación

En Go puede hacerse que una goroutine sea propietaria del estado:

```text
handlers
  | comandos
  v
state-owner goroutine
  |
  v
map/state
```

Los handlers no mutan directamente el mapa.

Esto puede simplificar ownership, pero los canales no eliminan mágicamente:

- deadlock;
- starvation;
- colas sin límite;
- shutdown mal ordenado.

Un canal puede bloquear para siempre si nadie recibe o si se forma un ciclo de espera.

La pregunta sigue siendo: **¿quién posee el estado y qué orden impone la comunicación?**

## 7. Deadlock es espera circular

Ejemplo:

```text
G1 tiene A, espera B
G2 tiene B, espera A
```

Ninguna progresa.

Estrategias locales:

- orden global de adquisición;
- no mantener locks durante I/O bloqueante;
- reducir locking anidado;
- ownership claro;
- usar timeouts solo como escape/diagnóstico cuando sea semánticamente seguro.

Un timeout puede hacer parecer que el deadlock «se recuperó» sin reparar el orden roto.

## 8. Starvation es negación injusta de progreso

El proceso puede seguir activo mientras una goroutine o solicitud rara vez obtiene el recurso que necesita.

Ejemplos:

- prioridad alta bloquea indefinidamente trabajo bajo;
- lectores posponen continuamente un escritor;
- jobs largos monopolizan un semáforo;
- el pool siempre favorece una clase.

Starvation es principalmente un problema de vivacidad/fairness, no necesariamente de safety.

## 9. Las fugas de goroutines son fugas de recursos

Una goroutine esperando eternamente en canal, timer, RPC o cola puede sobrevivir a la solicitud que la creó.

Una fuga parece pequeña. Miles pueden tumbar el servicio.

Preguntas:

- ¿quién cancela trabajo de fondo?
- ¿quién posee el timer?
- ¿quién cierra el canal?
- ¿un send bloqueado puede observar cancelación?
- ¿shutdown espera a todas las goroutines?

El mismo razonamiento de ownership usado para estado distribuido aplica dentro del proceso.

## 10. Pools acotados convierten concurrencia en política explícita de recursos

Una goroutine por solicitud puede funcionar a carga baja. Sin límites, el trabajo entrante se convierte en presión de memoria/scheduler.

```text
trabajo entrante
      ↓
cola acotada
      ↓
N workers
```

Si llegan solicitudes más rápido de lo que se procesan, el sistema debe escoger:

- bloquear/admitir lentamente;
- rechazar;
- descartar;
- poner en cola hasta un límite;
- priorizar.

Ese es el comienzo del backpressure.

## 11. Los límites de concurrencia forman parte del contrato de servicio

Supón un pool de base de datos con 20 conexiones.

Permitir 1000 handlers que las necesiten no crea 1000 unidades de paralelismo; puede crear 980 goroutines esperando y aumentar latencia/expiraciones.

Conviene limitar cerca del recurso escaso:

- workers CPU-bound cerca de capacidad de CPU;
- storage cerca de capacidad de cola del dispositivo;
- RPC salientes cerca del límite downstream;
- inferencia cerca de capacidad del acelerador.

El límite se mide; no se copia ciegamente de un framework.

## 12. No mantengas un lock local durante un RPC sin una razón fuerte

```text
lock estado local
RPC remoto
esperar
unlock
```

La duración del lock depende ahora de la red y del servicio remoto.

Un peer lento puede bloquear trabajo local no relacionado.

Dos servicios pueden crear ciclo distribuido:

```text
A tiene lock → llama B
B tiene lock → llama A
```

A menudo es mejor capturar/reservar estado, liberar, hacer trabajo remoto y después validar/actualizar.

Eso puede introducir concurrencia optimista; no existe receta universal. Lo importante es reconocer el acoplamiento.

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosidad</span>
  <strong>Un protocolo distribuido correcto en papel puede fallar por una carrera local</strong>
  <p>Deduplicación, liderazgo y membership se implementan con programas concurrentes ordinarios; un check-then-act incorrecto puede romper un invariante antes de que la red haga nada raro.</p>
  <p><strong>Pruébalo:</strong> Construye dos handlers que observen a la vez un request ID ausente y apliquen ambos el efecto.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">Más curiosidades del capítulo →</a>
</aside>

## 13. Un mutex local no implementa exclusión mutua distribuida

A y B pueden tener cada uno:

```text
mutex → leader=true
```

Ambos programas pueden estar libres de data races y discrepar globalmente.

> **La sincronización de memoria compartida ordena accesos dentro de un dominio. La coordinación distribuida ordena acciones entre dominios de fallo independientes.**

Más adelante aparecen elección de líder, consenso, leases y locks distribuidos.

## 14. Los procesos crean aislamiento de memoria y fallo

Procesos separados no comparten normalmente espacio de direcciones.

Ventajas:

- uno no muta directamente memoria ordinaria del otro;
- crashes pueden ser independientes;
- permisos/recursos pueden diferir;
- comunicación cruza IPC/red explícita.

Pero todavía pueden compartir:

- archivos;
- kernel;
- red;
- storage;
- CPU/memoria;
- fallo del host.

Tres procesos en un portátil son tres dominios de proceso, pero un solo dominio físico de host.

## 15. Los contenedores empaquetan y aíslan procesos, no hardware independiente

Namespaces y cgroups pueden dar vistas separadas de procesos, filesystem, red y recursos.

Son excelentes para laboratorios reproducibles.

Pero:

> **Tres contenedores sobre un kernel no equivalen a tres máquinas físicas independientes.**

Un kernel crash, OOM, fallo de disco o suspensión del host puede afectar a todos.

El modelo es válido si se declara honestamente.

## 16. Las máquinas virtuales ofrecen otro límite

Una VM incluye guest OS y hardware virtualizado.

Suele separar kernels con más fuerza que un contenedor, a cambio de mayor overhead/complejidad.

No hay que clasificar una opción como universalmente mejor.

Pregunta:

- ¿qué fallos deben ser independientes?
- ¿qué recursos aislar?
- ¿qué velocidad de arranque se necesita?
- ¿qué necesita emular el laboratorio?

Para muchos ejercicios bastan procesos o contenedores.

## 17. El shutdown es un protocolo concurrente

Un apagado real puede necesitar:

1. dejar de aceptar trabajo nuevo;
2. marcarse no disponible en descubrimiento;
3. drenar solicitudes en vuelo hasta un plazo;
4. cancelar lo que no terminará;
5. flush de estado/logs durables;
6. parar goroutines de fondo;
7. cerrar recursos;
8. salir.

El orden importa.

Cerrar recursos antes de terminar handlers provoca fallos incorrectos.

Esperar para siempre bloquea despliegue/recuperación.

Por eso shutdown merece pruebas deliberadas.

## 18. Graceful stop y crash-stop revelan supuestos distintos

Un graceful stop ejecuta cleanup.

Un crash abrupto no promete cleanup.

No demuestres «tolerancia a fallos» únicamente con SIGTERM y limpieza.

```text
SIGTERM + cleanup
```

y:

```text
kill -9 / muerte abrupta
```

pueden producir resultados completamente distintos.

## 19. Ejemplo trabajado — deduplicación concurrente

Del Capítulo 4:

```text
request_id → result
```

Llegan dos reintentos de R7 casi a la vez.

Código ingenuo:

```text
if R7 not in completed:
    apply effect
    completed[R7] = result
```

Intercalación:

```text
handler 1: absent
handler 2: absent
handler 1: apply
handler 2: apply
```

La idea distribuida de idempotencia era correcta, pero la implementación local tenía una carrera.

Reparaciones:

- mutex sobre check/apply/record completo;
- goroutine propietaria;
- almacenamiento transaccional.

Corrección local y distribuida se componen.

## 20. Ejemplo trabajado — carrera en el registro de workers

Una goroutine refresca leases y otra elimina expirados.

Sin sincronización, el mapa puede tener data race.

Incluso con mutex puede quedar una carrera semántica si la lógica de expiración usa un timestamp antiguo y elimina una encarnación recién renovada.

La eliminación debería validar:

```text
node_id
incarnation
lease version/deadline observado
```

antes de borrar.

`go test -race` ayuda con memoria insegura; el razonamiento de invariantes con estado obsoleto.

## 21. Ejemplo trabajado — sobrecarga dentro de un nodo saludable

Servidor vivo y alcanzable. Latencia pasa de 10 ms a 5 s.

Causa posible:

```text
entrada = 1000 req/s
capacidad = 600 req/s
```

La cola crece.

Clientes expiran y reintentan, añadiendo trabajo.

No hace falta pérdida de paquetes ni crash.

Investiga:

- número de goroutines;
- profundidad de cola;
- CPU;
- contención de locks;
- pools downstream;
- distribución de latencia.

«El nodo está up» no equivale a «puede progresar a tiempo».

## 22. Race detector: evidencia poderosa con autoridad limitada

```bash
go test -race ./...
go run -race ./cmd/server
```

Detecta carreras que ocurren en rutas realmente ejercitadas.

Un run limpio significa:

> no se observó una data race instrumentada en esa carga.

No prueba:

- ausencia en código no ejecutado;
- ausencia de deadlock;
- ausencia de carrera semántica;
- ausencia de carrera distribuida;
- ausencia de bottleneck.

El curso usa herramientas como evidencia con límites de autoridad explícitos.

## 23. Perspectiva histórica — de threads a runtimes de servicios

Threads, locks, monitors, message passing y procesos preceden al cloud.

Los runtimes modernos apilan niveles:

```text
cluster
  ↓
procesos/contenedores
  ↓
threads/goroutines
  ↓
async requests/tareas de fondo
```

Las nuevas abstracciones no eliminan problemas de concurrencia anteriores; se apoyan sobre ellos.

### Profundización — ownership, invariantes y evidencia local

Una forma práctica de revisar un nodo es escribir para cada estado mutable:

| Estado | Quién escribe | Quién lee | Invariante | Mecanismo |
|---|---|---|---|---|
| deduplicación | handlers | handlers | un ID lógico produce como máximo un efecto | mutex/owner |
| membresía | heartbeat + cleanup | router | no borrar una encarnación nueva usando evidencia vieja | versión + lock |
| cola | productores | workers | tamaño acotado | channel/semaphore |
| shutdown | señales | todos | no aceptar trabajo después de iniciar drain | context/estado |

Esta tabla evita la reparación superficial de «poner un mutex en el mapa». El mutex protege memoria; el invariante puede abarcar varias estructuras, una versión observada o una transición completa.

También conviene registrar el **tiempo de espera local** de recursos internos. Si un RPC tarda cinco segundos, la causa puede ser:

```text
4.8 s esperando un worker local
+
0.2 s ejecutando/esperando red
```

Sin medir cola y contención, es fácil culpar al peer remoto.

Los límites de aislamiento deben formularse con la misma precisión. Dos contenedores pueden aislar procesos y filesystem mientras comparten kernel, CPU, memoria, NIC y disco físico. Dos VMs pueden separar kernels pero seguir compartiendo host y alimentación. La afirmación correcta siempre nombra el fallo tolerado:

> «El experimento tolera la caída de un proceso», no «cada réplica es independiente».

Por último, el shutdown debe probarse como una máquina de estados. Una secuencia típica es:

```text
RUNNING → DRAINING → STOPPING → EXIT
```

y una muerte abrupta puede saltar directamente de `RUNNING` a proceso inexistente. Todo estado que solo se conserva gracias al camino `DRAINING` no forma parte de la garantía crash-recovery.

## 24. Errores comunes

### «Los canales de Go evitan carreras automáticamente»

Solo si el diseño sigue realmente una disciplina segura de ownership/comunicación.

### «Pasó el race detector; la concurrencia es correcta»

El detector observa data races ejecutadas, no cada invariante lógico.

### Proteger cada acceso individual, pero dividir un invariante entre locks

Seguridad del mapa no equivale a transición atómica de aplicación.

### Un lock global y olvidar rendimiento

Correctitud primero, pero un lock sobre trabajo caro puede serializar innecesariamente.

### Mantener locks durante llamadas remotas

El retraso remoto se convierte en bloqueo local.

### Usar mutex local para «arreglar» dos réplicas

No puede ordenar otro proceso.

### Tratar contenedores como hosts independientes

Pueden compartir kernel y fallo físico.

### Probar solo shutdown limpio

Una afirmación crash-tolerant exige muerte abrupta.

## Transición al laboratorio

El laboratorio parte de un servicio concurrente con estado compartido. Primero expones una data race, después la reparas, encuentras una carrera semántica que sobrevive al detector, provocas deadlock/sobrecarga y comparas graceful shutdown con muerte abrupta.

Regla de salida:

> **Antes de culpar a la distribución, demuestra que la máquina de estados local de cada nodo es segura, suficientemente viva y observable.**

## Resumen del capítulo

1. **Todo nodo distribuido es también un programa concurrente local.**
2. **Concurrencia produce intercalaciones incluso sin paralelismo físico.**
3. **El estado mutable compartido necesita ownership/sincronización explícitos.**
4. **Ausencia de data races no prueba invariantes de alto nivel.**
5. **Mutex y channels coordinan dentro de un dominio local.**
6. **Deadlock, starvation, fugas y sobrecarga pueden parecer problemas de red.**
7. **Concurrencia y colas acotadas son políticas de recursos.**
8. **Locks durante RPC acoplan progreso local a fallos remotos.**
9. **Un mutex local no crea acuerdo entre nodos.**
10. **Procesos, contenedores, VMs y hosts son límites de aislamiento/fallo distintos.**
11. **Graceful shutdown y crash-stop ejercitan caminos diferentes.**
12. **La corrección distribuida combina implementaciones locales correctas con protocolos correctos entre nodos.**

El siguiente capítulo cruza explícitamente el límite de proceso: incluso un servicio localmente correcto necesita un protocolo remoto cuyas semánticas de timeout, reintento y duplicados sigan siendo significativas.

<div class="ds-next-action">
  <span>Lectura esencial completada</span>
  <strong>Siguiente paso obligatorio · Práctica guiada</strong>
  <a href="../guided-practice/">Comenzar práctica guiada →</a>
</div>
