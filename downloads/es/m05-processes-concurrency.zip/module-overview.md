<p class="ds-book-part">Parte I — Fundamentos y arquitectura</p>
<p class="ds-module-kicker">Capítulo 3</p>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 3 de 12</span>
    <span>25% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 25%"></span></div>
</div>
<p class="ds-guiding-question">¿Qué límites de ejecución aíslan estado, planificación, recursos y fallos?</p>

Ya conoces procesos, hilos y sincronización de Sistemas Operativos. Aquí los retomamos como límites que determinan qué puede fallar junto, qué puede compartir memoria y qué debe comunicarse explícitamente.

## Ideas clave

- threads, goroutines y procesos;
- sincronización de estado compartido;
- condiciones de carrera e interbloqueos;
- servidores concurrentes;
- procesos frente a nodos distribuidos;
- contenedores y namespaces;
- máquinas virtuales y dominios de fallo del host;
- placement y migración como decisiones arquitectónicas.

## Transición al laboratorio

Expón una carrera dentro de un servicio, repárala, ejecuta después instancias independientes como procesos/contenedores y clasifica qué fallos siguen siendo compartidos.

## Empieza aquí

> **Antes de leer:** Cuatro contenedores se ejecutan en una misma computadora. ¿Cuántos dominios independientes de fallo de proceso existen? ¿Cuántos dominios independientes de fallo de máquina?

**Trae contigo:** Procesos, hilos o goroutines, sincronización y memoria virtual vistos en Sistemas Operativos.

**Este capítulo te prepara para:** Un límite preciso entre los errores locales de concurrencia y los fallos que requieren coordinación distribuida.

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>25 min–35 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>35 min–50 min</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>1 h 30 min–2 h · 5 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Leer lección →</a>
  <a class="ds-secondary-action" href="lab/">Abrir laboratorio</a>
</div>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../downloads/es/m05-processes-concurrency.zip" download>Descargar capítulo + laboratorio para estudio sin conexión (.zip)</a></p>

## Qué aprenderás

- Implementa un servidor concurrente e identifica su estado mutable compartido.
- Usa el detector de carreras de Go para revelar accesos no seguros.
- Distingue un mutex local de la coordinación distribuida.
- Explica los límites de aislamiento de procesos y contenedores.
- Diagnostica interbloqueo, inanición y sobrecarga en un nodo de servicio.

## Aprende trabajando la pregunta

1. Escribe tu respuesta a **Empieza aquí** antes de abrir la lección completa.
2. Lee hasta la siguiente predicción o traza; detente y resuélvela antes de revelar la explicación.
3. Trata la práctica guiada como un **banco de práctica**, no como una hoja para completar deprisa. Trabaja las trazas centrales hasta alcanzar el objetivo de práctica y vuelve después a los casos restantes.
4. Usa la comprobación para detectar vacíos y entra al laboratorio con una predicción falsable y con la evidencia que podría contradecirla.
5. Termina explicando qué estableció el experimento, qué no estableció y cómo cambia tu explicación del servicio acumulativo.

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../m02-ray-middleware/">← Arquitecturas y middleware</a>
<a class="ds-sequence-link next" href="../m03-rpc/">Comunicación I — Mensajes, RPC y fallos remotos →</a>
</nav>
