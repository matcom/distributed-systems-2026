> **Vista de referencia.** Esta página ofrece contexto opcional; vuelve a la [Lección](../lesson/) para la ruta obligatoria.

## Esencial

- **● Distributed Systems, 4th ed.** — Maarten van Steen and Andrew S. Tanenbaum. [book](https://www.distributed-systems.net/index.php/books/ds4/)
- **●● Data Race Detector** — The Go Project. [tool documentation](https://go.dev/doc/articles/race_detector)

## Recomendado

- **●● Designing Data-Intensive Applications** — Martin Kleppmann. [book](https://dataintensive.net/)
- **● The Go Documentation** — The Go Project. [tool documentation](https://go.dev/doc/)

## Avanzado

Todavía no hay un recurso adicional asignado.

## Herramientas y práctica

- **● Docker Documentation** — Docker. [tool documentation](https://docs.docker.com/)

## Explora

- **●●● 6.5840 Distributed Systems** — MIT PDOS. [course](https://pdos.csail.mit.edu/6.824/)
