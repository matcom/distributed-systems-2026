<div class="ds-lesson-banner">
  <div><span>Laboratorio obligatorio</span><strong>Capítulo 1</strong></div>
  <div><span>Modelo de evidencia</span><strong>predecir → ejecutar → observar → explicar</strong></div>
  <div><span>Verificación</span><strong>6 pruebas públicas transparentes + evidencia</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 1 de 12</span>
    <span>8% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 8%"></span></div>
</div>
<p class="ds-back-link"><a href="../quick-check/">← Volver a la comprobación</a></p>

> **Antes de comenzar:** Completa los pasos de práctica guiada y comprobación de conocimientos. Ya deberías poder formular una predicción y nombrar la evidencia que la apoyaría o contradeciría. Si no, [vuelve a la comprobación](../quick-check/) y revisa la lección donde haga falta.

## Propósito

Este laboratorio convierte la afirmación central del Capítulo 1 en un experimento observable:

> Una operación remota puede parecerse a una llamada local, pero su semántica temporal y de fallo es diferente.

Compararás el mismo cálculo realizado localmente y por otro proceso. Después añadirás retardo, provocarás un timeout del cliente, terminarás el servidor y clasificarás exactamente qué puede y qué no puede saber el cliente en cada caso.

## Pregunta central

En cada ejecución responde:

> **¿Qué observó el cliente, qué pudo haber ocurrido en el servidor y qué evidencia adicional distinguiría esas posibilidades?**

## Preparación

Reutiliza el pequeño contrato del Calentamiento o implementa un servicio equivalente de dos procesos. Mantén la aplicación deliberadamente simple para aislar la diferencia semántica entre ejecución local y remota.

Usa una operación determinista como:

```text
double(21) → 42
```

en dos formas:

```text
llamada local a función
```

y:

```text
cliente → límite socket/RPC → proceso servidor → respuesta
```

## Experimento A — Línea base local

Ejecuta muchas veces la operación local.

Registra:

- cantidad de llamadas;
- tiempo total;
- tiempo mediano o representativo por llamada;
- identidad del proceso;
- si se cruza algún límite de serialización/red.

No sobreinterpretes diferencias de nanosegundos. El objetivo es establecer dependencias, no hacer benchmark del runtime.

## Experimento B — Línea base remota

Inicia un proceso servidor independiente e invoca la misma operación remotamente.

Dibuja:

```text
proceso cliente
   ↓
serialización / framing
   ↓
transporte
   ↓
proceso servidor
   ↓
operación
   ↓
ruta de respuesta
```

Registra:

- PID del cliente y servidor;
- endpoint;
- request ID;
- respuesta;
- tiempo transcurrido;
- evidencia correspondiente del servidor.

Explica qué componentes adicionales aparecen frente a la llamada local.

## Experimento C — Servidor lento, timeout amplio

Configura un retardo:

```text
server delay: 700 ms
client timeout: 1500 ms
```

Predice antes de ejecutar si la solicitud terminará.

Compara la latencia observada con el retardo configurado y explica por qué «el servidor está lento» no equivale a «el servidor falló».

## Experimento D — Servidor lento, timeout pequeño

Mantén el retardo y reduce el timeout:

```text
server delay: 700 ms
client timeout: 200 ms
```

Predice primero. Después recoge evidencia del cliente y del servidor.

El informe debe responder:

1. ¿Recibió el cliente el resultado?
2. ¿Recibió el servidor la solicitud?
3. ¿Comenzó a ejecutarla?
4. ¿Terminó?
5. ¿Qué demostró por sí solo el timeout?

Aquí el curso separa por primera vez **conocimiento del cliente** de **realidad remota**.

## Experimento E — Servidor caído antes de la solicitud

Detén el servidor y envía una nueva solicitud.

Registra la categoría del error y compárala con el Experimento D.

La pregunta no es si el texto del error coincide. Pregunta si el cliente puede distinguir ambas situaciones con la evidencia disponible y en qué capa.

## Experimento F — Finalización ambigua

Usa un modo en el que el servidor complete un efecto visible y luego falle o pierda la respuesta antes de que el cliente confirme el éxito.

Un efecto educativo sencillo es añadir el request ID a un archivo del servidor:

```text
cliente envía R
     ↓
servidor registra R
     ↓
respuesta no disponible
     ↓
cliente agota timeout
```

Ahora pregunta:

> ¿Debe el cliente reintentar R?

Explica qué mecanismo adicional haría más seguro el reintento:

- operaciones idempotentes;
- request IDs estables;
- detección de duplicados;
- consulta del estado de la operación;
- cambios de estado transaccionales.

No resuelvas todos esos mecanismos todavía. Identifica el problema de diseño que atacan.

## Experimento G — Clientes concurrentes

Ejecuta al menos dos clientes en paralelo.

Si la operación es pura, predice si el orden de solicitudes debería cambiar el resultado.

Después explica qué cambia si la operación modifica un contador compartido.

## Requisitos de evidencia

En los experimentos remotos incluye evidencia de al menos tres capas:

```text
observación del cliente
observación del servidor/proceso
observación de comunicación/endpoint
```

Puede incluir:

- resultado/error del cliente;
- logs estructurados;
- request IDs;
- salida de `ss`;
- estado del proceso;
- captura opcional de paquetes;
- archivo/estado con efectos.

## Pruebas transparentes

La implementación inicial en `starter/src/` incluye:

- la misma operación `double` local y remota;
- un servicio HTTP con request IDs estables;
- un log visible de efectos;
- un modo que registra el efecto y cierra la conexión antes de responder.

Las pruebas públicas en `tests/official/` verifican:

- equivalencia entre resultado local y remoto;
- validación de request ID y timeout;
- representación visible del efecto;
- efectos confirmados;
- el caso de finalización ambigua en el que el cliente no recibe respuesta pero el efecto existe.

Ese último caso no «resuelve» los reintentos: establece la incertidumbre que deberán resolver mecanismos posteriores.

Añade tus casos en `tests/student/`. Son buenas extensiones solicitudes malformadas, valores negativos, request IDs repetidos o supresión de duplicados si decides implementarla.

No existen casos ocultos.

## Informe obligatorio

Completa `REPORT.md` con una tabla como:

| Experimento | Observación del cliente | Realidad/evidencia del servidor | ¿Qué puedes concluir? |
|---|---|---|---|
| Local | | | |
| Remoto normal | | | |
| Lento / timeout suficiente | | | |
| Lento / timeout del cliente | | | |
| Servidor ausente | | | |
| Finalización ambigua | | | |

Después responde:

1. ¿Por qué una llamada remota es semánticamente distinta de una local?
2. ¿Qué experimento mostró fallo parcial?
3. ¿Cuál mostró conocimiento incompleto?
4. ¿Qué operaciones serían seguras de reintentar y por qué?
5. ¿Qué supuesto tendría que cambiar para que el cliente supiera con certeza que una operación no se ejecutó?

## Uso de IA

Se permiten asistentes y agentes.

Pide, por ejemplo, que clasifique cada fallo y compara su explicación con la evidencia real de procesos/logs. Registra al menos un caso en el que la evidencia te obligó a refinar o rechazar una explicación inicial.

## Termina el capítulo

Reproduce el resultado importante desde un inicio limpio. Después vuelve a tu predicción inicial: explica qué cambió, qué evidencia provocó el cambio y qué incertidumbre queda. Un comando exitoso o una captura no bastan cuando la afirmación trata de retries, orden, durabilidad, consistencia, recovery, seguridad o rendimiento.

<div class="ds-next-action">
  <span>Capítulo completo</span>
  <strong>Continuar el curso</strong>
  <a href="../../m02-ray-middleware/">Arquitecturas y middleware →</a>
</div>

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../../m00-tooling/">← Taller de laboratorio</a>
<a class="ds-sequence-link next" href="../../m02-ray-middleware/">Arquitecturas y middleware →</a>
</nav>
