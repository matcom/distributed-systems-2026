"""Deterministic pieces of the Chapter 1 local/remote experiment."""

from __future__ import annotations

from pathlib import Path


def double(value: int) -> int:
    return value * 2


def validate_timeout_ms(value: int) -> int:
    if value <= 0:
        raise ValueError("timeout must be positive")
    return value


def normalize_request_id(value: str | None) -> str:
    if value is None or not value.strip():
        raise ValueError("X-Request-ID is required")
    return value.strip()


def append_effect(path: str | Path, request_id: str) -> int:
    rid = normalize_request_id(request_id)
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("a", encoding="utf-8") as handle:
        handle.write(rid + "\n")
    return count_effect(path, rid)


def count_effect(path: str | Path, request_id: str) -> int:
    target = Path(path)
    if not target.exists():
        return 0
    return sum(1 for line in target.read_text(encoding="utf-8").splitlines() if line == request_id)
