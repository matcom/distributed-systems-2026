"""Client helpers for Chapter 1 remote-operation experiments."""

from __future__ import annotations

import argparse
import json
import urllib.error
import urllib.request

from model import normalize_request_id, validate_timeout_ms


def _get(*, port: int, path: str, request_id: str, timeout_ms: int) -> dict[str, object]:
    rid = normalize_request_id(request_id)
    timeout = validate_timeout_ms(timeout_ms) / 1000.0
    req = urllib.request.Request(
        f"http://127.0.0.1:{port}{path}",
        headers={"X-Request-ID": rid},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise RuntimeError(f"remote observation: {exc}") from exc


def remote_double(*, port: int, value: int, request_id: str, timeout_ms: int = 1000) -> dict[str, object]:
    return _get(
        port=port,
        path=f"/work?value={value}",
        request_id=request_id,
        timeout_ms=timeout_ms,
    )


def remote_effect(*, port: int, request_id: str, timeout_ms: int = 1000) -> dict[str, object]:
    return _get(
        port=port,
        path="/effect",
        request_id=request_id,
        timeout_ms=timeout_ms,
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8201)
    parser.add_argument("--operation", choices=("work", "effect"), default="work")
    parser.add_argument("--value", type=int, default=21)
    parser.add_argument("--request-id", required=True)
    parser.add_argument("--timeout-ms", type=int, default=1000)
    args = parser.parse_args()

    try:
        if args.operation == "work":
            result = remote_double(
                port=args.port,
                value=args.value,
                request_id=args.request_id,
                timeout_ms=args.timeout_ms,
            )
        else:
            result = remote_effect(
                port=args.port,
                request_id=args.request_id,
                timeout_ms=args.timeout_ms,
            )
    except (ValueError, RuntimeError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, sort_keys=True))
        return 2

    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
