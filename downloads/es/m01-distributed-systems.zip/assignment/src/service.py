"""Small stateful HTTP service for local-vs-remote failure experiments."""

from __future__ import annotations

import argparse
import json
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from model import append_effect, double, normalize_request_id


class ExperimentServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(
        self,
        address: tuple[str, int],
        *,
        delay_ms: int = 0,
        effect_file: str = "effects.log",
        drop_response_after_effect: bool = False,
    ) -> None:
        if delay_ms < 0:
            raise ValueError("delay must be non-negative")
        super().__init__(address, ExperimentHandler)
        self.delay_ms = delay_ms
        self.effect_file = effect_file
        self.drop_response_after_effect = drop_response_after_effect
        self.events: list[dict[str, object]] = []

    def record(self, **event: object) -> None:
        self.events.append(dict(event))
        print(json.dumps(event, sort_keys=True), flush=True)


class ExperimentHandler(BaseHTTPRequestHandler):
    server: ExperimentServer

    def log_message(self, format: str, *args) -> None:
        return

    def _json(self, status: int, payload: dict[str, object]) -> None:
        body = json.dumps(payload, sort_keys=True).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        try:
            request_id = normalize_request_id(self.headers.get("X-Request-ID"))
        except ValueError as exc:
            self._json(400, {"error": str(exc)})
            return

        if parsed.path == "/work":
            values = parse_qs(parsed.query).get("value")
            if not values or len(values) != 1:
                self._json(400, {"error": "exactly one value is required"})
                return
            try:
                value = int(values[0])
            except ValueError:
                self._json(400, {"error": "value must be an integer"})
                return

            self.server.record(event="received", request_id=request_id, operation="work")
            if self.server.delay_ms:
                time.sleep(self.server.delay_ms / 1000.0)
            result = double(value)
            self.server.record(
                event="finished",
                request_id=request_id,
                operation="work",
                result=result,
            )
            self._json(
                200,
                {
                    "request_id": request_id,
                    "value": value,
                    "result": result,
                },
            )
            return

        if parsed.path == "/effect":
            self.server.record(event="received", request_id=request_id, operation="effect")
            count = append_effect(self.server.effect_file, request_id)
            self.server.record(
                event="effect_recorded",
                request_id=request_id,
                operation="effect",
                count=count,
            )
            if self.server.drop_response_after_effect:
                self.close_connection = True
                return
            self._json(
                200,
                {
                    "request_id": request_id,
                    "acknowledged": True,
                    "effect_count": count,
                },
            )
            return

        self._json(404, {"error": "unknown path"})


def make_server(
    *,
    port: int,
    delay_ms: int = 0,
    effect_file: str = "effects.log",
    drop_response_after_effect: bool = False,
    host: str = "127.0.0.1",
) -> ExperimentServer:
    return ExperimentServer(
        (host, port),
        delay_ms=delay_ms,
        effect_file=effect_file,
        drop_response_after_effect=drop_response_after_effect,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8201)
    parser.add_argument("--delay-ms", type=int, default=0)
    parser.add_argument("--effect-file", default="effects.log")
    parser.add_argument("--drop-response-after-effect", action="store_true")
    args = parser.parse_args()

    server = make_server(
        port=args.port,
        delay_ms=args.delay_ms,
        effect_file=args.effect_file,
        drop_response_after_effect=args.drop_response_after_effect,
    )
    print(json.dumps({"event": "listening", "port": server.server_address[1]}), flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
