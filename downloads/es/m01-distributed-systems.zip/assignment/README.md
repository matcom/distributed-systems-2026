# Laboratory — Local Call vs Remote Operation

## Purpose

This laboratory turns the central claim of Chapter 1 into an observable experiment:

> A remote operation may look like a local function call, but its timing and failure semantics are different.

You will compare the same computation performed locally and by another process. Then you will add delay, trigger a client timeout, kill the server, and classify exactly what the client can and cannot know in each case.

## Core question

For every run, answer:

> **What did the client observe, what might have happened at the server, and which additional evidence would distinguish those possibilities?**

## Required setup

Reuse the small service contract from the Warm-up or implement an equivalent two-process service. The application behavior should remain deliberately simple so this lab isolates the semantic difference between local and remote execution rather than introducing a new framework.

The workload should expose one deterministic operation such as:

```text
double(21) → 42
```

in two forms:

```text
local function call
```

and:

```text
client → socket/RPC boundary → server process → response
```

The application function should remain deliberately trivial so the experiment isolates the distributed boundary.

## Experiment A — Local baseline

Run the operation locally many times.

Record:

- number of calls;
- total elapsed time;
- median or representative per-call time;
- process identity;
- whether any serialization/network boundary is crossed.

Do not over-interpret nanosecond-level differences. The purpose is to establish the dependency structure, not benchmark the Python or Go runtime.

## Experiment B — Remote baseline

Start a separate server process and invoke the same operation remotely.

Draw the path:

```text
client process
   ↓
serialization / request framing
   ↓
transport
   ↓
server process
   ↓
operation
   ↓
response path
```

Record:

- client and server PIDs;
- endpoint;
- request identifier;
- response;
- elapsed time;
- matching server evidence.

Explain which additional components exist compared with the local call.

## Experiment C — Slow server, large timeout

Configure the remote operation to delay before responding.

Example target:

```text
server delay: 700 ms
client timeout: 1500 ms
```

Before running it, predict whether the request should complete.

After running, compare the observed latency with the configured server delay.

Explain why “the server is slow” is a different statement from “the server failed.”

## Experiment D — Slow server, small timeout

Keep the server delay but reduce the client timeout.

Example:

```text
server delay: 700 ms
client timeout: 200 ms
```

Predict the client outcome first.

Then collect both client and server evidence.

The report must explicitly answer:

1. Did the client receive the result?
2. Did the server receive the request?
3. Did the server begin execution?
4. Did the server finish execution?
5. What did the timeout alone prove?

This is the first place where the course separates **client knowledge** from **remote truth**.

## Experiment E — Server crash before the request

Stop the server and issue a new remote request.

Record the error category and compare it with Experiment D.

The important question is not whether the two errors have identical text. It is whether the client can distinguish them through available evidence and at what layer.

## Experiment F — Ambiguous completion

Create or use a mode in which the server can complete a visible side effect and then fail or lose the response before the client confirms success.

A simple educational side effect is appending a request ID to a local server file.

The conceptual timeline is:

```text
client sends R
     ↓
server records R
     ↓
response unavailable
     ↓
client times out
```

Now ask:

> Should the client retry R?

Explain what additional mechanism would make retry safer. Candidate mechanisms include:

- idempotent operations;
- stable request IDs;
- duplicate detection;
- querying operation status;
- transactional state changes.

Do not solve all of those mechanisms in Chapter 1. Identify the design problem they address.

## Experiment G — Concurrent clients

Run at least two clients concurrently against the server.

If the operation is pure, predict whether request order should affect the result.

Then answer how the problem would change if the operation modified one shared counter.

This prepares the transition from simple remote computation to distributed state.

## Evidence requirements

For the remote experiments, include enough evidence to distinguish at least three layers:

```text
client observation
server/process observation
communication or endpoint observation
```

Useful evidence can include:

- client result/error;
- structured server logs;
- request IDs;
- `ss` output;
- process state;
- optional packet capture;
- side-effect file/state.

## Transparent tests

The starter implementation lives in `starter/src/` and includes:

- the same deterministic `double` operation locally and remotely;
- an HTTP service carrying stable request IDs;
- a visible side-effect log;
- a mode that records the effect and then closes the connection before returning a response.

The public tests under `tests/official/` verify deterministic pieces of the experiment:

- local and remote result equivalence;
- request-ID and timeout validation;
- visible side-effect representation;
- acknowledged side effects;
- the ambiguous-completion case where the client gets no response but the effect is present.

That final case is intentionally important: the test does not “solve” retries. It establishes the uncertainty the rest of the course must address.

Add your own cases under `tests/student/`. Useful extensions include malformed requests, negative values, repeated request IDs, or duplicate suppression if you choose to add it.

No hidden cases are planned.

## Required report

Complete `REPORT.md` with a table similar to:

| Experiment | Client observation | Server truth/evidence | What can be concluded? |
|---|---|---|---|
| Local | | | |
| Remote baseline | | | |
| Slow / sufficient timeout | | | |
| Slow / client timeout | | | |
| Server absent | | | |
| Ambiguous completion | | | |

Then answer:

1. Why is a remote call semantically different from a local call?
2. Which experiment demonstrated partial failure?
3. Which experiment demonstrated incomplete knowledge?
4. Which operation(s) would be safe to retry and why?
5. What assumption would have to change for the client to know with certainty that an operation did not execute?

## AI use

AI assistants and coding agents are permitted.

A useful exercise is to ask an assistant to classify each failure, then compare its explanation with the actual process/log evidence. Record at least one place where evidence was necessary to refine or reject an initial explanation.