# M01 Laboratory Report

## Environment and topology

- Client process:
- Server process:
- Endpoint:
- Git revision / dirty state:

## Results table

| Experiment | Client observation | Server/process evidence | What can be concluded? |
|---|---|---|---|
| Local baseline | | | |
| Remote baseline | | | |
| Slow / sufficient timeout | | | |
| Slow / client timeout | | | |
| Server absent | | | |
| Ambiguous completion | | | |
| Concurrent clients | | | |

## Local vs remote dependency path

Draw or describe the extra components crossed by the remote operation.

## Ambiguous timeout analysis

List at least four server-side realities that can produce a client timeout or missing response.

## Retry analysis

- Which operation is safe to retry?
- Which operation may duplicate a side effect?
- Which mechanism would make the dangerous retry safer?

## Partial failure

Identify the experiment that best demonstrates partial failure and explain why surviving components cannot directly know all remote state.

## Student-authored transparent test

Describe the case and why it matters.

## AI-use disclosure

```yaml
ai_use:
  used: false
  tools: []
  activities: []
  verification: []
```

## Final answer

In your own words: **What changes when one program becomes several independently failing processes?**