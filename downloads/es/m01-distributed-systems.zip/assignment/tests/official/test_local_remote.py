import tempfile
import threading
import unittest
from pathlib import Path

from client import remote_double, remote_effect
from model import append_effect, count_effect, double, normalize_request_id, validate_timeout_ms
from service import make_server


class LocalModelTests(unittest.TestCase):
    def test_local_operation_is_deterministic(self):
        self.assertEqual(double(21), 42)
        self.assertEqual(double(-5), -10)

    def test_request_and_timeout_validation(self):
        self.assertEqual(normalize_request_id(" r-1 "), "r-1")
        self.assertEqual(validate_timeout_ms(200), 200)
        with self.assertRaises(ValueError):
            normalize_request_id("")
        with self.assertRaises(ValueError):
            validate_timeout_ms(0)

    def test_side_effect_representation_is_observable(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "effects.log"
            self.assertEqual(append_effect(path, "r-9"), 1)
            self.assertEqual(append_effect(path, "r-9"), 2)
            self.assertEqual(count_effect(path, "r-9"), 2)


class RemoteExperimentTests(unittest.TestCase):
    def setUp(self):
        self._servers = []

    def tearDown(self):
        for server, thread in self._servers:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)

    def start_server(self, **kwargs):
        server = make_server(port=0, **kwargs)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self._servers.append((server, thread))
        return server

    def test_remote_result_matches_local_result(self):
        with tempfile.TemporaryDirectory() as tmp:
            server = self.start_server(effect_file=str(Path(tmp) / "effects.log"))
            body = remote_double(
                port=server.server_address[1],
                value=21,
                request_id="remote-1",
            )
            self.assertEqual(body["result"], double(21))
            self.assertEqual(body["request_id"], "remote-1")

    def test_acknowledged_effect_is_recorded(self):
        with tempfile.TemporaryDirectory() as tmp:
            effect_file = Path(tmp) / "effects.log"
            server = self.start_server(effect_file=str(effect_file))
            body = remote_effect(
                port=server.server_address[1],
                request_id="effect-1",
            )
            self.assertTrue(body["acknowledged"])
            self.assertEqual(body["effect_count"], 1)
            self.assertEqual(count_effect(effect_file, "effect-1"), 1)

    def test_missing_response_does_not_mean_missing_effect(self):
        with tempfile.TemporaryDirectory() as tmp:
            effect_file = Path(tmp) / "effects.log"
            server = self.start_server(
                effect_file=str(effect_file),
                drop_response_after_effect=True,
            )
            with self.assertRaises(RuntimeError):
                remote_effect(
                    port=server.server_address[1],
                    request_id="ambiguous-1",
                )
            self.assertEqual(count_effect(effect_file, "ambiguous-1"), 1)


if __name__ == "__main__":
    unittest.main()
