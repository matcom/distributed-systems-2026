# Transparent official cases

The public suite is executable and intentionally small.

It checks:

- deterministic local operation results;
- identical remote results for the same valid input;
- stable request-ID validation and propagation;
- positive timeout configuration;
- a visible append-only side-effect representation;
- an acknowledged remote side effect;
- an ambiguous-completion execution in which the client receives no response even though the server-side effect was recorded.

The suite does not pretend to prove every network execution. Delay, process crash, socket state, and evidence interpretation remain explicit laboratory experiments.

Add your own visible cases under `tests/student/`.

No hidden tests are used.
