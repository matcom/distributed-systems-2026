> **Vista de referencia.** Esta página ofrece contexto opcional; vuelve a la [Lección](../lesson/) para la ruta obligatoria.

## Esencial

- **● Distributed Systems, 4th ed.** — Maarten van Steen and Andrew S. Tanenbaum. [book](https://www.distributed-systems.net/index.php/books/ds4/)
- **● Distributed Systems lecture/book resources** — Maarten van Steen. [book resources](https://www.distributed-systems.net/)

## Recomendado

- **●● Designing Data-Intensive Applications** — Martin Kleppmann. [book](https://dataintensive.net/)

## Avanzado

- **●● Time, Clocks, and the Ordering of Events in a Distributed System** — Leslie Lamport. [paper](https://lamport.azurewebsites.net/pubs/time-clocks.pdf)

## Herramientas y práctica

- **● The Go Documentation** — The Go Project. [tool documentation](https://go.dev/doc/)

## Explora

- **●●● 6.5840 Distributed Systems** — MIT PDOS. [course](https://pdos.csail.mit.edu/6.824/)
