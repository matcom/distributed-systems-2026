<p class="ds-book-part">Parte I — Fundamentos y arquitectura</p>
<p class="ds-module-kicker">Capítulo 1</p>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 1 de 12</span>
    <span>8% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 8%"></span></div>
</div>
<p class="ds-guiding-question">¿Qué cambia cuando una operación atraviesa un límite de fallo independiente?</p>

Comienza con la comparación más pequeña que resulta útil: una llamada local y la misma operación ejecutada por otro proceso. Después añade retardo, concurrencia, una respuesta perdida y un servidor que puede fallar de manera independiente. La sintaxis puede parecer casi igual; el conocimiento disponible para quien llama no lo es.

## Ideas clave

- componentes autónomos;
- latencia y retardo incierto;
- estado independiente;
- concurrencia;
- fallo parcial;
- transparencia y apertura;
- escalabilidad;
- supuestos del sistema y del modelo de fallos.

## Transición al laboratorio

Ejecuta la misma operación de forma local y remota. Introduce retardo y fallos; después indica exactamente qué puede y qué no puede saber el cliente tras un timeout.

## Empieza aquí

> **Antes de leer:** Un cliente agota su tiempo de espera después de enviar una actualización. Enumera tres ejecuciones en las que el servidor no hizo nada y tres en las que sí modificó su estado.

**Trae contigo:** Procesos, sockets, latencia y llamadas locales ordinarias a funciones vistos en Sistemas Operativos y Redes de Computadoras.

**Este capítulo te prepara para:** El modelo mental que usarás en todos los capítulos siguientes: estado independiente, comunicación incierta, concurrencia y fallos parciales.

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>30 min–40 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>35 min–50 min</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>1 h 15 min–1 h 45 min · 6 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Leer lección →</a>
  <a class="ds-secondary-action" href="lab/">Abrir laboratorio</a>
</div>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../downloads/es/m01-distributed-systems.zip" download>Descargar capítulo + laboratorio para estudio sin conexión (.zip)</a></p>

## Qué aprenderás

- Explica por qué una operación remota no puede tratarse como una llamada local a función.
- Distingue concurrencia, distribución y paralelismo.
- Describe el fallo parcial y por qué complica la corrección.
- Identifica los supuestos de los modelos síncrono, asíncrono y parcialmente síncrono.
- Traduce la descripción de una aplicación a nodos, canales, estado y supuestos de fallo.

## Aprende trabajando la pregunta

1. Escribe tu respuesta a **Empieza aquí** antes de abrir la lección completa.
2. Lee hasta la siguiente predicción o traza; detente y resuélvela antes de revelar la explicación.
3. Trata la práctica guiada como un **banco de práctica**, no como una hoja para completar deprisa. Trabaja las trazas centrales hasta alcanzar el objetivo de práctica y vuelve después a los casos restantes.
4. Usa la comprobación para detectar vacíos y entra al laboratorio con una predicción falsable y con la evidencia que podría contradecirla.
5. Termina explicando qué estableció el experimento, qué no estableció y cómo cambia tu explicación del servicio acumulativo.

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../m00-tooling/">← Taller de laboratorio</a>
<a class="ds-sequence-link next" href="../m02-ray-middleware/">Arquitecturas y middleware →</a>
</nav>
