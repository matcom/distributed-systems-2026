<p class="ds-book-part">Parte I — Fundamentos y arquitectura</p>
<div class="ds-lesson-banner">
  <div><span>Paso del curso</span><strong>Capítulo 1</strong></div>
  <div><span>Lectura esencial</span><strong>30 min–40 min</strong></div>
  <div><span>Ruta obligatoria</span><strong>Leer → Objetivo de práctica → Comprobar → Laboratorio</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 1 de 12</span>
    <span>8% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 8%"></span></div>
</div>

> **Pregunta guía:** ¿Qué cambia cuando una operación atraviesa un límite de fallo independiente?

## Antes de leer

> Un cliente agota su tiempo de espera después de enviar una actualización. Enumera tres ejecuciones en las que el servidor no hizo nada y tres en las que sí modificó su estado.

Escribe primero una respuesta breve. No necesitas acertar todavía: necesitas una predicción que puedas revisar a medida que el capítulo te dé mejores modelos y evidencia.

**Usa lo que ya sabes:** Procesos, sockets, latencia y llamadas locales ordinarias a funciones vistos en Sistemas Operativos y Redes de Computadoras.

## Mapa de carga de trabajo

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>30 min–40 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>35 min–50 min</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>1 h 15 min–1 h 45 min · 6 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../../downloads/es/m01-distributed-systems.zip" download>Descargar lección + práctica + laboratorio para estudio sin conexión (.zip)</a></p>

## Por qué importa este capítulo

Un programa que funciona perfectamente dentro de un proceso puede volverse incorrecto cuando su cálculo y su estado se reparten entre participantes que fallan de manera independiente.

Una llamada local:

```text
result = service.update(x)
```

puede convertirse en:

```text
result = remote_service.update(x)
```

La sintaxis apenas cambia. La semántica sí.

Una llamada local puede retornar, lanzar un error, bloquearse o desaparecer con el proceso. Una operación remota añade red, otro scheduler, otro proceso, otro reloj, otro dominio de fallo y, sobre todo, incertidumbre sobre lo ocurrido después de que el mensaje abandonó al cliente.

La respuesta importante no es «se vuelve más lento». Cambian el **estado**, la **comunicación**, el **orden**, los **fallos** y el **conocimiento** disponible en cada participante.

## 1. Empieza por el sistema distribuido más pequeño

Dos procesos ya bastan:

```text
Cliente                         Servidor
  │                               │
  │ -------- solicitud ---------> │
  │                               │ calcula
  │ <------- respuesta ---------  │
```

Hay al menos tres grupos de estado.

### Estado del cliente

- operación deseada;
- request ID;
- timeout;
- política de reintento;
- creencia sobre si la operación terminó.

### Estado del servidor

- si recibió la solicitud;
- si comenzó la ejecución;
- si terminó;
- si cambió estado durable;
- si envió respuesta.

### Estado de comunicación

- si se entregaron los bytes;
- cuánto tardaron;
- si existe conexión;
- si se entregaron los bytes de respuesta.

Ningún participante puede observar todo eso atómicamente. La ausencia de una observación global perfecta es una dificultad central.

<aside class="ds-book-note ds-history">
  <span class="ds-book-note-label">Historia</span>
  <strong>RPC facilitó escribir programas distribuidos al ocultar la red, y también hizo más fácil olvidar la semántica de los fallos</strong>
  <p>Remote Procedure Call convirtió mensajes en llamadas con apariencia familiar, pero timeouts, ejecución duplicada, reintentos y fallos parciales impiden que una llamada remota sea semánticamente igual a una local.</p>
  <a class="ds-book-note-source" href="../../../history/rpc-transparency-and-failure/">Lee la historia del diseño →</a>
</aside>

## 2. Distribución no es lo mismo que paralelismo

### Paralelismo

Varias computaciones se ejecutan simultáneamente para acelerar trabajo.

```text
un programa
   ├── núcleo 1
   ├── núcleo 2
   └── núcleo 3
```

Pueden compartir memoria y dominio de fallo.

### Distribución

Varios componentes con ejecución independiente cooperan mediante comunicación.

```text
proceso A       proceso B       proceso C
   │               │               │
   └────── red / mensajes ──────────┘
```

Un sistema distribuido puede ser paralelo, pero no tiene que serlo.

> **Detente y predice.** Ocho goroutines actualizan un mapa protegido por un mutex. ¿Es automáticamente un sistema distribuido? No. Comparten espacio de direcciones y el mutex puede proteger directamente esa memoria.

## 3. Memoria independiente cambia la coordinación

Dentro de un proceso, dos funciones pueden coordinarse mediante una variable compartida.

Entre máquinas no existe una variable ordinaria que ambas CPU lean y escriban atómicamente.

```text
Nodo A                    Nodo B
estado_A                  estado_B
   │                         │
   └──────── mensajes ───────┘
```

Si A quiere que B conozca algo, la información debe cruzar un límite de comunicación o ambos deben depender de un tercer servicio.

> **Coordinación distribuida = comunicación + transiciones de estado bajo fallo.**

Un mutex local no puede impedir directamente que otra máquina tome una decisión incompatible.

Más adelante usarás líderes, leases, quórums, consenso, transacciones, CRDT y coordinación específica de la aplicación.

## 4. No existe un único reloj perfectamente compartido

Supón:

```text
10:00:00.120  Nodo A envía R
10:00:00.090  Nodo B recibe R
```

¿Recibió B el mensaje antes de que A lo enviara? No. Los timestamps pertenecen a relojes distintos.

El mensaje crea una relación causal aunque los valores físicos resulten engañosos.

```text
lectura de reloj local ≠ orden universal de eventos
```

Esto importa para depuración, conflictos, leases, transacciones, medición y auditoría. El Capítulo 6 lo formaliza con happened-before, Lamport y relojes vectoriales.

## 5. La comunicación tiene retardo y ese retardo varía

Una operación remota incluye:

```text
serialización
   +
planificación local
   +
transporte/red
   +
planificación remota
   +
ejecución del servidor
   +
ruta de respuesta
```

El cliente observa principalmente el tiempo total hasta respuesta o timeout.

Una respuesta que suele tardar 2 ms puede tardar 200 ms por colas, scheduling, GC, almacenamiento, retransmisiones, sobrecarga, dependencias o failover.

La variabilidad deja de ser «solo rendimiento» cuando un timeout obliga a decidir si esperar, fallar o reintentar.

<figure class="ds-book-figure">
  <img src="../../../../assets/book/m01-remote-ambiguity-es.svg" alt="Varias ejecuciones remotas diferentes pueden producir el mismo timeout observado por el cliente." loading="lazy" decoding="async" />
  <figcaption><span>Figura</span>Un timeout, varias historias remotas compatibles. El cliente observa su espera; no observa directamente la historia del servidor.</figcaption>
</figure>

## 6. El fallo parcial es la diferencia central

En un sistema distribuido algunos componentes pueden seguir funcionando mientras otros no:

```text
Cliente   ✓ vivo
Servidor  ✗ crash
Red       ✓ parcialmente operativa
DB        ✓ viva
Réplica   ? no alcanzable
```

Ese **fallo parcial** obliga a los supervivientes a actuar sin acceder directamente al estado interno del componente ausente.

### El timeout ambiguo

```text
Cliente                Servidor
  │                      │
  │ -- retirar 10 -----> │
  │                      │ resta 10
  │                      │ persiste
  │ <---- respuesta -- X │
  │
 timeout
```

El cliente sabe que no recibió respuesta.

No sabe si el servidor:

1. nunca recibió la solicitud;
2. la recibió y falló antes de ejecutar;
3. ejecutó pero falló antes de persistir;
4. persistió y falló antes de responder;
5. respondió y la respuesta se perdió o retrasó.

Un reintento ciego puede producir un segundo efecto.

De aquí nacen request IDs, idempotencia, deduplicación, transacciones, estado durable y replicación.

## 7. Fallo y lentitud pueden parecer idénticos

A envía un heartbeat a B y no recibe respuesta en 500 ms.

Posibilidades:

```text
B murió
B está pausado
B está sobrecargado
solicitud retrasada
respuesta retrasada
ruta particionada
el propio A estuvo pausado
```

A no puede saber siempre cuál es la causa real cuando expira su temporizador.

> **Un timeout puede justificar una acción local sin demostrar un hecho remoto.**

El detector de fallos del Capítulo 10 formaliza esta idea.

## 8. La concurrencia admite varios órdenes válidos

Dos clientes escriben:

```text
A: set x = 1
B: set x = 2
```

Dos réplicas pueden recibir en distinto orden:

```text
R1: A luego B → x = 2
R2: B luego A → x = 1
```

La red no ofrece un orden universal para emisores independientes.

El sistema debe decidir qué orden necesita o cómo resolver/mezclar estados.

Alternativas posteriores:

- secuenciador/líder;
- consenso sobre un log;
- orden causal;
- timestamps/version vectors;
- reglas CRDT;
- resolución de conflictos de aplicación.

## 9. Piensa en máquinas de estado locales

En lugar de imaginar un gran programa global, modela cada nodo como:

```text
estado local + evento entrante
             ↓
     transición de estado
             +
      mensajes salientes
```

Un worker puede pasar por:

```text
IDLE → RUNNING(job-7) → IDLE
                │
                └→ CRASHED
```

A la vez, un coordinador puede seguir creyendo:

```text
worker-2 = RUNNING(job-7)
```

si el worker murió antes de notificarlo.

Los algoritmos distribuidos organizan la comunicación entre esas máquinas locales para obtener propiedades globales útiles.

## 10. Haz explícita la propiedad del estado

Para cada dato pregunta:

> **¿Dónde vive la autoridad sobre este estado?**

### Un propietario

```text
líder posee el estado de escritura
followers lo replican
```

### Varias réplicas escribibles

```text
Réplica A <── mezcla/coordinación ──> Réplica B
```

### Propiedad particionada

```text
claves A–M → shard 1
claves N–Z → shard 2
```

### Sin propietario durable

Estado transitorio que puede recomputarse.

Si nadie puede decir dónde vive el estado, tampoco podrá explicar recuperación, consistencia o reintentos.

## 11. La transparencia ayuda hasta que oculta una diferencia semántica

Sistemas distribuidos intentan hacer cómodos recursos remotos:

- archivos remotos parecidos a locales;
- RPC parecida a una función;
- réplicas presentadas como un servicio;
- tareas Ray parecidas a funciones Python;
- bases distribuidas detrás de un endpoint.

La transparencia reduce esfuerzo. El peligro aparece cuando de:

```text
sintaxis local ≈ sintaxis remota
```

se infiere incorrectamente:

```text
semántica de fallo local = semántica de fallo remota
```

El Capítulo 2 usa middleware cómodo y después te obliga a identificar qué oculta.

## 12. Tipos de transparencia

Son objetivos de diseño, no propiedades gratuitas:

- **acceso**: operaciones similares pese a ubicación/representación;
- **ubicación**: no necesitas conocer el lugar físico;
- **migración/relocación**: un recurso puede moverse;
- **replicación**: muchas copias parecen un recurso lógico;
- **fallos**: algunos fallos quedan enmascarados;
- **concurrencia**: muchos usuarios comparten recursos correctamente.

Ocultar replicación, por ejemplo, obliga a decidir qué réplica responde, cómo se propagan escrituras y qué consistencia ve el cliente.

## 13. Escalabilidad no significa únicamente «más máquinas»

### Tamaño

¿Qué pasa al crecer nodos, usuarios, objetos o solicitudes?

### Geografía

¿Qué cambia al pasar de micro/milisegundos a decenas o centenas de milisegundos?

### Administración

¿Pueden participar organizaciones independientes sin una configuración o autoridad de confianza universal?

### Carga

¿Aumenta throughput al añadir recursos o existe un cuello de botella serializado?

Un coordinador central no es automáticamente un mal diseño. Pregunta:

> **¿Qué cuello de botella o dominio de fallo crea y es aceptable para los requisitos?**

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosidad</span>
  <strong>Un timeout describe lo que no observaste, no lo que ocurrió remotamente</strong>
  <p>La solicitud pudo perderse, retrasarse, ejecutarse, quedar durable o terminar mientras desaparecía únicamente la respuesta.</p>
  <p><strong>Pruébalo:</strong> Dibuja cuatro ejecuciones que terminen con el mismo timeout del cliente y dejen cuatro estados distintos en el servidor.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">Más curiosidades del capítulo →</a>
</aside>

## 14. Los modelos de sistema hacen explícitos los supuestos

### Síncrono

Se asumen límites superiores conocidos para procesamiento/comunicación relevantes.

### Asíncrono

No se asume límite fijo de retardo ni velocidad relativa.

### Parcialmente síncrono

Puede existir un periodo asíncrono, pero finalmente aparecen límites útiles; o existen límites todavía desconocidos.

Los sistemas reales suelen usar razonamiento parcialmente síncrono: los timeouts pueden equivocarse durante periodos malos y volverse útiles tras estabilizarse la comunicación.

Un protocolo sin sus supuestos temporales está incompleto.

## 15. El modelo de fallos también es parte de la especificación

### Crash-stop

El nodo se detiene y no vuelve.

### Crash-recovery

Puede detenerse y reiniciar preservando quizá estado durable.

### Omisión

Mensajes o acciones pueden perderse.

### Fallo temporal

Una acción ocurre fuera de un límite esperado.

### Bizantino

El participante puede comportarse arbitraria o maliciosamente.

La primera parte del curso asume sobre todo crash/recovery y comunicación imperfecta. El Capítulo 12 amplía el modelo.

No digas «tolerante a fallos» sin decir **a qué fallos**.

## 16. Safety y liveness prometen cosas diferentes

### Safety

Algo malo nunca ocurre.

Ejemplos:

- dos valores incompatibles no ocupan la misma posición committed;
- una transferencia no crea dinero;
- un usuario no autorizado no lee un mensaje privado.

### Liveness

Algo bueno termina ocurriendo bajo los supuestos declarados.

Ejemplos:

- una solicitud aceptada termina;
- se elige un líder tras estabilizarse la comunicación;
- las réplicas convergen.

Un sistema puede preservar safety y perder liveness.

Durante una partición, un servicio fuertemente consistente puede rechazar escrituras para evitar estado committed incompatible. Eso puede ser correcto.

## 17. Disponibilidad es progreso observable ahora

Disponibilidad pregunta si una solicitud obtiene una respuesta útil ahora o dentro de un objetivo de servicio.

Un sistema puede ser:

- seguro pero temporalmente no disponible;
- disponible pero servir datos obsoletos;
- live en sentido teórico pero demasiado lento;
- muy disponible para lecturas y no para escrituras.

No prometas «siempre funciona». Declara qué operación, bajo qué fallo y con qué garantía.

## 18. La red no es un bus perfecto

Desde Redes de Computadoras ya conoces colas, capacidad finita, pérdida, retransmisión y cambios de ruta.

Sistemas Distribuidos pregunta qué significan esos fenómenos para el estado y la corrección.

```text
pérdida de paquete
  ↓
retransmisión / retardo
  ↓
timeout de aplicación
  ↓
reintento
  ↓
posible efecto duplicado
```

o:

```text
partición
  ↓
réplicas no coordinan
  ↓
decisión de consistencia/disponibilidad
```

## 19. Convierte las «falacias» en preguntas experimentales

Supuestos peligrosos frecuentes:

- la red es fiable;
- la latencia es despreciable;
- el ancho de banda es infinito;
- la topología no cambia;
- existe un solo administrador;
- el transporte es seguro;
- comunicar no cuesta;
- el sistema es homogéneo.

Memorizar la lista ayuda menos que intentar falsar cada supuesto.

«Las solicitudes llegan rápido o fallan» → introduce dos segundos de retardo.

«Todos ejecutan el mismo binario» → prueba una actualización gradual con dos versiones compatibles.

El curso convierte supuestos en experimentos.

## 20. Ejemplo trabajado: un contador, tres diseños

### A — Contador local

```text
un proceso
counter = 41
increment() → 42
```

Un mutex resuelve concurrencia local. Si el proceso muere y el estado está solo en memoria, desaparece.

### B — Un servidor remoto

```text
Clientes ───> Servidor contador
```

Compartes un valor lógico, pero introduces dependencia de red, cuello de botella, dominio de fallo, persistencia y ambigüedad tras timeout.

### C — Tres réplicas escribibles

```text
         ┌─ Réplica A
Clientes ─┼─ Réplica B
         └─ Réplica C
```

Puede aumentar disponibilidad, pero surgen escrituras concurrentes y divergencia.

Debes responder:

- ¿se coordinan incrementos?
- ¿pueden divergir las réplicas?
- ¿pueden mezclarse valores?
- ¿qué garantiza una lectura?

Un contador puede modelarse con CRDT bajo ciertas semánticas; una secuencia global estricta puede exigir coordinación más fuerte.

> Distribuir no es «mover el mismo programa a varias máquinas». Cambia el modelo de estado.

## 21. Ejemplo trabajado: el punto de confirmación

Una operación remota atraviesa etapas:

```text
recibida
  ↓
validada
  ↓
estado en memoria
  ↓
estado durable
  ↓
respuesta enviada
  ↓
respuesta recibida
```

El **punto de durabilidad** y el **punto de confirmación al cliente** no tienen por qué coincidir.

Si el efecto ya es durable y se pierde la respuesta, el cliente conserva incertidumbre aunque el servidor tenga un resultado estable.

Diseñar el protocolo exige decidir qué significa realmente `OK`.

## 22. Un sistema distribuido se define también por sus límites

Antes de elegir algoritmos escribe:

- participantes;
- canales;
- estado;
- propietarios del estado;
- modelo temporal;
- modelo de fallos;
- requisitos de durabilidad;
- garantías de lectura/escritura;
- evidencia observable.

Eso evita empezar por «quiero usar Raft» cuando el problema quizá no requiere consenso.

## 23. Evidencia: afirmación, predicción, escenario, observación

El patrón del curso es:

```text
afirmación
   ↓
predicción
   ↓
escenario controlado
   ↓
observaciones desde puntos con autoridad
   ↓
explicación
   ↓
incertidumbre restante
```

Una captura de pantalla de «success» no establece una garantía distribuida. La garantía debe conectarse con una ejecución y un modelo.

## 27. Errores comunes

### «Usa varios threads, por tanto es distribuido»

La concurrencia dentro de un espacio de direcciones no introduce memoria independiente ni fallos de red entre nodos.

### «TCP es fiable, por tanto la operación remota es fiable»

La entrega fiable de bytes mientras existe una conexión no define reintentos, idempotencia, persistencia ni el resultado de un crash.

### «Un timeout significa que el servidor cayó»

Es una observación local después de esperar un intervalo elegido.

### «Replicar significa que el dato está seguro»

Solo si la regla de reconocimiento, placement, recuperación y consistencia protege los fallos que el contrato afirma tolerar.

### «Es eventualmente consistente» como excusa para cualquier valor obsoleto

La consistencia eventual necesita condiciones de convergencia y supuestos de entrega. Divergencia indefinida sin contrato no es un modelo.

### «Usamos consenso, así que todo es consistente»

Consenso puede ordenar decisiones concretas. La aplicación todavía debe conectar esas decisiones con estado, durabilidad, lecturas, reintentos y efectos externos.

### «Lo maneja el middleware»

Puede ser cierto. Entonces debes identificar **qué propiedad maneja, bajo qué configuración y con qué supuestos**.

## 28. Cómo leer cada capítulo posterior

Para cualquier sistema o algoritmo, construye la misma tabla mental:

| Pregunta | Qué debes identificar |
|---|---|
| Participantes | clientes, servidores, réplicas, peers, coordinadores |
| Estado local | variables, logs, archivos, cachés, terms, versiones |
| Mensajes | requests, heartbeats, votos, append, gossip, ACK |
| Safety | qué no debe ocurrir nunca |
| Liveness | qué debe terminar ocurriendo |
| Modelo de fallos | crash, recovery, pérdida, partición, Byzantine |
| Modelo temporal | qué supuestos existen sobre retraso/timeouts |
| Durabilidad | qué sobrevive a reinicio |
| Reintentos | qué operaciones pueden repetirse con seguridad |
| Evidencia | tests, logs, trazas, métricas, estado persistido |

Es también una plantilla útil para revisar la arquitectura del proyecto final.

## Resumen del capítulo

Un sistema distribuido difiere fundamentalmente de un único programa local porque:

1. **los participantes tienen estado y ciclos de fallo independientes;**
2. **la comunicación tiene retraso incierto y puede fallar independientemente del cómputo;**
3. **no existe un reloj perfectamente compartido ni una observación global instantánea;**
4. **varias operaciones pueden ser concurrentes y observarse en órdenes distintos;**
5. **el fallo parcial deja a los supervivientes con conocimiento incompleto;**
6. **los timeouts producen sospechas y decisiones de política, no verdad remota;**
7. **propiedad del estado, durabilidad y frontera de reconocimiento deben ser explícitas;**
8. **la transparencia facilita programación y puede ocultar diferencias semánticas importantes;**
9. **safety, liveness, disponibilidad, escalabilidad, tiempo y fallos son dimensiones distintas;**
10. **toda afirmación de corrección distribuida es corrección bajo un modelo declarado.**

Antes de continuar debes poder tomar un requisito ordinario —incrementar un contador, almacenar un archivo, ejecutar un trabajo o agendar una reunión— y enumerar qué preguntas nuevas aparecen al cruzar un límite de proceso o red.

## Conexiones con otras asignaturas

### [OS]

Procesos, aislamiento, scheduling, persistencia y concurrencia local determinan los límites dentro de cada nodo.

### [NET]

Retardo, pérdida, retransmisión y particiones influyen en qué sabe la aplicación y cuándo actúan sus timeouts.

### [ARCH]

Memoria remota no equivale a memoria local. La jerarquía de memoria y el coste de comunicación ayudan a entender por qué la ubicación del estado importa.

### [SEC]

Autenticidad y autorización añaden otra dimensión: incluso un mensaje correctamente entregado puede provenir de un participante no autorizado.

### [AI]

Un asistente puede proponer una explicación; tu experimento debe demostrar cuál explicación es compatible con la evidencia.

<div class="ds-next-action">
  <span>Lectura esencial completada</span>
  <strong>Siguiente paso obligatorio · Práctica guiada</strong>
  <a href="../guided-practice/">Comenzar práctica guiada →</a>
</div>
