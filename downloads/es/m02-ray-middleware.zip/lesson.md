<p class="ds-book-part">Parte I — Fundamentos y arquitectura</p>
<div class="ds-lesson-banner">
  <div><span>Paso del curso</span><strong>Capítulo 2</strong></div>
  <div><span>Lectura esencial</span><strong>40 min–55 min</strong></div>
  <div><span>Ruta obligatoria</span><strong>Leer → Objetivo de práctica → Comprobar → Laboratorio</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 2 de 12</span>
    <span>17% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 17%"></span></div>
</div>

> **Pregunta guía:** ¿Dónde deben residir las responsabilidades distribuidas y qué decisiones toma el middleware por ti?

## Antes de leer

> Dos sistemas exponen la misma API: uno usa cliente/servidor y el otro es entre pares. ¿Qué responsabilidades deben moverse cuando no existe un servidor permanente?

Escribe primero una respuesta breve. No necesitas acertar todavía: necesitas una predicción que puedas revisar a medida que el capítulo te dé mejores modelos y evidencia.

**Usa lo que ya sabes:** Los límites de fallo del Capítulo 1 y la idea de que los componentes se comunican mediante interfaces explícitas.

## Mapa de carga de trabajo

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>40 min–55 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>45 min–1 h</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>1 h 30 min–2 h · 6 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../../downloads/es/m02-ray-middleware.zip" download>Descargar lección + práctica + laboratorio para estudio sin conexión (.zip)</a></p>

## Por qué importa este capítulo

Antes de elegir un runtime decide **dónde vive cada responsabilidad**. Dos sistemas pueden exponer la misma API y, sin embargo, colocar estado, descubrimiento, scheduling y recuperación en lugares completamente distintos.

Usa durante todo el capítulo estas preguntas:

- ¿quién posee el estado autoritativo?
- ¿quién inicia la comunicación?
- ¿quién descubre a quién?
- ¿quién decide dónde ejecutar trabajo?
- ¿qué puede fallar de forma independiente?
- ¿qué responsabilidad pertenece a la aplicación y cuál al middleware?

Ray será nuestro ejemplo concreto de middleware. No es la definición de una arquitectura distribuida.

## 1. Arquitectura primero: coloca responsabilidades

### Cliente/servidor

```text
cliente → servicio
```

Se centraliza un **rol**, no necesariamente una máquina. Puede haber muchas réplicas detrás de un nombre lógico. Pregunta quién posee la decisión autoritativa para cada operación.

### Por capas o multicapa

```text
cliente → API → capa de workers/servicios → estado
```

Cada límite puede escalar y fallar de forma distinta. Una capa es útil cuando encapsula una responsabilidad coherente; es ruido si solo añade otro salto de red.

### Dirigida por eventos

```text
productor → evento/cola → consumidor(es)
```

El productor puede terminar antes de que un consumidor actúe. Por tanto, «aceptado», «entregado», «procesado» y «confirmado» dejan de significar lo mismo.

### Entre pares

```text
peer A ↔ peer B ↔ peer C
```

Descubrimiento, placement y membresía ya no pueden suponerse responsabilidad de un servidor permanente.

### Los sistemas híbridos son normales

Un plano de datos P2P puede depender de identidad centralizada. Microservicios pueden usar eventos y RPC al mismo tiempo. No etiquetes el sistema con una sola palabra y dejes de razonar.

> **Detente y predice.** Necesitas workers dinámicos, estado durable de trabajos y consultas de estado de baja latencia. ¿Qué responsabilidad centralizarías primero y cuál puede permanecer distribuida sin crear coordinación innecesaria?

Cuando el mapa de responsabilidades está claro, puedes evaluar exactamente qué cajas, canales y políticas implementa el middleware.

<aside class="ds-book-note ds-history">
  <span class="ds-book-note-label">Historia</span>
  <strong>RPC facilitó escribir programas distribuidos al ocultar la red, y también hizo más fácil olvidar la semántica de los fallos</strong>
  <p>Remote Procedure Call convirtió mensajes en llamadas con apariencia familiar, pero timeouts, ejecución duplicada, reintentos y fallos parciales impiden que una llamada remota sea semánticamente igual a una local.</p>
  <a class="ds-book-note-source" href="../../../history/rpc-transparency-and-failure/">Lee la historia del diseño →</a>
</aside>

## 2. Middleware entre intención y mecanismo

La aplicación quiere decir:

```text
ejecuta F en recursos disponibles y entrégame el resultado más tarde
```

Sin middleware tendría que resolver algo como:

```text
descubrir workers
      ↓
elegir endpoint
      ↓
serializar argumentos
      ↓
enviar solicitud
      ↓
seguir identidad del trabajo
      ↓
ejecutar
      ↓
representar/guardar resultado
      ↓
manejar crash o timeout
      ↓
recuperar resultado
```

El middleware ofrece una abstracción más alta.

```text
abstracción de aplicación ≠ mecanismo subyacente
```

Una API no elimina red, serialización, scheduling, procesos o fallos. Solo delega su mecanismo/política.

Mantén una pregunta visible:

> **¿Qué responsabilidad acabo de delegar?**

## 4. Modelo mental de Ray Core

```text
Driver / proceso de aplicación
          │
          ├── envía Tasks
          ├── crea Actors
          └── conserva ObjectRefs
                    │
              runtime de Ray
          ┌─────────┼─────────┐
          ▼         ▼         ▼
       worker     actor     worker
       process    process    process
          │         │         │
          └──── objetos remotos ────┘
```

- **Driver**: programa que inicializa Ray y envía trabajo.
- **Task**: función remota asíncrona.
- **Actor**: worker con identidad y estado asociado a una clase remota.
- **ObjectRef**: referencia a un resultado/objeto que quizá todavía no está localmente disponible.
- **Runtime/cluster**: workers, scheduling, objetos, procesos, metadatos y políticas de fallo.

Son abstracciones de programación. Más adelante sustituirás solo las que tu sistema necesite.

## 5. Una task no es simplemente «llamar esta IP»

```python
@ray.remote
def transform(x):
    return x + 1

ref = transform.remote(41)
```

La aplicación no indicó dirección de worker, conexión TCP, formato de serialización, request ID, endpoint de resultado, cola ni bucle de reintento.

El runtime recibe trabajo y el scheduler elige dónde ejecutarlo según recursos lógicos, estrategia y otros factores.

Compara:

```text
RPC:
el cliente elige un servicio/endpoint y llama una operación

Ray task:
la aplicación envía trabajo; el runtime elige un worker adecuado
```

La diferencia útil es **quién posee la decisión de placement**.

## 6. `.remote()` cambia lugar y tiempo

Llamada ordinaria:

```python
value = transform(41)
```

Llamada remota:

```python
ref = transform.remote(41)
```

La segunda devuelve una referencia y separa envío de finalización.

```text
submit A ─────┐
              ├─ posible ejecución concurrente
submit B ─────┘
       ↓
esperar cuando los valores sean necesarios
```

No existe speedup «por usar Ray». Existe concurrencia cuando el grafo contiene trabajo independiente y hay recursos para ejecutarlo.

## 7. ObjectRef es una future distribuida

```python
ref = work.remote(data)
```

puede leerse como:

```text
ObjectRef
   │
   └── “valor producido por este trabajo remoto”
```

Solo cuando necesitas materializarlo llamas, por ejemplo:

```python
value = ray.get(ref)
```

La referencia puede formar parte de otro trabajo sin que el driver tenga que descargar y reenviar el valor.

### Error común de rendimiento

Expone concurrencia:

```python
refs = [work.remote(x) for x in values]
results = ray.get(refs)
```

Puede serializar:

```python
results = []
for x in values:
    results.append(ray.get(work.remote(x)))
```

> **Predice:** cuatro tasks de un segundo y cuatro workers. ¿Qué diferencia esperas? Después mídela.

## 8. `ray.wait` y finalización parcial

No siempre quieres esperar todos los resultados.

```text
refs = [A, B, C, D]

termina primero: C
después:          A
en curso:         B, D
```

Separar envío y finalización sirve para progreso incremental, trabajo especulativo, limitar solicitudes en vuelo o responder con resultados disponibles.

La idea excede a Ray: futures, colas y job IDs usan la misma separación.

## 9. El movimiento de datos no desaparece

Aunque no llames `send()`, los bytes deben estar donde se ejecuta el trabajo.

Pregunta siempre:

```text
¿mover cálculo hacia los datos?
        o
¿mover datos hacia el cálculo?
```

Esta pregunta reaparece en bases distribuidas, object stores, búsqueda fragmentada, ML y sistemas edge.

No deduzcas número de copias o coste físico desde la sintaxis. Obsérvalo o decláralo como supuesto.

## 10. Actors: estado local con identidad

```python
@ray.remote
class Counter:
    def __init__(self):
        self.value = 0

    def increment(self):
        self.value += 1
        return self.value
```

Un actor hace natural modelar coordinadores, registros, modelos cargados, caches, shards o participantes con estado.

Pero:

```text
abstracción con estado ≠ estado durable y replicado
```

Si el proceso actor desaparece, su memoria no se vuelve durable mágicamente. Si el estado importa tras un crash, tu diseño debe persistirlo o reconstruirlo.

## 11. Serialización del actor no significa orden global

Un actor ordinario puede ejecutar sus métodos con un modelo que simplifica el acceso a su estado local.

No extrapoles:

> «Los actores garantizan un único orden global».

Varios actores, clientes concurrentes y tasks independientes siguen generando problemas distribuidos de orden.

## 12. Identidad del actor y proceso worker no son lo mismo

Distingue:

```text
proceso físico/del runtime
          ≠
identidad lógica del actor
```

La misma distinción aparecerá entre proceso y nodo Raft, contenedor y servicio, máquina y shard.

## 13. Scheduling: una decisión delegada

Al enviar trabajo alguien debe responder:

> **¿Dónde se ejecuta?**

Ray usa recursos lógicos como CPU, GPU o recursos personalizados.

```python
@ray.remote(num_cpus=2)
def expensive_job(x):
    ...
```

Esto restringe elegibilidad de scheduling. No es por sí solo aislamiento del sistema operativo.

```text
declaración de recursos → política de scheduling → placement
```

es diferente de:

```text
aislamiento/enforcement de SO o contenedor
```

## 14. Localidad frente a independencia de fallos

Supón:

```text
Nodo A: 4 CPU
Nodo B: 4 CPU
Nodo C: 1 GPU + 4 CPU
```

Una tarea GPU necesita un lugar compatible. Actores que se comunican mucho pueden beneficiarse de cercanía; réplicas cuyo objetivo es tolerar fallos pueden necesitar separación.

```text
localidad / menor coste de comunicación
               ↕
independencia de fallos / distribución de carga
```

Este compromiso reaparece en almacenamiento replicado.

## 15. La semántica de fallo forma parte del contrato

Ray distingue, entre otras cosas, muerte inesperada de workers, excepciones de aplicación, reinicio de actors y reintentos configurables.

No memorices una frase como «Ray reintenta». Pregunta:

- ¿qué tipo de fallo?
- ¿cuántos reintentos?
- ¿se reinicia un actor?
- ¿qué estado sobrevive?
- ¿puede repetirse un efecto externo?

### Repetición segura y peligrosa

Seguro:

```text
hash(data)
square(7)
thumbnail(immutable_input)
```

Peligroso sin mecanismo adicional:

```text
charge(card)
send_email()
increment_external_counter()
```

La corrección de un reintento depende de la semántica de la aplicación, no solo del runtime.

<aside class="ds-book-note ds-curiosity">
  <span class="ds-book-note-label">Curiosidad</span>
  <strong>Una sola línea de Ray puede esconder scheduling, serialización, movimiento de datos y política de fallos</strong>
  <p>La sintaxis compacta del middleware oculta una ruta distribuida extensa; el curso primero aprovecha esa comodidad y luego te pide identificar cada dependencia.</p>
  <p><strong>Pruébalo:</strong> Para una llamada f.remote(x), escribe la secuencia mínima de pasos ocultos hasta obtener el resultado.</p>
  <a class="ds-book-note-source" href="../../../curiosity/">Más curiosidades del capítulo →</a>
</aside>

## 16. Request identity e idempotencia reaparecerán

Middleware puede reintentar trabajo, pero si el mismo efecto puede ejecutarse dos veces la aplicación necesita una estrategia: operación idempotente, clave estable, deduplicación, transacción u otro mecanismo.

El Capítulo 4 hace explícita esta frontera mediante RPC.

## 17. Éxito del runtime no es corrección de aplicación

Una task puede terminar «OK» y producir un resultado lógicamente incorrecto.

Un actor puede seguir vivo mientras su estado está desactualizado.

Un reintento puede conseguir que una task termine y duplicar un efecto externo.

Por eso debemos separar:

```text
salud/estado del runtime
       ≠
garantía de la aplicación
```

## 18. Observabilidad: mira debajo de la abstracción

Durante el laboratorio recoge PID, job/task IDs, tiempos, estado del actor y logs de aplicación.

La pregunta no es «¿Ray dice SUCCESS?». Es «¿qué ejecución ocurrió y qué evidencia la reconstruye?».

## 19. La observabilidad debe exponer la frontera de abstracción

Ray ofrece información de runtime sobre tasks, actors y su estado de ejecución mediante herramientas de observabilidad, State APIs, logs y dashboard.

Úsala para responder:

- ¿qué proceso ejecutó esta task?
- ¿se solaparon dos tasks en el tiempo?
- ¿qué actor murió?
- ¿se reintentó una task?
- ¿dónde residía un objeto?
- ¿qué recursos se solicitaron?

Después compara lo que sabe el runtime con lo que sabe la **aplicación**.

Por ejemplo:

```text
Runtime: el intento #2 de la task terminó correctamente
Aplicación: la solicitud R aparece dos veces en el log de auditoría externo
```

Ambos hechos pueden ser verdaderos. Un diagnóstico correcto cruza la frontera de abstracción.

## 20. Ejemplo trabajado — tasks secuenciales frente a paralelas

Supón cuatro inputs independientes y una función que tarda aproximadamente un segundo.

### Python secuencial

```python
results = [slow(x) for x in range(4)]
```

Forma aproximada de dependencias:

```text
A → B → C → D
```

### Envío remoto con `get` inmediato

```python
results = [ray.get(slow.remote(x)) for x in range(4)]
```

Sigue siendo aproximadamente:

```text
A → espera → B → espera → C → espera → D
```

### Enviar todo y recoger después

```python
refs = [slow.remote(x) for x in range(4)]
results = ray.get(refs)
```

Forma de dependencias:

```text
A ─┐
B ─┼─ workers disponibles
C ─┼─ pueden ejecutar concurrentemente
D ─┘
```

El laboratorio mide tiempo transcurrido y registra PIDs reales de workers para que puedas observar tanto concurrencia como scheduling.

## 21. Ejemplo trabajado — ¿task o actor?

Supón que la aplicación cuenta trabajos procesados.

### Enfoque con task

```python
@ray.remote
def process(job):
    return result
```

Cada task puede ser conceptualmente independiente.

Si el contador importa, otro servicio debe ser su propietario.

### Enfoque con actor

```python
@ray.remote
class Worker:
    def __init__(self):
        self.completed = 0

    def process(self, job):
        ...
        self.completed += 1
```

Ahora el contador es estado local del actor.

Aparecen inmediatamente preguntas:

- ¿qué ocurre si muere el actor?
- ¿debe sobrevivir el contador?
- ¿un actor se convierte en cuello de botella?
- ¿pueden varios actors tener contadores independientes?
- ¿quién los agrega?

La abstracción correcta depende de la semántica requerida para el estado.

## 22. Ejemplo trabajado — dependencias ocultas en una aplicación Ray pequeña

Considera:

```python
@ray.remote
def resize(image):
    return transformed

refs = [resize.remote(img) for img in images]
outputs = ray.get(refs)
```

La lógica visible es pequeña.

Un mapa de dependencias de middleware revela más:

| Requisito de aplicación | Responsabilidad de Ray en Fase 1 |
|---|---|
| encontrar capacidad de ejecución | scheduler / workers |
| despachar trabajo | runtime de tasks remotas |
| serializar input | serialización del runtime |
| hacer accesible el input | movimiento de objetos/datos |
| representar resultado pendiente | `ObjectRef` |
| ejecutar concurrentemente | scheduling de workers |
| exponer crash de worker | manejo de fallos de task |
| recoger resultado | recuperación de objeto |
| observar estado de task | logs/state/dashboard |

Esta tabla es uno de los artefactos más importantes de toda la metodología del proyecto final.

## 23. El mapa de dependencias de middleware no es una lista de APIs de Ray

Un mapa débil dice:

```text
usa ray.remote
usa ray.get
usa actors
```

Un mapa útil empieza por **requisitos**:

| Requisito | Mecanismo Ray | Supuesto | Pregunta para diseño nativo |
|---|---|---|---|
| distribuir trabajos independientes | tasks | trabajos serializables | ¿cómo se envían a workers? |
| conservar estado local del worker | actor | el proceso del actor sigue siendo útil | ¿debe ser durable el estado? |
| elegir un worker | scheduler | los recursos declarados representan necesidad | ¿qué política de scheduling hace falta? |
| sobrevivir crash de worker | retry de task | repetir ejecución es seguro | ¿cómo se manejarán duplicados? |
| referirse a un resultado remoto | ObjectRef | runtime sigue la dependencia | ¿dónde vivirán los resultados nativos? |

La cuarta columna se convierte en la agenda de diseño de la Fase 2.

## 24. La Fase 1 del proyecto final debe optimizar aprendizaje, no sofisticación arquitectónica

El propósito del prototipo Ray es comprender rápidamente el dominio.

Una buena Fase 1:

- implementa el camino funcional principal;
- se ejecuta sobre varios workers o actors Ray;
- demuestra al menos un comportamiento de fallo o concurrencia;
- congela un contrato externo de comportamiento;
- documenta dependencias de middleware;
- identifica preguntas para el diseño nativo.

Una mala Fase 1 dedica casi todo el esfuerzo a infraestructura avanzada específica de Ray que será eliminada inmediatamente.

Mantén deliberadamente pequeño el prototipo Ray.

## 25. La frontera de retirada de Ray es un ejercicio de diseño

Después de Fase 1 **no** traduces cada feature de Ray línea por línea.

En su lugar:

```text
prototipo Ray
     ↓
contrato de comportamiento
     ↓
requisitos + mapa de dependencias
     ↓
alternativas arquitectónicas
     ↓
mínimos mecanismos nativos justificados
```

Ejemplos:

| Fase 1 | Posibilidad nativa en Fase 2 |
|---|---|
| task Ray | operación explícita de worker por gRPC |
| actor | servicio Go de larga duración |
| ObjectRef | job ID + almacén de resultados |
| scheduler Ray | cola central / work stealing / asignación estática |
| membership del runtime | registro / gossip / bootstrap por configuración |
| retries de tasks | timeout, retry y deduplicación explícitos |
| estado del actor | base de datos persistente / log replicado / estado local |

Proyectos diferentes deben producir respuestas diferentes.

Si todos los grupos recrean el mismo scheduler y registro genéricos, la metodología dejó de usar el dominio de la aplicación como restricción de diseño.

## 26. Lo que Ray **no** debe enseñarte

### «Distribuir es añadir un decorator»

El decorator elige una abstracción. El runtime sigue implementando muchos mecanismos distribuidos.

### «ObjectRef es almacenamiento durable»

Una referencia a un objeto remoto no proporciona automáticamente la garantía de durabilidad de la aplicación.

### «Actor significa servicio replicado»

Un actor es un worker remoto con estado, no una máquina de estados replicada por defecto.

### «Retries significa exactly-once»

Repetir la ejecución puede repetir efectos secundarios.

### «Solicitar recursos equivale a seguridad/aislamiento»

Los recursos de scheduling y la imposición de aislamiento por el sistema operativo son problemas distintos.

### «Si Ray lo maneja, no necesito entenderlo»

El resto del curso existe precisamente para entender y construir explícitamente los mecanismos ocultos aquí.

## 29. Los agentes de programación con IA hacen todavía más importante la lección sobre abstracciones

Un agente puede generar una solución Ray con enorme rapidez.

Eso está permitido en este curso.

La pregunta educativa cambia de:

> «¿Recordaste la sintaxis de `@ray.remote`?»

a:

> «¿Puedes identificar de qué depende el sistema generado, probar su comportamiento ante fallos y rediseñarlo sin Ray?»

Puedes usar IA para:

- generar el primer prototipo;
- inspeccionar APIs de Ray;
- proponer experimentos;
- analizar logs;
- criticar el mapa de dependencias.

Pero la Fase 1 no termina hasta que puedas explicar cada capacidad del runtime relevante para el proyecto.

### Profundización — qué debe quedar visible detrás de la comodidad de Ray

La forma más útil de estudiar middleware no es memorizar APIs, sino reconstruir el **camino real** de una operación.

Cuando escribes:

```python
ref = work.remote(input)
```

la línea visible no te dice, por sí sola:

- qué proceso recibió finalmente el trabajo;
- qué metadata necesitó el scheduler para decidir placement;
- si el input se serializó una vez o varias;
- si los bytes viajaron desde el driver, desde otro worker o desde un object store del runtime;
- cuántos intentos de ejecución ocurrieron;
- qué estado del runtime sobreviviría a la muerte de un worker;
- cómo se representaría el resultado si el proceso productor desapareciera.

Ese inventario importa porque la Fase 2 tendrá que decidir cuáles de esas propiedades son realmente necesarias. Un servicio nativo pequeño quizá no necesite scheduler general: puede bastar una cola central o incluso una asignación estática. Otro proyecto puede necesitar afinidad por datos, prioridad o recursos heterogéneos. El criterio no es «recrear Ray», sino conservar las garantías relevantes con la arquitectura más pequeña que puedas justificar.

### Placement no es solo un detalle de rendimiento

Imagina dos decisiones válidas para el mismo actor con estado:

```text
A. colocar cerca de sus datos
B. colocar lejos de otra réplica para reducir fallo correlacionado
```

A reduce coste de movimiento. B mejora independencia de fallos.

El middleware puede elegir usando información y políticas que la aplicación no ve directamente. Por eso un benchmark sin registrar dónde ejecutó realmente cada tarea puede confundir una mejora de placement accidental con una propiedad general del diseño.

En la versión nativa debes poder contestar:

- ¿qué información usa la política?
- ¿qué ocurre cuando el nodo preferido no está?
- ¿la decisión es estable o puede cambiar entre intentos?
- ¿qué parte de la corrección depende de esa ubicación?

### ObjectRef representa una dependencia, no una garantía de almacenamiento

Una referencia remota resulta cómoda porque desacopla producción y consumo:

```text
producer task ──> ObjectRef ──> consumer task
```

Pero el significado de aplicación depende de lo que ocurra con el valor subyacente. Un runtime puede conservar una copia, transferirla, reconstruirla a partir del linaje de cómputo o declarar el objeto perdido cuando ya no puede producirse otra vez.

Esto obliga a separar tres conceptos:

```text
resultado disponible
resultado reconstruible
resultado durable según el contrato de la aplicación
```

No son equivalentes. Un modelo entrenado que el usuario considera «guardado» necesita una frontera de durabilidad distinta a una salida temporal que puede recalcularse.

### El linaje solo ayuda cuando repetir el cómputo conserva la semántica

La recomputación es poderosa para funciones puras:

```text
output = transform(input_inmutable)
```

pero puede ser incorrecta si ejecutar otra vez produce efectos externos:

```text
reserve_ticket()
send_notification()
charge_account()
```

Incluso cuando Ray puede volver a lanzar una task, la aplicación debe decidir si repetir esa task representa el mismo efecto lógico o uno nuevo.

Esta observación conecta directamente con el Capítulo 4:

```text
retry de runtime
      ↓
nuevo intento de ejecución
      ↓
¿misma operación lógica?
      ↓
request_id + idempotencia/deduplicación
```

### Actors simplifican ownership local, pero crean preguntas de ciclo de vida

Un actor permite decir con claridad:

> este estado pertenece a esta identidad lógica de worker.

Eso es valioso. Pero todavía debes distinguir:

```text
identidad del actor
proceso que lo ejecuta ahora
estado en memoria
estado durable
réplicas de ese estado
```

Si un actor reinicia, la clase puede reconstruirse con memoria vacía. Si el sistema necesita continuidad lógica, debe existir una historia de recuperación: cargar snapshot, reabrir almacenamiento, reconstruir desde eventos o consultar otra autoridad.

También debes preguntar si serializar métodos del actor oculta una política de concurrencia que después deberás recrear explícitamente. Un actor que procesa una llamada a la vez puede hacer correcto un contador simplemente porque convierte todo acceso en secuencial. Al retirar Ray, varios handlers concurrentes de un servidor Go podrían reintroducir la carrera si no preservas el mismo invariante.

### La política de fallos debe observarse, no imaginarse

Para una task concreta, registra:

```text
logical_job_id
runtime_task_id
attempt
worker_pid
start
end / failure
effect_id si existe
```

Con esa evidencia puedes distinguir:

- una task que nunca empezó;
- una que falló a mitad;
- una que terminó y fue reintentada;
- dos intentos que produjeron un único efecto lógico;
- dos intentos que produjeron efectos duplicados.

Sin esta correlación, «Ray recuperó el trabajo» puede esconder comportamientos de aplicación muy distintos.

### Arquitecturas híbridas y middleware especializado

No todos los mecanismos tienen que vivir en el mismo lugar.

Un proyecto puede terminar con:

```text
registro central para discovery
+
workers stateless
+
almacenamiento replicado
+
RPC directo
```

Otro puede usar:

```text
bootstrap estático
+
membresía por gossip
+
cola durable
+
workers con estado local reconstruible
```

Ambos son distribuidos. El valor del capítulo es que puedas asignar cada responsabilidad a una capa deliberadamente y explicar qué ocurre cuando esa capa falla.

### Criterio final antes de retirar Ray

Para cada abstracción usada en Fase 1 completa mentalmente esta frase:

> «Ray me permite expresar ___; debajo necesita ___; mi aplicación realmente exige ___; en la versión nativa lo resolveré mediante ___ porque ___».

Si alguna parte queda vacía, todavía no entiendes suficientemente la dependencia como para retirarla con seguridad.

## 30. Errores comunes

### Llamar `ray.get()` inmediatamente después de cada envío

Puede serializar accidentalmente trabajo independiente y destruir el paralelismo esperado.

### Usar actors para todo estado porque son cómodos

Pregunta si el estado debe sobrevivir al fallo del actor o compartirse entre actors. Si es así, memoria local del actor puede no satisfacer el requisito.

### Suponer que retry de task siempre es seguro

Efectos externos y operaciones no idempotentes pueden duplicarse.

### Tratar placement del scheduler como determinista

Salvo que se restrinja placement, el runtime puede elegir entre recursos elegibles. Las pruebas no deben depender sin necesidad de un worker concreto.

### Confundir solicitudes lógicas de recursos con aislamiento fuerte

Una declaración de scheduling no equivale a una cuota impuesta por el sistema operativo.

### Medir solamente «la versión Ray es más rápida»

Ray introduce overhead además de paralelismo. Usa una carga suficientemente grande para revelar comportamiento significativo de scheduling/concurrencia e identifica el límite de medición.

### Construir todo el proyecto final alrededor de internos de Ray

Fase 1 debe exponer el problema de aplicación. El curso no te pide convertirte en mantenedor de Ray.

### Volver a introducir Ray después de la frontera de retirada

Cuando comienza Fase 2, scheduling, comunicación, descubrimiento, persistencia, retries y los demás mecanismos necesarios deben aparecer explícitamente en el diseño nativo.

## 31. Checklist antes de retirar Ray

### Ejecución

- ¿qué es una task?
- ¿qué es un actor?
- ¿qué operaciones son concurrentes?
- ¿qué operaciones quedan serializadas?

### Datos

- ¿qué valores se convierten en objetos remotos?
- ¿qué valores se mueven entre workers?
- ¿qué estado es local del actor?
- ¿qué datos son realmente durables?

### Scheduling

- ¿qué restricciones de recursos declaras?
- ¿placement importa a corrección o solo rendimiento?
- ¿qué ocurre si un nodo no tiene capacidad?

### Fallos

- ¿qué fallos de task provocan retry?
- ¿qué fallos de actor provocan restart?
- ¿es seguro repetir las operaciones?
- ¿qué estado de aplicación sobrevive?

### Observabilidad

- ¿cómo demuestras qué worker ejecutó una task?
- ¿cómo observas un retry?
- ¿qué solicitud de aplicación corresponde a qué task del runtime?

### Rediseño nativo

- ¿qué capacidad de Ray necesita realmente este proyecto?
- ¿qué capacidad puede omitirse?
- ¿qué garantía debe ser más fuerte que en el prototipo Ray?

## Resumen del capítulo

Ray nos permite experimentar primero con un modelo compacto de programación distribuida antes de implementar directamente sus mecanismos.

Las lecciones centrales son:

1. **El middleware delega responsabilidades distribuidas; no las elimina.**
2. **Las tasks Ray expresan trabajo remoto asíncrono cuyo placement selecciona el runtime.**
3. **`ObjectRef` separa envío/dependencia de disponibilidad local de un valor.**
4. **Los actors proporcionan workers remotos con estado, no estado automáticamente durable o replicado.**
5. **Placement y movimiento de datos siguen importando aunque el código no envíe bytes explícitamente.**
6. **Los recursos lógicos influyen en scheduling y son distintos del aislamiento fuerte de recursos.**
7. **La semántica de fallo y retry forma parte del contrato del middleware.**
8. **Retry automático puede duplicar efectos secundarios de aplicación.**
9. **Éxito del runtime y corrección de aplicación son afirmaciones distintas.**
10. **El mapa de dependencias convierte comodidad en Fase 1 en preguntas de diseño para Fase 2.**
11. **Ray se elimina deliberadamente tras el prototipo para que seas responsable de los mecanismos requeridos.**

La progresión deseada es:

```text
«Puedo distribuir esto con Ray».
              ↓
«Puedo explicar qué proporcionó Ray».
              ↓
«Sé cuáles de esos mecanismos necesita realmente mi problema».
              ↓
«Puedo construir y defender esos mecanismos sin Ray».
```

## Conexiones de sistemas

### [OS]

Workers y actors son procesos reales con memoria, scheduling y fallos locales.

### [NET]

Serialización, objetos remotos y resultados implican comunicación aunque la API no exponga sockets.

### [ARCH]

Placement y movimiento de datos interactúan con CPU, memoria y localidad.

### [SEC]

El runtime no elimina la necesidad de declarar identidades, permisos y límites de confianza de la aplicación.

### [AI]

Un agente puede generar rápidamente código Ray, pero debes verificar ownership, reintentos, estado y fallos con evidencia.

<div class="ds-next-action">
  <span>Lectura esencial completada</span>
  <strong>Siguiente paso obligatorio · Práctica guiada</strong>
  <a href="../guided-practice/">Comenzar práctica guiada →</a>
</div>
