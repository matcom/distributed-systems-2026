<p class="ds-book-part">Parte I — Fundamentos y arquitectura</p>
<p class="ds-module-kicker">Capítulo 2</p>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 2 de 12</span>
    <span>17% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 17%"></span></div>
</div>
<p class="ds-guiding-question">¿Dónde deben residir las responsabilidades distribuidas y qué decisiones toma el middleware por ti?</p>

Compara estructuras cliente/servidor, por capas, orientadas a servicios, dirigidas por eventos, entre pares e híbridas **antes** de depender de un framework. Después usa Ray como ejemplo concreto de middleware: construye algo útil rápidamente y mapea cada capacidad que el runtime aporta en tu nombre.

## Ideas clave

- responsabilidad arquitectónica y ubicación;
- cliente/servidor y sistemas multicapa;
- estructura orientada a servicios y a eventos;
- diseños entre pares e híbridos;
- middleware como límite de abstracción;
- tareas, actores, ObjectRef, planificación y reintentos en Ray;
- mapas de dependencias del middleware.

## Transición al laboratorio

Convierte un pequeño programa secuencial de workers en tareas/actores de Ray. Termina workers, observa qué ocurre y registra qué responsabilidades arquitectónicas pertenecen a tu aplicación y cuáles al runtime.

## Empieza aquí

> **Antes de leer:** Dos sistemas exponen la misma API: uno usa cliente/servidor y el otro es entre pares. ¿Qué responsabilidades deben moverse cuando no existe un servidor permanente?

**Trae contigo:** Los límites de fallo del Capítulo 1 y la idea de que los componentes se comunican mediante interfaces explícitas.

**Este capítulo te prepara para:** La capacidad de ver la arquitectura y el middleware como asignaciones explícitas de responsabilidad, no como magia del framework.

<div class="ds-workload ds-workload-three" aria-label="Carga de trabajo esencial">
  <div><span>Núcleo · leer</span><strong>Lección integrada</strong><small>40 min–55 min</small></div>
  <div><span>Núcleo · practicar</span><strong>Objetivo de práctica + comprobación</strong><small>45 min–1 h</small></div>
  <div><span>Núcleo · laboratorio</span><strong>Laboratorio de evidencia</strong><small>1 h 30 min–2 h · 6 pruebas públicas + evidencia</small></div>
</div>
<p class="ds-workload-note"><strong>Banco de práctica / reto:</strong> Las páginas de práctica guiada y comprobación identifican los casos esenciales exactos. Los casos restantes, las extensiones opcionales y las referencias avanzadas no forman parte de la carga esencial salvo que el profesor los asigne.</p>
<div class="ds-actions-simple">
  <a class="ds-primary-action" href="lesson/">Leer lección →</a>
  <a class="ds-secondary-action" href="lab/">Abrir laboratorio</a>
</div>
<p class="ds-offline-link"><span>SIN CONEXIÓN</span><a href="../../../downloads/es/m02-ray-middleware.zip" download>Descargar capítulo + laboratorio para estudio sin conexión (.zip)</a></p>

## Qué aprenderás

- Compara la asignación de responsabilidades en arquitecturas cliente/servidor, por capas, orientadas a servicios, dirigidas por eventos, entre pares e híbridas.
- Usa tareas y actores de Ray para distribuir una carga pequeña sin tratar el runtime como magia.
- Distingue las responsabilidades de la aplicación de las responsabilidades de planificación, comunicación, objetos y fallos que asume el middleware.
- Observa el comportamiento de planificación y fallos en vez de asumirlo.
- Construye un mapa de arquitectura y dependencias del middleware que guíe un rediseño nativo posterior.

## Aprende trabajando la pregunta

1. Escribe tu respuesta a **Empieza aquí** antes de abrir la lección completa.
2. Lee hasta la siguiente predicción o traza; detente y resuélvela antes de revelar la explicación.
3. Trata la práctica guiada como un **banco de práctica**, no como una hoja para completar deprisa. Trabaja las trazas centrales hasta alcanzar el objetivo de práctica y vuelve después a los casos restantes.
4. Usa la comprobación para detectar vacíos y entra al laboratorio con una predicción falsable y con la evidencia que podría contradecirla.
5. Termina explicando qué estableció el experimento, qué no estableció y cómo cambia tu explicación del servicio acumulativo.

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../m01-distributed-systems/">← Pensar en sistemas distribuidos</a>
<a class="ds-sequence-link next" href="../m05-processes-concurrency/">Procesos, virtualización y ejecución distribuida →</a>
</nav>
