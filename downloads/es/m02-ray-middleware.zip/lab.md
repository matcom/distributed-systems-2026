<div class="ds-lesson-banner">
  <div><span>Laboratorio obligatorio</span><strong>Capítulo 2</strong></div>
  <div><span>Modelo de evidencia</span><strong>predecir → ejecutar → observar → explicar</strong></div>
  <div><span>Verificación</span><strong>6 pruebas públicas transparentes + evidencia</strong></div>
</div>
<div class="ds-progress" aria-label="Progreso del curso">
  <div class="ds-progress-meta">
    <span>Capítulo 2 de 12</span>
    <span>17% de la secuencia del curso</span>
  </div>
  <div class="ds-progress-track"><span style="width: 17%"></span></div>
</div>
<p class="ds-back-link"><a href="../quick-check/">← Volver a la comprobación</a></p>

> **Antes de comenzar:** Completa los pasos de práctica guiada y comprobación de conocimientos. Ya deberías poder formular una predicción y nombrar la evidencia que la apoyaría o contradeciría. Si no, [vuelve a la comprobación](../quick-check/) y revisa la lección donde haga falta.

## Propósito

Este laboratorio te da un modelo productivo de programación distribuida **antes** de que implementes tú mismo los mecanismos.

Tomarás una carga secuencial pequeña y la expresarás mediante tasks y actores de Ray. Después observarás dónde se ejecutó el trabajo, compararás ejecución secuencial y concurrente, provocarás fallos de workers/actores, estudiarás reintentos y construirás un mapa de dependencias del middleware.

El objetivo no es convertirte en experto de Ray. El objetivo es poder decir:

> **«Este requisito parece sencillo porque Ray está asumiendo estas responsabilidades distribuidas.»**

## Versión del curso

Usa la versión de Ray Core fijada por el módulo. No uses Ray Train, Ray Serve, RLlib u otras capas de alto nivel para el ejercicio obligatorio: queremos ver las abstracciones Core.

## Preparación

```bash
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install --upgrade pip
python3 -m pip install 'ray==2.58.0'
python3 -c 'import ray; print(ray.__version__)'
```

Si el repositorio cambia la versión fijada, usa la que declare la actividad.

## Parte A — Línea base secuencial

Crea varios trabajos independientes. Cada trabajo debe:

- recibir un entero/ID;
- dormir un intervalo configurable;
- devolver un resultado determinista;
- informar el PID que lo ejecutó.

Cuatro trabajos de un segundo ejecutados secuencialmente deberían tardar alrededor de cuatro segundos más overhead.

Registra número de trabajos, duración, tiempo total, PID y orden de finalización. No evalúes por tiempos exactos: importa el grafo de dependencias.

## Parte B — Tasks de Ray

Convierte la función en task remota y envía todos los trabajos antes de recoger resultados.

```text
Driver
  ├── submit J1 ──> worker
  ├── submit J2 ──> worker
  ├── submit J3 ──> worker
  └── submit J4 ──> worker
```

Recoge resultado, PID, tiempo e identidad del trabajo.

Responde:

1. ¿quién eligió el worker?
2. ¿quién serializó y transportó argumentos/resultados?
3. ¿qué devolvió `.remote()` inmediatamente?
4. ¿cuándo necesitó realmente el driver el valor?

## Parte C — Serialización accidental

Compara:

```python
refs = [work.remote(x) for x in jobs]
results = ray.get(refs)
```

con:

```python
results = []
for x in jobs:
    results.append(ray.get(work.remote(x)))
```

Predice primero. Explica por qué usar primitivas distribuidas no garantiza concurrencia útil.

## Parte D — Finalización incremental

Usa `ray.wait` para consumir resultados a medida que terminan. Haz que los trabajos duren tiempos diferentes.

Registra:

```text
orden de envío
orden de finalización
PID del worker para cada trabajo
```

Explica por qué una future/`ObjectRef` es útil antes de materializar su valor.

## Parte E — Actor con estado

Crea un actor que cuente trabajos procesados:

```text
process(job)
count()
```

Llama varias veces e inspecciona su PID.

Responde:

- ¿dónde vive el contador?
- ¿existe automáticamente en otro nodo?
- ¿es durable si desaparece el proceso?
- ¿por qué es cómoda la abstracción?
- ¿qué mecanismo posterior necesitarías si el estado debe sobrevivir un crash?

## Parte F — Scheduling con recursos

Declara un requisito lógico de recursos para una task o actor.

Compara:

```text
recurso lógico de scheduling de Ray
```

con:

```text
aislamiento de CPU/memoria impuesto por el sistema operativo
```

No presentes una declaración lógica como límite de seguridad.

## Parte G — Fallo de worker y reintento

Usa una task cuyo primer intento pueda terminar el worker de forma controlada, o el helper del profesor. Configura explícitamente pocos reintentos.

Predice:

```text
intento 1 → worker muere
intento 2 → ?
```

Recoge evidencia del runtime y de la aplicación.

Distingue una operación segura de repetir —por ejemplo, un cálculo determinista— de un efecto externo peligroso, como duplicar un pago o incrementar un contador sin deduplicación.

No realices un efecto peligroso real; modélalo localmente.

## Parte H — Fallo de actor

Termina un actor y observa llamadas posteriores bajo la política de reinicio/reintento elegida.

No escribas simplemente «Ray maneja fallos». Indica **qué fallo, qué política, qué estado sobrevivió y qué observó la aplicación**.

## Parte I — Movimiento de datos

Crea un objeto Python moderado que usen varias tasks.

Compara:

```text
Driver envía valores independientes a tasks
```

con:

```text
Driver crea/referencia objeto remoto compartido
Tasks dependen del ObjectRef
```

Razona sobre propiedad y dependencias antes de interpretar pequeñas diferencias de tiempo en localhost.

## Parte J — Mapa de dependencias del middleware

Entrega obligatoria:

| Requisito | Qué aporta Ray | Supuesto/configuración | Pregunta nativa |
|---|---|---|---|
| ejecución remota | | | |
| selección de worker | | | |
| resultado pendiente | | | |
| worker con estado | | | |
| movimiento de datos | | | |
| scheduling de recursos | | | |
| reporte/reintento de fallos | | | |
| observabilidad | | | |

No escribas solo nombres de API. `ray.get` no es un requisito; «obtener un resultado producido por otro worker» sí lo es.

## Parte K — Mini diseño al eliminar Ray

Elige un programa pequeño del laboratorio y responde:

> Si Ray desapareciera mañana, ¿cuál es la arquitectura nativa **mínima** que conserva el comportamiento necesario?

Podrías necesitar direcciones de workers, scheduler central, HTTP/gRPC, job ID, almacén de resultados, heartbeats, reintentos o archivos durables. No implementes todavía el reemplazo.

## Pruebas transparentes

El starter mantiene una superficie pequeña:

- función pura;
- constructor de task con reintento explícito;
- actor contador;
- helper con `ray.wait`;
- validador del mapa de dependencias.

La suite pública tiene dos capas:

1. casos estructurales que no necesitan Ray;
2. integración con Ray cuando Ray está instalado.

Los casos de integración comprueban resultados remotos, identidad de worker, estado de actor y orden de finalización sin asumir ubicación determinista.

Si Ray no está instalado, esos casos aparecen como **skipped**, no como éxitos falsos. En el entorno soportado del capítulo se ejecutan en modo local, sin clúster en la nube.

Añade casos propios bajo `tests/student/`.

No existen casos ocultos.

### Cómo interpretar las pruebas públicas

Una prueba estructural satisfactoria demuestra únicamente la propiedad determinista que comprueba. Por ejemplo, validar que un helper conserva un identificador o que un mapa de dependencias contiene un requisito no demuestra que el runtime haya ejecutado trabajo sobre varios procesos.

Las pruebas de integración con Ray aportan evidencia diferente:

- PIDs distintos muestran ejecución multiproceso en la ejecución observada;
- tiempos solapados muestran concurrencia observada;
- reintentos observados muestran la política configurada para ese escenario;
- estado de actor demuestra ownership local en esa instancia.

Para una afirmación de fallo o recuperación conserva también logs de la aplicación. El estado del runtime y el efecto externo pueden contar historias distintas.

### Evidencia mínima del experimento de fallo

Para la task que reintentas registra, cuando sea posible:

```text
job_id lógico
task/attempt ID
worker PID
inicio
fallo
nuevo intento
resultado
efecto externo relevante
```

Si el ejemplo tiene un efecto no idempotente, explica por qué un segundo intento sería peligroso aunque el runtime considere satisfactoria la ejecución final.

## Informe obligatorio

Incluye:

1. entorno y versión de Ray;
2. evidencia secuencial frente a tasks;
3. resultado de serialización accidental;
4. finalización incremental;
5. análisis de estado de actor;
6. una observación de scheduling/recursos;
7. fallo/reintento de task;
8. fallo de actor;
9. mapa completo de dependencias;
10. mini diseño sin Ray;
11. declaración del uso de IA.

## Énfasis de evaluación

La mejor entrega no usa más features. Explica:

```text
requisito de aplicación
       ↓
abstracción Ray
       ↓
responsabilidad distribuida oculta
       ↓
comportamiento observado ante fallo
       ↓
pregunta del diseño nativo
```

## Límite de Ray

Ray permanece disponible para la **Fase 1 del proyecto final**. Después se elimina del runtime. No construyas el proyecto alrededor de features de Ray que tendrías que clonar si no iluminan un mecanismo del curso.

## Uso de IA

Se permiten asistentes y agentes. Si un agente genera la implementación, todavía debes identificar tasks, actores, ObjectRef, propiedad del estado, supuestos de scheduling y semántica de fallo.

## Termina el capítulo

Reproduce el resultado importante desde un inicio limpio. Después vuelve a tu predicción inicial: explica qué cambió, qué evidencia provocó el cambio y qué incertidumbre queda. Un comando exitoso o una captura no bastan cuando la afirmación trata de retries, orden, durabilidad, consistencia, recovery, seguridad o rendimiento.

<div class="ds-next-action">
  <span>Capítulo completo</span>
  <strong>Continuar el curso</strong>
  <a href="../../m05-processes-concurrency/">Procesos, virtualización y ejecución distribuida →</a>
</div>

<nav class="ds-sequence" aria-label="Secuencia del curso">
<a class="ds-sequence-link" href="../../m01-distributed-systems/">← Pensar en sistemas distribuidos</a>
<a class="ds-sequence-link next" href="../../m05-processes-concurrency/">Procesos, virtualización y ejecución distribuida →</a>
</nav>
