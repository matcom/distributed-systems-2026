> **Vista de referencia.** Esta página ofrece contexto opcional; vuelve a la [Lección](../lesson/) para la ruta obligatoria.

## Esencial

- **● Ray Core Walkthrough** — Ray Project. [documentation](https://docs.ray.io/en/latest/ray-core/walkthrough.html)

## Recomendado

- **●●● Ray: A Distributed Framework for Emerging AI Applications** — Philipp Moritz et al.. [paper](https://www.usenix.org/conference/osdi18/presentation/moritz)

## Avanzado

Todavía no hay un recurso adicional asignado.

## Herramientas y práctica

- **●● Ray Core Documentation** — Ray Project. [documentation](https://docs.ray.io/en/latest/ray-core/)

## Explora

- **●●● Ray Architecture Whitepapers** — Ray Project. [architecture notes](https://docs.ray.io/en/latest/ray-contribute/whitepaper.html)
